export type UserStatus = 'online' | 'ocupado' | 'em_almoco' | 'ausente' | 'invisivel';

export interface RelationshipLevel {
  id: string;
  name: string;
  description: string;
  icon: string; // Emoji (e.g. ❤️, ☕, ⭐, 💼, 💍, 🏡)
  color: string; // Hex color
  isDefault?: boolean;
  createdAt: string;
}

export interface ContactGroup {
  id: string;
  name: string;
  icon?: string;
  color?: string;
}

export interface UserContact {
  id: string;
  userId: string;
  name: string;
  lastName: string;
  email: string;
  status: UserStatus;
  relationshipLevelId: string;
  relationshipLevelName: string;
  relationshipLevelIcon: string;
  relationshipLevelColor: string;
  groupId: string;
  groupName: string;
  addedAt: string;
  notes?: string;
}

export interface FriendshipRequest {
  id: string;
  senderId: string;
  senderName: string;
  senderLastName?: string;
  senderAvatar?: string;
  senderStatus: UserStatus;
  receiverId: string;
  receiverName: string;
  receiverLastName?: string;
  receiverAvatar?: string;
  receiverStatus: UserStatus;
  relationshipLevelId: string;
  relationshipLevelName: string;
  relationshipLevelIcon: string;
  relationshipLevelColor: string;
  senderGroupId: string;
  senderGroupName: string;
  receiverGroupId?: string;
  receiverGroupName?: string;
  message?: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
  respondedAt?: string;
}

export interface User {
  id: string;
  name: string;
  lastName: string;
  birthDate: string;
  cpf: string;
  googleEmail: string;
  twoFactorSecret: string;
  twoFactorEnabled: boolean;
  disposableCodes: DisposableCode[];
  isBlocked: boolean;
  blockReason?: string;
  createdAt: string;
  avatarUrl?: string;
  bio?: string;
  interests?: string[];
  status?: UserStatus;
  contactGroups?: ContactGroup[];
  contacts?: UserContact[];
  nickname?: string;
  nicknameType?: 'temporary' | 'permanent';
  balance?: number; // Saldo em R$ (ex: 5.00)
  pasqcoins?: number; // Saldo da moeda virtual pasqcoin que vale tempo e desbloqueio de chat
  firstInteractionAt?: string; // Data da primeira entrada em sala ou contato direto que dispara os 30 dias
  rechargeExpiresAt?: string; // Data de expiração dos créditos (30 dias após primeira interação)
  isFreeAccess?: boolean; // Acesso FREE sem custos em qualquer sala/chat (isento de cobrança)
  passwordHash?: string; // Senha de acesso criptografada
  coverUrl?: string; // Foto de capa do perfil
  profilePrivacy?: 'public' | 'restricted' | 'friends_only' | 'private'; // Perfil público ou restrito
  privacySettings?: {
    whoCanSeePosts: 'public' | 'friends' | 'only_me';
    whoCanAddFriend: 'everyone' | 'friends_of_friends';
    whoCanSeeFriendsList: 'public' | 'friends' | 'only_me';
    whoCanMessage: 'everyone' | 'friends';
    isProfileRestricted: boolean;
  };
  city?: string;
  hometown?: string;
  work?: string;
  education?: string;
  relationshipStatus?: string;
}

export interface DisposableCode {
  code: string;
  used: boolean;
  usedAt?: string;
}

export interface Room {
  id: string;
  name: string;
  description: string;
  category: 'paquera' | 'amizade' | 'romance' | 'geral' | 'musica';
  type: 'public' | 'private';
  creatorId: string;
  creatorName: string;
  creatorEmail: string;
  createdAt: string;
  maxParticipants: number;
  activeParticipantsCount: number;
  participants: RoomParticipant[];
  bans: ModeratorBan[];
  isLocked?: boolean;
  state?: string;
  stateName?: string;
  city?: string;
  theme?: string;
  themeLabel?: string;
}

export interface RoomParticipant {
  id: string;
  userId: string;
  name: string;
  avatarUrl?: string;
  isModerator: boolean;
  isAudioMuted: boolean;
  isVideoOff: boolean;
  isScreenSharing: boolean;
  isHandRaised: boolean;
  joinedAt: string;
}

export interface JoinRequest {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  userEmail: string;
  presentationMessage: string;
  avatarUrl?: string;
  status: 'pending' | 'approved' | 'rejected' | 'expired';
  createdAt: string;
  expiresAt?: string;
  timeoutSeconds?: number;
  secondsRemaining?: number;
}

export interface ModeratorBan {
  id: string;
  userId: string;
  userCpf?: string;
  userName: string;
  moderatorId: string;
  moderatorName: string;
  roomId?: string; // Ban applies to all rooms created by this moderator
  bannedAt: string;
  expiresAt: string;
  durationLabel: string;
  reason: string;
}

export interface VideoEmbed {
  platform: 'youtube' | 'vimeo' | 'twitch' | 'dailymotion' | 'direct';
  url: string;
  embedUrl: string;
  title?: string;
}

export interface AudioAttachment {
  name: string;
  url: string;
  format: 'wav' | 'mp3';
  size: number;
}

export interface ChatMessage {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  senderNickname?: string;
  senderAvatar?: string;
  isModerator?: boolean;
  text?: string;
  file?: {
    name: string;
    url: string;
    size: number;
    type: string;
  };
  videoEmbed?: VideoEmbed;
  audioAttachment?: AudioAttachment;
  timestamp: string;
}

export interface LiveViewRequest {
  id: string;
  transmissionId: string;
  userId: string;
  userName: string;
  userNickname?: string;
  avatarUrl?: string;
  requestedAt: string;
  expiresAt: string;
  secondsRemaining: number;
}

export interface LiveTransmission {
  id: string;
  streamerId: string;
  streamerName: string;
  streamerNickname: string;
  streamerAvatar?: string;
  title: string;
  fixedText: string;
  type: 'public' | 'restricted';
  maxViewers: 55; // Limite fixo de 55 usuários assistindo
  currentViewersCount: number;
  currentViewers: string[]; // userIds
  pendingViewRequests: LiveViewRequest[]; // Máximo 11 pedidos simultâneos, 33s cada
  approvedViewers: string[]; // userIds liberados para visualização da câmera
  createdAt: string;
  status: 'active' | 'ended';
}

export type DeviceType = 'desktop' | 'tablet' | 'mobile';
export type DeviceOrientation = 'landscape' | 'portrait';

export interface ScreenFormatInfo {
  deviceType: DeviceType;
  orientation: DeviceOrientation;
  is16to9: boolean;
  width: number;
  height: number;
  aspectRatio: number;
  label: string;
}

export interface DevicePermissionsState {
  granted: boolean;
  date?: string;
  camera: boolean;
  microphone: boolean;
  speaker: boolean;
}

export interface SecurityNotification {
  id: string;
  userId: string;
  userEmail: string;
  type: 'disposable_code_used' | '2fa_enabled' | 'login_alert';
  title: string;
  message: string;
  codeUsed?: string;
  timestamp: string;
  read: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  details: string;
  ipAddress?: string;
  level: 'info' | 'warn' | 'security';
}

export interface SpeakerQueueItem {
  slot: number; // 1 to 14 (Fl_01 to Fl_14)
  userId: string;
  name: string;
  nickname?: string;
  avatarUrl?: string;
  requestedAt: string;
}

export interface HandRaiseQueueItem {
  userId: string;
  name: string;
  nickname?: string;
  avatarUrl?: string;
  requestedAt: string;
  position: number; // 1 = Verde (próximo a falar), 2 = Amarelo, >=3 = Vermelho
}

export interface MatrixSubRoom {
  roomNumber: number; // 1 (Matriz), 2 to 7 (or 8) (Filhas)
  name: string;
  isMatrix: boolean;
  participantCount: number;
  maxParticipants: number; // 15
  participants: RoomParticipant[];
}

export interface StandardConferenceData {
  roomId: string;
  currentSpeaker: {
    userId: string;
    name: string;
    nickname?: string;
    avatarUrl?: string;
    startedAt: string;
    isAudioMuted?: boolean;
    isVideoOff?: boolean;
  } | null;
  speakerQueue: SpeakerQueueItem[]; // Fl_01 a Fl_14
  handRaiseQueue: HandRaiseQueueItem[];
  matrixRooms: MatrixSubRoom[];
}

export interface DirectPrivateMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderNickname?: string;
  senderAvatar?: string;
  senderRoomNumber: number;
  receiverId: string;
  receiverName: string;
  text: string;
  timestamp: string;
}

export interface ChamassoTariffSettings {
  billingEnabled: boolean; // Ativar ou suspender a cobrança do bate-papo
  unlockFeeEnabled?: boolean; // Taxa de desbloqueio das funcionalidades do chat (áudio, vídeo, texto, compartilhamento)
  ratePerMinute: number; // R$ por minuto, padrão 0.01
  minRechargeAmount: number; // Valor mínimo de recarga, padrão R$ 5.00
  rechargeValidityDays: number; // Validade dos créditos em dias, padrão 30 dias após primeiro uso
}

export interface MercadoPagoSettings {
  publicKey: string; // API Key Pública do Mercado Pago
  accessToken: string; // Secret Key / Access Token do Mercado Pago
  webhookUrl: string; // Link de Webhooks
  redirectUrl: string; // Link de redirecionamento pós-pagamento
  sandboxMode: boolean; // Modo Testes (Sandbox) ou Produção
}

export interface RechargeTransaction {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  amount: number;
  minutesGranted: number;
  status: 'pending' | 'approved' | 'cancelled';
  paymentMethod: 'pix' | 'credit_card' | 'ticket';
  pixQrCode?: string;
  pixCopyPaste?: string;
  createdAt: string;
  approvedAt?: string;
  expiresAt: string;
}

// ==============================================================================
// SUPABASE CLOUD BACKUP & DISASTER RECOVERY
// ==============================================================================
export interface SupabaseSyncConfig {
  supabaseUrl: string;
  anonKey: string;
  serviceRoleKey: string;
  dbHost?: string;
  dbPort?: number;
  dbUser?: string;
  dbPassword?: string;
  dbName?: string;
  autoSyncEnabled: boolean;
  syncIntervalMinutes: number;
  lastBackupAt?: string;
  lastBackupStatus?: 'success' | 'failed' | 'in_progress';
  lastBackupMessage?: string;
  lastSyncDirection?: 'local_to_cloud' | 'cloud_to_local' | 'cloud_populated' | 'tested';
  tablesCount?: number;
  recordsSynced?: number;
  nextSyncAt?: string;
  lastConnectionTest?: SupabaseTestResult;
}

export interface SupabaseTestResult {
  success: boolean;
  message: string;
  latencyMs?: number;
  httpStatus?: number;
  testedAt: string;
  endpointTested?: string;
  tablesDetected?: string[];
  cloudHasData?: boolean;
  cloudRecordsCount?: number;
}

export interface BackupHistoryItem {
  id: string;
  timestamp: string;
  target: 'supabase' | 'local_file';
  status: 'success' | 'failed';
  recordsCount: number;
  fileSizeBytes?: number;
  details: string;
  direction?: 'local_to_cloud' | 'cloud_to_local' | 'cloud_populated';
  downloadUrl?: string;
}

// ==============================================================================
// FIREWALL & ATTACK MONITORING (DDOS, BRUTE FORCE, PHISHING)
// ==============================================================================
export type AttackType = 'ddos' | 'brute_force' | 'phishing' | 'port_scan' | 'sql_injection' | 'suspicious_flood';

export interface BlockedIpRecord {
  id: string;
  ip: string;
  reason: string;
  attackType: AttackType;
  blockedAt: string;
  blockedUntil?: string; // ISO date or 'permanent'
  requestCount: number;
  country?: string;
  lastUserAgent?: string;
  isPermanent: boolean;
}

export interface SecurityEvent {
  id: string;
  timestamp: string;
  ip: string;
  attackType: AttackType;
  severity: 'low' | 'medium' | 'high' | 'critical';
  details: string;
  actionTaken: 'blocked' | 'rate_limited' | 'warned' | 'dropped';
  endpoint?: string;
}

export interface FirewallStats {
  activeBlocksCount: number;
  totalAttacksBlocked: number;
  ddosAttemptsBlocked: number;
  bruteForceBlocked: number;
  phishingBlocked: number;
  systemStatus: 'active' | 'learning' | 'alert';
  requestsPerSecond: number;
  cpuLoadPercentage: number;
}

// ==============================================================================
// GESTÃO FINANCEIRA (CONTAS A PAGAR, RECEBER, CLIENTES E CAMPANHAS)
// ==============================================================================
export interface BillToPay {
  id: string;
  description: string;
  category: 'vps_infra' | 'webrtc_bandwidth' | 'domain_ssl' | 'payment_gateway' | 'software_license' | 'operational' | 'other';
  amount: number;
  dueDate: string;
  status: 'pending' | 'paid' | 'overdue';
  paidAt?: string;
  beneficiary: string;
  notes?: string;
  createdAt: string;
}

export interface BillToReceive {
  id: string;
  description: string;
  customerName: string;
  customerEmail: string;
  customerId?: string;
  category: 'recharge_chamasso' | 'corporate_room' | 'vip_badge' | 'custom_plan' | 'other';
  amount: number;
  dueDate: string;
  status: 'pending' | 'received' | 'cancelled';
  receivedAt?: string;
  method?: 'pix' | 'credit_card' | 'ticket' | 'invoice';
  transactionId?: string;
  createdAt: string;
}

export interface PromotionalCampaign {
  id: string;
  title: string;
  description: string;
  bonusPercentage: number; // Ex: 30 para +30%
  bonusFixedAmount: number; // Ex: R$ 5 fixo a mais
  minRechargeAmount: number; // Ex: a partir de R$ 10
  maxUsesPerMonth: number; // Ex: 2 recargas por mês
  currentUsesCount?: number;
  freeDaysBonus?: number; // Ex: 3 dias grátis de chat
  validFrom: string;
  validTo: string;
  isActive: boolean;
  badgeLabel?: string; // Ex: "PROMO 30% EM DOBRO"
  createdAt: string;
}

// ==============================================================================
// PASQCOIN - MOEDA VIRTUAL DE TEMPO E DESBLOQUEIO DO CHAT
// ==============================================================================
export interface PasqcoinSettings {
  enabled: boolean;
  name: string; // "pasqcoin"
  symbol: string; // "PASQ"
  secondsPerCoin: number; // Quantos segundos vale cada pasqcoin (ex: 60 segundos)
  pricePerCoin: number; // Preço de compra em R$ por pasqcoin (ex: 0.01)
  batchSize: number; // Quantidade gerada por vez: 1141
  autoReplenishThresholdPercent: number; // 20% (quando sobrar <= 20%, gera +1141)
  expirationDays: number; // Validade em dias das pasqcoins adquiridas/geradas
  totalMinted: number; // Total histórico gerado/minerado
  availableReserve: number; // Saldo disponível em estoque para compra
  circulatingInWallets: number; // Quantidade em posse dos usuários
  autoReplenishEnabled: boolean;
  lastMintAt?: string;
  updatedAt: string;
}

export interface PasqcoinMintBatch {
  id: string;
  batchNumber: number;
  amount: number; // 1141
  trigger: 'initial' | 'auto_replenish_20' | 'manual_admin';
  timestamp: string;
  reserveBefore: number;
  reserveAfter: number;
  notes: string;
}

export interface PasqcoinTransaction {
  id: string;
  userId: string;
  userName: string;
  userEmail?: string;
  type: 'purchase' | 'chat_usage' | 'admin_bonus' | 'refund';
  amountCoins: number;
  pricePaid?: number;
  paymentMethod?: 'balance' | 'pix' | 'credit_card' | 'admin';
  chatDurationSeconds?: number;
  roomId?: string;
  timestamp: string;
  balanceAfter: number;
}

// ==============================================================================
// REDE SOCIAL - POSTS, COMENTÁRIOS E REAÇÕES
// ==============================================================================
export type SocialReactionType = 'like' | 'love' | 'care' | 'haha' | 'wow' | 'sad' | 'angry';

export interface SocialComment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  content: string;
  createdAt: string;
  likes?: string[];
}

export interface SocialPost {
  id: string;
  authorId: string;
  authorName: string;
  authorLastName?: string;
  authorAvatar?: string;
  authorEmail?: string;
  authorNickname?: string;
  content: string;
  mediaType?: 'image' | 'video' | 'audio' | 'file';
  mediaUrl?: string;
  mediaName?: string;
  privacy: 'public' | 'friends';
  createdAt: string;
  reactions: Record<string, SocialReactionType>; // userId -> reaction
  comments: SocialComment[];
  sharesCount: number;
}

export interface SocialLandingPageData {
  user: User;
  isOwner: boolean;
  isFriend: boolean;
  friendshipStatus?: 'none' | 'pending' | 'accepted';
  isRestrictedView: boolean;
  posts: SocialPost[];
  friendsCount: number;
  friends: Array<{
    id: string;
    name: string;
    lastName: string;
    avatarUrl?: string;
    status?: UserStatus;
  }>;
  photos: string[];
}

export interface PasqcoinChatProgress {
  userId: string;
  roomId?: string;
  hasStarted: boolean;
  currentSecond: number; // 1 a secondsPerCoin (ex: 1 a 60)
  secondsPerCoin: number; // ex: 60
  coinsRemaining: number;
  totalCoinsConsumed: number;
  isActive: boolean;
}



