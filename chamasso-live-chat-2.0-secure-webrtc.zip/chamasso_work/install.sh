#!/bin/bash
# ==============================================================================
# SCRIPT DE INSTALAÇÃO AUTOMATIZADA: CHAMASSO LIVE CHAT
# Compatível com: Linux Debian 12 (Bookworm) e derivados
# Servidor Web: Apache 2.4 com Proxy Reverso + WebSockets + Certificado SSL
# Domínio: chamasso.pasquared.space
# E-mail de Segurança: rogeriogomes11@ukbelol.space
# Gerenciador de Processos: PM2
# ==============================================================================

set -e

# Cores para saída no terminal
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m' # Sem cor

echo -e "${CYAN}${BOLD}"
echo "======================================================================"
echo "    INSTALADOR AUTOMATIZADO: CHAMASSO LIVE CHAT                     "
echo "    Servidor Debian 12 + Apache 2.4 + SSL + PM2                      "
echo "    Domínio: chamasso.pasquared.space                                  "
echo "    E-mail de Segurança: rogeriogomes11@ukbelol.space               "
echo "======================================================================"
echo -e "${NC}"

# 1. Verificar privilégios de root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERRO] Este script deve ser executado como root ou com sudo.${NC}"
  exit 1
fi

# Diretório base
INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$INSTALL_DIR"

# Segredos únicos desta implantação (não versionados)
DB_PASSWORD="$(openssl rand -hex 24)"
SESSION_SECRET="$(openssl rand -hex 48)"
TURN_PASSWORD="$(openssl rand -hex 24)"
ADMIN_PASSWORD="${SUPER_ADMIN_PASSWORD:-$(openssl rand -base64 24 | tr -d '\n' | tr '/+' 'AZ')}"

echo -e "${GREEN}[1/9] Atualizando repositórios do Debian 12...${NC}"
apt-get update -y
apt-get upgrade -y
apt-get install -y curl wget git build-essential ufw software-properties-common ca-certificates gnupg

echo -e "${GREEN}[2/9] Instalando Apache 2.4, Certbot (Let's Encrypt) e SGBD PostgreSQL...${NC}"
apt-get install -y apache2 certbot python3-certbot-apache postgresql postgresql-contrib redis-server coturn openssl

echo -e "${GREEN}[3/9] Inicializando e Configurando o Banco de Dados PostgreSQL (db_chamasso)...${NC}"
systemctl start postgresql || service postgresql start || true
systemctl enable postgresql || true

# Configuração automática do banco db_chamasso, user_chamasso e Super Admin
if [ -f "$INSTALL_DIR/db_chamasso.sql" ]; then
    echo -e "${CYAN}Executando script de criação db_chamasso.sql como usuário postgres...${NC}"
    sed "s/CHANGE_ME_DB_PASSWORD/$DB_PASSWORD/g" "$INSTALL_DIR/db_chamasso.sql" > /tmp/db_chamasso.runtime.sql
    sudo -u postgres psql -f /tmp/db_chamasso.runtime.sql || {
        echo -e "${YELLOW}[AVISO] Execução direta de db_chamasso.sql retornou aviso. Tentando modo de contingência...${NC}"
        sudo -u postgres psql -c "CREATE USER user_chamasso WITH ENCRYPTED PASSWORD '$DB_PASSWORD';" || sudo -u postgres psql -c "ALTER USER user_chamasso WITH ENCRYPTED PASSWORD '$DB_PASSWORD';" || true
        sudo -u postgres psql -c "CREATE DATABASE db_chamasso OWNER user_chamasso ENCODING 'UTF8';" || true
        sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE db_chamasso TO user_chamasso;" || true
        sudo -u postgres psql -d db_chamasso -f /tmp/db_chamasso.runtime.sql || true
    }
    echo -e "${GREEN}[OK] Banco db_chamasso e Super Admin roger577@ukbelol.space provisionados no PostgreSQL!${NC}"
else
    echo -e "${YELLOW}[AVISO] Arquivo db_chamasso.sql não encontrado no diretório do projeto.${NC}"
fi

# Criação/atualização segura do arquivo .env
cat > "$INSTALL_DIR/.env" <<EOF_ENV
NODE_ENV=production
PORT=3000
DOMAIN=chamasso.pasquared.space
SESSION_SECRET=$SESSION_SECRET
SESSION_TTL_SECONDS=7200
SUPER_ADMIN_EMAIL=roger577@ukbelol.space
SUPER_ADMIN_PASSWORD=$ADMIN_PASSWORD
PGHOST=127.0.0.1
PGPORT=5432
PGDATABASE=db_chamasso
PGUSER=user_chamasso
PGPASSWORD=$DB_PASSWORD
WEBRTC_MODE=p2p
STUN_URLS=stun:stun.l.google.com:19302
TURN_URLS=turn:chamasso.pasquared.space:3478,turns:chamasso.pasquared.space:5349
TURN_USERNAME=chamasso
TURN_PASSWORD=$TURN_PASSWORD
REDIS_URL=redis://127.0.0.1:6379
EOF_ENV
chmod 600 "$INSTALL_DIR/.env"

# Redis local para evolução de presença/pubsub/cache
systemctl enable --now redis-server || true

# Coturn: TURN/STUN para WebRTC atrás de NAT/CGNAT. O certificado TLS passa a ser usado após o Certbot.
cat > /etc/turnserver.conf <<EOF_TURN
listening-port=3478
tls-listening-port=5349
fingerprint
lt-cred-mech
realm=chamasso.pasquared.space
user=chamasso:$TURN_PASSWORD
min-port=49160
max-port=49200
no-multicast-peers
no-cli
EOF_TURN
sed -i 's/^#TURNSERVER_ENABLED=.*/TURNSERVER_ENABLED=1/; s/^TURNSERVER_ENABLED=.*/TURNSERVER_ENABLED=1/' /etc/default/coturn 2>/dev/null || true
systemctl enable --now coturn || true

echo -e "${GREEN}[4/9] Instalando Node.js (v20 LTS) e NPM...${NC}"
if ! command -v node &> /dev/null || [ "$(node -v | cut -d'.' -f1 | tr -d 'v')" -lt 18 ]; then
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg --yes
    NODE_MAJOR=20
    echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_$NODE_MAJOR.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list
    apt-get update -y
    apt-get install -y nodejs
fi

echo -e "${CYAN}Node.js versão instalada:${NC} $(node -v)"
echo -e "${CYAN}NPM versão instalada:${NC} $(npm -v)"

echo -e "${GREEN}[5/9] Instalando PM2 globalmente...${NC}"
npm install -g pm2

echo -e "${GREEN}[6/9] Habilitando módulos essenciais no Apache...${NC}"
a2enmod proxy
a2enmod proxy_http
a2enmod proxy_wstunnel
a2enmod rewrite
a2enmod ssl
a2enmod headers
a2enmod deflate

# Cria diretório de logs
mkdir -p /var/log/chamasso
mkdir -p /var/log/apache2

echo -e "${GREEN}[7/9] Configurando VirtualHost do Apache e Arquivos SSL...${NC}"
mkdir -p /etc/letsencrypt/live/chamasso.pasquared.space
chmod 755 /etc/letsencrypt
chmod 700 /etc/letsencrypt/live

# Criação preventiva de /etc/letsencrypt/options-ssl-apache.conf para evitar erro de sintaxe no Apache
if [ ! -f "/etc/letsencrypt/options-ssl-apache.conf" ]; then
    echo -e "${YELLOW}Criando parâmetros SSL em /etc/letsencrypt/options-ssl-apache.conf...${NC}"
    cat << 'EOF_SSL' > /etc/letsencrypt/options-ssl-apache.conf
# Baseline SSL Configuration for Apache 2.4 - chamasso live chat
SSLEngine on
SSLProtocol all -SSLv2 -SSLv3 -TLSv1 -TLSv1.1
SSLCipherSuite ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384
SSLHonorCipherOrder off
SSLSessionTickets off
EOF_SSL
    chmod 644 /etc/letsencrypt/options-ssl-apache.conf
fi

# Criação preventiva de certificado SSL autoassinado para o Apache conseguir validar sintaxe e inicializar
if [ ! -f "/etc/letsencrypt/live/chamasso.pasquared.space/fullchain.pem" ] || [ ! -f "/etc/letsencrypt/live/chamasso.pasquared.space/privkey.pem" ]; then
    echo -e "${YELLOW}Criando certificado SSL temporário para permitir validação do Apache...${NC}"
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
      -keyout /etc/letsencrypt/live/chamasso.pasquared.space/privkey.pem \
      -out /etc/letsencrypt/live/chamasso.pasquared.space/fullchain.pem \
      -subj "/C=BR/ST=SP/L=SaoPaulo/O=Chamasso/CN=chamasso.pasquared.space" 2>/dev/null || true
    chmod 600 /etc/letsencrypt/live/chamasso.pasquared.space/privkey.pem
    chmod 644 /etc/letsencrypt/live/chamasso.pasquared.space/fullchain.pem
fi

VHOST_FILE="/etc/apache2/sites-available/chamasso.pasquared.space.conf"

if [ -f "$INSTALL_DIR/apache/chamasso.pasquared.space.conf" ]; then
    cp "$INSTALL_DIR/apache/chamasso.pasquared.space.conf" "$VHOST_FILE"
else
    cat << 'EOF' > "$VHOST_FILE"
<VirtualHost *:80>
    ServerName chamasso.pasquared.space
    ServerAdmin rogeriogomes11@ukbelol.space
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
    ErrorLog ${APACHE_LOG_DIR}/chamasso_http_error.log
    CustomLog ${APACHE_LOG_DIR}/chamasso_http_access.log combined
</VirtualHost>

<VirtualHost *:443>
    ServerName chamasso.pasquared.space
    ServerAdmin rogeriogomes11@ukbelol.space

    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/chamasso.pasquared.space/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/chamasso.pasquared.space/privkey.pem

    # Parâmetros SSL Seguros
    SSLProtocol all -SSLv2 -SSLv3 -TLSv1 -TLSv1.1
    SSLCipherSuite ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384
    SSLHonorCipherOrder off
    SSLSessionTickets off
    IncludeOptional /etc/letsencrypt/options-ssl-apache.conf

    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"

    ProxyPreserveHost On
    ProxyRequests Off

    RewriteEngine On
    RewriteCond %{HTTP:Upgrade} =websocket [NC]
    RewriteRule /(.*) ws://127.0.0.1:3000/$1 [P,L]

    ProxyPass /ws ws://127.0.0.1:3000/ws
    ProxyPassReverse /ws ws://127.0.0.1:3000/ws

    ProxyPass / http://127.0.0.1:3000/
    ProxyPassReverse / http://127.0.0.1:3000/

    ErrorLog ${APACHE_LOG_DIR}/chamasso_ssl_error.log
    CustomLog ${APACHE_LOG_DIR}/chamasso_ssl_access.log combined
</VirtualHost>
EOF
fi

# Desativa default site se existir e ativa o novo
a2dissite 000-default.conf 2>/dev/null || true
a2ensite chamasso.pasquared.space.conf

echo -e "${GREEN}[8/9] Compilando a aplicação chamasso live chat e ajustando permissões...${NC}"
npm install --legacy-peer-deps || npm install
npm run build

# Ajuste de Permissões de Pastas, Arquivos, Grupos e Usuários
chown -R www-data:www-data "$INSTALL_DIR"
chmod -R 755 "$INSTALL_DIR"
chown -R www-data:adm /var/log/apache2 /var/log/chamasso
chmod -R 750 /var/log/apache2 /var/log/chamasso

echo -e "${GREEN}[9/9] Obtendo ou renovando certificado SSL com Certbot Let's Encrypt...${NC}"
echo -e "${CYAN}Tentando emitir certificado oficial Let's Encrypt para chamasso.pasquared.space...${NC}"
certbot --apache -d chamasso.pasquared.space --non-interactive --agree-tos -m rogeriogomes11@ukbelol.space --redirect 2>&1 || {
    echo -e "${YELLOW}[AVISO] Certbot não concluiu a emissão oficial automática (possível propagação DNS pendente ou modo simulado).${NC}"
    echo -e "${YELLOW}O servidor Apache usará o certificado de fallback seguro para manter o serviço 100% ativo.${NC}"
}

# Ativa TURN sobre TLS quando os certificados estiverem disponíveis
if [ -f /etc/letsencrypt/live/chamasso.pasquared.space/fullchain.pem ] && [ -f /etc/letsencrypt/live/chamasso.pasquared.space/privkey.pem ]; then
  grep -q '^cert=' /etc/turnserver.conf || echo 'cert=/etc/letsencrypt/live/chamasso.pasquared.space/fullchain.pem' >> /etc/turnserver.conf
  grep -q '^pkey=' /etc/turnserver.conf || echo 'pkey=/etc/letsencrypt/live/chamasso.pasquared.space/privkey.pem' >> /etc/turnserver.conf
  systemctl restart coturn || true
fi

# Garante permissões adequadas no certificado e chave
chmod 600 /etc/letsencrypt/live/chamasso.pasquared.space/privkey.pem 2>/dev/null || true
chmod 644 /etc/letsencrypt/live/chamasso.pasquared.space/fullchain.pem 2>/dev/null || true

# Testa configuração do Apache
echo -e "${GREEN}Verificando sintaxe do Apache (apache2ctl configtest)...${NC}"
apache2ctl configtest
systemctl restart apache2
systemctl enable apache2

# Inicia a aplicação com PM2
echo -e "${GREEN}Iniciando aplicação com PM2...${NC}"
pm2 delete chamasso-live-chat 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup systemd -u root --hp /root 2>/dev/null || true

# Configura regras de Firewall UFW (Portas abertas vs Portas protegidas/fechadas)
if command -v ufw &> /dev/null; then
    echo -e "${GREEN}Configurando Firewall UFW e Política de Portas...${NC}"
    # Portas que DEVEM estar ABERTAS externamente:
    ufw allow 80/tcp comment 'HTTP - Certbot & Redirect'
    ufw allow 443/tcp comment 'HTTPS & WSS - Chamasso Live Chat'
    ufw allow 3478/tcp comment 'TURN/STUN TCP'
    ufw allow 3478/udp comment 'TURN/STUN UDP'
    ufw allow 5349/tcp comment 'TURN TLS'
    ufw allow 49160:49200/udp comment 'TURN relay media'
    ufw allow OpenSSH comment 'SSH - Acesso Remoto Seguro'

    # Porta que DEVE estar FECHADA/INTERNA (Loopback 127.0.0.1 apenas):
    # A porta 3000 da aplicação Node/Vite não deve ser exposta diretamente para a internet,
    # evitando conflitos e contorno do proxy reverso SSL do Apache.
    ufw delete allow 3000/tcp 2>/dev/null || true
    ufw deny 3000/tcp comment 'Bloqueio externo da porta 3000 (Uso restrito via Proxy 127.0.0.1)' 2>/dev/null || true

    ufw --force enable 2>/dev/null || true
fi

echo -e "${CYAN}${BOLD}"
echo "======================================================================"
echo "    INSTALAÇÃO CONCLUÍDA COM SUCESSO!                                 "
echo "======================================================================"
echo -e "${GREEN}Aplicação 'chamasso live chat' está ativa e rodando com PM2!${NC}"
echo -e "URL Pública:       https://chamasso.pasquared.space"
echo -e "E-mail Segurança:  rogeriogomes11@ukbelol.space"
echo -e "SGBD Instalado:    PostgreSQL 15 (Serviço ativo)"
echo -e "Banco de Dados:    db_chamasso"
echo -e "Usuário do Banco:  user_chamasso"
echo -e "Super Admin:       roger577@ukbelol.space (Permissões: ALL)"
echo -e "Senha inicial Admin: $ADMIN_PASSWORD"
echo -e "IMPORTANTE: guarde esta senha e troque-a após o primeiro acesso."
echo -e "Web Server:        Apache 2.4 (Proxy Reverso + WSS na porta 3000)"
echo -e "Monitoramento PM2: pm2 status"
echo -e "Logs da Aplicação: pm2 logs chamasso-live-chat"
echo -e "Logs do Apache:    tail -f /var/log/apache2/chamasso_ssl_error.log"
echo "======================================================================"
