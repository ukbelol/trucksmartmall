import React, { useState } from 'react';
import { Lock, Unlock, Sparkles, X, Eye, EyeOff, AlertTriangle, ShieldCheck } from 'lucide-react';

interface AdminLoginProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
}

export default function AdminLogin({ isOpen, onClose, onLoginSuccess }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Pre-trimmed coordinates
    const targetEmail = 'magomagard@smartmall577.space';
    const targetPassword = 'magard577@Anjo2026';

    if (!email || !password) {
      setError('Por favor, informe o e-mail e a senha de acesso!');
      return;
    }

    setIsLoading(true);

    // Simulate short, polished terminal loading feedback
    setTimeout(() => {
      setIsLoading(false);
      if (email.trim() === targetEmail && password === targetPassword) {
        onLoginSuccess();
        setEmail('');
        setPassword('');
        onClose();
      } else {
        setError('Acesso Negado! Credenciais incorretas para o Super Admin.');
      }
    }, 850);
  };

  const handleQuickFill = () => {
    setEmail('magomagard@smartmall577.space');
    setPassword('magard577@Anjo2026');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex items-center justify-center p-4" id="admin-login-modal">
      {/* Overlay */}
      <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm" onClick={onClose} />

      {/* Login Card */}
      <div className="relative bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-scaleUp">
        {/* Color stripe */}
        <div className="h-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600" />
        
        {/* Header */}
        <div className="p-6 bg-slate-950 border-b border-indigo-950/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="bg-amber-500/10 p-2 rounded-lg text-amber-500 border border-amber-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider font-mono">
                Autenticação Restrita
              </h3>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
                Portal Super Admin
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Instructions banner */}
          <div className="bg-slate-950 p-3.5 border border-slate-800 rounded-xl space-y-1">
            <span className="text-[9px] text-slate-500 uppercase font-bold block font-mono">Atalhos Administrativos:</span>
            <div className="flex justify-between items-center">
              <span className="text-[10px] text-slate-400">Clique ao lado para preencher as credenciais de homologação automaticamente:</span>
              <button
                type="button"
                onClick={handleQuickFill}
                className="hover:scale-105 active:scale-95 py-1 px-2.5 bg-slate-900 border border-slate-750 hover:bg-slate-800 rounded text-[9px] text-amber-500 font-bold uppercase tracking-wider transition-all"
              >
                Preencher
              </button>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {/* Email Field */}
            <div>
              <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">E-mail Corporativo</label>
              <input
                type="email"
                placeholder="nome@smartmall577.space"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none transition-all placeholder:text-slate-600 font-mono"
              />
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Senha de Acesso</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isLoading}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 pr-10 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none transition-all placeholder:text-slate-600 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-500 hover:text-slate-350 transition-all"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error logs */}
            {error && (
              <div className="bg-red-500/10 border border-red-500/30 p-3 rounded-lg flex items-center gap-2 text-xs text-red-500">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span className="font-semibold">{error}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 py-3.5 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-805 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider shadow-lg transition-all"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              ) : (
                'Iniciar Sessão Segura'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
