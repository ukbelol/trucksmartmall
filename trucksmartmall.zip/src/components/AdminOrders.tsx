import React, { useState } from 'react';
import { Order, OrderStatus } from '../types';
import { Check, Truck, Clock, Eye, AlertCircle, FileText, Globe, MapPin, Printer } from 'lucide-react';

interface AdminOrdersProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
}

export default function AdminOrders({ orders, onUpdateOrderStatus }: AdminOrdersProps) {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(val);
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return 'bg-amber-500/10 border-amber-500/30 text-amber-500';
      case 'approved':
        return 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400';
      case 'dispatched':
        return 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400';
      default:
        return 'bg-slate-800 text-slate-400';
    }
  };

  const getStatusText = (status: OrderStatus) => {
    switch (status) {
      case 'pending': return 'Pendente de Análise';
      case 'approved': return 'Crédito Aprovado';
      case 'dispatched': return 'Despachado (Em Rota)';
      default: return status;
    }
  };

  return (
    <div className="space-y-6" id="admin-orders-section">
      {/* Title */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
        <h2 className="text-lg font-black text-white uppercase tracking-tight">Gerenciamento de Vendas & Logística</h2>
        <p className="text-xs text-slate-400 mt-1">Monitore faturamentos, aprove pedidos faturados e gere guias de despacho para as transportadoras parceiras.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Orders Table column */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between pb-3.5 border-b border-slate-850">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Pedidos Recentes</h3>
            <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-slate-500 font-mono">
              Total {orders.length}
            </span>
          </div>

          <div className="overflow-x-auto mt-4">
            {orders.length === 0 ? (
              <div className="text-center py-16 text-slate-500 font-mono space-y-2">
                <AlertCircle className="w-8 h-8 text-slate-650 mx-auto" />
                <p>Nenhuma venda registrada na loja do cliente até o momento.</p>
              </div>
            ) : (
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-500 font-mono uppercase tracking-wider">
                    <th className="py-3 px-2">Pedido ID</th>
                    <th className="py-3 px-2">Data / Hora</th>
                    <th className="py-3 px-2">Itens</th>
                    <th className="py-3 px-2 text-right">Valor Total</th>
                    <th className="py-3 px-2 text-center">Status</th>
                    <th className="py-3 px-2 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850">
                  {orders.map((o) => (
                    <tr 
                      key={o.id} 
                      className={`hover:bg-slate-950/20 text-slate-350 cursor-pointer ${
                        selectedOrder?.id === o.id ? 'bg-slate-950/45 border-l-2 border-amber-500' : ''
                      }`}
                      onClick={() => setSelectedOrder(o)}
                    >
                      <td className="py-3.5 px-2 font-black text-slate-200">
                        {o.id}
                      </td>
                      <td className="py-3.5 px-2 text-[11px] text-slate-400 font-mono">
                        {new Date(o.date).toLocaleDateString('pt-BR')} {new Date(o.date).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}
                      </td>
                      <td className="py-3.5 px-2 font-mono">
                        {o.items.length} {o.items.length === 1 ? 'item' : 'itens'}
                      </td>
                      <td className="py-3.5 px-2 text-right font-bold text-white font-mono">
                        {formatCurrency(o.totalValue)}
                      </td>
                      <td className="py-3.5 px-2 text-center">
                        <span className={`inline-block px-2 py-0.5 border rounded text-[10px] font-bold font-mono uppercase ${getStatusBadge(o.status)}`}>
                          {getStatusText(o.status)}
                        </span>
                      </td>
                      <td className="py-3.5 px-2 text-right" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setSelectedOrder(o)}
                          className="p-1 px-2.5 bg-slate-850 hover:bg-slate-800 text-slate-300 rounded border border-slate-750 flex items-center gap-1.5 ml-auto font-mono text-[10px]"
                        >
                          <Eye className="w-3.5 h-3.5 text-amber-500" /> Detalhar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Selected Order Detailed Panels (Receipt + Delivery Request Generator) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between">
          {selectedOrder ? (
            <div className="space-y-5">
              {/* Receipt detailed specs */}
              <div className="space-y-1">
                <div className="flex justify-between items-baseline">
                  <h3 className="text-sm font-extrabold text-white uppercase tracking-tight flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-amber-500" />
                    Detalhamento - {selectedOrder.id}
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono">{selectedOrder.trackingCode}</span>
                </div>
                <p className="text-[10px] text-slate-500 font-mono">GERADO EM: {new Date(selectedOrder.date).toLocaleString('pt-BR')}</p>
              </div>

              {/* Items List */}
              <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl space-y-3 font-mono">
                <span className="text-[9px] text-slate-500 font-bold block uppercase tracking-wider border-b border-slate-900 pb-1.5">Lista de Compras</span>
                <div className="space-y-2.5 max-h-40 overflow-y-auto scrollbar-none">
                  {selectedOrder.items.map((item, i) => (
                    <div key={i} className="text-xs flex justify-between space-y-0.5">
                      <div>
                        <span className="text-slate-200 block font-sans font-medium line-clamp-1">{item.name}</span>
                        <span className="text-slate-500 text-[10px]">{item.quantity} x {formatCurrency(item.unitPrice)}</span>
                      </div>
                      <span className="text-slate-300 font-bold text-right pl-3 font-mono">{formatCurrency(item.totalPrice)}</span>
                    </div>
                  ))}
                </div>
                {/* Total */}
                <div className="border-t border-slate-900 pt-2 flex justify-between text-xs">
                  <span className="text-slate-400 uppercase">Valor Total Faturado:</span>
                  <span className="text-amber-400 font-black text-sm">{formatCurrency(selectedOrder.totalValue)}</span>
                </div>
              </div>

              {/* Shipping Address */}
              <div className="bg-slate-950/40 p-4 border border-slate-850 rounded-xl space-y-2 text-xs">
                <span className="text-[9px] font-bold text-slate-500 font-mono block uppercase tracking-wider">Endereço Fiscal de Despacho</span>
                <div id="ship-address-block">
                  <p className="text-slate-200 font-black flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-amber-500" />
                    {selectedOrder.shippingAddress.receiverName}
                  </p>
                  <p className="text-slate-400 text-[11px] mt-1 leading-snug">
                    {selectedOrder.shippingAddress.street}, {selectedOrder.shippingAddress.number} <br />
                    {selectedOrder.shippingAddress.neighborhood} - {selectedOrder.shippingAddress.city} / {selectedOrder.shippingAddress.state} <br />
                    <span className="text-[10px] font-mono text-slate-500 font-bold">CEP: {selectedOrder.shippingAddress.zipCode}</span>
                  </p>
                </div>
              </div>

              {/* Status Update Actions */}
              <div className="space-y-2 pt-2 border-t border-slate-850">
                <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider font-mono">Ações de Controle Logístico</span>
                
                {selectedOrder.status === 'pending' && (
                  <button
                    onClick={() => {
                      onUpdateOrderStatus(selectedOrder.id, 'approved');
                      setSelectedOrder({...selectedOrder, status: 'approved'});
                    }}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md"
                  >
                    <Check className="w-4 h-4 stroke-[2.5]" /> Aprovar Faturamento
                  </button>
                )}

                {(selectedOrder.status === 'pending' || selectedOrder.status === 'approved') && (
                  <button
                    onClick={() => {
                      onUpdateOrderStatus(selectedOrder.id, 'dispatched');
                      setSelectedOrder({...selectedOrder, status: 'dispatched', deliveryRequestGenerated: true});
                    }}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md"
                  >
                    <Truck className="w-4 h-4" /> Despachar & Gerar Rastreio
                  </button>
                )}

                {selectedOrder.status === 'dispatched' && (
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                    <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold font-mono">
                      <Truck className="w-4 h-4 text-emerald-400" />
                      GUIA DE ENTREGA EMITIDA
                    </div>
                    
                    <div className="text-[10px] text-slate-400 space-y-1 font-mono">
                      <div className="flex justify-between">
                        <span>Transportadora:</span>
                        <span className="text-white">TNT Mercúrio / Alfa</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Código Rastreio:</span>
                        <span className="text-amber-500 font-bold">{selectedOrder.trackingCode}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Logística Local:</span>
                        <span className="text-white">Solicitação de Entrega Conferida</span>
                      </div>
                    </div>

                    <button
                      onClick={() => alert(`Emitindo Guia de Postagem TSM: ${selectedOrder.id}`)}
                      className="w-full py-1.5 bg-slate-850 hover:bg-slate-800 text-[10px] font-bold text-slate-300 font-mono rounded border border-slate-755 uppercase flex items-center justify-center gap-1 transition-all"
                    >
                      <Printer className="w-3.5 h-3.5 text-slate-400" /> Imprimir Etiqueta ZPL
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-3 select-none">
              <div className="w-12 h-12 rounded-full border border-slate-800 flex items-center justify-center text-slate-650">
                <Truck className="w-6 h-6 stroke-[1.2]" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-350 uppercase tracking-widest font-mono">Painel de Despacho</h4>
                <p className="text-[11px] text-slate-500 mt-1">Selecione algum pedido recebido na lista à esquerda para analisar endereços, aprovar transações financeiras e emitir solicitações de entrega.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
