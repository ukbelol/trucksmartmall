import React, { useState } from 'react';
import { CartItem, Product, Order, Customer } from '../types';
import { X, Trash2, Plus, Minus, CreditCard, ChevronRight, MapPin, CheckCircle, Package } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckoutComplete: (order: Order) => void;
  loggedCustomer: Customer | null;
  onRequireLogin: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onCheckoutComplete,
  loggedCustomer,
  onRequireLogin
}: CartDrawerProps) {
  const [step, setStep] = useState<'cart' | 'shipping' | 'success'>('cart');
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  // Shipping Form State
  const [receiver, setReceiver] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [street, setStreet] = useState('');
  const [number, setNumber] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [validationError, setValidationError] = useState('');

  if (!isOpen) return null;

  const totalValue = cartItems.reduce((acc, curr) => acc + (curr.product.price * curr.quantity), 0);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(val);
  };

  // Pre-fill fields for easy testing when clicking CEP helper
  const handleAutoFill = () => {
    setReceiver('Marlon Santos (Transportadora Sul)');
    setZipCode('05311-900');
    setStreet('Avenida Nações Unidas');
    setNumber('12901');
    setNeighborhood('Pinheiros');
    setCity('São Paulo');
    setState('SP');
  };

  const executeCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!receiver || !zipCode || !street || !number || !neighborhood || !city || !state) {
      setValidationError('Por favor, preencha todos os campos de entrega!');
      return;
    }

    // Prepare clean list of order items
    const orderItems = cartItems.map(item => ({
      productId: item.product.id,
      name: item.product.name,
      quantity: item.quantity,
      unitPrice: item.product.price,
      totalPrice: item.product.price * item.quantity
    }));

    // Create unique order ID and tracking code
    const orderId = `PED-${Math.floor(1000 + Math.random() * 9000)}`;
    const randomSuffix = Math.random().toString(36).substring(2, 8).toUpperCase();
    const trackingCode = `TSM-${Math.floor(1e7 + Math.random() * 9e7)}-BR`;

    const newOrder: Order = {
      id: orderId,
      date: new Date().toISOString(),
      items: orderItems,
      totalValue: totalValue,
      shippingAddress: {
        street,
        number,
        neighborhood,
        city,
        state,
        zipCode,
        receiverName: receiver
      },
      status: 'pending',
      trackingCode: trackingCode,
      deliveryRequestGenerated: false
    };

    setCreatedOrder(newOrder);
    onCheckoutComplete(newOrder);
    setValidationError('');
    setStep('success');
  };

  const resetAll = () => {
    setStep('cart');
    setCreatedOrder(null);
    setReceiver('');
    setZipCode('');
    setStreet('');
    setNumber('');
    setNeighborhood('');
    setCity('');
    setState('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" id="cart-drawer-overlay">
      {/* Background overlay */}
      <div 
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity" 
        onClick={resetAll}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-lg bg-slate-900 border-l border-slate-800 text-slate-100 shadow-2xl flex flex-col h-full">
          
          {/* Header */}
          <div className="p-6 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Package className="w-5 h-5 text-amber-500" />
              <h2 className="text-lg font-extrabold tracking-tight uppercase">
                {step === 'cart' && 'Sacola de Peças'}
                {step === 'shipping' && 'Dados de Entrega'}
                {step === 'success' && 'Pedido Concluído'}
              </h2>
            </div>
            <button 
              onClick={resetAll}
              className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart progress indicator */}
          <div className="bg-slate-950/40 px-6 py-2.5 border-b border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
            <span className={`${step === 'cart' ? 'text-amber-500 font-bold' : ''}`}>1. Sacola</span>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className={`${step === 'shipping' ? 'text-amber-500 font-bold' : ''}`}>2. Endereço</span>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className={`${step === 'success' ? 'text-emerald-500 font-bold' : ''}`}>3. Confirmação</span>
          </div>

          {/* Body Section */}
          <div className="flex-1 overflow-y-auto p-6 scrollbar-thin">
            {step === 'cart' && (
              <>
                {cartItems.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-12">
                    <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center text-slate-500">
                      <Package className="w-8 h-8 stroke-[1.5]" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-350">Sua sacola está vazia</h3>
                      <p className="text-xs text-slate-500 mt-1 max-w-xs">Navegue pelas melhores peças de reposição e adicione componentes para prosseguir.</p>
                    </div>
                    <button
                      onClick={onClose}
                      className="py-2 px-5 bg-amber-500 text-slate-950 hover:bg-amber-400 text-xs font-bold rounded-lg uppercase tracking-wider transition-all"
                    >
                      Ver Catálogo
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {cartItems.map((item) => (
                      <div key={item.product.id} className="flex gap-4 p-4 bg-slate-950/50 hover:bg-slate-950 border border-slate-800 rounded-xl transition-all">
                        {/* Image */}
                        <div className="w-20 h-20 bg-slate-900 rounded-lg overflow-hidden shrink-0 border border-slate-800">
                          <img 
                            src={item.product.imageUrl} 
                            alt={item.product.name} 
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover" 
                          />
                        </div>

                        {/* Content */}
                        <div className="flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex justify-between items-start">
                              <h4 className="text-xs font-semibold text-slate-100 line-clamp-1 pr-2">
                                {item.product.name}
                              </h4>
                              <button 
                                onClick={() => onRemoveItem(item.product.id)}
                                className="p-1 hover:bg-slate-800 rounded text-slate-500 hover:text-red-400 transition-all"
                                title="Remover item"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                            <span className="text-[10px] bg-slate-800 text-amber-500 px-2 py-0.5 rounded font-bold uppercase tracking-widest mt-1 inline-block">
                              {item.product.brand}
                            </span>
                          </div>

                          <div className="flex items-center justify-between mt-2">
                            {/* Quantity buttons with stock boundary */}
                            <div className="flex items-center bg-slate-900 border border-slate-750 rounded-lg overflow-hidden">
                              <button
                                onClick={() => onUpdateQuantity(item.product.id, -1)}
                                className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white transition-all"
                                disabled={item.quantity <= 1}
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="px-3 text-xs font-bold font-mono text-white">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => onUpdateQuantity(item.product.id, 1)}
                                className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white transition-all"
                                disabled={item.quantity >= item.product.stock}
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>

                            {/* Total price for product */}
                            <div className="text-right">
                              <span className="text-xs text-slate-500 block font-mono text-[9px] uppercase">SUBTOTAL</span>
                              <span className="text-sm font-bold text-white font-mono">
                                {formatCurrency(item.product.price * item.quantity)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            {step === 'shipping' && (
              <form onSubmit={executeCheckout} className="space-y-4">
                <div className="flex justify-between items-center bg-slate-950 p-4 border border-slate-800 rounded-xl">
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">Preenchimento Rápido</h4>
                    <p className="text-[10px] text-slate-500">Clique para autocompletar um endereço de transportadora paulista de teste.</p>
                  </div>
                  <button
                    type="button"
                    onClick={handleAutoFill}
                    className="py-1 px-3 bg-amber-500 text-slate-950 hover:bg-amber-400 text-[10px] font-black rounded uppercase tracking-wider transition-all"
                  >
                    Simular UF/CEP
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Destinatário / Empresa</label>
                    <input 
                      type="text" 
                      placeholder="Nome do Comprador ou Razão Social"
                      value={receiver}
                      onChange={(e) => setReceiver(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="col-span-2">
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">CEP</label>
                      <input 
                        type="text" 
                        placeholder="00000-000"
                        value={zipCode}
                        onChange={(e) => setZipCode(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Estado</label>
                      <input 
                        type="text" 
                        placeholder="SP"
                        maxLength={2}
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none uppercase text-center"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-3">
                    <div className="col-span-3">
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Endereço / Logradouro</label>
                      <input 
                        type="text" 
                        placeholder="Rua, Av, Rodovia..."
                        value={street}
                        onChange={(e) => setStreet(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Número</label>
                      <input 
                        type="text" 
                        placeholder="123"
                        value={number}
                        onChange={(e) => setNumber(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Bairro</label>
                      <input 
                        type="text" 
                        placeholder="Bairro"
                        value={neighborhood}
                        onChange={(e) => setNeighborhood(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Cidade</label>
                      <input 
                        type="text" 
                        placeholder="São Paulo"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {validationError && (
                  <p className="text-red-500 text-xs font-semibold py-1 bg-red-950/20 px-2.5 border border-red-900/40 rounded-lg">
                    {validationError}
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider shadow-lg transition-all"
                >
                  Confirmar e Gerar Pedido
                </button>
              </form>
            )}

            {step === 'success' && createdOrder && (
              <div className="text-center py-6 space-y-6 animate-fadeIn">
                <div className="w-16 h-16 bg-emerald-500/15 border-2 border-emerald-500 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="w-10 h-10 stroke-[2.2]" />
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white uppercase tracking-tight">Compra Registrada!</h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                    Seu pedido de reposição automotiva foi enviado com sucesso e já está registrado na central de vendas.
                  </p>
                </div>

                {/* Recibo Compacto */}
                <div className="bg-slate-955 p-4 rounded-xl border border-slate-800 text-left space-y-3 font-mono">
                  <div className="flex justify-between text-xs border-b border-slate-800 pb-2">
                    <span className="text-slate-500">CÓDIGO DE PEDIDO:</span>
                    <span className="text-white font-bold">{createdOrder.id}</span>
                  </div>

                  <div className="text-[11px] space-y-1.5 py-1 text-slate-300">
                    <div className="flex justify-between font-bold">
                      <span className="text-slate-400">Rastreio (Gerado):</span>
                      <span className="text-amber-400 select-all">{createdOrder.trackingCode}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Total Pago:</span>
                      <span className="text-white font-bold text-xs">{formatCurrency(createdOrder.totalValue)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px]">ENDEREÇO DE ENTREGA:</span>
                      <p className="text-[10px] text-slate-300 mt-0.5 leading-snug">
                        {createdOrder.shippingAddress.receiverName} <br />
                        {createdOrder.shippingAddress.street}, N° {createdOrder.shippingAddress.number} <br />
                        {createdOrder.shippingAddress.neighborhood} - {createdOrder.shippingAddress.city} / {createdOrder.shippingAddress.state}
                      </p>
                    </div>
                  </div>

                  <div className="bg-amber-500/10 border border-amber-500/20 p-2.5 rounded-lg text-[10px] text-center text-amber-500 leading-normal font-sans">
                    <strong>Status Atual: Pendente de Aprovação.</strong><br />
                    O administrador irá verificar as credenciais fiscais e despachar os itens na transportadora.
                  </div>
                </div>

                <button
                  onClick={resetAll}
                  className="w-full py-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-bold rounded-xl uppercase tracking-wider transition-all"
                >
                  Voltar para a Loja
                </button>
              </div>
            )}
          </div>

          {/* Footer of Drawer (Visible only in Cart view and when elements exist) */}
          {step === 'cart' && cartItems.length > 0 && (
            <div className="p-6 bg-slate-950 border-t border-slate-800 space-y-4">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-slate-400">
                  <span>Envio Especial</span>
                  <span className="text-emerald-400 font-bold">GRÁTIS (Campanha TruckSmart)</span>
                </div>
                <div className="flex justify-between items-baseline pt-1">
                  <span className="text-sm font-bold text-slate-300">Valor Total Estimado</span>
                  <span className="text-2xl font-black text-white font-mono tracking-tight">
                    {formatCurrency(totalValue)}
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  if (!loggedCustomer) {
                    onRequireLogin();
                  } else {
                    // Pre-fill fields automatically with logged customer's details
                    if (!receiver) setReceiver(`${loggedCustomer.firstName} ${loggedCustomer.lastName}`);
                    if (!zipCode) setZipCode(loggedCustomer.zipCode);
                    if (!street) setStreet(loggedCustomer.street);
                    if (!number) setNumber(loggedCustomer.number);
                    if (!neighborhood) setNeighborhood(loggedCustomer.neighborhood || '');
                    if (!city) setCity(loggedCustomer.city);
                    if (!state) setState(loggedCustomer.state);
                    
                    setStep('shipping');
                  }
                }}
                className="w-full flex items-center justify-center gap-2 py-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider shadow-lg transition-all"
              >
                Prosseguir para Entrega
                <ChevronRight className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
