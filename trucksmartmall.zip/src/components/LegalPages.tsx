import React, { useState } from 'react';
import { Shield, FileText, ArrowLeft, Clock, Scale, Eye, HelpCircle } from 'lucide-react';

interface LegalPagesProps {
  onBack: () => void;
  initialTab?: 'terms' | 'privacy';
}

export default function LegalPages({ onBack, initialTab = 'terms' }: LegalPagesProps) {
  const [activeTab, setActiveTab] = useState<'terms' | 'privacy'>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');

  const termsSections = [
    {
      id: 'obj',
      title: '1. Objeto e Amplitude Comercial',
      content: 'A plataforma virtual TruckSmartMall opera como distribuidora integrada de autopeças, componentes mecânicos e acessórios faturados para frotas de veículos utilitários pesados. Estes termos regem a consulta, cotação faturada, contratação logística e faturamento corporativo.'
    },
    {
      id: 'cadastro',
      title: '2. Cadastro de Clientes e Segurança de Credenciais',
      content: 'Para finalização de transações faturadas, o comprador necessita realizar cadastro contendo informações fidedignas (CNPJ, CPF, Endereço de Frota, etc). O acesso é pessoal, devendo o usuário manter a segurança de sua senha alfanumérica de 6 a 11 caracteres contendo letras maiúsculas, minúsculas, números e caracteres especiais.'
    },
    {
      id: 'logistica',
      title: '3. Política Logística de Despacho Imediato',
      content: 'O prazo do despacho inicia-se imediatamente após a confirmação do pagamento pelo gateway adquirente escolhido. Os produtos são embalados com proteção reforçada de padrão industrial contra impactos no transporte.'
    },
    {
      id: 'devolucao',
      title: '4. Trocas, Garantia e Devoluções',
      content: 'Como as peças se destinam ao tráfego rodoviário de alta periculosidade, todas as peças acompanham laudo de controle de torque e fadiga metalúrgica original do fabricante. Devoluções por arrependimento seguem o estipulado no Código de Defesa do Consumidor brasileiro.'
    }
  ];

  const privacySections = [
    {
      id: 'dados',
      title: '1. Coleta e Tratamento de Dados',
      content: 'Coletamos nome, sobrenome, data de nascimento, CPF, telefone, e-mail e endereço. Os dados de endereço são facilitados e auto-preenchidos mediante integração dinâmica com a API ViaCEP, exigindo do usuário somente as variáveis adicionais específicas (número, bloco, andar e complemento).'
    },
    {
      id: 'finalidade',
      title: '2. Finalidade do Armazenamento de Dados',
      content: 'Todas as informações coletadas destinam-se unicamente ao faturamento de notas fiscais, cumprimento de requisições de transporte, análise de crédito faturado de frotas e verificações internas de antifraude.'
    },
    {
      id: 'seguranca',
      title: '3. Criptografia e Armazenamento em Cloud',
      content: 'Não armazenamos senhas corporativas em texto aberto. Os dados de faturamento trafegam por canais seguros SSL/TLS de 256 bits, impedindo a interceptação por terceiros sob rígido controle de acesso de nossos funcionários autorizados.'
    },
    {
      id: 'direitos',
      title: '4. Direitos dos Titulares de Dados (LGPD)',
      content: 'Em conformidade absoluta com a Lei Geral de Proteção de Dados (LGPD - Lei nº 13.709/2018), o comprador detém o direito irrevogável de solicitar a consulta, correção, bloqueio ou eliminação imediata de seus registros cadastrais de frota do nosso sistema no e-mail contato@smartmall577.space.'
    }
  ];

  const activeSections = activeTab === 'terms' ? termsSections : privacySections;
  const filteredSections = activeSections.filter(sec => 
    sec.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    sec.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-12" id="legal-pages-hub">
      {/* Return Back Button */}
      <button 
        onClick={onBack}
        className="flex items-center gap-2 mb-8 text-xs text-slate-400 hover:text-white font-semibold transition-all group"
      >
        <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
        Voltar para a Página de Vendas
      </button>

      {/* Hero Header */}
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl mb-8 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600" />
        <div className="space-y-2 relative z-10">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold bg-amber-500/10 border border-amber-500/25 text-amber-400 uppercase tracking-widest">
            Centro de Transparência Jurídica
          </span>
          <h1 className="text-2xl font-black text-white uppercase tracking-tight">
            CONTRATOS E PRIVACIDADE DE DADOS
          </h1>
          <p className="text-xs text-slate-405 max-w-xl">
            Abaixo, você tem acesso às diretrizes legais de compras, tratamento transparente de dados faturados sob a LGPD brasileira e obrigações mútuas da TruckSmartMall.
          </p>
        </div>

        <div className="flex gap-3 shrink-0 relative z-10">
          <div className="bg-slate-950 p-4 border border-slate-800 rounded-2xl text-center min-w-[120px]">
            <Clock className="w-5 h-5 text-amber-500 mx-auto mb-1.5" />
            <span className="block text-[10px] text-slate-500 uppercase font-bold">Última Revisão</span>
            <span className="block text-xs font-black text-white font-mono mt-0.5">Jun/2026</span>
          </div>
          <div className="bg-slate-950 p-4 border border-slate-800 rounded-2xl text-center min-w-[120px]">
            <Scale className="w-5 h-5 text-amber-500 mx-auto mb-1.5" />
            <span className="block text-[10px] text-slate-500 uppercase font-bold">Jurisdição</span>
            <span className="block text-xs font-black text-white font-mono mt-0.5">São Paulo - SP</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Navigation Sidebar */}
        <div className="w-full md:w-3/12 space-y-3">
          <button
            onClick={() => { setActiveTab('terms'); setSearchQuery(''); }}
            className={`w-full flex items-center gap-3 p-4 rounded-xl text-left border transition-all ${
              activeTab === 'terms'
                ? 'bg-amber-500/10 border-amber-500 text-white font-black'
                : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-5 h-5 text-amber-500 shrink-0" />
            <div className="text-xs uppercase tracking-wide">
              Termos de Uso
            </div>
          </button>

          <button
            onClick={() => { setActiveTab('privacy'); setSearchQuery(''); }}
            className={`w-full flex items-center gap-3 p-4 rounded-xl text-left border transition-all ${
              activeTab === 'privacy'
                ? 'bg-amber-500/10 border-amber-500 text-white font-black'
                : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-5 h-5 text-amber-500 shrink-0" />
            <div className="text-xs uppercase tracking-wide">
              Política de Privacidade
            </div>
          </button>

          <div className="p-4 bg-slate-900/50 border border-slate-850 rounded-xl space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-mono">Dúvidas Frequentes?</span>
            <p className="text-[10px] text-slate-500 leading-normal">
              Nosso suporte corporativo está à disposição de segunda a sexta para esclarecimento de conformidades.
            </p>
            <a 
              href="mailto:contato@smartmall577.space"
              className="text-[10.5px] text-amber-500 hover:underline font-bold block"
            >
              contato@smartmall577.space
            </a>
          </div>
        </div>

        {/* Content Section */}
        <div className="w-full md:w-9/12 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-800">
            <h2 className="text-lg font-black text-white uppercase flex items-center gap-2">
              {activeTab === 'terms' ? (
                <>
                  <FileText className="w-5 h-5 text-amber-500" />
                  Termos e Condições de Uso
                </>
              ) : (
                <>
                  <Shield className="w-5 h-5 text-amber-500" />
                  Diretrizes de Privacidade e LGPD
                </>
              )}
            </h2>

            {/* Keyword mini-filter */}
            <input 
              type="text" 
              placeholder="Pesquisar cláusula..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg py-1.5 px-3 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500 w-full sm:w-48"
            />
          </div>

          <div className="space-y-6">
            {filteredSections.length === 0 ? (
              <p className="text-slate-500 text-center py-8 text-xs font-semibold">Nenhuma cláusula coincide com sua busca.</p>
            ) : (
              filteredSections.map((sec) => (
                <div key={sec.id} className="p-5 bg-slate-950/70 border border-slate-850 hover:border-slate-800 rounded-2xl transition-all space-y-2">
                  <span className="text-xs font-black text-amber-500 uppercase tracking-wider block font-mono">
                    {sec.title}
                  </span>
                  <p className="text-xs text-slate-350 leading-relaxed text-justify">
                    {sec.content}
                  </p>
                </div>
              ))
            )}
          </div>

          <div className="pt-6 border-t border-slate-800 flex justify-between items-center text-[10px] text-slate-500">
            <span>© 2026 TruckSmartMall S.A.</span>
            <span className="flex items-center gap-1 font-mono text-emerald-450">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              Documento Assinado Digitalmente
            </span>
          </div>
        </div>
      </div>

    </div>
  );
}
