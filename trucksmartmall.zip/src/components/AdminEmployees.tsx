import React, { useState, useEffect } from 'react';
import { Employee } from '../types';
import { 
  Users, 
  UserPlus, 
  Mail, 
  Phone, 
  Briefcase, 
  Check, 
  Trash2, 
  ShieldCheck, 
  ShieldAlert,
  Sliders
} from 'lucide-react';

interface AdminEmployeesProps {
  employees: Employee[];
  onAddEmployee: (employee: Employee) => void;
  onRemoveEmployee: (id: string) => void;
}

export default function AdminEmployees({ employees, onAddEmployee, onRemoveEmployee }: AdminEmployeesProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('Analista de Operações');
  
  // Custom permissions state
  const [permDashboard, setPermDashboard] = useState(true);
  const [permCatalog, setPermCatalog] = useState(false);
  const [permSales, setPermSales] = useState(false);
  const [permGateways, setPermGateways] = useState(false);
  const [permEmployees, setPermEmployees] = useState(false);

  const [validationError, setValidationError] = useState('');

  const formatPhone = (value: string) => {
    const raw = value.replace(/\D/g, '');
    if (raw.length <= 10) {
      return raw
        .replace(/(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{4})(\d)/, '$1-$2')
        .substring(0, 14);
    }
    return raw
      .replace(/(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{5})(\d)/, '$1-$2')
      .substring(0, 15);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');

    if (!name.trim()) {
      setValidationError('Por favor, informe o nome completo do funcionário.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setValidationError('Por favor, informe um endereço de e-mail corporativo válido.');
      return;
    }
    if (!phone.trim()) {
      setValidationError('O telefone do colaborador é obrigatório.');
      return;
    }

    const newEmp: Employee = {
      id: `EMP-${Math.floor(100 + Math.random() * 900)}`,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      phone: phone.trim(),
      role: role.trim(),
      permissions: {
        dashboard: permDashboard,
        catalog: permCatalog,
        sales: permSales,
        gateways: permGateways,
        employees: permEmployees
      }
    };

    onAddEmployee(newEmp);

    // Reset clean form
    setName('');
    setEmail('');
    setPhone('');
    setRole('Analista de Operações');
    setPermDashboard(true);
    setPermCatalog(false);
    setPermSales(false);
    setPermGateways(false);
    setPermEmployees(false);
    setShowAddForm(false);
  };

  return (
    <div id="admin-employees-section" className="space-y-6">
      
      {/* Title Header with Counter */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 p-6 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-xl font-black text-white uppercase tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-amber-500" />
            Quadro de Funcionários
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Cadastre novos colaboradores, defina suas atribuições corporativas e controle quais funcionalidades do painel administrativo eles têm permissão para acessar.
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-lg uppercase tracking-wider transition-all"
        >
          <UserPlus className="w-4.5 h-4.5" />
          {showAddForm ? 'Cancelar Cadastro' : 'Cadastrar Funcionário'}
        </button>
      </div>

      {/* RENDER ADD EMPLOYEE FORM */}
      {showAddForm && (
        <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4 animate-fadeIn">
          <div className="border-b border-slate-800 pb-3 mb-2">
            <span className="text-xs font-black text-white uppercase tracking-wider">Ficha Cadastral de Novo Colaborador</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Nome */}
            <div>
              <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">Nome Completo *</label>
              <input 
                type="text" 
                placeholder="Ex: Carlos Eduardo de Souza"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">E-mail Corporativo *</label>
              <input 
                type="email" 
                placeholder="Ex: carlos.souza@smartmall.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Telefone */}
            <div>
              <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">Celular / Ramal *</label>
              <input 
                type="text" 
                placeholder="Ex: (11) 98111-2222"
                value={phone}
                onChange={(e) => setPhone(formatPhone(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500"
                required
              />
            </div>

            {/* Role / Função */}
            <div>
              <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">Função / Cargo *</label>
              <select 
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                <option value="Analista de Operações">Analista de Operações</option>
                <option value="Gerente Comercial Linha Pesada">Gerente Comercial Linha Pesada</option>
                <option value="Estoquista de Peças Faturadas">Estoquista de Peças Faturadas</option>
                <option value="Administrador Geral">Administrador Geral</option>
                <option value="Suporte Tecnológico">Suporte Tecnológico</option>
              </select>
            </div>
          </div>

          {/* PERMISSIONS MATRIX WITH DYNAMIC INTERACTIVE CHECKBOXES */}
          <div className="bg-slate-950 border border-slate-850 p-5 rounded-xl space-y-4">
            <div>
              <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest block mb-1">Permissões de Acesso do Funcionário</span>
              <p className="text-[10.5px] text-slate-500 leading-snug">
                Marque abaixo nos checkboxes as funcionalidades do painel administrativo super admin às quais este funcionário terá autorização de visualização e edição.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-1">
              {/* Dashboard Indicator */}
              <label className="flex items-start gap-3 p-3 bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-lg cursor-pointer select-none transition-all">
                <input 
                  type="checkbox" 
                  checked={permDashboard}
                  onChange={(e) => setPermDashboard(e.target.checked)}
                  className="mt-0.5 rounded border-slate-800 bg-slate-950 text-amber-500 focus:ring-0 focus:ring-offset-0 h-4 w-4"
                />
                <div>
                  <span className="block text-xs font-bold text-white uppercase tracking-wide">Acesso ao Dashboard</span>
                  <span className="block text-[10px] text-slate-500 font-medium">Gráficos de receitas e métricas.</span>
                </div>
              </label>

              {/* Catalog Indicator */}
              <label className="flex items-start gap-3 p-3 bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-lg cursor-pointer select-none transition-all">
                <input 
                  type="checkbox" 
                  checked={permCatalog}
                  onChange={(e) => setPermCatalog(e.target.checked)}
                  className="mt-0.5 rounded border-slate-800 bg-slate-950 text-amber-500 focus:ring-0 focus:ring-offset-0 h-4 w-4"
                />
                <div>
                  <span className="block text-xs font-bold text-white uppercase tracking-wide">Gerenciar Catálogo</span>
                  <span className="block text-[10px] text-slate-500 font-medium">Adicionar, editar estoque de peças.</span>
                </div>
              </label>

              {/* Sales Indicator */}
              <label className="flex items-start gap-3 p-3 bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-lg cursor-pointer select-none transition-all">
                <input 
                  type="checkbox" 
                  checked={permSales}
                  onChange={(e) => setPermSales(e.target.checked)}
                  className="mt-0.5 rounded border-slate-800 bg-slate-950 text-amber-500 focus:ring-0 focus:ring-offset-0 h-4 w-4"
                />
                <div>
                  <span className="block text-xs font-bold text-white uppercase tracking-wide">Aprovações Vendas</span>
                  <span className="block text-[10px] text-slate-500 font-medium">Aprovar ordens, despachar cargas.</span>
                </div>
              </label>

              {/* Gateways Indicator */}
              <label className="flex items-start gap-3 p-3 bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-lg cursor-pointer select-none transition-all">
                <input 
                  type="checkbox" 
                  checked={permGateways}
                  onChange={(e) => setPermGateways(e.target.checked)}
                  className="mt-0.5 rounded border-slate-800 bg-slate-950 text-amber-500 focus:ring-0 focus:ring-offset-0 h-4 w-4"
                />
                <div>
                  <span className="block text-xs font-bold text-white uppercase tracking-wide">Hub de Gateways</span>
                  <span className="block text-[10px] text-slate-500 font-medium">Editar credenciais de adquirentes e pix.</span>
                </div>
              </label>

              {/* Employees Indicator */}
              <label className="flex items-start gap-3 p-3 bg-slate-900 border border-slate-800 hover:border-amber-500/20 rounded-lg cursor-pointer select-none transition-all">
                <input 
                  type="checkbox" 
                  checked={permEmployees}
                  onChange={(e) => setPermEmployees(e.target.checked)}
                  className="mt-0.5 rounded border-slate-800 bg-slate-950 text-amber-500 focus:ring-0 focus:ring-offset-0 h-4 w-4"
                />
                <div>
                  <span className="block text-xs font-bold text-white uppercase tracking-wide">Quadro de Colaboradores</span>
                  <span className="block text-[10px] text-slate-500 font-medium">Cadastrar e auditar outros funcionários.</span>
                </div>
              </label>
            </div>
          </div>

          {validationError && (
            <p className="text-xs text-red-400 font-semibold bg-red-950/20 border border-red-900/40 p-2.5 rounded-lg">
              {validationError}
            </p>
          )}

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-850">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="py-2 px-4 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-bold rounded-lg uppercase tracking-wider transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="py-2 px-6 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-extrabold rounded-lg uppercase tracking-wider transition-all"
            >
              Confirmar Admissão
            </button>
          </div>
        </form>
      )}

      {/* LIST CURRENT EMPLOYEES */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="p-4 bg-slate-950 border-b border-slate-850 flex justify-between items-center">
          <span className="text-xs font-black text-slate-400 uppercase tracking-widest font-mono">Quadro Ativo ({employees.length} colaboradores)</span>
        </div>

        {employees.length === 0 ? (
          <div className="p-16 text-center text-slate-500 font-medium space-y-2">
            <div>Sem colaboradores registrados adicionais.</div>
            <p className="text-xs text-slate-600 max-w-sm mx-auto">Colaboradores adicionais configurados aparecerão listados aqui com seus respectivos níveis de permissão.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-850">
            {employees.map((emp) => (
              <div key={emp.id} className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-slate-900/50 transition-all">
                {/* Employee Main Info */}
                <div className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-amber-500 font-mono text-sm shrink-0">
                    {emp.name.split(' ').map((n) => n[0]).slice(0, 2).join('').toUpperCase()}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-xs text-white uppercase tracking-wide">{emp.name}</span>
                      <span className="text-[10px] bg-slate-800 text-amber-500 font-bold border border-slate-750 px-2.0 py-0.5 rounded">
                        {emp.role}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] font-mono text-slate-450">
                      <span className="flex items-center gap-1">
                        <Mail className="w-3.5 h-3.5 text-slate-500" />
                        {emp.email}
                      </span>
                      <span className="flex items-center gap-1">
                        <Phone className="w-3.5 h-3.5 text-slate-500" />
                        {emp.phone}
                      </span>
                      <span className="text-slate-600 font-bold text-[10px]">ID: {emp.id}</span>
                    </div>
                  </div>
                </div>

                {/* Permissions Indicators Visual Tracker */}
                <div className="flex items-center gap-3 self-start lg:self-auto border-t lg:border-t-0 border-slate-850 pt-3 lg:pt-0">
                  <div className="flex flex-wrap gap-1.5">
                    {/* Dashboard indicator badge */}
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold font-mono border ${
                      emp.permissions.dashboard 
                        ? 'bg-emerald-950/20 border-emerald-900/50 text-emerald-400' 
                        : 'bg-slate-950 border-slate-850 text-slate-600 line-through'
                    }`}>
                      Dash
                    </span>

                    {/* Catalog indicator badge */}
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold font-mono border ${
                      emp.permissions.catalog 
                        ? 'bg-emerald-950/20 border-emerald-900/50 text-emerald-400' 
                        : 'bg-slate-950 border-slate-850 text-slate-600 line-through'
                    }`}>
                      Catálogo
                    </span>

                    {/* Sales indicator badge */}
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold font-mono border ${
                      emp.permissions.sales 
                        ? 'bg-emerald-950/20 border-emerald-900/50 text-emerald-400' 
                        : 'bg-slate-950 border-slate-850 text-slate-600 line-through'
                    }`}>
                      Vendas
                    </span>

                    {/* Gateways indicator badge */}
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold font-mono border ${
                      emp.permissions.gateways 
                        ? 'bg-emerald-950/20 border-emerald-900/50 text-emerald-400' 
                        : 'bg-slate-950 border-slate-850 text-slate-600 line-through'
                    }`}>
                      Gateways
                    </span>

                    {/* Employees indicator badge */}
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold font-mono border ${
                      emp.permissions.employees 
                        ? 'bg-emerald-950/20 border-emerald-900/50 text-emerald-400' 
                        : 'bg-slate-950 border-slate-850 text-slate-600 line-through'
                    }`}>
                      Equipe
                    </span>
                  </div>

                  <button
                    onClick={() => onRemoveEmployee(emp.id)}
                    className="p-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-850 hover:border-red-900 hover:text-red-400 rounded-lg text-slate-500 transition-all ml-2"
                    title="Excluir funcionário"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
