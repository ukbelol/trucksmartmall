import React, { useState } from 'react';
import { PaymentGateway } from '../types';
import { Shield, Sparkles, AlertCircle, Save, ToggleLeft, ToggleRight, Settings, CheckCircle2, Sliders } from 'lucide-react';

interface AdminGatewaysProps {
  gateways: PaymentGateway[];
  onUpdateGateway: (gw: PaymentGateway) => void;
}

export default function AdminGateways({ gateways, onUpdateGateway }: AdminGatewaysProps) {
  const [selectedGw, setSelectedGw] = useState<PaymentGateway | null>(gateways[0]);

  // Form states matching fields
  const [apiKey, setApiKey] = useState('');
  const [clientSecret, setClientSecret] = useState('');
  const [merchantId, setMerchantId] = useState('');
  const [sandboxMode, setSandboxMode] = useState(false);
  const [additionalFields, setAdditionalFields] = useState<{ [key: string]: string }>({});

  const handleSelectGateway = (gw: PaymentGateway) => {
    setSelectedGw(gw);
    setApiKey(gw.apiKey);
    setClientSecret(gw.clientSecret);
    setMerchantId(gw.merchantId);
    setSandboxMode(gw.sandboxMode);
    setAdditionalFields({ ...gw.additionalFields });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGw) return;

    const updated: PaymentGateway = {
      ...selectedGw,
      apiKey,
      clientSecret,
      merchantId,
      sandboxMode,
      additionalFields
    };

    onUpdateGateway(updated);
    setSelectedGw(updated);
    
    // Highlight save completion
    alert(`Configurações de integração com a API do gateway ${selectedGw.name} salvas com sucesso!`);
  };

  const handleToggleActive = (gw: PaymentGateway) => {
    // Only one key gateway should act as the active gateway hub checkout for the virtual store
    const updated = { ...gw, isActive: !gw.isActive };
    onUpdateGateway(updated);
    if (selectedGw?.id === gw.id) {
      setSelectedGw(updated);
    }
  };

  return (
    <div className="space-y-6" id="admin-gateways-section">
      {/* Title */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
        <h2 className="text-lg font-black text-white uppercase tracking-tight">Configurações do Hub de Pagamentos</h2>
        <p className="text-xs text-slate-400 mt-1">Conecte as credenciais, tokens de API e chaves privadas com os principais gateways de pagamento do Brasil para transicionar as vendas.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Gateways List */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="border-b border-slate-850 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Gateways do Brasil (Top 10)</h3>
          </div>

          <div className="space-y-2.5">
            {gateways.map((gw) => (
              <div
                key={gw.id}
                onClick={() => handleSelectGateway(gw)}
                className={`flex items-center justify-between p-3.5 rounded-xl border cursor-pointer transition-all ${
                  selectedGw?.id === gw.id
                    ? 'bg-slate-950 border-amber-500 shadow'
                    : 'bg-slate-950/40 border-slate-850 hover:bg-slate-950 hover:border-slate-750'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-slate-900 border border-slate-800 text-amber-500 font-extrabold flex items-center justify-center text-xs rounded-lg select-none">
                    {gw.logo}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-100">{gw.name}</span>
                    <div className="flex items-center gap-1 mt-1 text-[9px] font-mono">
                      <span className={`w-1.5 h-1.5 rounded-full ${gw.isActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-600'}`} />
                      <span className={gw.isActive ? 'text-emerald-400' : 'text-slate-500'}>
                        {gw.isActive ? 'Gateway Ativo' : 'Desativado'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Toggle button */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleToggleActive(gw);
                  }}
                  className="p-1 hover:scale-110 active:scale-95 transition-all text-slate-400 hover:text-white"
                >
                  {gw.isActive ? (
                    <ToggleRight className="w-7 h-7 text-emerald-400" />
                  ) : (
                    <ToggleLeft className="w-7 h-7 text-slate-500" />
                  )}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Configuration Credentials Form */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6">
          {selectedGw ? (
            <form onSubmit={handleSave} className="space-y-5">
              <div className="flex items-center justify-between pb-3.5 border-b border-slate-850">
                <div className="flex items-center gap-2">
                  <Settings className="w-4 h-4 text-amber-500" />
                  <h3 className="text-xs font-black uppercase text-slate-200 tracking-wider font-mono">
                    Integração de Credenciais - {selectedGw.name}
                  </h3>
                </div>
                <span className={`px-2 py-0.5 border rounded text-[10px] font-bold ${
                  selectedGw.isActive ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-slate-800 border-slate-700 text-slate-500'
                }`}>
                  {selectedGw.isActive ? 'Produção Online' : 'Fora do Ar'}
                </span>
              </div>

              {/* Secure Token Warnings */}
              <div className="bg-slate-950 p-3.5 border border-slate-800 rounded-xl flex items-start gap-2.5 text-xs text-slate-400">
                <Shield className="w-4.5 h-4.5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-slate-300 block font-mono">Protocolo de Comunicação TLS 1.3:</span>
                  As chaves informadas abaixo trafegam de forma assinada e criptografada (SSL Ativo) com os servidores oficiais de homologação do API hub de {selectedGw.name}.
                </div>
              </div>

              {/* Input details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Copa / Merchant ID</label>
                  <input
                    type="text"
                    value={merchantId}
                    onChange={(e) => setMerchantId(e.target.value)}
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Modo de Operação</label>
                  <div className="flex items-center h-[38px] bg-slate-950 border border-slate-800 rounded-lg px-3">
                    <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-350 select-none">
                      <input
                        type="checkbox"
                        checked={sandboxMode}
                        onChange={(e) => setSandboxMode(e.target.checked)}
                        className="rounded border-slate-800 text-amber-500 focus:ring-amber-500 bg-slate-950 w-4 h-4"
                      />
                      <span>Sandbox (Modo Teste / Simulador)</span>
                    </label>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Public Key / API Token</label>
                  <input
                    type="text"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none focus:border-amber-500 transition-all font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Private Client Secret / JWT Token</label>
                  <input
                    type="password"
                    value={clientSecret}
                    onChange={(e) => setClientSecret(e.target.value)}
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none focus:border-amber-500 transition-all font-mono"
                  />
                </div>
              </div>

              {/* Dynamic Additional Fields list */}
              <div className="border-t border-slate-850 pt-4 space-y-4">
                <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest font-mono block">Outros Parâmetros de Protocolo</span>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.keys(additionalFields).map((field) => (
                    <div key={field}>
                      <label className="block text-[10px] text-slate-400 font-bold mb-1 uppercase font-mono">{field}</label>
                      <input
                        type="text"
                        value={additionalFields[field]}
                        onChange={(e) => {
                          const updated = { ...additionalFields };
                          updated[field] = e.target.value;
                          setAdditionalFields(updated);
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Submit */}
              <div className="flex justify-end pt-3">
                <button
                  type="submit"
                  className="py-3 px-6 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-lg uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md"
                >
                  <Save className="w-4 h-4 text-slate-950 stroke-[3]" />
                  Salvar Chaves API {selectedGw.name}
                </button>
              </div>
            </form>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-550 font-mono text-center text-xs">
              Selecione algum Gateway à esquerda para iniciar as configurações.
            </div>
          )}
        </div>

      </div>

      {/* NEW FEATURE: Webhooks & API Credentials Integration Help Hub */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6" id="api-integration-help-hub">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <h3 className="text-sm font-black text-white uppercase tracking-tight font-mono">Central de Ajuda da API & Webhooks do Hub</h3>
            </div>
            <p className="text-[11px] text-slate-400">Canal de orientação para habilitar as notificações automáticas de pagamento instantâneo.</p>
          </div>
          
          <div className="bg-slate-950 px-3.5 py-2 border border-slate-800 rounded-xl flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">Serviço de Escuta Webhook Ativo</span>
          </div>
        </div>

        {/* Webhook Configuration Guide */}
        <div className="bg-slate-950 p-5 border border-slate-850 rounded-2xl space-y-3">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-amber-500" />
            1. Qual URL de Webhook / Retorno de Dados cadastrar nas Instituições?
          </h4>
          <p className="text-xs text-slate-400 leading-relaxed text-justify">
            Para que nosso sistema mude o status dos pedidos automaticamente para <span className="text-emerald-400 font-bold font-mono">"Aprovado"</span> assim que o cliente pagar nas plataformas adquirentes, você deve copiar o link oficial do nosso hub de escuta abaixo e inseri-lo no campo de <span className="text-white font-bold">"URL de Notificações / Webhook / URL de Callback"</span> no painel desenvolvedor da respectiva instituição:
          </p>

          <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 font-mono mt-2">
            <div className="text-xs text-amber-400 font-black select-all break-all w-full text-center sm:text-left">
              https://truck.smartmall577.space/api/pay-hub/webhook
            </div>
            <button 
              type="button"
              onClick={() => {
                navigator.clipboard.writeText("https://truck.smartmall577.space/api/pay-hub/webhook");
                alert("URL de Webhook copiada com sucesso para a área de transferência!");
              }}
              className="px-3.5 py-1.5 bg-slate-950 text-[10.5px] font-extrabold text-slate-300 border border-slate-800 rounded-lg hover:text-white hover:border-slate-650 transition-all active:scale-95 whitespace-nowrap"
            >
              Copiar Link
            </button>
          </div>
          
          <div className="text-[10px] text-slate-500 flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5 text-slate-500" />
            <span>Nota: Você pode adicionar segurança adicional assinando a requisição com o Token Secreto gerado.</span>
          </div>
        </div>

        {/* Guides for Each Gateway */}
        <div className="space-y-4">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
            2. Como obter as credenciais das principais Instituições de Pagamento?
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Mercado Pago */}
            <div className="p-4 bg-slate-950/60 border border-slate-850 hover:border-slate-800 rounded-xl space-y-2 transition-all">
              <span className="text-xs font-black text-amber-500 uppercase tracking-widest block font-mono">Mercado Pago</span>
              <ul className="text-[11px] text-slate-400 space-y-1.5 list-disc pl-4">
                <li>Acesse o portal oficial do <a href="https://developers.mercadopago.com" target="_blank" rel="noopener noreferrer" className="text-amber-400 underline inline-flex items-center gap-0.5">Mercado Pago Developers</a>.</li>
                <li>Faça o login em sua conta e crie uma nova "Aplicação de Venda On-line".</li>
                <li>No menu lateral esquerdo, acesse <span className="text-slate-200">"Credenciais de Produção"</span>.</li>
                <li>Copie o seu <span className="text-slate-200 font-bold">Access Token</span> (para usar como API Key) e o seu <span className="text-slate-200">Client Secret</span>.</li>
              </ul>
            </div>

            {/* Cielo */}
            <div className="p-4 bg-slate-950/60 border border-slate-850 hover:border-slate-800 rounded-xl space-y-2 transition-all">
              <span className="text-xs font-black text-amber-500 uppercase tracking-widest block font-mono">Cielo LIO / Ecommerce</span>
              <ul className="text-[11px] text-slate-400 space-y-1.5 list-disc pl-4">
                <li>Visite o site do <a href="https://develop.cielo.com.br" target="_blank" rel="noopener noreferrer" className="text-amber-400 underline inline-flex items-center gap-0.5">Cielo Developers</a>.</li>
                <li>Cadastre-se ou entre com a conta credenciada do estabelecimento comercial.</li>
                <li>Crie uma chave de API para obter o <span className="text-slate-200 font-bold">Merchant ID</span> e o <span className="text-slate-200 font-bold">Merchant Key</span>.</li>
                <li>Ative o recebimento de notificações no gerenciador de webhooks do painel.</li>
              </ul>
            </div>

            {/* PagBank */}
            <div className="p-4 bg-slate-950/60 border border-slate-850 hover:border-slate-800 rounded-xl space-y-2 transition-all">
              <span className="text-xs font-black text-amber-500 uppercase tracking-widest block font-mono">PagBank (PagSeguro)</span>
              <ul className="text-[11px] text-slate-400 space-y-1.5 list-disc pl-4">
                <li>Acesse a sua conta comercial no Painel do Pagseguro.</li>
                <li>Navegue até <span className="text-slate-200">Vendas Online {">"} Integrações</span>.</li>
                <li>Clique no botão <span className="text-slate-250 font-bold">"Gerar Token"</span> para extrair o código alfanumérico.</li>
                <li>Insira o Token gerado no campo Public Key / API Token do formulário acima.</li>
              </ul>
            </div>

            {/* Rede */}
            <div className="p-4 bg-slate-950/60 border border-slate-850 hover:border-slate-800 rounded-xl space-y-2 transition-all">
              <span className="text-xs font-black text-amber-500 uppercase tracking-widest block font-mono">Rede (Itaú)</span>
              <ul className="text-[11px] text-slate-400 space-y-1.5 list-disc pl-4">
                <li>Entre na plataforma dedicada Rede Dev (user.userede.com.br).</li>
                <li>Gere as chaves de integração V3 para o seu Número de Estabelecimento (PV).</li>
                <li>Insira o Número do PV no campo <span className="text-slate-200">Merchant ID</span> e configure as chaves privadas do Token JWT correspondentes.</li>
              </ul>
            </div>

            {/* Stone / Pagar me */}
            <div className="p-4 bg-slate-950/60 border border-slate-850 hover:border-slate-800 rounded-xl space-y-2 transition-all">
              <span className="text-xs font-black text-amber-500 uppercase tracking-widest block font-mono">Stone Pagamentos & Pagar.me</span>
              <ul className="text-[11px] text-slate-400 space-y-1.5 list-disc pl-4">
                <li>Faça o login em sua conta integrada na Stone ou no portal do parceiro.</li>
                <li>Vá até as Configurações de API e localize as credenciais corporativas.</li>
                <li>O <span className="text-slate-200">Stone Code</span> da sua distribuidora deve ser informado no Merchant ID e a Secret Key preenchida respectivamente.</li>
              </ul>
            </div>

            {/* Outros Gateways */}
            <div className="p-4 bg-slate-950/60 border border-slate-850 hover:border-slate-800 rounded-xl space-y-2 transition-all">
              <span className="text-xs font-black text-amber-500 uppercase tracking-widest block font-mono">Asaas, Getnet, Safe2Pay, PicPay</span>
              <ul className="text-[11px] text-slate-400 space-y-1.5 list-disc pl-4">
                <li><span className="text-white font-bold opacity-90">Asaas:</span> Acesse Minha Conta {">"} Integrações e gere a chave de API de Produção.</li>
                <li><span className="text-white font-bold opacity-90">PicPay:</span> Acesse o Painel Lojista para obter o link "Seller Token" de faturamento.</li>
                <li><span className="text-white font-bold opacity-90">Getnet:</span> Solicite acesso ao Getnet Sandbox/Produção para gerar ClientID e ClientSecret corporativos.</li>
              </ul>
            </div>

          </div>
        </div>
      </div>

    </div>
  );
}
