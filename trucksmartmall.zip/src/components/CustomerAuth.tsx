import React, { useState } from 'react';
import { Customer } from '../types';
import { 
  User, 
  Lock, 
  Mail, 
  Phone, 
  Calendar, 
  MapPin, 
  Hash, 
  Sparkles, 
  Check, 
  AlertCircle, 
  ArrowLeft, 
  Search, 
  Eye, 
  EyeOff,
  UserPlus,
  LogIn
} from 'lucide-react';

interface CustomerAuthProps {
  onLoginSuccess: (customer: Customer) => void;
  onCancel: () => void;
  initialMode?: 'login' | 'register';
}

export default function CustomerAuth({ onLoginSuccess, onCancel, initialMode = 'login' }: CustomerAuthProps) {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  
  // Login State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Register Form State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [cpf, setCpf] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Register Address Form State
  const [zipCode, setZipCode] = useState('');
  const [street, setStreet] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  
  // Custom required inputs
  const [number, setNumber] = useState('');
  const [block, setBlock] = useState('');
  const [floor, setFloor] = useState('');
  const [complement, setComplement] = useState('');

  // Status & Validation
  const [isSearchingCep, setIsSearchingCep] = useState(false);
  const [cepSuccess, setCepSuccess] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [registerSuccessMessage, setRegisterSuccessMessage] = useState('');

  // Helper formats
  const formatCPF = (value: string) => {
    const raw = value.replace(/\D/g, '');
    return raw
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d)/, '$1.$2')
      .replace(/(\d{3})(\d{1,2})$/, '$1-$2')
      .substring(0, 14);
  };

  const formatCEP = (value: string) => {
    const raw = value.replace(/\D/g, '');
    return raw
      .replace(/(\d{5})(\d)/, '$1-$2')
      .substring(0, 9);
  };

  const formatPhone = (value: string) => {
    const raw = value.replace(/\D/g, '');
    if (raw.length <= 10) {
      return raw
        .replace(/(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{4})(\d)/, '$1-$2')
        .substring(0, 14);
    }
    return raw
      .replace(/(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{5})(\d)/, '$1-$2')
      .substring(0, 15);
  };

  // ViaCEP look up API
  const handleSearchCep = async (cepValue: string) => {
    const cleanCep = cepValue.replace(/\D/g, '');
    if (cleanCep.length !== 8) return;

    setIsSearchingCep(true);
    setCepSuccess(false);
    try {
      const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await response.json();
      
      if (data.erro) {
        alert('CEP não encontrado. Por favor, verifique ou preencha manualmente.');
        setIsSearchingCep(false);
        return;
      }

      setStreet(data.logradouro || '');
      setNeighborhood(data.bairro || '');
      setCity(data.localidade || '');
      setState(data.uf || '');
      setCepSuccess(true);
    } catch (err) {
      console.error('Error fetching CEP:', err);
    } finally {
      setIsSearchingCep(false);
    }
  };

  const handleCepChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCEP(e.target.value);
    setZipCode(formatted);
    const clean = formatted.replace(/\D/g, '');
    if (clean.length === 8) {
      handleSearchCep(clean);
    }
  };

  const validatePassword = (pwd: string): string[] => {
    const errors: string[] = [];
    if (pwd.length < 6 || pwd.length > 11) {
      errors.push('A senha deve ter entre 6 e 11 caracteres.');
    }
    if (!/[A-Z]/.test(pwd)) {
      errors.push('A senha deve conter pelo menos uma letra maiúscula.');
    }
    if (!/[a-z]/.test(pwd)) {
      errors.push('A senha deve conter pelo menos uma letra minúscula.');
    }
    if (!/\d/.test(pwd)) {
      errors.push('A senha deve conter pelo menos um número.');
    }
    if (!/[!@#$%^&*(),.?":{}|<>_+\-\[\]\\\/]/.test(pwd)) {
      errors.push('A senha deve conter pelo menos um caractere especial (ex: !, @, #, $, %).');
    }
    return errors;
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: string[] = [];

    // Fields checked
    if (!firstName.trim()) errors.push('O Nome é obrigatório.');
    if (!lastName.trim()) errors.push('O Sobrenome é obrigatório.');
    if (!birthDate) errors.push('A Data de Nascimento é obrigatória.');
    if (!phone) errors.push('O Telefone é obrigatório.');
    if (!email.trim()) errors.push('O E-mail é obrigatório.');
    if (!cpf) errors.push('O CPF é obrigatório.');
    if (!zipCode) errors.push('O CEP é obrigatório.');
    if (!street.trim()) errors.push('O Endereço/Logradouro é obrigatório.');
    if (!number.trim()) errors.push('O Número do logradouro é obrigatório.');

    // Password validation errors check
    const pwdErrors = validatePassword(password);
    errors.push(...pwdErrors);

    if (errors.length > 0) {
      setValidationErrors(errors);
      return;
    }

    // Build the Customer profile
    const newCustomer: Customer = {
      id: `CLI-${Math.floor(100000 + Math.random() * 900000)}`,
      firstName,
      lastName,
      birthDate,
      phone,
      email: email.toLowerCase().trim(),
      cpf,
      zipCode,
      street,
      number,
      neighborhood,
      city,
      state,
      block,
      floor,
      complement,
      password // storing simulated
    };

    // Store in localStorage list of customers
    const existingCustomersStr = localStorage.getItem('tsm_customers_database');
    const existingCustomers: Customer[] = existingCustomersStr ? JSON.parse(existingCustomersStr) : [];
    
    // Check key duplicate
    if (existingCustomers.some(c => c.email === newCustomer.email)) {
      setValidationErrors(['Este endereço de e-mail já está cadastrado em nosso sistema.']);
      return;
    }

    existingCustomers.push(newCustomer);
    localStorage.setItem('tsm_customers_database', JSON.stringify(existingCustomers));

    setRegisterSuccessMessage('Cadastro concluído com sucesso!');
    setValidationErrors([]);
    
    // Auto-login
    setTimeout(() => {
      onLoginSuccess(newCustomer);
    }, 1500);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    if (!loginEmail.trim() || !loginPassword) {
      setLoginError('Por favor, informe seu e-mail e sua senha corporativa.');
      return;
    }

    // Get list of registered customers
    const existingCustomersStr = localStorage.getItem('tsm_customers_database');
    const existingCustomers: Customer[] = existingCustomersStr ? JSON.parse(existingCustomersStr) : [];

    // Find custom customer entry
    const found = existingCustomers.find(
      c => c.email.toLowerCase() === loginEmail.toLowerCase().trim() && c.password === loginPassword
    );

    if (found) {
      onLoginSuccess(found);
    } else {
      // Allow fallback default local storage demo credentials for super easy testing!
      if (loginEmail.toLowerCase().trim() === 'comprador@smartapp.com' && loginPassword === 'Mago577@') {
        const defaultDemoCustomerObj: Customer = {
          id: 'CLI-DEMO-01',
          firstName: 'Ricardo',
          lastName: 'Mecânico de Frotas',
          birthDate: '1985-11-20',
          phone: '(11) 98765-4321',
          email: 'comprador@smartapp.com',
          cpf: '123.456.789-00',
          zipCode: '01310-100',
          street: 'Avenida Paulista',
          number: '1000',
          neighborhood: 'Bela Vista',
          city: 'São Paulo',
          state: 'SP',
          block: 'A',
          floor: '5° andar',
          complement: 'Oficina Central'
        };
        onLoginSuccess(defaultDemoCustomerObj);
      } else {
        setLoginError('E-mail do cliente ou senha incorreta. Tente novamente ou cadastre uma conta.');
      }
    }
  };

  const fillQuickDemo = () => {
    setFirstName('Wellington');
    setLastName('Oliveira');
    setBirthDate('1990-05-14');
    setPhone('(11) 99999-5678');
    setEmail(`comprador${Math.floor(Math.random() * 999)}@smartmall577.space`);
    setCpf('456.789.012-34');
    setZipCode('04571-010');
    setPassword('Truck789@');
    
    // Auto lookup ViaCEP
    setIsSearchingCep(true);
    fetch('https://viacep.com.br/ws/04571010/json/')
      .then(res => res.json())
      .then(data => {
        setStreet(data.logradouro || '');
        setNeighborhood(data.bairro || '');
        setCity(data.localidade || '');
        setState(data.uf || '');
        setNumber('1305');
        setBlock('B');
        setFloor('7');
        setComplement('Conjunto 702');
        setCepSuccess(true);
      })
      .catch(() => {})
      .finally(() => setIsSearchingCep(false));
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12" id="customer-auth-container">
      {/* Return back buttons */}
      <button 
        onClick={onCancel}
        className="flex items-center gap-2 mb-8 text-xs text-slate-400 hover:text-white font-semibold transition-all group"
      >
        <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
        Voltar para a Página de Vendas
      </button>

      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row min-h-[600px]">
        {/* Decorative dynamic banner leftside */}
        <div className="w-full md:w-5/12 bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 p-8 flex flex-col justify-between border-r border-slate-800 relative">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent opacity-70" />
          
          <div className="space-y-4 relative z-10">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black bg-amber-500/15 border border-amber-500/25 text-amber-400 uppercase tracking-widest">
              Identificação de Frota
            </span>
            <h2 className="text-2xl font-black text-white leading-tight uppercase">
              ÁREA EXCLUSIVA <br />DO COMPRADOR
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Faça login ou cadastre sua empresa para gerenciar ordens de reposição faturadas, rastrear despachos imediatos na transportadora e obter descontos corporativos.
            </p>
          </div>

          <div className="space-y-4 pt-8 relative z-10">
            <div className="bg-slate-950/80 p-4 border border-slate-850 rounded-2xl space-y-1.5 text-xs text-slate-400 font-mono">
              <span className="text-[10px] font-bold text-amber-500 uppercase">Acesso Rápido Simulado</span>
              <p className="text-[11px] leading-snug">Se já tem conta cadastrada ou quer testar instantaneamente, use:</p>
              <div className="pt-2 text-[10px] space-y-1 text-slate-350 bg-slate-900/50 p-2 rounded border border-slate-800">
                <div>E-mail: <strong className="text-white">comprador@smartapp.com</strong></div>
                <div>Senha: <strong className="text-white">Mago577@</strong></div>
              </div>
            </div>
            
            <div className="text-[10px] text-slate-500 font-mono">
              © TruckSmartMall - Security Hub v2.6
            </div>
          </div>
        </div>

        {/* Dynamic Client Form Side */}
        <div className="w-full md:w-7/12 p-8 sm:p-10 flex flex-col justify-center">
          
          {/* Mode switch header */}
          <div className="flex border-b border-slate-800 pb-5 mb-6 justify-between items-center bg-slate-900">
            <div className="flex gap-4">
              <button
                onClick={() => { setMode('login'); setValidationErrors([]); setLoginError(''); }}
                className={`text-sm font-extrabold uppercase tracking-wide pb-2 transition-all ${
                  mode === 'login' 
                    ? 'border-b-2 border-amber-500 text-white' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Já tenho conta
              </button>
              <button
                onClick={() => { setMode('register'); setValidationErrors([]); setLoginError(''); }}
                className={`text-sm font-extrabold uppercase tracking-wide pb-2 transition-all ${
                  mode === 'register' 
                    ? 'border-b-2 border-amber-500 text-white' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Criar novo cadastro
              </button>
            </div>

            {mode === 'register' && (
              <button
                type="button"
                onClick={fillQuickDemo}
                className="text-[10px] font-black text-amber-500 hover:text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-md"
              >
                Gerar Cliente Fictício
              </button>
            )}
          </div>

          {/* RENDER LOGIN */}
          {mode === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-5 animate-fadeIn">
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">Endereço de E-mail</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                      <Mail className="w-4 h-4 text-slate-550" />
                    </span>
                    <input 
                      type="email" 
                      placeholder="seu.nome@empresa.com"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1.5">Senha de Acesso</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                      <Lock className="w-4 h-4 text-slate-550" />
                    </span>
                    <input 
                      type={showLoginPassword ? 'text' : 'password'} 
                      placeholder="Digite sua senha cadastrada"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-10 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPassword(!showLoginPassword)}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-white transition-all"
                    >
                      {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              {loginError && (
                <div className="bg-red-955/20 border border-red-900/45 p-3 rounded-xl text-xs text-red-400 font-medium flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
                  <span>{loginError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider transition-all shadow-md"
              >
                <LogIn className="w-4 h-4" />
                Acessar Minha Conta
              </button>
            </form>
          ) : (
            /* RENDER REGISTER */
            <form onSubmit={handleRegisterSubmit} className="space-y-5 animate-fadeIn">
              
              {registerSuccessMessage ? (
                <div className="bg-emerald-950/40 border border-emerald-900 p-6 rounded-2xl text-center space-y-3 animate-pulse">
                  <div className="w-12 h-12 rounded-full bg-emerald-500/15 border-2 border-emerald-500 flex items-center justify-center mx-auto text-emerald-400">
                    <Check className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <h4 className="text-base font-bold text-white uppercase">{registerSuccessMessage}</h4>
                  <p className="text-xs text-slate-400">Efetuando login automático em instantes...</p>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Nome */}
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Nome *</label>
                      <input 
                        type="text" 
                        placeholder="Ex: Wellington"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        required
                      />
                    </div>
                    {/* Sobrenome */}
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Sobrenome *</label>
                      <input 
                        type="text" 
                        placeholder="Ex: Oliveira"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Data de Nascimento */}
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Data de Nascimento *</label>
                      <div className="relative">
                        <input 
                          type="date" 
                          value={birthDate}
                          onChange={(e) => setBirthDate(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 pr-8 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500 scheme-dark"
                          required
                        />
                      </div>
                    </div>
                    {/* Telefone */}
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Telefone *</label>
                      <input 
                        type="text" 
                        placeholder="(11) 98765-4321"
                        value={phone}
                        onChange={(e) => setPhone(formatPhone(e.target.value))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* E-mail */}
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">E-mail *</label>
                      <input 
                        type="email" 
                        placeholder="seu.email@empresa.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        required
                      />
                    </div>
                    {/* CPF */}
                    <div>
                      <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">CPF *</label>
                      <input 
                        type="text" 
                        placeholder="000.000.000-00"
                        value={cpf}
                        onChange={(e) => setCpf(formatCPF(e.target.value))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        required
                      />
                    </div>
                  </div>

                  {/* ENDEREÇO COM VIA CEP INTEGRATION */}
                  <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-3.5">
                    <span className="text-[10px] font-bold text-amber-500 uppercase tracking-wider block border-b border-slate-850 pb-1.5">
                      Endereço de Faturamento / Entrega
                    </span>

                    <div className="grid grid-cols-3 gap-3">
                      <div className="col-span-2">
                        <label className="block text-[9px] text-slate-450 font-bold uppercase mb-1">Buscar por CEP *</label>
                        <div className="relative">
                          <input 
                            type="text" 
                            placeholder="00000-000"
                            value={zipCode}
                            onChange={handleCepChange}
                            className="w-full bg-slate-900 border border-slate-750 rounded-md p-2 pl-8 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500"
                            required
                          />
                          <span className="absolute inset-y-0 left-0 flex items-center pl-2.5">
                            {isSearchingCep ? (
                              <div className="w-3.5 h-3.5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
                            ) : (
                              <Search className="w-3.5 h-3.5 text-slate-500" />
                            )}
                          </span>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[9px] text-slate-450 font-bold uppercase mb-1">UF / Estado</label>
                        <input 
                          type="text" 
                          placeholder="Ex: SP"
                          value={state}
                          readOnly
                          className="w-full bg-slate-900/50 border border-slate-800 rounded-md p-2 text-xs text-slate-400 uppercase text-center focus:outline-none font-bold"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[9px] text-slate-450 font-bold uppercase mb-1">Cidade</label>
                        <input 
                          type="text" 
                          placeholder="Cidade Auto"
                          value={city}
                          readOnly
                          className="w-full bg-slate-900/50 border border-slate-800 rounded-md p-2 text-xs text-slate-400 focus:outline-none font-medium"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] text-slate-450 font-bold uppercase mb-1">Bairro</label>
                        <input 
                          type="text" 
                          placeholder="Bairro Auto"
                          value={neighborhood}
                          readOnly
                          className="w-full bg-slate-900/50 border border-slate-800 rounded-md p-2 text-xs text-slate-400 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[9px] text-slate-450 font-bold uppercase mb-1">Rua / Logradouro</label>
                      <input 
                        type="text" 
                        placeholder="Logradouro Auto"
                        value={street}
                        readOnly
                        className="w-full bg-slate-900/50 border border-slate-800 rounded-md p-2 text-xs text-slate-400 focus:outline-none"
                      />
                    </div>

                    {/* CLIENT ONLY HAS TO PROVIDE NUMBER, BLOCK, FLOOR, AND COMPLEMENT */}
                    <div className="grid grid-cols-4 gap-2.5">
                      <div>
                        <label className="block text-[9px] text-amber-400 font-bold uppercase mb-1">Número *</label>
                        <input 
                          type="text" 
                          placeholder="Ex: 577"
                          value={number}
                          onChange={(e) => setNumber(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-md p-2 text-xs text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500 font-bold"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] text-slate-450 font-bold uppercase mb-1">Bloco</label>
                        <input 
                          type="text" 
                          placeholder="Ex: A"
                          value={block}
                          onChange={(e) => setBlock(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-md p-2 text-xs text-slate-100 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] text-slate-450 font-bold uppercase mb-1">Andar</label>
                        <input 
                          type="text" 
                          placeholder="Ex: 3"
                          value={floor}
                          onChange={(e) => setFloor(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-md p-2 text-xs text-slate-100 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] text-slate-450 font-bold uppercase mb-1">Complemento</label>
                        <input 
                          type="text" 
                          placeholder="Ex: Apt 32"
                          value={complement}
                          onChange={(e) => setComplement(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-md p-2 text-xs text-slate-100 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* SENHA COLETOR */}
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Senha de Acesso Comercial *</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                        <Lock className="w-4 h-4 text-slate-550" />
                      </span>
                      <input 
                        type={showPassword ? 'text' : 'password'} 
                        placeholder="Senha (mín. 6, máx. 11 carac.)"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2.5 pl-10 pr-10 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        required
                        maxLength={11}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-550 hover:text-white transition-all"
                      >
                        {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                      </button>
                    </div>
                    {/* Password criteria helpful box */}
                    <div className="bg-slate-950/20 p-3 rounded-lg border border-slate-850 mt-1.5 space-y-1 text-[10px] text-slate-450 leading-relaxed font-mono">
                      <div>Exigências de formato de segurança:</div>
                      <div className="flex flex-wrap gap-x-3 gap-y-1 pt-1">
                        <span className={`inline-flex items-center gap-1 ${password.length >= 6 && password.length <= 11 ? 'text-emerald-400' : 'text-slate-550'}`}>
                          ● {password.length >= 6 && password.length <= 11 ? '✔' : ' '} 6 a 11 carac.
                        </span>
                        <span className={`inline-flex items-center gap-1 ${/[A-Z]/.test(password) ? 'text-emerald-400' : 'text-slate-550'}`}>
                          ● {/[A-Z]/.test(password) ? '✔' : ' '} 1 Maiúscula
                        </span>
                        <span className={`inline-flex items-center gap-1 ${/[a-z]/.test(password) ? 'text-emerald-400' : 'text-slate-550'}`}>
                          ● {/[a-z]/.test(password) ? '✔' : ' '} 1 Minúscula
                        </span>
                        <span className={`inline-flex items-center gap-1 ${/\d/.test(password) ? 'text-emerald-400' : 'text-slate-550'}`}>
                          ● {/\d/.test(password) ? '✔' : ' '} 1 Número
                        </span>
                        <span className={`inline-flex items-center gap-1 ${/[!@#$%^&*(),.?":{}|<>_+\-\[\]\\\/]/.test(password) ? 'text-emerald-400' : 'text-slate-550'}`}>
                          ● {/[!@#$%^&*(),.?":{}|<>_+\-\[\]\\\/]/.test(password) ? '✔' : ' '} 1 Carac. Especial
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* VALIDATION FEEDBACKS */}
                  {validationErrors.length > 0 && (
                    <div className="bg-red-955/20 border border-red-900/40 p-4 rounded-xl space-y-1 text-xs text-red-400">
                      <div className="font-bold flex items-center gap-1.5 text-red-500 mb-1">
                        <AlertCircle className="w-4.5 h-4.5 text-red-500" />
                        Erros de Validação:
                      </div>
                      <ul className="list-disc pl-5 space-y-0.5 text-[11px] leading-relaxed">
                        {validationErrors.map((msg, idx) => (
                          <li key={idx}>{msg}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider transition-all shadow-md"
                  >
                    <UserPlus className="w-4.5 h-4.5" />
                    Finalizar Cadastro e Entrar
                  </button>
                </>
              )}
            </form>
          )}

        </div>
      </div>
    </div>
  );
}
