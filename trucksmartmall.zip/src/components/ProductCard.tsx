import React, { useState } from 'react';
import { Product } from '../types';
import { ShoppingCart, Check, Info, ShieldCheck, Layers, Wrench } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  isInCart: boolean;
  key?: string;
}

export default function ProductCard({ product, onAddToCart, isInCart }: ProductCardProps) {
  const [showSpecs, setShowSpecs] = useState(false);
  const [imgError, setImgError] = useState(false);

  // Formats to Brazil currency: R$ X.XXX,XX
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(val);
  };

  const getStockBadgeColor = (qty: number) => {
    if (qty === 0) return 'bg-red-500/10 border-red-500/40 text-red-500';
    if (qty <= 5) return 'bg-amber-500/10 border-amber-500/40 text-amber-500 animate-pulse';
    return 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400';
  };

  const formattedPrice = formatCurrency(product.price);

  return (
    <div className="group relative bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg transition-all hover:translate-y-[-4px] hover:shadow-amber-500/10 hover:border-slate-700 flex flex-col h-full" id={`product-${product.id}`}>
      {/* Product Image and Badges */}
      <div className="relative pt-[70%] bg-slate-950 overflow-hidden">
        {imgError ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950 border-b border-slate-800 text-slate-500">
            <Wrench className="w-12 h-12 stroke-[1.2] text-amber-500/60 mb-2 animate-pulse" />
            <span className="text-xs uppercase font-mono tracking-wider">Peça TruckSmartMall</span>
          </div>
        ) : (
          <img
            src={product.imageUrl}
            alt={product.name}
            onError={() => setImgError(true)}
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        )}

        {/* Brand Tag Ribbon */}
        <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-md border border-slate-700 text-amber-400 text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded">
          {product.brand}
        </div>

        {/* Category Badge */}
        <div className="absolute bottom-3 left-3 bg-amber-500 text-slate-950 text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
          {product.category}
        </div>

        {/* Stock Level Badge */}
        <div className={`absolute top-3 right-3 border px-2.5 py-0.5 rounded text-[10px] font-bold uppercase ${getStockBadgeColor(product.stock)}`}>
          {product.stock === 0 ? 'Esgotado' : product.stock <= 5 ? `Últimas ${product.stock} peças` : 'Em Estoque'}
        </div>
      </div>

      {/* Content Area */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Product Title */}
          <h3 className="text-sm font-semibold text-slate-100 hover:text-amber-400 line-clamp-2 leading-snug transition-colors min-h-10">
            {product.name}
          </h3>

          {/* OEM reference */}
          <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono text-slate-400 select-all">
            <span>Cód. OEM: {product.specifications.oemCode || 'N/A'}</span>
          </div>

          {/* Description */}
          <p className="mt-3 text-xs text-slate-400 line-clamp-3 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Bottom controls */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 space-y-3">
          
          {/* Price display */}
          <div className="flex items-baseline justify-between">
            <span className="text-[10px] text-slate-500 font-mono uppercase">Preço Unitário</span>
            <span className="text-xl font-extrabold text-white tracking-tight">
              {formattedPrice}
            </span>
          </div>

          {/* Toggleable Technical Details */}
          <div>
            <button
              onClick={() => setShowSpecs(!showSpecs)}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 text-slate-400 hover:text-amber-400 text-[11px] font-semibold tracking-wider uppercase border border-slate-800 rounded bg-slate-950/40 hover:bg-slate-950 transition-all font-mono"
            >
              <Info className="w-3.5 h-3.5" />
              {showSpecs ? 'Ocultar Detalhes' : 'Especificações Técnicas'}
            </button>

            {showSpecs && (
              <div className="mt-2.5 p-3 bg-slate-950 rounded-lg text-[11px] text-slate-350 space-y-2 border border-slate-850 animate-fadeIn font-mono">
                <div>
                  <span className="text-slate-500 block">COMPATIBILIDADE:</span>
                  <span className="text-slate-300 font-sans">{product.specifications.compatibility}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 border-t border-slate-900 pt-2">
                  <div>
                    <span className="text-slate-500 block">PESO:</span>
                    <span className="text-white">{product.specifications.weight}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">GARANTIA:</span>
                    <span className="text-white">{product.specifications.warranty}</span>
                  </div>
                </div>
                <div className="border-t border-slate-900 pt-2">
                  <span className="text-slate-500 block">CONSTRUÇÃO:</span>
                  <span className="text-slate-300 font-sans text-[10px]">{product.specifications.material}</span>
                </div>
              </div>
            )}
          </div>

          {/* Buy Action Button */}
          {product.stock === 0 ? (
            <button
              disabled
              className="w-full flex items-center justify-center gap-2 py-3 bg-slate-800 text-slate-500 text-xs font-bold tracking-wider uppercase rounded-lg cursor-not-allowed border border-slate-750"
            >
              Fora de Estoque
            </button>
          ) : (
            <button
              onClick={() => onAddToCart(product)}
              className={`w-full flex items-center justify-center gap-2 py-3 rounded-lg text-xs font-extrabold tracking-wider uppercase shadow-md transition-all active:scale-[0.98] ${
                isInCart
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-500'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950 hover:shadow-amber-500/10'
              }`}
            >
              {isInCart ? (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  Adicionado à Sacola
                </>
              ) : (
                <>
                  <ShoppingCart className="w-4 h-4" />
                  Adicionar ao Carrinho
                </>
              )}
            </button>
          )}

        </div>
      </div>
    </div>
  );
}
