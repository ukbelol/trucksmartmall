import React, { useState, useEffect, useRef } from 'react';
import { Search, Truck, Settings, Sparkles, X, ChevronDown, Check, FileText, ShoppingBag } from 'lucide-react';
import { Product } from '../types';

interface AdvancedSearchFilterProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  cartItems: { product: Product; quantity: number }[];
  // If we want to synchronize with the parent App filters so that both lists match:
  externalBrand?: string;
  setExternalBrand?: (brand: string) => void;
}

// Popular truck and tractor models categorized by brand for smart autocomplete suggestions
const MODELS_BY_BRAND: { [key: string]: string[] } = {
  'Scania': ['R440', 'R450', 'G440', 'G480', 'R480', 'Streamline', 'R540', 'S500', 'P310', 'P360', 'R124', 'G380', 'G420'],
  'Volvo': ['FH 460', 'FH 540', 'FM 370', 'VM 270', 'VM 330', 'FMX 500', 'NL12', 'FH12', 'FH13', 'VM 220', 'VM 260'],
  'Mercedes-Benz': ['Axor 2544', 'Axor 2644', 'Actros 2546', 'Actros 2646', 'Atego 1719', 'Atego 2426', 'Accelo 815', 'Accelo 1016', '1113', '1620', 'Atron 2729', 'Atego 2430'],
  'DAF': ['XF105', 'CF85', 'XF 530', 'CF 340', 'XF106', 'CF65', 'LF45'],
  'Volkswagen': ['Constellation 19.320', 'Constellation 24.250', 'Constellation 24.280', 'Delivery 9.170', 'Delivery 11.180', 'Meteor 29.520', 'Constellation 17.190', 'Delivery 11.180 Prime', 'Meteor 28.460'],
  'Iveco': ['Stralis 380', 'Stralis 410', 'Tector 240E25', 'Tector 240E28', 'Hi-Way 440', 'Daily 30-130', 'Vertis 90V18', 'Stralis Active'],
  'Ford': ['Cargo 2422', 'Cargo 2428', 'Cargo 2628', 'Cargo 2429', 'Cargo 2842', 'F-4000', 'Cargo 815', 'Cargo 1119'],
  'John Deere': ['5078E', '6125J', '7200J', '5090E', '8R 370', '6110J'],
  'Massey Ferguson': ['MF 4275', 'MF 275', 'MF 7722', 'MF 4707'],
  'Valtra': ['BH 180', 'BH 194', 'A950', 'Valmet 785', 'Valmet 885'],
  'New Holland': ['T7.240', 'T7.245', 'T6.130', 'TS6.120', '7630'],
  'Case IH': ['Farmall 80', 'Farmall 95', 'Puma 200', 'Puma 220', 'Magnum 340']
};

export default function AdvancedSearchFilter({
  products,
  onAddToCart,
  cartItems,
  externalBrand,
  setExternalBrand
}: AdvancedSearchFilterProps) {
  // Brand selection state
  const [selectedBrand, setSelectedBrand] = useState('Todas');
  
  // Model search state with autocomplete
  const [modelInput, setModelInput] = useState('');
  const [filteredModels, setFilteredModels] = useState<string[]>([]);
  const [showModelSuggestions, setShowModelSuggestions] = useState(false);

  // Part name/type state with autocomplete
  const [partInput, setPartInput] = useState('');
  const [filteredParts, setFilteredParts] = useState<string[]>([]);
  const [showPartSuggestions, setShowPartSuggestions] = useState(false);

  const modelRef = useRef<HTMLDivElement>(null);
  const partRef = useRef<HTMLDivElement>(null);

  // Sync with external brand clicks if any
  useEffect(() => {
    if (externalBrand !== undefined && externalBrand !== selectedBrand) {
      setSelectedBrand(externalBrand);
      setModelInput('');
    }
  }, [externalBrand]);

  // Handle external clicks to dismiss autocompletes
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (modelRef.current && !modelRef.current.contains(event.target as Node)) {
        setShowModelSuggestions(false);
      }
      if (partRef.current && !partRef.current.contains(event.target as Node)) {
        setShowPartSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Update brand choice
  const handleBrandChange = (brand: string) => {
    setSelectedBrand(brand);
    setModelInput(''); // clear model input on brand switch
    if (setExternalBrand) {
      setExternalBrand(brand);
    }
  };

  // Manage autocomplete suggestions for truck models dynamically based on selected brand
  useEffect(() => {
    if (!modelInput.trim()) {
      setFilteredModels([]);
      return;
    }

    const normalizedInput = modelInput.toLowerCase();
    let pool: string[] = [];

    if (selectedBrand !== 'Todas') {
      pool = MODELS_BY_BRAND[selectedBrand] || [];
    } else {
      // Pool all models if no brand selected
      Object.values(MODELS_BY_BRAND).forEach((list) => {
        pool = [...pool, ...list];
      });
      // De-duplicate pool
      pool = Array.from(new Set(pool));
    }

    const matches = pool.filter((m) => m.toLowerCase().includes(normalizedInput));
    setFilteredModels(matches);
  }, [modelInput, selectedBrand]);

  // Manage autocomplete suggestions for parts based on products database
  useEffect(() => {
    if (!partInput.trim()) {
      setFilteredParts([]);
      return;
    }

    const normalizedInput = partInput.toLowerCase();
    
    // Extract part types/names dynamically from active products catalog
    const productNames = products.map((p) => p.name);
    const categoryNames = products.map((p) => p.category);
    const genericWords = [
      'Turbina', 'Compressor', 'Turbocompressor', 'Pastilhas', 'Freio', 'Embreagem', 
      'Platô', 'Disco', 'Amortecedor', 'Bolsa de Ar', 'Cabine', 'Pneumático', 
      'Filtro', 'Separador', 'Racor', 'Bomba', 'Água', 'Resfriamento', 'Arrefecimento',
      'Farol', 'Lanterna', 'Elétrica', 'Alternador', 'Carga', 'Servo', 'Radiador'
    ];

    const allPartWords = Array.from(new Set([...productNames, ...categoryNames, ...genericWords]));
    const matches = allPartWords.filter((w) => w.toLowerCase().includes(normalizedInput)).slice(0, 8);
    setFilteredParts(matches);
  }, [partInput, products]);

  // Compute products matching advanced search criteria
  const matchingProducts = products.filter((p) => {
    // 1. Brand match
    const matchBrand = selectedBrand === 'Todas' || p.brand.toLowerCase() === selectedBrand.toLowerCase();

    // 2. Model compatibility match
    let matchModel = true;
    if (modelInput.trim()) {
      const normalizedModel = modelInput.toLowerCase();
      const compatibilities = p.specifications.compatibility?.toLowerCase() || '';
      matchModel = compatibilities.includes(normalizedModel) || p.name.toLowerCase().includes(normalizedModel);
    }

    // 3. Part name or category match
    let matchPart = true;
    if (partInput.trim()) {
      const normalizedPart = partInput.toLowerCase();
      matchPart = p.name.toLowerCase().includes(normalizedPart) || 
                  p.category.toLowerCase().includes(normalizedPart) ||
                  p.description.toLowerCase().includes(normalizedPart);
    }

    return matchBrand && matchModel && matchPart;
  });

  const clearAllFilters = () => {
    setSelectedBrand('Todas');
    setModelInput('');
    setPartInput('');
    if (setExternalBrand) {
      setExternalBrand('Todas');
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl" id="advanced-search-engine">
      
      {/* Header with cool styling */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="bg-amber-500/15 p-1.5 rounded-lg border border-amber-500/30">
              <Sparkles className="w-4.5 h-4.5 text-amber-500" />
            </div>
            <h3 className="text-sm font-black text-white uppercase tracking-tight font-mono">Buscador Inteligente de Peças</h3>
          </div>
          <p className="text-[11px] text-slate-400">Encontre a peça exata para o seu modelo de caminhão de forma guiada e sem erro de compatibilidade.</p>
        </div>

        {(selectedBrand !== 'Todas' || modelInput || partInput) && (
          <button
            type="button"
            onClick={clearAllFilters}
            className="text-[10px] uppercase font-bold text-amber-500 hover:text-amber-400 font-mono flex items-center gap-1.5 bg-slate-950 px-3 py-1.5 border border-slate-800 rounded-lg hover:border-slate-700 transition-all active:scale-95"
          >
            <X className="w-3.5 h-3.5" /> Limpar Filtros
          </button>
        )}
      </div>

      {/* Inputs Form Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* 1. Brand selection */}
        <div className="space-y-2">
          <label className="text-[10px] text-slate-400 uppercase tracking-widest font-mono font-bold block">1. Escolher a Montadora</label>
          <div className="relative">
            <select
              value={selectedBrand}
              onChange={(e) => handleBrandChange(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500/80 focus:border-amber-500 transition-all appearance-none cursor-pointer font-medium"
            >
              <option value="Todas">Todas as Montadoras</option>
              <optgroup label="Caminhões">
                <option value="Scania">Scania</option>
                <option value="Volvo">Volvo</option>
                <option value="Mercedes-Benz">Mercedes-Benz</option>
                <option value="Volkswagen">Volkswagen (VW)</option>
                <option value="DAF">DAF</option>
                <option value="Iveco">Iveco</option>
                <option value="Ford">Ford Trucks</option>
              </optgroup>
              <optgroup label="Tratores & Agrícola">
                <option value="John Deere">John Deere</option>
                <option value="Massey Ferguson">Massey Ferguson</option>
                <option value="Valtra">Valtra</option>
                <option value="New Holland">New Holland</option>
                <option value="Case IH">Case IH</option>
              </optgroup>
            </select>
            <span className="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none text-slate-400">
              <ChevronDown className="w-4 h-4" />
            </span>
          </div>
        </div>

        {/* 2. Model Auto-Complete */}
        <div className="space-y-2 relative" ref={modelRef}>
          <label className="text-[10px] text-slate-400 uppercase tracking-widest font-mono font-bold block">2. Modelo do Caminhão</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-550">
              <Truck className="w-4 h-4" />
            </span>
            <input
              type="text"
              placeholder={selectedBrand !== 'Todas' ? `Ex: R440, P310, R450...` : "Selecione a montadora ou digite..."}
              value={modelInput}
              onChange={(e) => {
                setModelInput(e.target.value);
                setShowModelSuggestions(true);
              }}
              onFocus={() => setShowModelSuggestions(true)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500/80 focus:border-amber-500 transition-all font-medium"
            />
            {modelInput && (
              <button
                onClick={() => setModelInput('')}
                className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-500 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Autocomplete Suggestions Panel */}
          {showModelSuggestions && filteredModels.length > 0 && (
            <div className="absolute z-30 w-full mt-1 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl max-h-48 overflow-y-auto overflow-x-hidden divide-y divide-slate-900 scrollbar-thin">
              {filteredModels.map((model) => (
                <button
                  key={model}
                  type="button"
                  onClick={() => {
                    setModelInput(model);
                    setShowModelSuggestions(false);
                  }}
                  className="w-full text-left px-4 py-2 text-xs text-slate-300 hover:bg-slate-900 hover:text-white transition-colors flex items-center justify-between font-mono"
                >
                  <span className="flex items-center gap-2">
                    <Truck className="w-3.5 h-3.5 text-amber-500/60" />
                    {model}
                  </span>
                  <span className="text-[9px] text-slate-500 uppercase tracking-wider">{selectedBrand !== 'Todas' ? selectedBrand : ''}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 3. Part Type Auto-Complete */}
        <div className="space-y-2 relative" ref={partRef}>
          <label className="text-[10px] text-slate-400 uppercase tracking-widest font-mono font-bold block">3. Tipo ou Nome da Peça</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-550">
              <Search className="w-4 h-4" />
            </span>
            <input
              type="text"
              placeholder="Ex: Turbina, Filtro, Amortecedor..."
              value={partInput}
              onChange={(e) => {
                setPartInput(e.target.value);
                setShowPartSuggestions(true);
              }}
              onFocus={() => setShowPartSuggestions(true)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-amber-500/80 focus:border-amber-500 transition-all font-medium"
            />
            {partInput && (
              <button
                onClick={() => setPartInput('')}
                className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-500 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Autocomplete Suggestions Panel */}
          {showPartSuggestions && filteredParts.length > 0 && (
            <div className="absolute z-30 w-full mt-1 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl max-h-48 overflow-y-auto overflow-x-hidden divide-y divide-slate-900 scrollbar-thin">
              {filteredParts.map((part) => (
                <button
                  key={part}
                  type="button"
                  onClick={() => {
                    setPartInput(part);
                    setShowPartSuggestions(false);
                  }}
                  className="w-full text-left px-4 py-2.5 text-xs text-slate-300 hover:bg-slate-900 hover:text-white transition-colors flex items-center gap-2 font-mono"
                >
                  <Search className="w-3.5 h-3.5 text-amber-500/60" />
                  {part}
                </button>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Listing below filter: "liste logo abaixo o nome e descrição e especificações e preço" */}
      <div className="pt-4 border-t border-slate-800/80 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
            Resultados da Pesquisa Avançada ({matchingProducts.length})
          </h4>
          <span className="text-[10px] text-slate-500">Filtrado em tempo real</span>
        </div>

        {matchingProducts.length > 0 ? (
          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1 scrollbar-thin">
            {matchingProducts.map((p) => {
              const isAdded = cartItems.some((item) => item.product.id === p.id);
              return (
                <div 
                  key={p.id} 
                  className="bg-slate-950 p-5 border border-slate-850 hover:border-slate-800 rounded-2xl flex flex-col md:flex-row gap-5 transition-all duration-300 hover:shadow-lg relative overflow-hidden"
                >
                  {/* Subtle brand tag background */}
                  <div className="absolute top-0 right-0 bg-amber-500/10 text-amber-400 text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-bl-xl border-l border-b border-slate-800 font-mono">
                    {p.brand}
                  </div>

                  {/* Image container */}
                  <div className="w-full md:w-36 h-28 shrink-0 rounded-xl overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center relative group">
                    <img 
                      src={p.imageUrl} 
                      alt={p.name} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* Body Content */}
                  <div className="flex-1 space-y-3">
                    <div className="space-y-1">
                      <h5 className="text-sm font-black text-white hover:text-amber-400 transition-colors uppercase font-mono tracking-tight">{p.name}</h5>
                      <p className="text-[11px] text-slate-400 leading-relaxed text-justify">{p.description}</p>
                    </div>

                    {/* Specifications List */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2 bg-slate-900/40 p-3 border border-slate-850 rounded-xl text-[10px]">
                      <div>
                        <span className="text-slate-500 block font-mono">Código OEM</span>
                        <span className="text-slate-300 font-extrabold">{p.specifications.oemCode || 'N/D'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block font-mono">Material</span>
                        <span className="text-slate-300 font-extrabold truncate block" title={p.specifications.material}>{p.specifications.material || 'N/D'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block font-mono">Peso de Despacho</span>
                        <span className="text-slate-300 font-extrabold">{p.specifications.weight || 'N/D'}</span>
                      </div>
                      <div className="col-span-2 md:col-span-2">
                        <span className="text-slate-500 block font-mono">Compatibilidade</span>
                        <span className="text-amber-500/90 font-bold truncate block" title={p.specifications.compatibility}>{p.specifications.compatibility || 'N/D'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block font-mono">Garantia Comercial</span>
                        <span className="text-slate-300 font-extrabold">{p.specifications.warranty || 'N/D'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Price & Action */}
                  <div className="flex md:flex-col items-end justify-between md:justify-center gap-3 w-full md:w-44 border-t md:border-t-0 md:border-l border-slate-850 pt-4 md:pt-0 md:pl-5 shrink-0">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 block uppercase font-mono">Valor Unitário</span>
                      <span className="text-lg font-black text-white font-mono">
                        {p.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onAddToCart(p)}
                      className={`w-full md:w-auto px-4 py-2 text-xs font-black rounded-lg transition-all active:scale-95 flex items-center justify-center gap-1.5 uppercase tracking-wide ${
                        isAdded
                          ? 'bg-emerald-500/10 border border-emerald-500/40 text-emerald-400'
                          : 'bg-amber-500 text-slate-950 hover:bg-amber-400 border border-amber-600'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" /> Adicionado
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-3.5 h-3.5" /> Adicionar
                        </>
                      )}
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-10 bg-slate-950 border border-slate-850 rounded-2xl p-6">
            <p className="text-xs text-slate-500">Nenhuma autopeça compatível com os filtros e modelo digitados.</p>
          </div>
        )}
      </div>

    </div>
  );
}
