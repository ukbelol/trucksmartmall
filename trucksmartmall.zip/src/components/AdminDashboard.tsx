import React from 'react';
import { Order, Product } from '../types';
import { DollarSign, BarChart3, TrendingUp, Calendar, AlertTriangle, ArrowUpRight, CheckCircle2, Box, Users } from 'lucide-react';

interface AdminDashboardProps {
  orders: Order[];
  products: Product[];
}

export default function AdminDashboard({ orders, products }: AdminDashboardProps) {
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(val);
  };

  // Filter only completed sales (approved or dispatched orders)
  const completedOrders = orders.filter(o => o.status === 'approved' || o.status === 'dispatched');

  // Today corresponds to June 23, 2026
  const targetDate = new Date('2026-06-23T00:00:00');

  const checkIsSameDay = (d1: Date, d2: Date) => {
    return d1.getFullYear() === d2.getFullYear() &&
           d1.getMonth() === d2.getMonth() &&
           d1.getDate() === d2.getDate();
  };

  // Daily: June 23, 2026 (exact day match)
  const dailyTotal = completedOrders
    .filter(o => {
      const orderDate = new Date(o.date);
      return checkIsSameDay(orderDate, targetDate);
    })
    .reduce((sum, o) => sum + o.totalValue, 0);

  // Weekly: Last 7 days (June 17 to June 23, 2026)
  const weeklyTotal = completedOrders
    .filter(o => {
      const orderDate = new Date(o.date);
      const diffTime = Math.abs(targetDate.getTime() - orderDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 7;
    })
    .reduce((sum, o) => sum + o.totalValue, 0);

  // Monthly: Last 30 days
  const monthlyTotal = completedOrders
    .filter(o => {
      const orderDate = new Date(o.date);
      const diffTime = Math.abs(targetDate.getTime() - orderDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 30;
    })
    .reduce((sum, o) => sum + o.totalValue, 0);

  // Get aggregated total of completed product sales
  const productSalesMap: { [productId: string]: { name: string; brand: string; qty: number; revenue: number } } = {};

  completedOrders.forEach(order => {
    order.items.forEach(item => {
      if (!productSalesMap[item.productId]) {
        // Find brand from product list if possible
        const prodRef = products.find(p => p.id === item.productId);
        productSalesMap[item.productId] = {
          name: item.name,
          brand: prodRef ? prodRef.brand : 'Genérica',
          qty: 0,
          revenue: 0
        };
      }
      productSalesMap[item.productId].qty += item.quantity;
      productSalesMap[item.productId].revenue += item.totalPrice;
    });
  });

  const productSalesList = Object.values(productSalesMap).sort((a, b) => b.revenue - a.revenue);

  return (
    <div className="space-y-6" id="admin-dashboard-section">
      {/* Title */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
        <h2 className="text-lg font-black text-white uppercase tracking-tight">Painel Executivo Dashboard</h2>
        <p className="text-xs text-slate-400 mt-1">Sessão operacional de faturamento e desempenho comercial da TruckSmartMall.</p>
      </div>

      {/* Bento Grid Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Daily Card */}
        <div className="bg-slate-900 border border-slate-850 p-6 rounded-2xl space-y-4 relative overflow-hidden shadow-lg group hover:border-amber-500/40 transition-all">
          <div className="absolute right-4 top-4 text-amber-500 bg-amber-500/10 p-2 rounded-xl border border-amber-500/20">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 font-mono font-bold uppercase tracking-widest block">FATURAMENTO DIÁRIO (HOJE)</span>
            <span className="text-2xl font-black text-white tracking-tight mt-1 inline-block font-mono">
              {formatCurrency(dailyTotal)}
            </span>
          </div>
          <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 border-t border-slate-850 pt-3">
            <TrendingUp className="w-4.5 h-4.5" />
            <span>+15.2% em relação a ontem</span>
          </div>
        </div>

        {/* Weekly Card */}
        <div className="bg-slate-900 border border-slate-850 p-6 rounded-2xl space-y-4 relative overflow-hidden shadow-lg group hover:border-amber-500/40 transition-all">
          <div className="absolute right-4 top-4 text-amber-500 bg-amber-500/10 p-2 rounded-xl border border-amber-500/20">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 font-mono font-bold uppercase tracking-widest block">FATURAMENTO SEMANAL</span>
            <span className="text-2xl font-black text-white tracking-tight mt-1 inline-block font-mono">
              {formatCurrency(weeklyTotal)}
            </span>
          </div>
          <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 border-t border-slate-850 pt-3">
            <TrendingUp className="w-4.5 h-4.5" />
            <span>Meta de faturamento atingida!</span>
          </div>
        </div>

        {/* Monthly Card */}
        <div className="bg-slate-900 border border-slate-850 p-6 rounded-2xl space-y-4 relative overflow-hidden shadow-lg group hover:border-amber-500/40 transition-all">
          <div className="absolute right-4 top-4 text-emerald-400 bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 font-mono font-bold uppercase tracking-widest block">FATURAMENTO MENSAL (JUNHO)</span>
            <span className="text-2xl font-black text-white tracking-tight mt-1 inline-block font-mono">
              {formatCurrency(monthlyTotal)}
            </span>
          </div>
          <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 border-t border-slate-850 pt-3">
            <TrendingUp className="w-4.5 h-4.5" />
            <span>+34.8% ante o mês anterior</span>
          </div>
        </div>

      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Products detailed statistics */}
        <div className="xl:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="border-b border-slate-850 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Desempenho Comercial de Peças Vendidas</h3>
            <p className="text-[11px] text-slate-500 mt-0.5 font-mono">Listagem de peças com faturamento e expedição aprovada.</p>
          </div>

          <div className="overflow-x-auto">
            {productSalesList.length === 0 ? (
              <div className="text-center py-16 text-slate-500 font-mono space-y-2">
                <AlertTriangle className="w-8 h-8 text-slate-700/60 mx-auto" />
                <span>Nenhuma venda concluída foi registrada para análise gráfica.</span>
              </div>
            ) : (
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-500 font-mono uppercase tracking-wider">
                    <th className="py-2.5 px-1">Peça de Reposição</th>
                    <th className="py-2.5 px-1 text-center">Marca / Montadora</th>
                    <th className="py-2.5 px-1 text-center">Unidades Vendidas</th>
                    <th className="py-2.5 px-1 text-right">Faturamento Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-850 font-sans">
                  {productSalesList.map((ps, i) => (
                    <tr key={i} className="hover:bg-slate-950/20 text-slate-350">
                      <td className="py-3 px-1 font-semibold text-slate-100">
                        {ps.name}
                      </td>
                      <td className="py-3 px-1 text-center">
                        <span className="bg-slate-950 text-amber-500 border border-slate-800 px-2 py-0.5 rounded font-bold font-mono text-[10px] uppercase">
                          {ps.brand}
                        </span>
                      </td>
                      <td className="py-3 px-1 text-center font-bold text-white font-mono">
                        {ps.qty} un
                      </td>
                      <td className="py-3 px-1 text-right font-bold text-emerald-400 font-mono">
                        {formatCurrency(ps.revenue)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Graphical charts mockup built elegantly with responsive HTML meters */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="border-b border-slate-850 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Indicadores de Conversão</h3>
            <p className="text-[11px] text-slate-500 mt-0.5 font-mono">Métricas de tráfego, estoque e carrinhos de compra.</p>
          </div>

          <div className="space-y-4">
            
            {/* Conversion Rate */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400 font-medium">Taxa de Conversão de Vendas</span>
                <span className="text-emerald-400 font-bold font-mono">4.8%</span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-850">
                <div className="bg-emerald-500 h-full rounded-full" style={{ width: '48%' }} />
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>Cliques: 24.500</span>
                <span>Vendas: 1.176</span>
              </div>
            </div>

            {/* In-Stock Level indicator */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400 font-medium">Saúde Operacional (Estoque)</span>
                <span className="text-amber-500 font-bold font-mono">82%</span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-850">
                <div className="bg-amber-500 h-full rounded-full" style={{ width: '82%' }} />
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>Peças cadastradas: {products.length}</span>
                <span>Unidades totais: {products.reduce((acc, curr) => acc + curr.stock, 0)}</span>
              </div>
            </div>

            {/* Freight analysis */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400 font-medium">Volume Logístico de Postagem</span>
                <span className="text-indigo-400 font-bold font-mono">92 postagens/dia</span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-850">
                <div className="bg-indigo-500 h-full rounded-full" style={{ width: '92%' }} />
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>TNT Mercúrio: 78%</span>
                <span>Correios PAC: 22%</span>
              </div>
            </div>

          </div>

          {/* Action Log banner */}
          <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl space-y-2 text-[11px] text-slate-450 leading-relaxed font-mono">
            <span className="text-[10px] text-slate-500 font-bold block uppercase border-b border-slate-900 pb-1">Logs de Auditoria</span>
            <div className="space-y-1">
              <p className="text-emerald-500">● [07:21] Configurações de API Mercado Pago ATIVADAS.</p>
              <p className="text-amber-500">● [07:08] Estoque Turbocompressor editado p/ 12 un.</p>
              <p className="text-slate-500">● [06:45] Certificado SSL gerado para truck.smartmall577.space</p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
