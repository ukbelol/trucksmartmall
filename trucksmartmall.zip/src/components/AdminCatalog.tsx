import React, { useState } from 'react';
import { Product } from '../types';
import { Edit2, Plus, Info, Trash, RefreshCw, X, Check, Save } from 'lucide-react';

interface AdminCatalogProps {
  products: Product[];
  onUpdateProduct: (product: Product) => void;
  onAddProduct: (product: Product) => void;
}

export default function AdminCatalog({ products, onUpdateProduct, onAddProduct }: AdminCatalogProps) {
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [search, setSearch] = useState('');
  
  // Edit Form Fields
  const [name, setName] = useState('');
  const [brand, setBrand] = useState('');
  const [category, setCategory] = useState('');
  const [price, setPrice] = useState(0);
  const [stock, setStock] = useState(0);
  const [imageUrl, setImageUrl] = useState('');
  const [description, setDescription] = useState('');
  
  // Specs
  const [oemCode, setOemCode] = useState('');
  const [material, setMaterial] = useState('');
  const [weight, setWeight] = useState('');
  const [compatibility, setCompatibility] = useState('');
  const [warranty, setWarranty] = useState('');

  const handleEditClick = (p: Product) => {
    setEditingProduct(p);
    setName(p.name);
    setBrand(p.brand);
    setCategory(p.category);
    setPrice(p.price);
    setStock(p.stock);
    setImageUrl(p.imageUrl);
    setDescription(p.description);
    
    // specs
    setOemCode(p.specifications.oemCode);
    setMaterial(p.specifications.material);
    setWeight(p.specifications.weight);
    setCompatibility(p.specifications.compatibility);
    setWarranty(p.specifications.warranty);
  };

  const handleCreateNew = () => {
    const defaultProduct: Product = {
      id: `prod_${Date.now()}`,
      name: 'Novo Amortecedor de Suspensão Reforçado',
      brand: 'Scania',
      category: 'Suspensão e Direção',
      price: 1200.00,
      stock: 5,
      imageUrl: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&q=80&w=600',
      description: 'Escreva uma descrição detalhada para essa peça automotiva...',
      specifications: {
        oemCode: 'OEM-NEW-2026',
        material: 'Liga Siderúrgica',
        weight: '5.2 kg',
        compatibility: 'Scania R Series (Universal)',
        warranty: '1 Ano'
      }
    };
    onAddProduct(defaultProduct);
    handleEditClick(defaultProduct);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    const updated: Product = {
      ...editingProduct,
      name,
      brand,
      category,
      price: Number(price),
      stock: Number(stock),
      imageUrl,
      description,
      specifications: {
        oemCode,
        material,
        weight,
        compatibility,
        warranty
      }
    };

    onUpdateProduct(updated);
    setEditingProduct(null);
  };

  const filtered = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.brand.toLowerCase().includes(search.toLowerCase()) ||
    p.specifications.oemCode?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6" id="admin-catalog-section">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 p-6 rounded-2xl border border-slate-800">
        <div>
          <h2 className="text-lg font-black text-white uppercase tracking-tight">Catálogo de Peças</h2>
          <p className="text-xs text-slate-400 mt-1">Gerencie preços, estoque, especificações técnicas e mídias das autopeças.</p>
        </div>
        <button
          onClick={handleCreateNew}
          className="py-2 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg uppercase tracking-wider flex items-center gap-1.5 transition-all"
        >
          <Plus className="w-4 h-4 text-slate-950 stroke-[3]" />
          Adicionar Nova Peça
        </button>
      </div>

      {/* Filter and Table Grid layout */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Table List Column */}
        <div className="xl:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Filtrar por nome, marca ou código OEM..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 font-mono uppercase tracking-wider">
                  <th className="py-3 px-2">Peça / OEM</th>
                  <th className="py-3 px-2 text-center">Montadora</th>
                  <th className="py-3 px-2 text-right">Preço</th>
                  <th className="py-3 px-2 text-center">Estoque</th>
                  <th className="py-3 px-2 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {filtered.map(p => (
                  <tr key={p.id} className="hover:bg-slate-950/40 text-slate-300">
                    {/* Item */}
                    <td className="py-3.5 px-2">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-slate-950 border border-slate-800 rounded-lg overflow-hidden shrink-0">
                          <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <div className="font-bold text-slate-100 line-clamp-1">{p.name}</div>
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">OEM: {p.specifications.oemCode}</div>
                        </div>
                      </div>
                    </td>

                    {/* Brand */}
                    <td className="py-3.5 px-2 text-center">
                      <span className="bg-slate-950 text-amber-500 border border-slate-800 px-2.5 py-0.5 rounded text-[10px] font-black uppercase tracking-widest font-mono">
                        {p.brand}
                      </span>
                    </td>

                    {/* Price */}
                    <td className="py-3.5 px-2 text-right font-bold text-white font-mono">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(p.price)}
                    </td>

                    {/* Stock */}
                    <td className="py-3.5 px-2 text-center font-mono">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        p.stock === 0 ? 'bg-red-500/10 text-red-500' : p.stock <= 5 ? 'bg-amber-500/10 text-amber-500' : 'bg-emerald-500/10 text-emerald-400'
                      }`}>
                        {p.stock} un
                      </span>
                    </td>

                    {/* Action */}
                    <td className="py-3.5 px-2 text-right">
                      <button
                        onClick={() => handleEditClick(p)}
                        className="p-1 px-2.5 bg-slate-800 hover:bg-amber-500 border border-slate-750 hover:border-amber-400 hover:text-slate-950 text-slate-300 font-bold rounded flex items-center gap-1 text-[11px] transition-all ml-auto"
                      >
                        <Edit2 className="w-3 h-3" /> Editar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="text-center py-12 text-slate-500 font-mono">Nenhuma peça coincide com as especificações da busca.</div>
            )}
          </div>
        </div>

        {/* Edit Form Sidebar (Always active, dynamically switching or empty) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
          {editingProduct ? (
            <form onSubmit={handleSave} className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-850">
                <span className="text-xs font-black text-amber-500 uppercase tracking-wider font-mono">Editar Cadastro</span>
                <span className="text-[10px] text-slate-500 font-mono">ID: {editingProduct.id}</span>
              </div>

              {/* Basic specs */}
              <div className="space-y-3.5">
                <div>
                  <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Nome da Peça</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Montadora / Marca</label>
                    <input
                      type="text"
                      value={brand}
                      onChange={(e) => setBrand(e.target.value)}
                      required
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Categoria</label>
                    <input
                      type="text"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      required
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Preço Unitário (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={price}
                      onChange={(e) => setPrice(Number(e.target.value))}
                      required
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Qtd em Estoque</label>
                    <input
                      type="number"
                      value={stock}
                      onChange={(e) => setStock(Number(e.target.value))}
                      required
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Imagem URL</label>
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none font-mono"
                  />
                  {imageUrl && (
                    <div className="mt-2 text-center">
                      <span className="text-[10px] text-slate-500 block mb-1">Miniatura da imagem:</span>
                      <img src={imageUrl} alt="miniatura" className="mx-auto w-16 h-12 object-cover border border-slate-750 rounded" />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">Descrição</label>
                  <textarea
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none font-sans"
                  />
                </div>

                {/* Sub-component Specifications */}
                <div className="border-t border-slate-850 pt-3.5 space-y-3">
                  <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest font-mono block">Especificações Técnicas</span>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Código OEM</label>
                      <input
                        type="text"
                        value={oemCode}
                        onChange={(e) => setOemCode(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-[11px] text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Garantia</label>
                      <input
                        type="text"
                        value={warranty}
                        onChange={(e) => setWarranty(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-[11px] text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Peso da Peça</label>
                      <input
                        type="text"
                        value={weight}
                        onChange={(e) => setWeight(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-[11px] text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Material</label>
                      <input
                        type="text"
                        value={material}
                        onChange={(e) => setMaterial(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-[11px] text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[9px] text-slate-400 font-bold uppercase mb-1">Compatibilidade de Modelos</label>
                    <input
                      type="text"
                      value={compatibility}
                      onChange={(e) => setCompatibility(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-[11px] text-slate-100 focus:ring-1 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Form Buttons */}
              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="w-1/3 py-2.5 border border-slate-800 bg-slate-950 hover:bg-slate-800 rounded-lg text-xs font-bold text-slate-400 uppercase tracking-wider transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="w-2/3 py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-xs font-black text-white uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md"
                >
                  <Save className="w-4 h-4" /> Salvar Peça
                </button>
              </div>
            </form>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-3">
              <div className="w-12 h-12 rounded-full border border-slate-800 flex items-center justify-center text-amber-500/40">
                <Edit2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-350 uppercase tracking-widest font-mono">Modo de Edição</h4>
                <p className="text-[11px] text-slate-500 mt-1">Selecione alguma peça da tabela ao lado para editar as informações cadastrais e preços.</p>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
