import React, { useState } from 'react';
import { Truck, ShoppingCart, User, UserCheck, Search, LogOut, SlidersHorizontal, Settings, LogIn } from 'lucide-react';
import { Customer } from '../types';

interface NavbarProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedBrand: string;
  setSelectedBrand: (brand: string) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  onOpenCart: () => void;
  cartItemsCount: number;
  isAdminLoggedIn: boolean;
  onAdminLoginTrigger: () => void;
  onAdminLogout: () => void;
  onSetView: (view: 'store' | 'admin' | 'customer-auth' | 'legal') => void;
  currentView: 'store' | 'admin' | 'customer-auth' | 'legal';
  loggedCustomer: Customer | null;
  onCustomerLogout: () => void;
  onCustomerLoginTrigger: () => void;
}

export default function Navbar({
  searchQuery,
  setSearchQuery,
  selectedBrand,
  setSelectedBrand,
  selectedCategory,
  setSelectedCategory,
  onOpenCart,
  cartItemsCount,
  isAdminLoggedIn,
  onAdminLoginTrigger,
  onAdminLogout,
  onSetView,
  currentView,
  loggedCustomer,
  onCustomerLogout,
  onCustomerLoginTrigger
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const brands = ['Todas', 'Scania', 'Volvo', 'Mercedes-Benz', 'Volkswagen', 'DAF', 'Iveco', 'Ford', 'John Deere', 'Massey Ferguson', 'Valtra', 'New Holland', 'Case IH'];
  const categories = ['Todas', 'Motor e Turbos', 'Sistema de Freios', 'Transmissão', 'Suspensão e Direção', 'Filtros e Fluídos', 'Resfriamento e Motor', 'Iluminação e Elétrica', 'Tratores - Hidráulico'];

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950 text-slate-100 shadow-xl border-b border-slate-800" id="main-header">
      {/* Upper bar: Emergency contact info */}
      <div className="bg-amber-500 text-slate-950 font-bold text-xs py-1.5 px-4 text-center tracking-wide uppercase flex items-center justify-center gap-2">
        <Truck className="w-4 h-4 animate-bounce" />
        PROMOÇÃO TRUCKSMARTMALL: Frete Grátis na primeira compra para todo o Brasil • Peças 100% Originais
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => { onSetView('store'); setMobileMenuOpen(false); }} id="logo-container">
            <div className="bg-amber-500 text-slate-950 p-2 rounded-lg flex items-center justify-center">
              <Truck className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent uppercase">
                TruckSmart
              </span>
              <span className="text-xl font-light text-white tracking-widest uppercase">
                Mall
              </span>
              <div className="text-[9px] text-slate-400 uppercase tracking-widest font-mono -mt-1">
                Linha Pesada & Diesel
              </div>
            </div>
          </div>

          {/* Inline Search Bar (Desktop) */}
          <div className="hidden lg:flex flex-1 max-w-md mx-8 relative" id="desktop-search">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="h-5 w-5 text-slate-400" />
            </span>
            <input
              type="text"
              placeholder="Buscar por peça, marca, código OEM..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="block w-full py-2.5 pl-10 pr-3 text-sm text-slate-250 bg-slate-900 border border-slate-750 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all placeholder:text-slate-500"
            />
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center gap-4">
            {/* View Selector for Admin with login check */}
            {isAdminLoggedIn && (
              <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800" id="view-toggle">
                <button
                  onClick={() => onSetView('store')}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                    currentView === 'store'
                      ? 'bg-amber-500 text-slate-950 shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Loja Virtual
                </button>
                <button
                  onClick={() => onSetView('admin')}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all flex items-center gap-1.5 ${
                    currentView === 'admin'
                      ? 'bg-amber-500 text-slate-950 shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Settings className="w-3.5 h-3.5" />
                  Painel Admin
                </button>
              </div>
            )}

            {/* Shopping Cart button */}
            <button
              onClick={onOpenCart}
              className="relative p-2.5 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-amber-400 border border-slate-800 rounded-lg transition-all"
              title="Sacola de Compras"
              id="cart-btn"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-amber-500 text-slate-950 text-[10px] font-black animate-pulse shadow-md">
                  {cartItemsCount}
                </span>
              )}
            </button>

            {/* Customer Account Trigger (Desktop) */}
            <div className="hidden sm:block">
              {loggedCustomer ? (
                <div className="flex items-center gap-2.5 bg-amber-500/10 border border-amber-500/35 py-1.5 px-3 rounded-lg">
                  <div className="flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4 text-amber-400" />
                    <span className="text-xs text-amber-400 font-extrabold uppercase tracking-wider">{loggedCustomer.firstName}</span>
                  </div>
                  <button
                    onClick={onCustomerLogout}
                    className="p-1 hover:bg-slate-850 rounded text-slate-400 hover:text-red-400 transition-all"
                    title="Sair da Conta de Cliente"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={onCustomerLoginTrigger}
                  className={`flex items-center gap-2 py-2 px-3.5 bg-slate-900 border border-slate-800 hover:border-amber-500/50 hover:bg-slate-800 text-slate-250 text-xs font-semibold rounded-lg transition-all ${
                    currentView === 'customer-auth' ? 'border-amber-500 text-white bg-slate-855' : ''
                  }`}
                >
                  <LogIn className="w-4 h-4 text-amber-500" />
                  Minha Conta
                </button>
              )}
            </div>

            {/* Super Admin Access Trigger */}
            <div className="hidden sm:block">
              {isAdminLoggedIn ? (
                <div className="flex items-center gap-3 bg-emerald-950/40 border border-emerald-900 py-1.5 px-3 rounded-lg">
                  <div className="flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs text-emerald-400 font-medium">Super Admin</span>
                  </div>
                  <button
                    onClick={onAdminLogout}
                    className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-red-400 transition-all"
                    title="Sair do Painel"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={onAdminLoginTrigger}
                  className="flex items-center gap-2 py-2 px-3.5 bg-slate-900 border border-slate-800 hover:border-amber-500/50 hover:bg-slate-800 text-slate-250 text-xs font-semibold rounded-lg transition-all"
                >
                  <User className="w-4 h-4 text-amber-500" />
                  Acesso Restrito
                </button>
              )}
            </div>

            {/* Hamburger for mobile filters */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 rounded-lg flex lg:hidden"
              id="mobile-menu-trigger"
            >
              <SlidersHorizontal className="w-5 h-5 text-amber-500" />
            </button>
          </div>
        </div>
      </div>

      {/* Brand & Filter Rail (Desktop Always Dynamic, Mobile Collapsible) */}
      <div className={`border-t border-slate-800 bg-slate-900/90 py-3 ${mobileMenuOpen ? 'block' : 'hidden lg:block'}`} id="filters-rail">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4 lg:space-y-0 lg:flex lg:items-center lg:justify-between lg:gap-4">
          
          {/* Mobile search */}
          <div className="block lg:hidden relative relative-span">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </span>
            <input
              type="text"
              placeholder="Buscar por peça, marca, código..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="block w-full py-2 pl-9 pr-3 text-xs text-slate-200 bg-slate-950 border border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>

          {/* Brand Scroll */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">Montadoras</span>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none scroll-smooth">
              {brands.map((brand) => (
                <button
                  key={brand}
                  onClick={() => { setSelectedBrand(brand); onSetView('store'); }}
                  className={`px-3 py-1 text-xs rounded transition-all whitespace-nowrap border ${
                    selectedBrand === brand
                      ? 'bg-amber-500 border-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-950 border-slate-805 text-slate-400 hover:text-white hover:border-slate-700'
                  }`}
                >
                  {brand}
                </button>
              ))}
            </div>
          </div>

          {/* Category Scroll */}
          <div className="flex flex-col gap-1.5 lg:max-w-2xl">
            <span className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">Categorias de Reposição</span>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none scroll-smooth">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 text-xs rounded transition-all whitespace-nowrap border ${
                    selectedCategory === cat
                      ? 'bg-amber-500 border-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-950 border-slate-805 text-slate-400 hover:text-white hover:border-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Mobile Customer Button wrapper */}
          <div className="block sm:hidden border-t border-slate-805 pt-3">
            {loggedCustomer ? (
              <div className="flex items-center justify-between bg-amber-500/10 border border-amber-500/25 py-2 px-3 rounded-lg mb-2">
                <span className="text-xs text-amber-400 font-black uppercase flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-amber-500" />
                  {loggedCustomer.firstName} {loggedCustomer.lastName}
                </span>
                <button
                  onClick={() => { onCustomerLogout(); setMobileMenuOpen(false); }}
                  className="text-xs text-slate-400 hover:text-red-400 flex items-center gap-1"
                >
                  <LogOut className="w-3.5 h-3.5" /> Sair
                </button>
              </div>
            ) : (
              <button
                onClick={() => { onCustomerLoginTrigger(); setMobileMenuOpen(false); }}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-slate-950 border border-slate-800 hover:border-amber-500/50 text-slate-300 text-xs font-semibold rounded-lg mb-2"
              >
                <LogIn className="w-4 h-4 text-amber-500" />
                Área do Cliente (Entrar / Cadastrar)
              </button>
            )}
          </div>

          {/* Mobile Restrito Button wrapper */}
          <div className="block sm:hidden border-t border-slate-800 pt-3">
            {isAdminLoggedIn ? (
              <div className="flex items-center justify-between bg-emerald-950/40 border border-emerald-900 py-2 px-3 rounded-lg">
                <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-emerald-400" />
                  Super Admin Ativo
                </span>
                <button
                  onClick={() => { onAdminLogout(); setMobileMenuOpen(false); }}
                  className="text-xs text-red-400 hover:underline flex items-center gap-1"
                >
                  <LogOut className="w-3.5 h-3.5" /> Sair
                </button>
              </div>
            ) : (
              <button
                onClick={() => { onAdminLoginTrigger(); setMobileMenuOpen(false); }}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-slate-950 border border-slate-800 hover:border-amber-500/50 text-slate-300 text-xs font-semibold rounded-lg"
              >
                <User className="w-4 h-4 text-amber-500" />
                Painel Restrito Super Admin
              </button>
            )}
          </div>

        </div>
      </div>
    </header>
  );
}
