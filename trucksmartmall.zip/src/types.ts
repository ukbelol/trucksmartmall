export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  stock: number;
  imageUrl: string;
  description: string;
  specifications: {
    oemCode: string; // Original Equipment Manufacturer code
    material: string;
    weight: string;
    compatibility: string; // Compatible truck models
    warranty: string;
  };
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface OrderItem {
  productId: string;
  name: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export type OrderStatus = 'pending' | 'approved' | 'dispatched';

export interface Order {
  id: string;
  date: string; // ISO string
  items: OrderItem[];
  totalValue: number;
  shippingAddress: {
    street: string;
    number: string;
    neighborhood: string;
    city: string;
    state: string;
    zipCode: string;
    receiverName: string;
  };
  status: OrderStatus;
  trackingCode?: string;
  deliveryRequestGenerated?: boolean;
}

export interface PaymentGateway {
  id: string;
  name: string;
  logo: string; // Icon or abbreviation
  isActive: boolean;
  apiKey: string;
  clientSecret: string;
  merchantId: string;
  sandboxMode: boolean;
  additionalFields: { [key: string]: string };
}

export interface Customer {
  id: string;
  firstName: string;
  lastName: string;
  birthDate: string;
  phone: string;
  email: string;
  cpf: string;
  zipCode: string;
  street: string;
  number: string;
  neighborhood: string;
  city: string;
  state: string;
  block?: string;
  floor?: string;
  complement?: string;
  password?: string;
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  permissions: {
    dashboard: boolean;
    catalog: boolean;
    sales: boolean;
    gateways: boolean;
    employees: boolean;
  };
}
