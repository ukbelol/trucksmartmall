/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Product, CartItem, Order, PaymentGateway, OrderStatus, Customer, Employee } from './types';
import { INITIAL_PRODUCTS, INITIAL_GATEWAYS } from './data/initialProducts';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import CartDrawer from './components/CartDrawer';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';
import AdminCatalog from './components/AdminCatalog';
import AdminOrders from './components/AdminOrders';
import AdminGateways from './components/AdminGateways';
import AdminEmployees from './components/AdminEmployees';
import CustomerAuth from './components/CustomerAuth';
import LegalPages from './components/LegalPages';
import AdvancedSearchFilter from './components/AdvancedSearchFilter';
import TractorSection from './components/TractorSection';
import { 
  BarChart2, 
  Settings, 
  Package, 
  CreditCard, 
  Truck, 
  Terminal, 
  BookOpen, 
  Users, 
  HelpCircle,
  FileCode,
  Shield,
  Clock,
  ExternalLink,
  ChevronDown,
  Lock,
  ChevronRight,
  Search,
  CheckCircle,
  TrendingUp,
  MapPin
} from 'lucide-react';

export default function App() {
  // --- STATE CORE ---
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('tsm_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('tsm_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('tsm_orders');
    if (saved) return JSON.parse(saved);

    // Default Seeded Orders tailored for June 23, 2026 stats
    const seeds: Order[] = [
      {
        id: 'PED-5482',
        date: '2026-06-23T06:15:00Z', // Today
        items: [
          {
            productId: 'prod_1',
            name: 'Turbocompressor Holset HE400VG',
            quantity: 1,
            unitPrice: 4850.00,
            totalPrice: 4850.00
          }
        ],
        totalValue: 4850.00,
        shippingAddress: {
          receiverName: 'Marlon Santos (Transportadora Sul)',
          street: 'Avenida Nações Unidas',
          number: '12901',
          neighborhood: 'Pinheiros',
          city: 'São Paulo',
          state: 'SP',
          zipCode: '05311-900'
        },
        status: 'approved',
        trackingCode: 'TSM-8910129-BR',
        deliveryRequestGenerated: false
      },
      {
        id: 'PED-4122',
        date: '2026-06-22T14:30:00Z', // Yesterday
        items: [
          {
            productId: 'prod_4',
            name: 'Amortecedor de Cabine Pneumático Traseiro',
            quantity: 2,
            unitPrice: 940.00,
            totalPrice: 1880.00
          },
          {
            productId: 'prod_5',
            name: 'Filtro Separador de Água Racor (Combustível)',
            quantity: 1,
            unitPrice: 310.00,
            totalPrice: 310.00
          }
        ],
        totalValue: 2190.00,
        shippingAddress: {
          receiverName: 'Lúcio Viana (Auto Car Ltda)',
          street: 'Rodovia Régis Bittencourt Km 26',
          number: '480',
          neighborhood: 'Invernada',
          city: 'Taboão da Serra',
          state: 'SP',
          zipCode: '06815-100'
        },
        status: 'dispatched',
        trackingCode: 'TSM-1204958-BR',
        deliveryRequestGenerated: true
      },
      {
        id: 'PED-3910',
        date: '2026-06-15T09:12:00Z', // 8 days ago
        items: [
          {
            productId: 'prod_3',
            name: 'Kit de Embreagem Completo com Platô e Disco (430mm)',
            quantity: 1,
            unitPrice: 3250.00,
            totalPrice: 3250.00
          }
        ],
        totalValue: 3250.00,
        shippingAddress: {
          receiverName: 'Frota TransRodoviária S.A.',
          street: 'Av. Industrial',
          number: '100',
          neighborhood: 'Setor de Autopeças',
          city: 'Belo Horizonte',
          state: 'MG',
          zipCode: '31000-010'
        },
        status: 'dispatched',
        trackingCode: 'TSM-4420194-BR',
        deliveryRequestGenerated: true
      }
    ];
    return seeds;
  });

  const [gateways, setGateways] = useState<PaymentGateway[]>(() => {
    const saved = localStorage.getItem('tsm_gateways');
    return saved ? JSON.parse(saved) : INITIAL_GATEWAYS;
  });

  // --- FILTERS & INTERFACES ---
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('Todas');
  const [selectedCategory, setSelectedCategory] = useState('Todas');

  const [currentView, setCurrentView] = useState<'store' | 'admin' | 'customer-auth' | 'legal'>('store');
  const [legalInitialTab, setLegalInitialTab] = useState<'terms' | 'privacy'>('terms');
  const [adminTab, setAdminTab] = useState<'dashboard' | 'catalog' | 'sales' | 'gateways' | 'employees'>('dashboard');

  const [cartOpen, setCartOpen] = useState(false);
  const [adminLoginOpen, setAdminLoginOpen] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(() => {
    return localStorage.getItem('tsm_admin_logged') === 'true';
  });

  const [loggedCustomer, setLoggedCustomer] = useState<Customer | null>(() => {
    const saved = localStorage.getItem('tsm_logged_customer');
    return saved ? JSON.parse(saved) : null;
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('tsm_employees');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'EMP-740',
        name: 'Carlos Oliveira',
        email: 'carlos@smartmall.com',
        phone: '(11) 98222-1111',
        role: 'Estoquista de Peças Faturadas',
        permissions: {
          dashboard: true,
          catalog: true,
          sales: false,
          gateways: false,
          employees: false
        }
      },
      {
        id: 'EMP-902',
        name: 'Mariana Silva',
        email: 'mariana.silva@smartmall.com',
        phone: '(21) 97111-5555',
        role: 'Gerente Comercial Linha Pesada',
        permissions: {
          dashboard: true,
          catalog: false,
          sales: true,
          gateways: true,
          employees: false
        }
      }
    ];
  });

  const [checkoutRedirectPending, setCheckoutRedirectPending] = useState(false);

  const [showDeploymentHelp, setShowDeploymentHelp] = useState(true);

  // --- PERSISTENCE ---
  useEffect(() => {
    localStorage.setItem('tsm_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('tsm_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('tsm_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('tsm_gateways', JSON.stringify(gateways));
  }, [gateways]);

  useEffect(() => {
    localStorage.setItem('tsm_admin_logged', isAdminLoggedIn ? 'true' : 'false');
  }, [isAdminLoggedIn]);

  useEffect(() => {
    localStorage.setItem('tsm_employees', JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    if (loggedCustomer) {
      localStorage.setItem('tsm_logged_customer', JSON.stringify(loggedCustomer));
    } else {
      localStorage.removeItem('tsm_logged_customer');
    }
  }, [loggedCustomer]);

  // --- OPERATIONS ---
  const handleAddToCart = (product: Product) => {
    const existing = cart.find(item => item.product.id === product.id);
    if (existing) {
      // Check stock limit
      if (existing.quantity >= product.stock) {
        alert(`Desculpe! Estoque máximo atingido para essa peça (${product.stock} un).`);
        return;
      }
      setCart(cart.map(item => 
        item.product.id === product.id 
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
    // Automatically trigger visual feedback opening cart drawer
    setCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart(cart.map(item => {
      if (item.product.id === productId) {
        const nextQty = item.quantity + delta;
        // Check limits
        if (nextQty < 1) return item;
        if (nextQty > item.product.stock) {
          alert(`Limite máximo de estoque atingido (${item.product.stock} un).`);
          return item;
        }
        return { ...item, quantity: nextQty };
      }
      return item;
    }));
  };

  const handleRemoveItem = (productId: string) => {
    setCart(cart.filter(item => item.product.id !== productId));
  };

  const handleCheckoutComplete = (newOrder: Order) => {
    // 1. Register order
    setOrders([newOrder, ...orders]);

    // 2. Reduce products stock
    const updatedProducts = products.map(p => {
      const orderItem = newOrder.items.find(item => item.productId === p.id);
      if (orderItem) {
        const nextStock = Math.max(0, p.stock - orderItem.quantity);
        return { ...p, stock: nextStock };
      }
      return p;
    });

    setProducts(updatedProducts);

    // 3. Clear shopping store cart
    setCart([]);
  };

  const handleAdminLoginSuccess = () => {
    setIsAdminLoggedIn(true);
    setCurrentView('admin');
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    setCurrentView('store');
  };

  const handleCustomerLogout = () => {
    setLoggedCustomer(null);
    setCurrentView('store');
  };

  const handleCustomerLoginTrigger = () => {
    setCheckoutRedirectPending(false);
    setCurrentView('customer-auth');
  };

  const handleAddEmployee = (newEmp: Employee) => {
    setEmployees([...employees, newEmp]);
  };

  const handleRemoveEmployee = (id: string) => {
    setEmployees(employees.filter(e => e.id !== id));
  };

  const handleUpdateProduct = (updated: Product) => {
    setProducts(products.map(p => p.id === updated.id ? updated : p));
  };

  const handleAddProduct = (newProduct: Product) => {
    setProducts([newProduct, ...products]);
  };

  const handleUpdateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders(orders.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          status: nextStatus(o.status, newStatus),
          deliveryRequestGenerated: newStatus === 'dispatched' ? true : o.deliveryRequestGenerated
        };
      }
      return o;
    }));
  };

  const nextStatus = (current: OrderStatus, requested: OrderStatus): OrderStatus => {
    return requested;
  };

  const handleUpdateGateway = (updatedGw: PaymentGateway) => {
    // Only one payment gateway hub active at a time to keep virtual payment pipelines structured
    let updatedList = gateways.map(gw => {
      if (gw.id === updatedGw.id) {
        return updatedGw;
      }
      // If setting this one active, deactivate all other hubs
      if (updatedGw.isActive && gw.id !== updatedGw.id) {
        return { ...gw, isActive: false };
      }
      return gw;
    });
    setGateways(updatedList);
  };

  // --- FILTERS LOGIC ---
  const filteredProducts = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        p.specifications.oemCode?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchBrand = selectedBrand === 'Todas' || p.brand === selectedBrand;
    const matchCategory = selectedCategory === 'Todas' || p.category === selectedCategory;
    return matchSearch && matchBrand && matchCategory;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans" id="tsm-layout">
      
      {/* Top Navigation Hub Header */}
      <Navbar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedBrand={selectedBrand}
        setSelectedBrand={setSelectedBrand}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        onOpenCart={() => setCartOpen(true)}
        cartItemsCount={cart.reduce((acc, curr) => acc + curr.quantity, 0)}
        isAdminLoggedIn={isAdminLoggedIn}
        onAdminLoginTrigger={() => setAdminLoginOpen(true)}
        onAdminLogout={handleAdminLogout}
        onSetView={setCurrentView}
        currentView={currentView}
        loggedCustomer={loggedCustomer}
        onCustomerLogout={handleCustomerLogout}
        onCustomerLoginTrigger={handleCustomerLoginTrigger}
      />

      {/* RENDER VIEW CONTROLLER */}
      {currentView === 'customer-auth' ? (
        <CustomerAuth 
          onLoginSuccess={(customer) => {
            setLoggedCustomer(customer);
            // If checking out when redirected, immediately open the cart to step 2!
            if (checkoutRedirectPending) {
              setCheckoutRedirectPending(false);
              setCurrentView('store');
              setCartOpen(true);
            } else {
              setCurrentView('store');
            }
          }}
          onCancel={() => {
            setCheckoutRedirectPending(false);
            setCurrentView('store');
          }}
          initialMode={checkoutRedirectPending ? 'register' : 'login'}
        />
      ) : currentView === 'legal' ? (
        <LegalPages 
          onBack={() => setCurrentView('store')}
          initialTab={legalInitialTab}
        />
      ) : currentView === 'store' ? (
        <main className="pb-16" id="client-store-view">
          {/* Cover Hero Banner */}
          <div className="relative bg-slate-900 border-b border-slate-800 overflow-hidden py-16 sm:py-20 flex items-center">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_left,_var(--tw-gradient-stops))] from-amber-500/10 via-slate-900/40 to-slate-950" />
            <div className="absolute -right-24 bottom-0 opacity-20 text-[20vw] font-black select-none tracking-tighter text-slate-800">
              TRUCK
            </div>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
              <div className="max-w-3xl space-y-6">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                  E-commerce Oficial Linha Pesada Brasil
                </span>
                
                <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight uppercase leading-[1.1]">
                  A Peça Certa para o seu <br />
                  <span className="text-amber-500 bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
                    Gigante das Estradas
                  </span>
                </h1>

                <p className="text-sm sm:text-base text-slate-400 leading-relaxed max-w-xl">
                  Encontre mangueiras, pastilhas, turbinas, sensores de injeção e kits transmissão faturados com garantia de fábrica e de reposição imediata para as marcas mais queridas do país.
                </p>

                {/* Badges shortcuts */}
                <div className="flex flex-wrap gap-4 pt-2">
                  <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-950 p-2 px-3.5 border border-slate-850 rounded-xl">
                    <Truck className="w-4 h-4 text-amber-500" />
                    <span>Postagem Rápida</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-950 p-2 px-3.5 border border-slate-850 rounded-xl">
                    <Shield className="w-4 h-4 text-amber-500" />
                    <span>Garantia 100% Original</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Core Storefront Body Grid */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10 space-y-8">
            
            {/* Advanced Search Filter Component */}
            <AdvancedSearchFilter
              products={products}
              onAddToCart={handleAddToCart}
              cartItems={cart}
              externalBrand={selectedBrand}
              setExternalBrand={setSelectedBrand}
            />

            {/* Tractor Section Component */}
            <TractorSection
              products={products}
              onSelectBrand={setSelectedBrand}
              selectedBrand={selectedBrand}
            />

            <div className="flex justify-between items-end border-b border-slate-850 pb-4">
              <div>
                <h2 className="text-lg font-black text-white uppercase tracking-wider">Peças para Pronta Entrega</h2>
                <p className="text-xs text-slate-500 mt-1">Clique para conferir as especificações mecânicas de cada item faturado e adicione à sacola.</p>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                Exibindo <strong>{filteredProducts.length}</strong> de {products.length} peças
              </span>
            </div>

            {/* Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredProducts.map((p) => (
                  <ProductCard
                    key={p.id}
                    product={p}
                    onAddToCart={handleAddToCart}
                    isInCart={cart.some(item => item.product.id === p.id)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-24 bg-slate-900 border border-slate-850 rounded-2xl p-8 space-y-4 max-w-lg mx-auto">
                <p className="text-slate-400 font-bold">Nenhuma autopeça encontrada!</p>
                <p className="text-xs text-slate-550 leading-relaxed">Não encontramos resultados para os parâmetros escolhidos. Tente limpar os filtros nas montadoras ou buscar por referências OEM alternativas nas categorias.</p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedBrand('Todas');
                    setSelectedCategory('Todas');
                  }}
                  className="py-2 px-4.5 bg-slate-800 hover:bg-slate-750 text-xs font-bold text-slate-200 rounded-lg uppercase tracking-wider transition-all"
                >
                  Limpar Todos os Filtros
                </button>
              </div>
            )}
          </section>
        </main>
      ) : (
        /* SUPER ADMIN PANEL VIEW */
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" id="super-admin-layout">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar selection portal */}
            <aside className="w-full lg:w-64 shrink-0 space-y-4">
              <div className="bg-slate-900 rounded-2xl p-5 border border-slate-800 space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-850 pb-3">
                  <div className="font-bold text-xs uppercase text-slate-500 font-mono">Identificação:</div>
                  <span className="text-[10px] text-amber-500 font-black font-mono select-all">m_smartmall577</span>
                </div>

                <nav className="flex flex-row lg:flex-col gap-1 overflow-x-auto lg:overflow-x-visible pb-2 lg:pb-0 scrollbar-none">
                  {/* Dashboard */}
                  <button
                    onClick={() => setAdminTab('dashboard')}
                    className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-extrabold uppercase tracking-wide flex items-center gap-2.5 whitespace-nowrap transition-all ${
                      adminTab === 'dashboard'
                        ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                        : 'text-slate-400 hover:text-white hover:bg-slate-950'
                    }`}
                  >
                    <BarChart2 className="w-4.5 h-4.5" />
                    Dashboard Vendas
                  </button>

                  {/* Catalog manager */}
                  <button
                    onClick={() => setAdminTab('catalog')}
                    className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-extrabold uppercase tracking-wide flex items-center gap-2.5 whitespace-nowrap transition-all ${
                      adminTab === 'catalog'
                        ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                        : 'text-slate-400 hover:text-white hover:bg-slate-950'
                    }`}
                  >
                    <Package className="w-4.5 h-4.5" />
                    Gerenciar Catálogo
                  </button>

                  {/* Sales tracking control */}
                  <button
                    onClick={() => setAdminTab('sales')}
                    className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-extrabold uppercase tracking-wide flex items-center gap-2.5 whitespace-nowrap transition-all ${
                      adminTab === 'sales'
                        ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                        : 'text-slate-400 hover:text-white hover:bg-slate-950'
                    }`}
                  >
                    <Truck className="w-4.5 h-4.5" />
                    Aprovações Vendas
                  </button>

                  {/* Payment hub gateway config */}
                  <button
                    onClick={() => setAdminTab('gateways')}
                    className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-extrabold uppercase tracking-wide flex items-center gap-2.5 whitespace-nowrap transition-all ${
                      adminTab === 'gateways'
                        ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                        : 'text-slate-400 hover:text-white hover:bg-slate-950'
                    }`}
                  >
                    <CreditCard className="w-4.5 h-4.5" />
                    Hub de Gateway
                  </button>

                  {/* Employee management button */}
                  <button
                    onClick={() => setAdminTab('employees')}
                    className={`w-full text-left py-2.5 px-3 rounded-lg text-xs font-extrabold uppercase tracking-wide flex items-center gap-2.5 whitespace-nowrap transition-all ${
                      adminTab === 'employees'
                        ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                        : 'text-slate-400 hover:text-white hover:bg-slate-950'
                    }`}
                  >
                    <Users className="w-4.5 h-4.5" />
                    Quadro de Equipe
                  </button>
                </nav>
              </div>

              {/* Server virtual host settings helper widget */}
              <div className="bg-slate-900 rounded-2xl p-5 border border-slate-800 text-xs text-slate-400 space-y-3">
                <div className="flex items-center gap-2 text-slate-200">
                  <Shield className="w-4 h-4 text-amber-500" />
                  <span className="font-extrabold uppercase tracking-wide text-[10px] font-mono">Conformidade e Suporte</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  Para esclarecimento de dúvidas sobre conformidade legal, faturamento de frotas ou termos de serviço, entre em contato diretamente com o nosso suporte.
                </p>
                <div className="pt-2 border-t border-slate-850 space-y-1 text-[10px] font-mono">
                  <div className="text-white font-bold">rogermei577@gmail.com</div>
                  <div className="text-slate-500">Controladoria de Relações Corporativas</div>
                </div>
              </div>
            </aside>

            {/* Main view router admin panel */}
            <main className="flex-1 min-w-0">
              {adminTab === 'dashboard' && (
                <AdminDashboard orders={orders} products={products} />
              )}
              {adminTab === 'catalog' && (
                <AdminCatalog
                  products={products}
                  onUpdateProduct={handleUpdateProduct}
                  onAddProduct={handleAddProduct}
                />
              )}
              {adminTab === 'sales' && (
                <AdminOrders
                  orders={orders}
                  onUpdateOrderStatus={handleUpdateOrderStatus}
                />
              )}
              {adminTab === 'gateways' && (
                <AdminGateways
                  gateways={gateways}
                  onUpdateGateway={handleUpdateGateway}
                />
              )}
              {adminTab === 'employees' && (
                <AdminEmployees
                  employees={employees}
                  onAddEmployee={handleAddEmployee}
                  onRemoveEmployee={handleRemoveEmployee}
                />
              )}
            </main>
          </div>
        </div>
      )}

      {/* FOOTER GENERAL */}
      <footer className="bg-slate-900 border-t border-slate-805 py-12 mt-20" id="global-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="bg-amber-500 text-slate-950 p-2 rounded-lg flex items-center justify-center">
                <Truck className="w-5 h-5 stroke-[2.5]" />
              </div>
              <span className="text-lg font-extrabold tracking-tight text-white uppercase">
                TruckSmartMall
              </span>
            </div>
            <p className="text-xs text-slate-450 leading-relaxed max-w-sm">
              Maior distribuidora digital de componentes automotivos pesados de reposição do Brasil. Faturamento ágil de blocos de motor, mangueiras hidráulicas e suspensão pneumática com acompanhamento em tempo real.
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider font-mono font-bold">Atendimento Corporativo</h4>
            <div className="space-y-2 text-xs text-slate-400">
              <p>Segunda a Sexta-feira: 08h às 18h (Horário de Brasília).</p>
              <p className="text-amber-500 font-bold">Suporte Frotistas: rogermei577@gmail.com</p>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-xs font-black text-white uppercase tracking-wider font-mono font-bold">Garantia e Segurança</h4>
            <div className="space-y-2 text-xs text-slate-400">
              <p>Todas as autopeças possuem certificação de qualidade nacional e laudo técnico contra fadiga estrutural original do fabricante.</p>
            </div>
          </div>
        </div>

         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-850 mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-550">
          <div>
            © {new Date().getFullYear()} TruckSmartMall Ltda. CNPJ 77.592.577/0001-20. Todos os direitos reservados.
          </div>
          <div className="flex items-center gap-6">
            <button
              onClick={() => {
                setLegalInitialTab('terms');
                setCurrentView('legal');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-amber-500 font-bold uppercase tracking-wider text-[11px] transition-all"
            >
              Termos de Uso
            </button>
            <span className="text-slate-800">|</span>
            <button
              onClick={() => {
                setLegalInitialTab('privacy');
                setCurrentView('legal');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-amber-500 font-bold uppercase tracking-wider text-[11px] transition-all"
            >
              Política de Privacidade
            </button>
          </div>
        </div>
      </footer>

      {/* SLIDE-OUT CART SIDEBAR */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckoutComplete={handleCheckoutComplete}
        loggedCustomer={loggedCustomer}
        onRequireLogin={() => {
          setCartOpen(false);
          setCheckoutRedirectPending(true);
          setCurrentView('customer-auth');
        }}
      />

      {/* ADMIN SIGN-IN MODAL */}
      <AdminLogin
        isOpen={adminLoginOpen}
        onClose={() => setAdminLoginOpen(false)}
        onLoginSuccess={handleAdminLoginSuccess}
      />

    </div>
  );
}

