import { Product, PaymentGateway } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod_1',
    name: 'Turbocompressor Holset HE400VG',
    brand: 'Scania',
    category: 'Motor e Turbos',
    price: 4850.00,
    stock: 12,
    imageUrl: 'https://images.unsplash.com/photo-1616788494707-ec28f08d05a1?auto=format&fit=crop&q=80&w=600',
    description: 'Turbocompressor de alta performance com geometria variável (VGT) projetado especificamente para motores Scania de 13 litros (R-440 / R-450). Oferece maior economia de combustível, redução na emissão de poluentes e aumento substancial de torque em baixas rotações.',
    specifications: {
      oemCode: '2283526 / 5322474',
      material: 'Liga Siderúrgica de Alta Resistência Térmica',
      weight: '18.4 kg',
      compatibility: 'Scania G440, R440, G480, R480 (Euro 5) - Anos 2012 a 2019',
      warranty: '1 Ano contra defeitos de fabricação'
    }
  },
  {
    id: 'prod_2',
    name: 'Kit de Pastilhas de Freio Dianteiras HeavyDuty',
    brand: 'Volvo',
    category: 'Sistema de Freios',
    price: 680.00,
    stock: 24,
    imageUrl: 'https://images.unsplash.com/photo-1606577924006-27d39b132dd2?auto=format&fit=crop&q=80&w=600',
    description: 'Pastilhas de freio premium formuladas com composto semimetálico de alta fricção. Desenvolvidas sob rigorosos padrões de segurança para suportar frenagens extremas sob cargas de até 74 toneladas. Menor desgaste do disco e excelente dissipação térmica.',
    specifications: {
      oemCode: '21496550 / 85103117',
      material: 'Composto Dinâmico Semimetálico reforçado com Fibras de Kevlar',
      weight: '9.2 kg',
      compatibility: 'Volvo FH 460, FH 540, FM 370, FMX (Sistemas de freio Knorr/Meritor)',
      warranty: '6 Meses contra desgaste precoce'
    }
  },
  {
    id: 'prod_3',
    name: 'Kit de Embreagem Completo com Platô e Disco (430mm)',
    brand: 'Mercedes-Benz',
    category: 'Transmissão',
    price: 3250.00,
    stock: 8,
    imageUrl: 'https://images.unsplash.com/photo-1625047509168-a7026f36de04?auto=format&fit=crop&q=80&w=600',
    description: 'Kit de embreagem profissional composto por platô reforçado, disco de fricção orgânica de alta durabilidade e rolamento de encosto. Projetado para suportar as duras condições das rodovias brasileiras e regimes severos de trocas automáticas e manuais.',
    specifications: {
      oemCode: '0012501201 / 3400700346',
      material: 'Aço Temperado Silício-Manganês e Fricção de Ultra-Aderência',
      weight: '48.5 kg',
      compatibility: 'Mercedes-Benz Axor 2544, 2644, Actros 2546, 2646 (Caixas G281 / G330 Powershift)',
      warranty: '1 Ano de garantia de fábrica'
    }
  },
  {
    id: 'prod_4',
    name: 'Amortecedor de Cabine Pneumático Traseiro',
    brand: 'DAF',
    category: 'Suspensão e Direção',
    price: 940.00,
    stock: 15,
    imageUrl: 'https://images.unsplash.com/photo-1612462551373-c603b70868eb?auto=format&fit=crop&q=80&w=600',
    description: 'Bolsa de ar amortecedora integrada para suspensão da cabine. Oferece o máximo conforto ao motorista, absorvendo vibrações e impactos provocados pelas irregularidades do asfalto, reduzindo a fadiga em viagens de longa distância.',
    specifications: {
      oemCode: '1698805 / 1794420',
      material: 'Borracha natural vulcanizada reforçada com malha de nylon de alta densidade',
      weight: '4.8 kg',
      compatibility: 'DAF XF105, CF85 (Todos os modelos Euro 5)',
      warranty: '6 Meses'
    }
  },
  {
    id: 'prod_5',
    name: 'Filtro Separador de Água Racor (Combustível)',
    brand: 'Volkswagen',
    category: 'Filtros e Fluídos',
    price: 310.00,
    stock: 45,
    imageUrl: 'https://images.unsplash.com/photo-1558448295-d85c4bf4184c?auto=format&fit=crop&q=80&w=600',
    description: 'Filtro separador de alta eficiência para proteção do sistema de injeção Common Rail dos motores Cummins. Separa até 99.8% da água presente no óleo diesel brasileiro, evitando travamento de bicos injetores e desgaste prematuro da bomba de alta.',
    specifications: {
      oemCode: '2R0127177J / FS19732',
      material: 'Papel Coalescente Sintético Premium e Polímero de Alta Densidade',
      weight: '1.2 kg',
      compatibility: 'Volkswagen Constellation 19.320, 24.250, 24.280, Delivery 9.170, 11.180',
      warranty: '3 Meses'
    }
  },
  {
    id: 'prod_6',
    name: 'Bomba de Água de Arrefecimento de Alta Vazão',
    brand: 'Iveco',
    category: 'Resfriamento e Motor',
    price: 1150.00,
    stock: 10,
    imageUrl: 'https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?auto=format&fit=crop&q=80&w=600',
    description: 'Bomba d\'água fabricada em liga especial de alumínio injetado, com juntas e retentores de alta performance. Garante a circulação constante e pressurizada do fluído de arrefecimento, mantendo o motor Cursor na temperatura exata de operação.',
    specifications: {
      oemCode: '504241285 / 5801439902',
      material: 'Alumínio Injetado com Rotor Interno Balanceado',
      weight: '6.7 kg',
      compatibility: 'Iveco Stralis 380, 410, Trakker, Tector 240E25, 240E28',
      warranty: '9 Meses'
    }
  },
  {
    id: 'prod_7',
    name: 'Farol Principal Máscara Negra H7 Lado Direito',
    brand: 'Scania',
    category: 'Iluminação e Elétrica',
    price: 1890.00,
    stock: 6,
    imageUrl: 'https://images.unsplash.com/photo-1508974239320-0a029497e820?auto=format&fit=crop&q=80&w=600',
    description: 'Farol dianteiro esportivo estilo Máscara Negra com lentes de policarbonato de alta resistência contra pedriscos e incidência severa de raios UV. Farol alto/baixo e pisca integrados. Conexão elétrica idêntica ao chicote original.',
    specifications: {
      oemCode: '1882006 / 2081822',
      material: 'Policarbonato Macrolon Anti-Amarelamento e Refletores Metalizados',
      weight: '5.1 kg',
      compatibility: 'Scania Streamline, Linha P, G e R (Euro 5 Serie 5 e Serie 6) - 2013 a 2018',
      warranty: '6 Meses contra infiltração'
    }
  },
  {
    id: 'prod_8',
    name: 'Alternador de Carga Reforçado 24V / 120A',
    brand: 'Volvo',
    category: 'Iluminação e Elétrica',
    price: 2150.00,
    stock: 7,
    imageUrl: 'https://images.unsplash.com/photo-1504221507732-5246c045949b?auto=format&fit=crop&q=80&w=600',
    description: 'Alternador de alto rendimento projetado para trabalhar em condições climáticas extremas e alta requisição elétrica (cabines leito com geladeira, inversores e ar condicionado elétrico). Regulador de tensão interno blindado com proteção de surto.',
    specifications: {
      oemCode: '20849349 / RE554580',
      material: 'Bobinas de Cobre Eletrolítico e Carcaça Alumínio Silício',
      weight: '11.5 kg',
      compatibility: 'Volvo FH12, FH13, FM11, VM 270, VM 330 (Motores D11 / D13)',
      warranty: '1 Ano de garantia total'
    }
  },
  {
    id: 'prod_9',
    name: 'Servo de Embreagem Pneumático Knorr-Bremse',
    brand: 'Mercedes-Benz',
    category: 'Transmissão',
    price: 1420.00,
    stock: 9,
    imageUrl: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&q=80&w=600',
    description: 'Servo de auxílio pneumático de embreagem hidro-pneumática. Reduz em até 70% o esforço físico exigido no pedal pelo motorista profissional, otimizando as trocas de marchas e protegendo o garfo de acionamento.',
    specifications: {
      oemCode: 'A0002500062 / VG3208',
      material: 'Carcaça de Alumínio Polido com Selos de PTFE e Viton',
      weight: '3.6 kg',
      compatibility: 'Mercedes-Benz Atego 1719, 2425, 2426, Accelo 815, 1016',
      warranty: '1 Ano'
    }
  },
  {
    id: 'prod_10',
    name: 'Radiador de Água do Motor Brasado em Alumínio',
    brand: 'Ford',
    category: 'Resfriamento e Motor',
    price: 2790.00,
    stock: 4,
    imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=600',
    description: 'Radiador de água com núcleo brasado de alta capacidade de troca térmica. Construído inteiramente em alumínio expandido, sem caixas plásticas crimpadas, eliminando o risco de trincas e vazamentos causados pela vibração severa de caminhões trucados.',
    specifications: {
      oemCode: 'XC458005AA / 5030230',
      material: 'Alumínio de Brasagem Ativa de Parede Dupla',
      weight: '14.9 kg',
      compatibility: 'Ford Cargo 2422, 2428, 2628, 2429, 2842 (Cabines antigas e novas com motores Cummins)',
      warranty: '1 Ano contra vazamento'
    }
  },
  {
    id: 'prod_11',
    name: 'Bomba Hidráulica de Engrenagem Dupla Reforçada',
    brand: 'John Deere',
    category: 'Tratores - Hidráulico',
    price: 1540.00,
    stock: 8,
    imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=600',
    description: 'Bomba hidráulica de engrenagem de alta vazão reforçada, ideal para acionamento de implementos agrícolas pesados e sistemas de levante de três pontos. Fabricada sob os mais rígidos padrões internacionais para máxima durabilidade do óleo e resistência à cavitação.',
    specifications: {
      oemCode: 'RE228352 / AL161103',
      material: 'Ferro Fundido Nodular GGG50 com vedações em Poliuretano de Alto Desempenho',
      weight: '8.5 kg',
      compatibility: 'Tratores John Deere 5078E, 5090E, 6110J, 6125J, 7200J',
      warranty: '1 Ano contra defeito de fabricação'
    }
  },
  {
    id: 'prod_12',
    name: 'Filtro Hidráulico de Transmissão Dynashift',
    brand: 'Massey Ferguson',
    category: 'Filtros e Fluídos',
    price: 420.00,
    stock: 35,
    imageUrl: 'https://images.unsplash.com/photo-1558448295-d85c4bf4184c?auto=format&fit=crop&q=80&w=600',
    description: 'Filtro de óleo hidráulico de transmissão projetado especificamente para sistemas Dynashift e transmissões sincronizadas. Retém micropartículas metálicas suspensas de até 10 microns, estendendo a vida útil dos pacotes de embreagem molhada.',
    specifications: {
      oemCode: '3901411M91 / 4302922M1',
      material: 'Papel Microfibra de Vidro Plissado Sintético com Carcaça Metálica Revestida',
      weight: '1.5 kg',
      compatibility: 'Tratores Massey Ferguson MF 4275, MF 275, MF 7722, MF 4707',
      warranty: '3 Meses de garantia'
    }
  },
  {
    id: 'prod_13',
    name: 'Conjunto de Embreagem Dupla Estriada (310mm)',
    brand: 'Valtra',
    category: 'Transmissão',
    price: 3850.00,
    stock: 5,
    imageUrl: 'https://images.unsplash.com/photo-1625047509168-a7026f36de04?auto=format&fit=crop&q=80&w=600',
    description: 'Kit de embreagem dupla completo composto por disco orgânico, disco cerametálico amortecido, platô reforçado e rolamentos de acionamento. Garante trocas precisas e macias do sistema de tomada de força (TDP) em operações agrícolas pesadas.',
    specifications: {
      oemCode: '82944200 / 83912000',
      material: 'Pastilhas de Metal-Cerâmica (Cerametálico) e Aço de Mola Alto Carbono',
      weight: '22.0 kg',
      compatibility: 'Tratores Valtra A950, BH180, BH194, Valmet 785, 885',
      warranty: '1 Ano contra defeitos de fabricação'
    }
  },
  {
    id: 'prod_14',
    name: 'Alternador de Corrente de Carga Rápida 14V / 120A',
    brand: 'New Holland',
    category: 'Iluminação e Elétrica',
    price: 1190.00,
    stock: 14,
    imageUrl: 'https://images.unsplash.com/photo-1504221507732-5246c045949b?auto=format&fit=crop&q=80&w=600',
    description: 'Alternador reforçado projetado para operar com eficiência mesmo sob baixas rotações rotineiras de motores agrícolas. Possui rolamentos duplos blindados contra poeira e fuligem de palha de soja ou cana.',
    specifications: {
      oemCode: '87532293 / 48120349',
      material: 'Bobinamento Dinâmico em Cobre Puro e Estator Silício de Alta Eficiência',
      weight: '6.2 kg',
      compatibility: 'Tratores New Holland T7.240, T7.245, T6.130, TS6.120, 7630',
      warranty: '6 Meses contra defeitos'
    }
  },
  {
    id: 'prod_15',
    name: 'Radiador de Alumínio Expandido de Alta Dissipação',
    brand: 'Case IH',
    category: 'Resfriamento e Motor',
    price: 2650.00,
    stock: 7,
    imageUrl: 'https://images.unsplash.com/photo-1616788494707-ec28f08d05a1?auto=format&fit=crop&q=80&w=600',
    description: 'Radiador de água com colmeias expandidas de alta dissipação térmica e espaçamento otimizado para evitar acúmulo de poeira vegetal. Juntas fundidas de alta resistência a vibrações de solo arado.',
    specifications: {
      oemCode: '47935212 / 84320490',
      material: 'Alumínio Estampado de Alta Brasagem e Tratamento Anti-Corrosivo',
      weight: '12.8 kg',
      compatibility: 'Tratores Case IH Farmall 80, Farmall 95, Puma 200, Puma 220, Magnum 340',
      warranty: '1 Ano de fábrica'
    }
  },
  {
    id: 'prod_16',
    name: 'Elemento Filtro de Ar Seco Radial Seal (Par Primário + Secundário)',
    brand: 'John Deere',
    category: 'Filtros e Fluídos',
    price: 340.00,
    stock: 22,
    imageUrl: 'https://images.unsplash.com/photo-1517524006039-e8b4495cb1a1?auto=format&fit=crop&q=80&w=600',
    description: 'Conjunto completo de filtro de ar (interno e externo) com tecnologia Radial Seal para retenção avançada de poeira ultrafina suspensa em suspensão. Essencial para preservar as camisas do pistão e evitar desgaste precoce do motor em condições extremas de plantio e colheita.',
    specifications: {
      oemCode: 'DQ49586 / RE196945',
      material: 'Papel Plissado Especial de Celulose e Poliuretano Microcelular Hidrofóbico',
      weight: '2.1 kg',
      compatibility: 'Tratores John Deere 5078E, 5090E, 6110J, 6125J, 6110E, 5065E, 5075E',
      warranty: 'Garantia legal contra defeito estrutural'
    }
  },
  {
    id: 'prod_17',
    name: 'Bomba de Água de Alto Fluxo com Polia Dupla e Vedação de Silicone',
    brand: 'Massey Ferguson',
    category: 'Resfriamento e Motor',
    price: 680.00,
    stock: 15,
    imageUrl: 'https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&q=80&w=600',
    description: 'Bomba de água robusta de alta capacidade de arrefecimento, projetada especificamente para motores Perkins agrícolas. Inclui rotor balanceado dinamicamente para evitar ruídos de cavitação e juntas triplas de silicone de alta resistência térmica.',
    specifications: {
      oemCode: 'U5MW0194 / 3641832M91',
      material: 'Ferro Fundido Cinzento G25 e Rotor Interno de Alumínio Fundido',
      weight: '4.8 kg',
      compatibility: 'Tratores Massey Ferguson MF 275, MF 290, MF 4275, MF 4290 (Motor Perkins de 4 cilindros)',
      warranty: '6 Meses contra falhas estruturais'
    }
  },
  {
    id: 'prod_18',
    name: 'Cabo de Comando Hidráulico Duplo de Engate Rápido',
    brand: 'Valtra',
    category: 'Tratores - Hidráulico',
    price: 890.00,
    stock: 12,
    imageUrl: 'https://images.unsplash.com/photo-1508962914676-134849a727f0?auto=format&fit=crop&q=80&w=600',
    description: 'Cabo flexível blindado com joystick duplo e conexões de latão de engate rápido. Fabricado com proteção de nylon trançada de alta espessura para resistir à fricção do chassi e temperaturas de operação elevadas sob o assoalho do trator.',
    specifications: {
      oemCode: '81467400 / 81467500',
      material: 'Alma de Aço Carbono Flexível, Bainha de Poliuretano e Conectores de Latão',
      weight: '3.4 kg',
      compatibility: 'Tratores Valtra A750, A850, A950, BH140, BH180, BH194',
      warranty: '1 Ano de garantia de fábrica'
    }
  },
  {
    id: 'prod_19',
    name: 'Bico Injetor de Combustível Bosch Common Rail Premium',
    brand: 'New Holland',
    category: 'Motor e Turbos',
    price: 1450.00,
    stock: 24,
    imageUrl: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&q=80&w=600',
    description: 'Bico injetor calibrado com alta precisão para sistemas de injeção direta de alta pressão FPT Common Rail. Assegura a atomização ideal do diesel, reduzindo o consumo de combustível e a emissão de fumaça preta em acelerações sob carga.',
    specifications: {
      oemCode: '504380123 / 0445120236',
      material: 'Aço Liga Endurecido por Tratamento Térmico por Indução',
      weight: '0.85 kg',
      compatibility: 'Tratores New Holland T7.175, T7.190, T7.240, T7.245, T6.130 (Motores FPT NEF6)',
      warranty: '1 Ano de garantia do fabricante'
    }
  },
  {
    id: 'prod_20',
    name: 'Sensor Digital de Pressão de Óleo e Temperatura CanBus',
    brand: 'Case IH',
    category: 'Iluminação e Elétrica',
    price: 520.00,
    stock: 18,
    imageUrl: 'https://images.unsplash.com/photo-1555664424-778a1e5e1b48?auto=format&fit=crop&q=80&w=600',
    description: 'Sensor combinado de precisão industrial com protocolo de comunicação CanBus integrado para envio contínuo de leituras ao computador de bordo do trator. Resistente a picos de pressão hidráulica de até 15 bar e poeira intensa.',
    specifications: {
      oemCode: '84152345 / 47395200',
      material: 'Corpo de Latão Niquelado e Conector Termoplástico Vedado contra Umidade IP69K',
      weight: '0.12 kg',
      compatibility: 'Tratores Case IH Puma 140, Puma 155, Puma 185, Puma 220, Magnum 340',
      warranty: '1 Ano contra falhas elétricas'
    }
  },
  {
    id: 'prod_21',
    name: 'Bico Injetor de Combustível DAF MX-13 Bosch',
    brand: 'DAF',
    category: 'Motor e Turbos',
    price: 1890.00,
    stock: 12,
    imageUrl: 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&q=80&w=600',
    description: 'Bico injetor calibrado Bosch de alta precisão para o motor PACCAR MX-13 de 12.9 litros. Otimiza a combustão sob altas pressões, garantindo a redução do consumo de diesel e menor emissão de partículas sólidas.',
    specifications: {
      oemCode: '1824765 / 0445120352',
      material: 'Liga Metálica Endurecida por Têmpera Seletiva',
      weight: '0.90 kg',
      compatibility: 'DAF XF105, CF85 (Euro 5) - Motor PACCAR MX-13 410cv, 460cv',
      warranty: '6 Meses contra defeitos de fábrica'
    }
  },
  {
    id: 'prod_22',
    name: 'Turbocompressor Bi-Turbo BorgWarner K27',
    brand: 'Volkswagen',
    category: 'Motor e Turbos',
    price: 3950.00,
    stock: 6,
    imageUrl: 'https://images.unsplash.com/photo-1616788494707-ec28f08d05a1?auto=format&fit=crop&q=80&w=600',
    description: 'Turbina de alta vazão BorgWarner para motores MAN D08 de 4 e 6 cilindros. Projetado para suportar altos gradientes de temperatura e severas flutuações de pressão sem perda de rendimento dinâmico.',
    specifications: {
      oemCode: '062145701 / 53279887122',
      material: 'Carcaça de Ferro Silício-Molibdênio com Eixo de Titânio',
      weight: '16.5 kg',
      compatibility: 'VW Constellation 17.280, 24.280, 26.280, 31.280',
      warranty: '1 Ano de garantia integral'
    }
  },
  {
    id: 'prod_23',
    name: 'Servo de Embreagem Pneumático Wabco Pro',
    brand: 'Iveco',
    category: 'Transmissão',
    price: 1590.00,
    stock: 10,
    imageUrl: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&q=80&w=600',
    description: 'Servo-assistência pneumática de alta resposta para redução drástica do esforço físico de acionamento do pedal de embreagem. Garante suavidade incomparável e prolonga a durabilidade de todo o trambulador.',
    specifications: {
      oemCode: '41211244 / 9700511520',
      material: 'Alumínio Injetado sob Pressão e Vedações Internas de Teflon Autolubrificante',
      weight: '3.9 kg',
      compatibility: 'Iveco Stralis 380, 410, 460, Tector 240E25, PowerStar',
      warranty: '1 Ano contra defeitos de fabricação'
    }
  },
  {
    id: 'prod_24',
    name: 'Kit Pastilhas de Freio Dianteiras Fras-le HD',
    brand: 'Ford',
    category: 'Sistema de Freios',
    price: 540.00,
    stock: 28,
    imageUrl: 'https://images.unsplash.com/photo-1606577924006-27d39b132dd2?auto=format&fit=crop&q=80&w=600',
    description: 'Pastilhas de freio semimetálicas Fras-le para eixos dianteiros sob regime rodoviário severo. Formulação livre de amianto com alta estabilidade de atrito, prevenindo fadiga térmica do disco e ruidos estranhos.',
    specifications: {
      oemCode: 'YC352001AA / PD/452-HD',
      material: 'Fibra de Carbono, Kevlar e Cobre Sinterizado em Matriz Polimérica',
      weight: '8.2 kg',
      compatibility: 'Ford Cargo 2422, 2428, 2429, 1719, 1722, 1729, 2628',
      warranty: '6 Meses contra falhas estruturais'
    }
  },
  {
    id: 'prod_25',
    name: 'Bolsa de Ar Pneumática Suspensa Traseira Firestone',
    brand: 'Scania',
    category: 'Suspensão e Direção',
    price: 1120.00,
    stock: 14,
    imageUrl: 'https://images.unsplash.com/photo-1612462551373-c603b70868eb?auto=format&fit=crop&q=80&w=600',
    description: 'Fole ou bolsa pneumática suspensa traseira para chassi Scania. Projetada em borracha de alta flexibilidade para suavizar o transporte de cargas frógeis e sensíveis a balanços, mantendo o caminhão estável.',
    specifications: {
      oemCode: '1440294 / 1865759',
      material: 'Borracha Natural de Alta Elasticidade com 4 Camadas de Nylon Reforçado',
      weight: '6.5 kg',
      compatibility: 'Scania R440, R480, G420, S500, R540 (Eixos Traseiros de Tração)',
      warranty: '1 Ano de garantia contra vazamento ou ressecamento'
    }
  },
  {
    id: 'prod_26',
    name: 'Sensor de Óxido de Nitrogênio (Sensor NOx) 24V Continental',
    brand: 'Volvo',
    category: 'Iluminação e Elétrica',
    price: 1980.00,
    stock: 9,
    imageUrl: 'https://images.unsplash.com/photo-1555664424-778a1e5e1b48?auto=format&fit=crop&q=80&w=600',
    description: 'Sensor NOx original Continental de reposição de 24V para leitura exata de emissões pós-tratamento no sistema Arla 32. Evita perda de potência automática e ativação do modo de emergência da ECU por falha de leitura.',
    specifications: {
      oemCode: '22303391 / 21567763',
      material: 'Sonda Cerâmica de Óxido de Zircônio e Módulo Controlador Vedado IP69K',
      weight: '0.35 kg',
      compatibility: 'Volvo FH 460, FH 540, FM 370, VM 270, VM 330 (Sistemas Euro 5 SCR)',
      warranty: '6 Meses contra queima do circuito eletrônico'
    }
  },
  {
    id: 'prod_27',
    name: 'Cubo Redutor de Engrenagem Planetária de Roda Carraro',
    brand: 'John Deere',
    category: 'Transmissão',
    price: 2450.00,
    stock: 4,
    imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=600',
    description: 'Cubo redutor de roda dianteira completo para tração 4x4 Carraro original do trator. Inclui todas as engrenagens planetárias internas retificadas com dentes tratados térmicamente para máxima distribuição de torque severo.',
    specifications: {
      oemCode: 'AL160293 / RE245812',
      material: 'Aço de Alta Liga Cementado e Usinado em Centros CNC de Alta Precisão',
      weight: '15.2 kg',
      compatibility: 'Tratores John Deere 5078E, 5085E, 5090E, 6110J, 6125J',
      warranty: '1 Ano contra desgaste prematuro das engrenagens'
    }
  },
  {
    id: 'prod_28',
    name: 'Bomba Injetora Rotativa CAV Perkins 4 Cilindros',
    brand: 'Massey Ferguson',
    category: 'Motor e Turbos',
    price: 3200.00,
    stock: 6,
    imageUrl: 'https://images.unsplash.com/photo-1504221507732-5246c045949b?auto=format&fit=crop&q=80&w=600',
    description: 'Bomba injetora de combustível rotativa para motores agrícolas Perkins de 4 cilindros. Calibrada em bancadas profissionais para garantir partida imediata sob frio extremo e otimização total de queima sob cargas severas.',
    specifications: {
      oemCode: '3641888M91 / CAV3242F',
      material: 'Corpo de Alumínio Fundido e Elementos Internos de Aço Carbono Nitretado',
      weight: '7.8 kg',
      compatibility: 'Tratores Massey Ferguson MF 275, MF 290, MF 4275 (Motor Perkins 4236 / 4.41)',
      warranty: '6 Meses contra emperramento de pistão interno'
    }
  },
  {
    id: 'prod_29',
    name: 'Radiador de Água Compacto Reforçado com Colmeia de Cobre',
    brand: 'Valtra',
    category: 'Resfriamento e Motor',
    price: 2150.00,
    stock: 8,
    imageUrl: 'https://images.unsplash.com/photo-1616788494707-ec28f08d05a1?auto=format&fit=crop&q=80&w=600',
    description: 'Radiador de água com núcleo composto de tubos de cobre e aletas de latão estanhadas para máxima condutividade e resistência ao ataque corrosivo de aditivos químicos. Suporta as mais intensas trepidações em arado pesado.',
    specifications: {
      oemCode: '82934211 / 82952200',
      material: 'Tubulações de Cobre Puro e Caixas de Latão Soldadas à Mão',
      weight: '11.4 kg',
      compatibility: 'Tratores Valtra A850, A950, Valmet 885, 985',
      warranty: '1 Ano de garantia contra vazamento de soldas'
    }
  },
  {
    id: 'prod_30',
    name: 'Elemento Filtro de Ar Seco Radial T7 Donaldson',
    brand: 'New Holland',
    category: 'Filtros e Fluídos',
    price: 490.00,
    stock: 18,
    imageUrl: 'https://images.unsplash.com/photo-1517524006039-e8b4495cb1a1?auto=format&fit=crop&q=80&w=600',
    description: 'Kit de filtro de ar premium Donaldson composto por elemento de segurança secundário e elemento filtrante de barreira primária. Retém grãos de pólen, poeira de calcário e restos vegetais com eficiência máxima absoluta.',
    specifications: {
      oemCode: '84325212 / 87529340',
      material: 'Papel Plissado de Microfibra Sintética e Vedação Integral de Poliuretano',
      weight: '2.5 kg',
      compatibility: 'Tratores New Holland T7.175, T7.190, T7.240, T7.245, T7.260',
      warranty: 'Garantia legal contra defeitos do meio filtrante'
    }
  },
  {
    id: 'prod_31',
    name: 'Acoplamento Flexível Elástico de Transmissão Principal',
    brand: 'Case IH',
    category: 'Transmissão',
    price: 780.00,
    stock: 14,
    imageUrl: 'https://images.unsplash.com/photo-1508962914676-134849a727f0?auto=format&fit=crop&q=80&w=600',
    description: 'Acoplamento elástico de borracha nitrílica com inserção de cabos de aço internos. Projetado para amortecer picos de torque violentos transmitidos do motor ao eixo da transmissão hidrostática em tratores pesados.',
    specifications: {
      oemCode: '47942125 / 84129320',
      material: 'Borracha Nitrílica NBR Revestida e Insertos Metálicos de Aço Carbono',
      weight: '2.8 kg',
      compatibility: 'Tratores Case IH Puma 155, Puma 185, Puma 220, Magnum 340',
      warranty: '6 Meses contra rasgos estruturais'
    }
  },
  {
    id: 'prod_32',
    name: 'Motor de Partida Elétrico de Partida Rápida Delco Remy 12V',
    brand: 'John Deere',
    category: 'Iluminação e Elétrica',
    price: 1580.00,
    stock: 10,
    imageUrl: 'https://images.unsplash.com/photo-1504221507732-5246c045949b?auto=format&fit=crop&q=80&w=600',
    description: 'Motor de partida Delco Remy reforçado de 12V para motores John Deere PowerTech de 4.5 e 6.8 litros. Oferece alta rotação inicial com menor consumo de bateria, reduzindo o tempo de arranque matinal em plantações.',
    specifications: {
      oemCode: 'RE507236 / SE501861',
      material: 'Carcaça de Aço Silício Estampado e Pinhão de Aço Cromo-Níquel Cementado',
      weight: '8.4 kg',
      compatibility: 'Tratores John Deere 5078E, 5090E, 6110J, 6125J, 6145J, 7200J',
      warranty: '1 Ano contra defeitos internos de enrolamento'
    }
  },
  {
    id: 'prod_33',
    name: 'Filtro Separador de Água Racor MF Parker',
    brand: 'Massey Ferguson',
    category: 'Filtros e Fluídos',
    price: 290.00,
    stock: 40,
    imageUrl: 'https://images.unsplash.com/photo-1558448295-d85c4bf4184c?auto=format&fit=crop&q=80&w=600',
    description: 'Copo separador de água e filtro Racor original Parker para motores Perkins e AGCO Power. Protege contra impurezas abrasivas presentes nos tanques de diesel de fazendas e fazendas agrícolas brasileiras.',
    specifications: {
      oemCode: '7111296 / 3901245M91',
      material: 'Carcaça de Polímero de Policarbonato Transparente e Papel Coalescente Aquabloc',
      weight: '0.95 kg',
      compatibility: 'Tratores Massey Ferguson MF 275, MF 290, MF 4275, MF 4290, MF 50X',
      warranty: 'Garantia contra defeito de moldagem do copo'
    }
  },
  {
    id: 'prod_34',
    name: 'Kit de Reparos de Cilindro de Direção Hidráulica Dianteira',
    brand: 'Valtra',
    category: 'Suspensão e Direção',
    price: 310.00,
    stock: 25,
    imageUrl: 'https://images.unsplash.com/photo-1508962914676-134849a727f0?auto=format&fit=crop&q=80&w=600',
    description: 'Jogo completo de guarnições, raspadores e anéis o-ring de poliuretano e viton para vedação absoluta de cilindros de direção de tratores. Restaura o desempenho de manobra sem vazamentos de óleo hidráulico.',
    specifications: {
      oemCode: '82942099 / 82950201',
      material: 'Anéis de Poliuretano de Alto Torque e O-Rings de Fluorocarboneto (Viton)',
      weight: '0.25 kg',
      compatibility: 'Tratores Valtra A750, A850, A950, Valmet 785, 885',
      warranty: '3 Meses de garantia'
    }
  },
  {
    id: 'prod_35',
    name: 'Sensor Optoeletrônico de Fluxo de Grãos Colheitadeira',
    brand: 'New Holland',
    category: 'Iluminação e Elétrica',
    price: 2250.00,
    stock: 6,
    imageUrl: 'https://images.unsplash.com/photo-1555664424-778a1e5e1b48?auto=format&fit=crop&q=80&w=600',
    description: 'Sensor óptico de alta precisão calibrado para leitura do fluxo volumétrico e umidade de colheita no elevador de grãos limpos de colheitadeiras de soja e milho. Conexão direta com os monitores de telemetria PLM.',
    specifications: {
      oemCode: '84352119 / 87293402',
      material: 'Lente de Vidro de Quartzo Anti-Riscos e Carcaça Vedada de Alumínio Fundido IP67',
      weight: '0.45 kg',
      compatibility: 'Colheitadeiras New Holland TC5070, TC5090, TX5.90, CR5.85, CR6.80',
      warranty: '1 Ano de garantia de fábrica'
    }
  },
  {
    id: 'prod_36',
    name: 'Bomba Hidráulica Auxiliar de Engrenagem Traseira Rexroth',
    brand: 'Case IH',
    category: 'Tratores - Hidráulico',
    price: 1850.00,
    stock: 7,
    imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=600',
    description: 'Bomba de engrenagens externa Bosch Rexroth com fluxo contínuo balanceado para fornecimento de pressão suplementar ao circuito hidráulico de controle remoto traseiro (VCRs). Evita quedas bruscas de vazão.',
    specifications: {
      oemCode: '47934293 / 84358001',
      material: 'Corpo Extrudado de Alumínio de Alta Resistência e Tampas de Ferro Fundido',
      weight: '4.6 kg',
      compatibility: 'Tratores Case IH Farmall 80, Farmall 95, Puma 140, Puma 155',
      warranty: '1 Ano contra falhas elétricas ou mecânicas'
    }
  }
];

export const INITIAL_GATEWAYS: PaymentGateway[] = [
  {
    id: 'gw_1',
    name: 'Mercado Pago',
    logo: 'MP',
    isActive: true,
    apiKey: 'APP_USR-7826352932029320-9428-prod',
    clientSecret: 'sec_mp_prod_77cf02a3fe9c',
    merchantId: 'm_pago_88352',
    sandboxMode: true,
    additionalFields: {
      'Webhook URL': 'https://truck.smartmall577.space/api/pay-hub/webhook-mp',
      'Chave Pix': 'pix@smartmall577.space',
      'Modo de Checkouts': 'Redirect Pro ou Transparente'
    }
  },
  {
    id: 'gw_2',
    name: 'Cielo LIO',
    logo: 'CL',
    isActive: false,
    apiKey: 'ci_key_4432-8854-942810',
    clientSecret: 'ci_sec_77ff8d99c2d1b7',
    merchantId: 'cielo_merchant_001293',
    sandboxMode: true,
    additionalFields: {
      'Client ID': 'cielo-client-app-v3',
      'Adquirente Primária': 'Cielo S.A.',
      'Antifraude Integrado': 'CyberSource (Ativo)'
    }
  },
  {
    id: 'gw_3',
    name: 'PagBank (PagSeguro)',
    logo: 'PS',
    isActive: false,
    apiKey: 'pg_key_9941a877bf77ea',
    clientSecret: 'pg_sec_22913e0bc9fa7',
    merchantId: 'pagseguro_885429',
    sandboxMode: true,
    additionalFields: {
      'Token de Notificação': 'notif_token_pagseg_94218',
      'Checkout Express': 'Habilitado'
    }
  },
  {
    id: 'gw_4',
    name: 'Rede (Itaú)',
    logo: 'RD',
    isActive: false,
    apiKey: 're_key_e310ea09bbcf88',
    clientSecret: 're_sec_7fa831cf02a9fa3',
    merchantId: 'rede_itau_7761042',
    sandboxMode: true,
    additionalFields: {
      'ID de Estabelecimento': '99412039',
      'Captura Automática': 'Sim'
    }
  },
  {
    id: 'gw_5',
    name: 'Stone Pagamentos',
    logo: 'ST',
    isActive: false,
    apiKey: 'st_key_bf88ea30ac179ff3',
    clientSecret: 'st_sec_00a943acbd928fc',
    merchantId: 'stone_sac_99218',
    sandboxMode: true,
    additionalFields: {
      'Stone Code': 'SC-209485293',
      'Versão da API': 'v2'
    }
  },
  {
    id: 'gw_6',
    name: 'Asaas Fintech',
    logo: 'AS',
    isActive: false,
    apiKey: 'asaas_key_77a9cf02cb2e18d',
    clientSecret: 'asaas_sec_6641abdafe937',
    merchantId: 'asaas_m_334582',
    sandboxMode: true,
    additionalFields: {
      'Retorno Automatizado': 'Habilitado (Webhook V3)',
      'Geração de Boleto Registrado': 'Ativo'
    }
  },
  {
    id: 'gw_7',
    name: 'Getnet (Santander)',
    logo: 'GT',
    isActive: false,
    apiKey: 'gt_key_11eef2a9fbc88cd9',
    clientSecret: 'gt_sec_7781bcfda093efb87',
    merchantId: 'get_merch_009941a',
    sandboxMode: true,
    additionalFields: {
      'Chave Pix Gateway': 'pix-getnet@smartmall577.space',
      'Multi-comprador': 'Permitido'
    }
  },
  {
    id: 'gw_8',
    name: 'Safe2Pay',
    logo: 'S2',
    isActive: false,
    apiKey: 's2_key_88fa93cbe2fa0192',
    clientSecret: 's2_sec_ffffaa300e84f271',
    merchantId: 'safe_294380',
    sandboxMode: true,
    additionalFields: {
      'Split de Pagamento': 'Não',
      'Notificar por E-mail': 'Sim'
    }
  },
  {
    id: 'gw_9',
    name: 'PicPay E-commerce',
    logo: 'PP',
    isActive: false,
    apiKey: 'pp_key_9941fa9e39cefa01',
    clientSecret: 'pp_sec_330efdcaa7882fa',
    merchantId: 'picpay_merch_01824',
    sandboxMode: true,
    additionalFields: {
      'Seller Token': 'st_picpay_83952a9fbc30',
      'Exibição QR Code': 'Checkout Dinâmico'
    }
  },
  {
    id: 'gw_10',
    name: 'Pagar.me',
    logo: 'PM',
    isActive: false,
    apiKey: 'pm_key_fcee0394bdabfe421',
    clientSecret: 'pm_sec_884192b0cffe982f1',
    merchantId: 'pagarme_merch_77592',
    sandboxMode: true,
    additionalFields: {
      'Versão Engine': 'Pagar.me V5',
      'Split Recorrente': 'Desabilitado'
    }
  }
];
