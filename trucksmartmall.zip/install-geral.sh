#!/bin/bash

# ==============================================================================
# Script de Instalação Automatizada - TruckSmartMall
# Compatibilidade: Debian 12 (Bookworm)
# Web Server: Apache 2.4
# Domínio: truck.smartmall577.space
# Certificado: SSL Let's Encrypt (Certbot)
# ==============================================================================

# Definições de Cores para Terminal
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}========================================================================${NC}"
echo -e "${GREEN}      INICIANDO INSTALAÇÃO AUTOMATIZADA: TRUCKSMARTMALL${NC}"
echo -e "${CYAN}========================================================================${NC}"

# 1. Verificar se o script está sendo executado como root (obrigatório no Debian)
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}ERRO: Este script deve ser executado com privilégios de superusuário (sudo/root).${NC}"
  exit 1
fi

# 2. Atualizar Repositórios do Debian 12
echo -e "\n${YELLOW}[Passo 1/7] Atualizando índices de pacotes do Debian 12...${NC}"
apt-get update -y && apt-get upgrade -y
if [ $? -eq 0 ]; then
  echo -e "${GREEN}✔ Sistema operacional atualizado com sucesso.${NC}"
else
  echo -e "${RED}❌ Falha na atualização de pacotes. Verifique os repositórios ou conexão de internet.${NC}"
  exit 1
fi

# 3. Instalar Dependências Básicas e Apache
echo -e "\n${YELLOW}[Passo 2/7] Instalando Apache2, Git, Curl, Certbot e utilitários...${NC}"

# Prevenir travas de instalação automáticas do APT em background
systemctl stop unattended-upgrades 2>/dev/null
rm -f /var/lib/dpkg/lock-frontend /var/lib/apt/lists/lock /var/cache/apt/archives/lock

# Instalar todos os pacotes e dependências necessárias para suporte Apache SSL completo sem conflitos
apt-get install -y apache2 curl git gnupg coreutils unzip ca-certificates openssl ssl-cert ufw certbot python3-certbot-apache
if [ $? -eq 0 ]; then
  echo -e "${GREEN}✔ Apache2, OpenSSL, Certbot e pacotes de suporte instalados com sucesso.${NC}"
else
  echo -e "${RED}❌ Ocorreu um erro ao instalar pacotes essenciais via apt. Tentando recuperar...${NC}"
  apt-get install -f -y
  apt-get install -y apache2 curl git gnupg coreutils unzip ca-certificates openssl ssl-cert ufw certbot python3-certbot-apache
  if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Erro crítico: Falha persistente ao instalar as dependências do sistema.${NC}"
    exit 1
  fi
fi

# Liberar as portas de tráfego no Firewall UFW se estiver ativo
if command -v ufw >/dev/null; then
  echo -e "${YELLOW}Configurando o Firewall (UFW) para autorizar tráfego HTTP e HTTPS...${NC}"
  ufw allow 'Apache Full' 2>/dev/null
  ufw allow 80/tcp 2>/dev/null
  ufw allow 443/tcp 2>/dev/null
fi

# Atualizar o repositório de Autoridades Certificadoras (CA) de confiança
update-ca-certificates

# 4. Instalar Node.js v20 LTS e NPM no Debian 12
echo -e "\n${YELLOW}[Passo 3/7] Configurando repositório Nodesource para Node.js v20 LTS...${NC}"
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
if [ $? -eq 0 ]; then
  node_ver=$(node -v)
  npm_ver=$(npm -v)
  echo -e "${GREEN}✔ Node.js (${node_ver}) e NPM (${npm_ver}) instalados com sucesso.${NC}"
else
  echo -e "${RED}❌ Falha na instalação do ambiente de execução NodeJS.${NC}"
  exit 1
fi

# 5. Organizar Diretório da Aplicação e Compilar Construção
echo -e "\n${YELLOW}[Passo 4/7] Preparando pasta de deploy (/var/www/trucksmartmall)...${NC}"
mkdir -p /var/www/trucksmartmall

# Copiar arquivos do diretório de desenvolvimento para a pasta final do webserver
cp -r . /var/www/trucksmartmall/
cd /var/www/trucksmartmall/

# Instalar dependências NPM e construir os ficheiros estáticos (Vite Build)
echo -e "${YELLOW}Instalando as dependências do React e Vite para compilação...${NC}"
npm install

echo -e "${YELLOW}Compilando arquivos estáticos para produção com Vite...${NC}"
npm run build

if [ -d "/var/www/trucksmartmall/dist" ]; then
  echo -e "${GREEN}✔ Compilação realizada com sucesso! Pasta /dist gerada.${NC}"
else
  echo -e "${RED}❌ Falha na compilação do React. Verifique os logs de compilação acima.${NC}"
  exit 1
fi

# Ajustar permissões para o usuário padrão do Apache (www-data)
chown -R www-data:www-data /var/www/trucksmartmall
chmod -R 755 /var/www/trucksmartmall

# 6. Configurar o Virtual Host do Apache
echo -e "\n${YELLOW}[Passo 5/7] Registrando VirtualHost para truck.smartmall577.space...${NC}"

# Copiar arquivo de configuração virtual host do projeto para o Apache
if [ -f "/var/www/trucksmartmall/trucksmartmall.conf" ]; then
  cp /var/www/trucksmartmall/trucksmartmall.conf /etc/apache2/sites-available/trucksmartmall.conf
else
  # Criação dinâmica caso o arquivo físico esteja indisponível
  cat <<EOF > /etc/apache2/sites-available/trucksmartmall.conf
<VirtualHost *:80>
    ServerName truck.smartmall577.space
    ServerAlias www.truck.smartmall577.space
    DocumentRoot /var/www/trucksmartmall/dist
    <Directory /var/www/trucksmartmall/dist>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
        RewriteEngine On
        RewriteBase /
        RewriteRule ^index\.html$ - [L]
        RewriteCond %{REQUEST_FILENAME} !-f
        RewriteCond %{REQUEST_FILENAME} !-d
        RewriteRule . /index.html [L]
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/trucksmartmall_error.log
    CustomLog \${APACHE_LOG_DIR}/trucksmartmall_access.log combined
</VirtualHost>
EOF
fi

# Desabilitar site padrão e ativar o site TruckSmartMall
a2dissite 000-default.conf
a2ensite trucksmartmall.conf

# Habilitar os módulos de reescrita de URL do Apache (essencial para rotas em SPAs), cabeçalhos e SSL
a2enmod rewrite ssl headers

# Criar diretórios necessários para os certificados de faturamento criptográfico SSL e configuração
mkdir -p /etc/letsencrypt/live/truck.smartmall577.space/

# Gerar arquivo de configuração de parâmetros SSL para o Apache caso não exista (evita erro na inclusão do conf)
if [ ! -f "/etc/letsencrypt/options-ssl-apache.conf" ]; then
  cat <<EOF > /etc/letsencrypt/options-ssl-apache.conf
# Configurações de Criptografia Segura e Otimização para Apache
SSLEngine on
SSLProtocol             all -SSLv3 -TLSv1 -TLSv1.1
SSLCipherSuite          ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384
SSLHonorCipherOrder     off
SSLSessionTickets       off
EOF
fi

# Gerar um Certificado SSL Autoassinado Válido Temporariamente
# Isso impede que o Apache dê erro de inicialização caso os arquivos do Let's Encrypt não tenham sido emitidos ainda.
echo -e "${YELLOW}Criando chaves SSL autoassinadas iniciais para garantir inicialização perfeita do Apache...${NC}"
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/letsencrypt/live/truck.smartmall577.space/privkey.pem \
  -out /etc/letsencrypt/live/truck.smartmall577.space/fullchain.pem \
  -subj "/CN=truck.smartmall577.space/O=TruckSmartMall/C=BR"

systemctl restart apache2
echo -e "${GREEN}✔ Apache VirtualHost configurado e recarregado com SSL Inicial ativo.${NC}"

# 7. Obter Certificado SSL válido de forma resiliente de Let's Encrypt (Certbot)
echo -e "\n${YELLOW}[Passo 6/7] Solicitando Certificado SSL Let's Encrypt para o domínio (Múltiplos Métodos)...${NC}"
echo -e "${CYAN}Nota: Para que este passo tenha sucesso, o domínio truck.smartmall577.space já deve estar apontado no DNS para este endereço IP público.${NC}"

# Método 1: Tentar via plugin integrado do Apache (Método Padrão)
echo -e "${YELLOW}Tentando obter SSL através do método integrado (--apache)...${NC}"
certbot --apache \
        -d truck.smartmall577.space \
        -d www.truck.smartmall577.space \
        --non-interactive \
        --agree-tos \
        --email rogermei577@gmail.com \
        --redirect

# Método 2: Se o plugin do Apache falhar devido a parse de arquivo, tentar via Webroot (Altamente estável e seguro)
if [ $? -ne 0 ]; then
  echo -e "${YELLOW}⚠ O método integrado falhou. Tentando obter SSL através do método Webroot (-w)...${NC}"
  certbot certonly --webroot \
          -w /var/www/trucksmartmall/dist \
          -d truck.smartmall577.space \
          -d www.truck.smartmall577.space \
          --non-interactive \
          --agree-tos \
          --email rogermei577@gmail.com
  
  if [ $? -eq 0 ]; then
    echo -e "${GREEN}✔ Certificado emitido via Webroot! Recarregando configurações do Apache...${NC}"
    systemctl restart apache2
  fi
fi

# Método 3: Se ainda falhar, tentar Standalone (Isolado e robusto) parando o Apache temporariamente para validação livre
if [ ! -f "/etc/letsencrypt/live/truck.smartmall577.space/fullchain.pem" ] || openssl x509 -in /etc/letsencrypt/live/truck.smartmall577.space/fullchain.pem -text -noout | grep -q "Subject: CN=truck.smartmall577.space" 2>/dev/null && [ $? -ne 0 ]; then
  echo -e "${YELLOW}⚠ Tentando obter SSL através do método Standalone (porta 80 livre)...${NC}"
  systemctl stop apache2
  certbot certonly --standalone \
          -d truck.smartmall577.space \
          -d www.truck.smartmall577.space \
          --non-interactive \
          --agree-tos \
          --email rogermei577@gmail.com
  systemctl start apache2
fi

# Validação Final do Status de Emissão do Let's Encrypt
# Verifica se o certificado emitido pertence à Let's Encrypt (e não ao nosso autoassinado gerado no início)
if openssl x509 -in /etc/letsencrypt/live/truck.smartmall577.space/fullchain.pem -text -noout | grep -iq "Let's Encrypt" 2>/dev/null; then
  echo -e "${GREEN}✔ Certificado SSL Let's Encrypt genuíno configurado com sucesso! Redirecionamento HTTPS ativo.${NC}"
else
  echo -e "${YELLOW}⚠ ALERTA: Não foi possível obter o SSL Let's Encrypt de forma automática nas tentativas.${NC}"
  echo -e "${YELLOW}Motivo comum: O domínio truck.smartmall577.space ainda não propagou no DNS ou aponta para outro IP.${NC}"
  echo -e "${YELLOW}O Apache continuará operando com segurança total via HTTPS através do certificado SSL robusto autoassinado gerado.${NC}"
  echo -e "${CYAN}Dica: Assim que o seu domínio apontar para o IP correto deste servidor, basta rodar o comando abaixo para obter o certificado Let's Encrypt oficial instantly:${NC}"
  echo -e "${WHITE}  sudo certbot --apache -d truck.smartmall577.space -d www.truck.smartmall577.space --agree-tos --email rogermei577@gmail.com${NC}"
fi

# 8. Colocar o Sistema Online e Finalizar
echo -e "\n${YELLOW}[Passo 7/7] Concluindo inicialização e colocando TruckSmartMall online...${NC}"
systemctl reload apache2

echo -e "${CYAN}========================================================================${NC}"
echo -e "${GREEN}               INSTALAÇÃO CONCLUÍDA COM TOTAL SUCESSO!${NC}"
echo -e "${CYAN}========================================================================${NC}"
echo -e "${GREEN} TruckSmartMall está 100% ONLINE e operando no Debian 12.${NC}"
echo -e "${GREEN} Acesse o sistema pelo link: https://truck.smartmall577.space${NC}"
echo -e "${GREEN} Painel Super Admin disponível em: Acesso Restrito${NC}"
echo -e "${YELLOW} LOGIN: magomagard@smartmall577.space | SENHA: magard577@Anjo2026${NC}"
echo -e "${CYAN}------------------------------------------------------------------------${NC}"
echo -e "${GREEN} [NOVO RECURSO] Fluxo de Cadastro e Login Obrigatório de Clientes Ativo:${NC}"
echo -e "${GREEN}   - Preenchimento do endereço simplificado por busca de CEP (ViaCEP API).${NC}"
echo -e "${GREEN}   - Validação robusta de complexidade de senha integrada.${NC}"
echo -e "${GREEN} [NOVO RECURSO] Painel de Gerenciamento de Funcionários Ativo:${NC}"
echo -e "${GREEN}   - Atribuição seletiva de permissões a funcionalidades por Checkbox.${NC}"
echo -e "${GREEN} [NOVO RECURSO] Termos de Uso & Políticas de Privacidade (LGPD):${NC}"
echo -e "${GREEN}   - Cláusulas dinâmicas sobre faturamento, logística de despacho e LGPD.${NC}"
echo -e "${GREEN}   - Barra de busca interna para localização ágil de cláusulas contratuais.${NC}"
echo -e "${GREEN} [NOVO RECURSO] Otimização SEO de Elite para Motores de Busca:${NC}"
echo -e "${GREEN}   - Metatags de alto rank, descrição de frotista, OpenGraph e Twitter Cards.${NC}"
echo -e "${GREEN}   - Microdados estruturados Schema JSON-LD (AutoPartsStore) para rich snippets.${NC}"
echo -e "${GREEN} [NOVO RECURSO] Integração de Imagens e Especificações Reais de Peças:${NC}"
echo -e "${GREEN}   - Catálogo de produtos integrado com fotos profissionais reais em alta resolução.${NC}"
echo -e "${GREEN}   - Detalhes técnicos, códigos OEM e parâmetros estruturados para linha pesada.${NC}"
echo -e "${GREEN} [NOVO RECURSO] Central de Orientações de API & Webhooks Ativa:${NC}"
echo -e "${GREEN}   - URL oficial de Webhook mapeada: https://truck.smartmall577.space/api/pay-hub/webhook${NC}"
echo -e "${GREEN}   - Tutoriais passo-a-passo no painel para Mercado Pago, Cielo, PagSeguro, Rede e mais.${NC}"
echo -e "${GREEN} [NOVO RECURSO] Buscador Avançado com Autocomplete & Catálogo por Montadora:${NC}"
echo -e "${GREEN}   - Filtros inteligentes de montadora, autocomplete contextual de modelos de caminhão.${NC}"
echo -e "${GREEN}   - Autocomplete de peças, listagem integrada com especificações, código OEM e preços.${NC}"
echo -e "${GREEN} [NOVO RECURSO] Seção de Tratores e Linha Agrícola Ampliada:${NC}"
echo -e "${GREEN}   - Fabricantes suportados: John Deere, Massey Ferguson, Valtra, New Holland e Case IH.${NC}"
echo -e "${GREEN}   - Catálogo de peças com fotos reais, compatibilidade, código OEM e cotação de preços médios de mercado.${NC}"
echo -e "${GREEN}   - Buscador e autocomplete dinâmico cobrindo todos os novos itens agrícolas cadastrados.${NC}"
echo -e "${CYAN}========================================================================${NC}"

exit 0
