import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  ScreenShare,
  Hand,
  Smile,
  MessageSquare,
  Users,
  PhoneOff,
  Shield,
  Crown,
  Paperclip,
  Send,
  X,
  MoreVertical,
  VolumeX,
  Ban,
  Check,
  CheckCircle,
  Clock,
  Timer,
  RotateCcw,
  Heart,
  Flame,
  FileText,
  Download,
  AlertCircle,
  Copy,
  Sparkles,
  UserPlus,
  Radio,
  CreditCard,
  DollarSign,
  Lock,
  Coins,
  Zap,
  TrendingUp,
} from 'lucide-react';
import type { Room, User, RoomParticipant, ChatMessage, JoinRequest, RelationshipLevel } from '../types.ts';
import { VideoEmbedPlayer } from './VideoEmbedPlayer.tsx';
import { AudioPlayer } from './AudioPlayer.tsx';
import { LiveTransmissionModal } from './LiveTransmissionModal.tsx';
import { StandardConferenceTemplate } from './StandardConferenceTemplate.tsx';
import { RechargeModal } from './RechargeModal.tsx';
import { MAX_FILE_SIZE_BYTES, formatFileSize, isAudioWavOrMp3, isImageValid } from '../utils/mediaEmbed.ts';

interface ConferenceRoomProps {
  room: Room;
  currentUser: User;
  onLeaveRoom: () => void;
}

const RemoteVideo: React.FC<{ stream?: MediaStream; hidden?: boolean }> = ({ stream, hidden }) => {
  const ref = useRef<HTMLVideoElement | null>(null);
  useEffect(() => {
    if (ref.current) ref.current.srcObject = stream || null;
  }, [stream]);
  return <video ref={ref} autoPlay playsInline className={`h-full w-full object-cover ${hidden || !stream ? 'hidden' : 'block'}`} />;
};

export const ConferenceRoom: React.FC<ConferenceRoomProps> = ({ room, currentUser, onLeaveRoom }) => {
  const isModerator = room.creatorId === currentUser.id;

  // Modo de visualização: Template Padrão (Tabela Mosaico 15+Palestrante) ou Clássico
  const [conferenceViewMode, setConferenceViewMode] = useState<'standard_template' | 'classic'>('classic');

  // Admission status for Private Rooms
  const [admitted, setAdmitted] = useState<boolean>(room.type === 'public' || isModerator);
  const [presentationText, setPresentationText] = useState('');
  const [waitingApproval, setWaitingApproval] = useState(false);
  const [rejectedMessage, setRejectedMessage] = useState<string | null>(null);

  // Regra dos 400 segundos para sala privada
  const [joinRequestCreatedAt, setJoinRequestCreatedAt] = useState<string | null>(null);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(400);
  const [isExpired, setIsExpired] = useState<boolean>(false);

  // In-meeting states
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [activeDrawer, setActiveDrawer] = useState<'none' | 'chat' | 'participants'>('none');
  const [unreadChatCount, setUnreadChatCount] = useState(0);

  // Participants & Messages
  const [participants, setParticipants] = useState<RoomParticipant[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');

  // Reactions & Floating animations
  const [floatingReactions, setFloatingReactions] = useState<{ id: string; emoji: string; left: number }[]>([]);
  const [showReactionsMenu, setShowReactionsMenu] = useState(false);

  // Moderator Join Requests Queue (for Private Rooms)
  const [pendingJoinRequests, setPendingJoinRequests] = useState<JoinRequest[]>([]);

  // Moderator Ban Modal
  const [banTarget, setBanTarget] = useState<RoomParticipant | null>(null);
  const [banDurationAmount, setBanDurationAmount] = useState('30');
  const [banDurationUnit, setBanDurationUnit] = useState<'minutes' | 'hours' | 'days' | 'months'>('minutes');
  const [banReason, setBanReason] = useState('Desrespeito às diretrizes da sala.');
  const [copiedLink, setCopiedLink] = useState(false);
  const [isLiveModalOpen, setIsLiveModalOpen] = useState(false);
  const [showChatEmojis, setShowChatEmojis] = useState(false);

  // Friendship request inside room
  const [friendshipTarget, setFriendshipTarget] = useState<{ id: string; name: string } | null>(null);
  const [relationshipLevels, setRelationshipLevels] = useState<RelationshipLevel[]>([]);
  const [selectedRelLevel, setSelectedRelLevel] = useState<string>('');
  const [friendshipMessage, setFriendshipMessage] = useState<string>('');
  const [friendshipStatusNotice, setFriendshipStatusNotice] = useState<string | null>(null);

  // Tarifas Chamasso e Saldo do Usuário
  const [tariffSettings, setTariffSettings] = useState<{
    billingEnabled: boolean;
    ratePerMinute: number;
    minRechargeAmount: number;
    rechargeValidityDays: number;
  }>({
    billingEnabled: true,
    ratePerMinute: 0.01,
    minRechargeAmount: 5.0,
    rechargeValidityDays: 30,
  });
  const [hasCredits, setHasCredits] = useState<boolean>(true);
  const [showRechargeModal, setShowRechargeModal] = useState<boolean>(false);
  const [billingNotice, setBillingNotice] = useState<string | null>(null);

  // Moeda Virtual Pasqcoin & Contagem Progressiva no Chat (1 até segundosPerCoin)
  const [pasqcoinSettings, setPasqcoinSettings] = useState<{
    enabled: boolean;
    name: string;
    symbol: string;
    secondsPerCoin: number;
    pricePerCoin: number;
  }>({
    enabled: true,
    name: 'pasqcoin',
    symbol: 'PASQ',
    secondsPerCoin: 60,
    pricePerCoin: 0.01,
  });
  const [pasqcoinBalance, setPasqcoinBalance] = useState<number>(currentUser.pasqcoins ?? 0);
  const [firstMessageSent, setFirstMessageSent] = useState<boolean>(false);
  const [pasqcoinActive, setPasqcoinActive] = useState<boolean>(false);
  const [pasqcoinProgressSec, setPasqcoinProgressSec] = useState<number>(0);
  const [pasqcoinsConsumedThisSession, setPasqcoinsConsumedThisSession] = useState<number>(0);
  const [showPasqcoinAdminDetails, setShowPasqcoinAdminDetails] = useState<boolean>(true);
  const [isBuyingPasqcoins, setIsBuyingPasqcoins] = useState<boolean>(false);
  const [purchaseStatusNotice, setPurchaseStatusNotice] = useState<string | null>(null);
  const pendingPasqSecondsRef = useRef<number>(0);
  const consumeRequestInFlightRef = useRef<boolean>(false);

  const formatPasq = (value: number) => Math.max(0, Number(value) || 0).toFixed(6);
  const formatRemainingTime = (totalSeconds: number) => {
    const safe = Math.max(0, Math.floor(totalSeconds));
    const days = Math.floor(safe / 86400);
    const hours = Math.floor((safe % 86400) / 3600);
    const minutes = Math.floor((safe % 3600) / 60);
    const seconds = safe % 60;
    if (days > 0) return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`;
    return `${minutes}m ${seconds}s`;
  };

  // Carrega parâmetros do Pasqcoin e saldo em tempo real
  useEffect(() => {
    fetch('/api/pasqcoin/settings')
      .then((r) => r.json())
      .then((data) => {
        if (data.settings) {
          setPasqcoinSettings(data.settings);
        }
      })
      .catch((err) => console.error('Erro ao carregar pasqcoin settings:', err));

    fetch(`/api/users/${currentUser.id}/balance`)
      .then((r) => r.json())
      .then((data) => {
        if (data && typeof data.pasqcoins === 'number') {
          setPasqcoinBalance(data.pasqcoins);
        }
      })
      .catch(() => {});
  }, [currentUser.id]);

  // Contagem regressiva PASQcoin por tempo consumido.
  // A interface atualiza a cada segundo; o backend persiste em lotes de até 5 segundos
  // para evitar uma requisição por segundo por usuário.
  useEffect(() => {
    if (!pasqcoinActive) return;

    const secondsPerCoin = Math.max(1, Number(pasqcoinSettings.secondsPerCoin) || 60);

    const flushPendingSeconds = async () => {
      if (consumeRequestInFlightRef.current || pendingPasqSecondsRef.current <= 0) return;
      const secondsToConsume = Math.min(30, pendingPasqSecondsRef.current);
      pendingPasqSecondsRef.current -= secondsToConsume;
      consumeRequestInFlightRef.current = true;
      try {
        const res = await fetch('/api/pasqcoin/consume', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUser.id,
            roomId: room.id,
            seconds: secondsToConsume,
          }),
          keepalive: true,
        });
        const result = await res.json();
        if (!res.ok) throw new Error(result.error || 'Falha ao consumir PASQcoin.');

        const newCoins = Number(result.pasqcoinsRemaining ?? result.user?.pasqcoins ?? 0);
        setPasqcoinBalance(newCoins);
        if (newCoins <= 0) {
          setPasqcoinActive(false);
          setHasCredits(false);
          setBillingNotice('Seu saldo PASQcoin chegou a zero. Adquira mais PASQcoin para continuar interagindo.');
          setShowRechargeModal(true);
        }
      } catch (err) {
        console.error('Erro ao persistir consumo fracionário de PASQcoin:', err);
        // Reconcilia a carteira com o servidor se houver falha de rede.
        fetch(`/api/users/${currentUser.id}/balance`)
          .then((r) => r.json())
          .then((data) => {
            if (typeof data.pasqcoins === 'number') setPasqcoinBalance(data.pasqcoins);
          })
          .catch(() => {});
      } finally {
        consumeRequestInFlightRef.current = false;
        if (pendingPasqSecondsRef.current >= 5) void flushPendingSeconds();
      }
    };

    const ticker = window.setInterval(() => {
      setPasqcoinProgressSec((prev) => (prev + 1) % secondsPerCoin);
      setPasqcoinBalance((prev) => {
        const next = Math.max(0, Number((prev - 1 / secondsPerCoin).toFixed(6)));
        if (next <= 0) setPasqcoinActive(false);
        return next;
      });
      setPasqcoinsConsumedThisSession((prev) => Number((prev + 1 / secondsPerCoin).toFixed(6)));
      pendingPasqSecondsRef.current += 1;
      if (pendingPasqSecondsRef.current >= 5) void flushPendingSeconds();
    }, 1000);

    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && pendingPasqSecondsRef.current > 0) {
        void flushPendingSeconds();
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    return () => {
      window.clearInterval(ticker);
      document.removeEventListener('visibilitychange', onVisibilityChange);
      if (pendingPasqSecondsRef.current > 0) void flushPendingSeconds();
    };
  }, [pasqcoinActive, pasqcoinSettings.secondsPerCoin, currentUser.id, room.id]);

  // Aquisição de PASQcoin sempre pelo checkout oficial (PIX/Mercado Pago).
  const handleQuickBuyPasqcoins = (_amount: number) => {
    setPurchaseStatusNotice(null);
    setShowRechargeModal(true);
  };

  useEffect(() => {
    fetch('/api/relationship-levels')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setRelationshipLevels(data);
          if (data.length > 0) setSelectedRelLevel(data[0].id);
        }
      })
      .catch((err) => console.error(err));
  }, []);

  // Tarifas Chamasso: acesso tarifado baseado exclusivamente em PASQcoin.
  useEffect(() => {
    if (!admitted) return;

    const checkTariffsAndBalance = async () => {
      try {
        const tariffRes = await fetch('/api/tariffs/settings');
        let billingActive = true;
        if (tariffRes.ok) {
          const tData = await tariffRes.json();
          setTariffSettings(tData);
          billingActive = !!tData.billingEnabled && tData.unlockFeeEnabled !== false;
        }
        if (!billingActive) {
          setHasCredits(true);
          setBillingNotice(null);
          return;
        }

        const balRes = await fetch(`/api/users/${currentUser.id}/balance`);
        if (!balRes.ok) return;
        const bData = await balRes.json();
        const coins = Math.max(0, Number(bData.pasqcoins) || 0);
        setPasqcoinBalance(coins);
        const userHasCredits = coins > 0 || !!bData.isFreeAccess;

        if (!userHasCredits) {
          setHasCredits(false);
          setIsAudioMuted(true);
          setIsVideoOff(true);
          if (localStreamRef.current) {
            localStreamRef.current.getAudioTracks().forEach((t) => (t.enabled = false));
            localStreamRef.current.getVideoTracks().forEach((t) => (t.enabled = false));
          }
          setBillingNotice('Saldo PASQcoin insuficiente. Você está no modo somente visualização.');
        } else {
          setHasCredits(true);
          setBillingNotice(null);
        }
      } catch (err) {
        console.error('Erro ao verificar carteira PASQcoin:', err);
      }
    };

    void checkTariffsAndBalance();
  }, [admitted, currentUser.id]);

  const handleSendFriendship = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendshipTarget || !selectedRelLevel) return;
    try {
      const res = await fetch('/api/friendship-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: currentUser.id,
          receiverId: friendshipTarget.id,
          relationshipLevelId: selectedRelLevel,
          message: friendshipMessage.trim() || undefined,
        }),
      });
      if (res.ok) {
        setFriendshipStatusNotice(`Solicitação enviada com sucesso para ${friendshipTarget.name}!`);
        setTimeout(() => {
          setFriendshipTarget(null);
          setFriendshipStatusNotice(null);
          setFriendshipMessage('');
        }, 1500);
      } else {
        const errData = await res.json();
        setFriendshipStatusNotice(errData.error || 'Erro ao enviar solicitação.');
      }
    } catch (err) {
      setFriendshipStatusNotice('Falha na comunicação com o servidor.');
    }
  };

  // Media Streams & WebSockets
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const myClientIdRef = useRef<string | null>(null);
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const iceServersRef = useRef<RTCIceServer[]>([{ urls: 'stun:stun.l.google.com:19302' }]);
  const [remoteStreams, setRemoteStreams] = useState<Record<string, MediaStream>>({});
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  const closePeer = (clientId: string) => {
    const pc = peerConnectionsRef.current.get(clientId);
    if (pc) pc.close();
    peerConnectionsRef.current.delete(clientId);
    setRemoteStreams((prev) => {
      const next = { ...prev };
      delete next[clientId];
      return next;
    });
  };

  const ensurePeerConnection = async (targetClientId: string): Promise<RTCPeerConnection> => {
    const existing = peerConnectionsRef.current.get(targetClientId);
    if (existing) return existing;

    const pc = new RTCPeerConnection({ iceServers: iceServersRef.current });
    peerConnectionsRef.current.set(targetClientId, pc);
    localStreamRef.current?.getTracks().forEach((track) => pc.addTrack(track, localStreamRef.current!));

    pc.onicecandidate = (event) => {
      if (event.candidate && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'webrtc_ice_candidate', targetClientId, candidate: event.candidate }));
      }
    };
    pc.ontrack = (event) => {
      const stream = event.streams[0] || new MediaStream([event.track]);
      setRemoteStreams((prev) => ({ ...prev, [targetClientId]: stream }));
    };
    pc.onconnectionstatechange = () => {
      if (['failed', 'closed'].includes(pc.connectionState)) closePeer(targetClientId);
    };
    return pc;
  };

  const createOfferFor = async (targetClientId: string) => {
    if (!localStreamRef.current || targetClientId === myClientIdRef.current) return;
    const pc = await ensurePeerConnection(targetClientId);
    if (pc.signalingState !== 'stable') return;
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    wsRef.current?.send(JSON.stringify({ type: 'webrtc_offer', targetClientId, sdp: offer }));
  };

  // Setup Local Media (Camera & Mic)
  useEffect(() => {
    if (!admitted) return;

    let mounted = true;

    async function setupMedia() {
      try {
        try {
          const cfg = await fetch('/api/webrtc/config').then((r) => r.json());
          if (Array.isArray(cfg.iceServers) && cfg.iceServers.length) iceServersRef.current = cfg.iceServers;
        } catch { /* STUN padrão permanece ativo */ }
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: true,
        });

        if (!mounted) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        localStreamRef.current = stream;
        peerConnectionsRef.current.forEach((pc) => {
          const existingTrackIds = new Set(pc.getSenders().map((sender) => sender.track?.id));
          stream.getTracks().forEach((track) => { if (!existingTrackIds.has(track.id)) pc.addTrack(track, stream); });
        });
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.warn('Câmera/Microfone físico não disponível no contêiner ou permissão negada:', err);
      }
    }

    setupMedia();

    return () => {
      mounted = false;
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((t) => t.stop());
      }
      peerConnectionsRef.current.forEach((pc) => pc.close());
      peerConnectionsRef.current.clear();
      setRemoteStreams({});
    };
  }, [admitted]);

  // Polling e ticker de contagem regressiva para moderador (pedidos visíveis por 400 segundos)
  useEffect(() => {
    if (!isModerator || !admitted) return;

    const fetchRequests = () => {
      fetch(`/api/rooms/${room.id}/join-requests`)
        .then((res) => res.json())
        .then((data) => {
          if (Array.isArray(data)) {
            setPendingJoinRequests(data);
          }
        })
        .catch((err) => console.error(err));
    };

    fetchRequests();

    // Ticker a cada 1s decrementa segundos restantes e remove os que ultrapassarem 400s
    const ticker = setInterval(() => {
      const now = Date.now();
      setPendingJoinRequests((prev) =>
        prev
          .map((req) => {
            const elapsed = Math.floor((now - new Date(req.createdAt).getTime()) / 1000);
            const remaining = Math.max(0, 400 - elapsed);
            return { ...req, secondsRemaining: remaining };
          })
          .filter((req) => (req.secondsRemaining ?? 0) > 0)
      );
    }, 1000);

    return () => clearInterval(ticker);
  }, [isModerator, admitted, room.id]);

  // Ticker de 1s para o pretendente (contagem regressiva de 400s até 0)
  useEffect(() => {
    if (!waitingApproval || admitted) return;

    const ticker = setInterval(() => {
      if (joinRequestCreatedAt) {
        const elapsed = Math.floor((Date.now() - new Date(joinRequestCreatedAt).getTime()) / 1000);
        const remaining = Math.max(0, 400 - elapsed);
        setSecondsRemaining(remaining);
        if (remaining <= 0) {
          setIsExpired(true);
          setWaitingApproval(false);
        }
      } else {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            setIsExpired(true);
            setWaitingApproval(false);
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => clearInterval(ticker);
  }, [waitingApproval, admitted, joinRequestCreatedAt]);

  // Polling a cada 2.5s para pretendente conferir se foi aprovado, reprovado ou expirado
  useEffect(() => {
    if (!waitingApproval || admitted) return;

    const poll = setInterval(async () => {
      try {
        const res = await fetch(`/api/rooms/${room.id}/join-request-status?userId=${currentUser.id}`);
        if (res.ok) {
          const data = await res.json();
          if (data.status === 'approved') {
            setAdmitted(true);
            setWaitingApproval(false);
            setIsExpired(false);
          } else if (data.status === 'rejected') {
            setWaitingApproval(false);
            setRejectedMessage('O anfitrião recusou seu pedido de entrada no momento.');
          } else if (data.status === 'expired') {
            setWaitingApproval(false);
            setIsExpired(true);
          } else if (typeof data.secondsRemaining === 'number') {
            setSecondsRemaining(data.secondsRemaining);
            if (data.secondsRemaining <= 0) {
              setWaitingApproval(false);
              setIsExpired(true);
            }
          }
        }
      } catch (err) {
        // ignore network glitches
      }
    }, 2500);

    return () => clearInterval(poll);
  }, [waitingApproval, admitted, room.id, currentUser.id]);

  // Conexão WebSocket especial para pretendente aguardando aprovação
  useEffect(() => {
    if (admitted || !waitingApproval) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws?roomId=${encodeURIComponent(room.id)}&userId=${encodeURIComponent(
      currentUser.id
    )}&waitingAdmission=true`;

    const ws = new WebSocket(wsUrl);
    ws.onmessage = async (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'join_request_decision' && data.userId === currentUser.id) {
          if (data.status === 'approved') {
            setAdmitted(true);
            setWaitingApproval(false);
            setIsExpired(false);
          } else {
            setWaitingApproval(false);
            setRejectedMessage(data.message || 'Seu pedido de entrada foi recusado pelo moderador.');
          }
        } else if (data.type === 'join_request_expired' && data.userId === currentUser.id) {
          setWaitingApproval(false);
          setIsExpired(true);
        }
      } catch (err) {
        // ignore
      }
    };

    return () => {
      ws.close();
    };
  }, [admitted, waitingApproval, room.id, currentUser.id]);

  // Setup WebSocket Connection
  useEffect(() => {
    if (!admitted) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/ws?roomId=${encodeURIComponent(room.id)}&userId=${encodeURIComponent(
      currentUser.id
    )}&userName=${encodeURIComponent(currentUser.name + ' ' + currentUser.lastName)}&isModerator=${isModerator}`;

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log('[chamasso WS] Conectado à sala:', room.id);
    };

    ws.onmessage = async (event) => {
      try {
        const data = JSON.parse(event.data);

        switch (data.type) {
          case 'room_init':
            myClientIdRef.current = data.clientId;
            setParticipants(data.participants || []);
            setMessages(data.messages || []);
            // O cliente recém-chegado inicia ofertas para todos os pares já presentes.
            setTimeout(() => {
              (data.participants || []).filter((p: RoomParticipant) => p.id !== data.clientId).forEach((p: RoomParticipant) => {
                createOfferFor(p.id).catch((err) => console.error('[WebRTC] offer:', err));
              });
            }, 250);
            break;

          case 'participant_joined':
            setParticipants((prev) => {
              if (prev.some((p) => p.id === data.participant.id)) return prev;
              return [...prev, data.participant];
            });
            break;

          case 'participant_updated':
            setParticipants((prev) =>
              prev.map((p) => (p.id === data.participant.id ? data.participant : p))
            );
            break;

          case 'participant_left':
            setParticipants((prev) => prev.filter((p) => p.id !== data.clientId));
            closePeer(data.clientId);
            break;

          case 'webrtc_offer': {
            const pc = await ensurePeerConnection(data.fromClientId);
            await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            ws.send(JSON.stringify({ type: 'webrtc_answer', targetClientId: data.fromClientId, sdp: answer }));
            break;
          }

          case 'webrtc_answer': {
            const pc = peerConnectionsRef.current.get(data.fromClientId);
            if (pc && data.sdp) await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
            break;
          }

          case 'webrtc_ice_candidate': {
            const pc = await ensurePeerConnection(data.fromClientId);
            if (data.candidate) await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
            break;
          }

          case 'new_chat_message':
            setMessages((prev) => [...prev, data.message]);
            if (activeDrawer !== 'chat') {
              setUnreadChatCount((c) => c + 1);
            }
            break;

          case 'reaction_broadcast': {
            const id = Math.random().toString(36).substring(2, 9);
            const left = Math.floor(Math.random() * 60) + 20; // 20% to 80% screen width
            setFloatingReactions((prev) => [...prev, { id, emoji: data.reaction, left }]);
            setTimeout(() => {
              setFloatingReactions((prev) => prev.filter((r) => r.id !== id));
            }, 3000);
            break;
          }

          case 'new_join_request':
            if (isModerator) {
              setPendingJoinRequests((prev) => {
                if (prev.some((r) => r.id === data.request.id)) return prev;
                return [...prev, data.request];
              });
            }
            break;

          case 'join_request_expired':
            if (isModerator) {
              setPendingJoinRequests((prev) => prev.filter((r) => r.id !== data.requestId));
            }
            if (data.userId === currentUser.id) {
              setWaitingApproval(false);
              setIsExpired(true);
            }
            break;

          case 'join_request_decision':
            if (data.userId === currentUser.id) {
              if (data.status === 'approved') {
                setAdmitted(true);
                setWaitingApproval(false);
                setIsExpired(false);
              } else {
                setWaitingApproval(false);
                setRejectedMessage(data.message || 'Seu pedido de entrada foi recusado pelo moderador.');
              }
            }
            break;

          case 'forced_muted_by_moderator':
            setIsAudioMuted(true);
            if (localStreamRef.current) {
              localStreamRef.current.getAudioTracks().forEach((t) => (t.enabled = false));
            }
            alert(`Você foi silenciado pelo moderador ${data.moderatorName}.`);
            break;

          case 'user_banned':
            if (data.userId === currentUser.id) {
              alert(
                `Você foi bloqueado desta sala pelo moderador ${data.moderatorName} até ${new Date(
                  data.expiresAt
                ).toLocaleString('pt-BR')}. Motivo: ${data.reason}`
              );
              onLeaveRoom();
            }
            break;

          case 'room_closed':
            alert(data.message);
            onLeaveRoom();
            break;

          default:
            break;
        }
      } catch (err) {
        console.error('Erro no parser de evento WS:', err);
      }
    };

    ws.onclose = () => {
      console.log('[chamasso WS] Desconectado da sala');
    };

    return () => {
      ws.close();
    };
  }, [admitted, room.id, currentUser.id, isModerator]);

  // Scroll chat to bottom when messages update
  useEffect(() => {
    if (activeDrawer === 'chat' && chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, activeDrawer]);

  // Toggle Audio (Mic)
  const handleToggleAudio = () => {
    if (tariffSettings.billingEnabled && !hasCredits) {
      setBillingNotice('Saldo insuficiente para ativar o microfone. Recarregue seus créditos para transmitir áudio.');
      setShowRechargeModal(true);
      return;
    }
    const newState = !isAudioMuted;
    setIsAudioMuted(newState);
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((t) => {
        t.enabled = !newState;
      });
    }
    wsRef.current?.send(
      JSON.stringify({
        type: 'media_state_change',
        isAudioMuted: newState,
      })
    );
  };

  // Toggle Video (Camera)
  const handleToggleVideo = () => {
    if (tariffSettings.billingEnabled && !hasCredits) {
      setBillingNotice('Saldo insuficiente para ligar a câmera. Recarregue seus créditos para transmitir vídeo.');
      setShowRechargeModal(true);
      return;
    }
    const newState = !isVideoOff;
    setIsVideoOff(newState);
    if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach((t) => {
        t.enabled = !newState;
      });
    }
    wsRef.current?.send(
      JSON.stringify({
        type: 'media_state_change',
        isVideoOff: newState,
      })
    );
  };

  // Toggle Screen Share
  const handleToggleScreenShare = async () => {
    if (tariffSettings.billingEnabled && !hasCredits) {
      setBillingNotice('Saldo insuficiente para compartilhar tela. Recarregue seus créditos para interagir.');
      setShowRechargeModal(true);
      return;
    }
    if (!isScreenSharing) {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        setIsScreenSharing(true);
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = screenStream;
        }
        const screenTrack = screenStream.getVideoTracks()[0];
        await Promise.all((Array.from(peerConnectionsRef.current.values()) as RTCPeerConnection[]).map(async (pc) => {
          const sender = pc.getSenders().find((s) => s.track?.kind === 'video');
          if (sender) await sender.replaceTrack(screenTrack);
        }));

        screenTrack.onended = () => {
          setIsScreenSharing(false);
          if (localStreamRef.current && localVideoRef.current) {
            localVideoRef.current.srcObject = localStreamRef.current;
            const cameraTrack = localStreamRef.current.getVideoTracks()[0];
            peerConnectionsRef.current.forEach((pc) => {
              const sender = pc.getSenders().find((s) => s.track?.kind === 'video');
              if (sender) sender.replaceTrack(cameraTrack).catch(() => {});
            });
          }
          wsRef.current?.send(
            JSON.stringify({
              type: 'media_state_change',
              isScreenSharing: false,
            })
          );
        };

        wsRef.current?.send(
          JSON.stringify({
            type: 'media_state_change',
            isScreenSharing: true,
          })
        );
      } catch (err) {
        console.warn('Compartilhamento de tela cancelado ou não suportado:', err);
      }
    } else {
      setIsScreenSharing(false);
      if (localStreamRef.current && localVideoRef.current) {
        localVideoRef.current.srcObject = localStreamRef.current;
      }
      wsRef.current?.send(
        JSON.stringify({
          type: 'media_state_change',
          isScreenSharing: false,
        })
      );
    }
  };

  // Toggle Hand Raise
  const handleToggleHandRaise = () => {
    const newState = !isHandRaised;
    setIsHandRaised(newState);
    wsRef.current?.send(
      JSON.stringify({
        type: 'media_state_change',
        isHandRaised: newState,
      })
    );
  };

  // Send Reaction
  const handleSendReaction = (emoji: string) => {
    wsRef.current?.send(
      JSON.stringify({
        type: 'reaction',
        reaction: emoji,
      })
    );
    setShowReactionsMenu(false);
  };

  // Send Chat Message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    if (tariffSettings.billingEnabled && !hasCredits) {
      setBillingNotice('Saldo insuficiente para enviar mensagens. Recarregue seus créditos para conversar no bate-papo.');
      setShowRechargeModal(true);
      return;
    }

    // Regra Pasqcoin: ao mandar a primeira mensagem inicia-se a contagem progressiva 1 até a quantidade em segundos que vale um pasqcoin
    if (!firstMessageSent) {
      setFirstMessageSent(true);
      setPasqcoinActive(true);
      setPasqcoinProgressSec(0);
    }

    wsRef.current?.send(
      JSON.stringify({
        type: 'chat_message',
        text: chatInput.trim(),
        senderNickname: currentUser.nickname,
      })
    );
    setChatInput('');
  };

  // Upload file in chat (limite estrito de 33MB e áudio somente WAV/MP3)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (tariffSettings.billingEnabled && !hasCredits) {
      alert('Saldo insuficiente para enviar arquivos. Recarregue seus créditos para interagir.');
      setShowRechargeModal(true);
      e.target.value = '';
      return;
    }

    if (file.size > MAX_FILE_SIZE_BYTES) {
      alert(`O arquivo selecionado (${formatFileSize(file.size)}) excede o limite estrito de 33 MB.`);
      e.target.value = '';
      return;
    }

    const isAudio = file.type.startsWith('audio/') || file.name.toLowerCase().endsWith('.wav') || file.name.toLowerCase().endsWith('.mp3');
    if (isAudio && !isAudioWavOrMp3(file.name, file.type)) {
      alert('Atenção: Arquivos de áudio são permitidos exclusivamente nos formatos WAV e MP3.');
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;

      try {
        await fetch(`/api/rooms/${room.id}/upload`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: file.name,
            fileType: file.type,
            fileSize: file.size,
            fileBase64: base64Data,
            senderId: currentUser.id,
            senderName: `${currentUser.name} ${currentUser.lastName}`,
            senderNickname: currentUser.nickname,
          }),
        });
      } catch (err) {
        console.error('Erro ao enviar arquivo:', err);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Submit Join Request (Pretendente se apresentando para sala privada - visível por 400s)
  const handleSubmitJoinRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!presentationText.trim()) return;

    setWaitingApproval(true);
    setRejectedMessage(null);
    setIsExpired(false);
    setSecondsRemaining(400);

    try {
      const res = await fetch(`/api/rooms/${room.id}/join-request`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          userName: `${currentUser.name} ${currentUser.lastName}`,
          userEmail: currentUser.googleEmail,
          presentationMessage: presentationText.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao enviar pedido.');
      }

      setJoinRequestCreatedAt(data.createdAt || new Date().toISOString());
      if (typeof data.secondsRemaining === 'number') {
        setSecondsRemaining(data.secondsRemaining);
      }
    } catch (err: any) {
      setWaitingApproval(false);
      alert(err.message || 'Falha ao solicitar entrada.');
    }
  };

  // Permite ao usuário refazer a solicitação após expiração ou rejeição
  const handleRetryJoinRequest = () => {
    setIsExpired(false);
    setWaitingApproval(false);
    setRejectedMessage(null);
    setSecondsRemaining(400);
  };

  // Moderator approves or rejects a candidate
  const handleModerateRequest = async (requestId: string, action: 'approve' | 'reject') => {
    try {
      const res = await fetch(`/api/rooms/${room.id}/moderate-request`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          requestId,
          action,
          moderatorId: currentUser.id,
        }),
      });

      if (res.status === 410) {
        const errData = await res.json();
        alert(errData.error || 'Esta solicitação expirou após 400 segundos.');
      }

      setPendingJoinRequests((prev) => prev.filter((r) => r.id !== requestId));
    } catch (err) {
      console.error('Erro ao moderar pedido:', err);
    }
  };

  // Moderator applies ban (minutes, hours, days, months)
  const handleApplyBan = async () => {
    if (!banTarget) return;

    try {
      await fetch(`/api/rooms/${room.id}/ban-user`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: banTarget.userId,
          userName: banTarget.name,
          moderatorId: currentUser.id,
          moderatorName: `${currentUser.name} ${currentUser.lastName}`,
          durationAmount: banDurationAmount,
          durationUnit: banDurationUnit,
          reason: banReason,
        }),
      });

      setBanTarget(null);
    } catch (err) {
      console.error('Erro ao aplicar bloqueio:', err);
    }
  };

  const copyRoomInvite = () => {
    const inviteUrl = `${window.location.origin}/?room=${room.id}`;
    navigator.clipboard.writeText(inviteUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // ==============================================================================
  // VIEW: GUEST WAITING ROOM / APRESENTAÇÃO DO PRETENDENTE (SALA PRIVADA)
  // ==============================================================================
  if (!admitted) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <div className="rounded-3xl border border-[#1E293B] bg-[#0F172A] p-8 shadow-2xl backdrop-blur-xl text-[#E2E8F0]">
          {/* Logotipo da Sala Privada */}
          <div className="mx-auto flex flex-col items-center justify-center mb-4">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onLeaveRoom();
              }}
              title="Ir para a página inicial"
              className="relative w-20 h-20 rounded-2xl overflow-hidden border-2 border-[#22D3EE]/60 shadow-[0_0_25px_rgba(34,211,238,0.5)] mb-3 bg-[#0A0C10] block cursor-pointer transition-transform hover:scale-105 active:scale-95"
            >
              <img
                src="/fenix_chamas.gif"
                alt="chamasso live chat"
                className="w-full h-full object-cover"
              />
            </a>
          </div>

          <h2 className="text-2xl font-black tracking-tight text-white uppercase italic">Sala Privada com Moderação</h2>
          <p className="text-xs text-[#22D3EE] font-semibold uppercase mt-1">"{room.name}"</p>
          <p className="text-xs text-slate-400 mt-2">
            Anfitrião: <strong className="text-slate-200">{room.creatorName}</strong>
          </p>

          {rejectedMessage ? (
            <div className="mt-6 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-5 text-xs text-rose-300">
              <AlertCircle className="h-6 w-6 text-rose-400 mx-auto mb-2" />
              <p className="text-sm font-bold text-white">Acesso não liberado pelo anfitrião</p>
              <p className="mt-1 text-slate-300">{rejectedMessage}</p>
              <div className="mt-5 flex gap-2 justify-center">
                <button
                  type="button"
                  onClick={onLeaveRoom}
                  className="rounded-xl bg-[#1E293B] border border-[#1E293B] px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-[#334155] transition"
                >
                  Voltar para a Lista de Salas
                </button>
                <button
                  type="button"
                  onClick={handleRetryJoinRequest}
                  className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 py-2 text-xs font-bold text-black hover:brightness-110 transition"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Tentar Novamente</span>
                </button>
              </div>
            </div>
          ) : isExpired ? (
            /* ESTADO EXPIRADO (APÓS 400 SEGUNDOS SEM RESPOSTA DO MODERADOR) */
            <div className="mt-6 rounded-2xl border border-amber-500/40 bg-amber-500/10 p-6 text-xs text-amber-200 text-center animate-in fade-in">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 mb-3">
                <Clock className="h-7 w-7 animate-pulse" />
              </div>
              <p className="text-base font-black text-white uppercase tracking-wide">
                Solicitação Expirada (400 Segundos)
              </p>
              <p className="mt-2 text-slate-300 leading-relaxed max-w-md mx-auto text-xs">
                O seu pedido de entrada esteve visível ao anfitrião por <strong>400 segundos</strong>. Como não houve aprovação ou reprovação pelo moderador dentro deste tempo limite, a solicitação foi <strong>removida automaticamente</strong>.
              </p>

              <div className="mt-4 rounded-xl bg-[#0A0C10]/80 border border-amber-500/30 p-3 text-[11px] text-amber-300 flex items-center justify-center gap-2">
                <span>🔄</span>
                <span>Conforme a regra da sala, você pode <strong>refazer a sua solicitação agora mesmo</strong>!</span>
              </div>

              <div className="flex flex-col sm:flex-row gap-2 mt-5">
                <button
                  type="button"
                  onClick={onLeaveRoom}
                  className="flex-1 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2.5 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition"
                >
                  Voltar para Salas
                </button>
                <button
                  type="button"
                  onClick={handleRetryJoinRequest}
                  className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2.5 text-xs font-black text-black shadow-lg hover:brightness-110 active:scale-98 transition"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>Refazer Solicitação de Entrada</span>
                </button>
              </div>
            </div>
          ) : waitingApproval ? (
            /* AGUARDANDO RESPOSTA DO MODERADOR COM CONTAGEM REGRESSIVA DE 400 SEGUNDOS */
            <div className="mt-6 space-y-4">
              <div className="flex flex-col items-center justify-center rounded-2xl border border-[#22D3EE]/30 bg-[#0A0C10] p-6 text-center">
                <div className="relative flex h-12 w-12 items-center justify-center mb-3">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#22D3EE] opacity-75" />
                  <span className="relative inline-flex h-9 w-9 items-center justify-center rounded-full bg-[#22D3EE] text-black">
                    <Clock className="h-5 w-5" />
                  </span>
                </div>
                <p className="text-base font-bold text-[#22D3EE]">Apresentação enviada ao moderador!</p>
                <p className="text-xs text-slate-400 mt-1 max-w-sm">
                  O anfitrião da sala está analisando o seu pedido. Você será conectado automaticamente assim que ele aprovar.
                </p>

                {/* Bloco de Contagem Regressiva de 400 Segundos */}
                <div className="w-full mt-5 rounded-xl border border-[#1E293B] bg-[#0F172A] p-4 text-left">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <Timer className="h-4 w-4 text-amber-400 animate-spin" />
                      Tempo limite para resposta:
                    </span>
                    <span className="font-mono font-bold text-amber-400 text-sm">
                      {secondsRemaining}s / 400s{' '}
                      <span className="text-xs text-slate-400 font-normal">
                        ({Math.floor(secondsRemaining / 60)}m {(secondsRemaining % 60).toString().padStart(2, '0')}s)
                      </span>
                    </span>
                  </div>

                  {/* Barra de Progresso visual */}
                  <div className="h-2 w-full bg-[#0A0C10] rounded-full overflow-hidden border border-[#1E293B] my-2">
                    <div
                      className="h-full bg-gradient-to-r from-amber-400 to-[#22D3EE] transition-all duration-1000"
                      style={{ width: `${Math.min(100, Math.max(0, (secondsRemaining / 400) * 100))}%` }}
                    />
                  </div>

                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    ⚖️ <strong>Regra da Sala Privada:</strong> Este pedido permanece visível ao anfitrião por exatamente <strong>400 segundos</strong>. Caso não haja resposta de aprovação ou reprovação neste prazo, ele será removido automaticamente e você poderá refazê-lo.
                  </p>
                </div>
              </div>

              <button
                onClick={onLeaveRoom}
                className="rounded-xl border border-[#1E293B] bg-[#1E293B] px-5 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition"
              >
                Cancelar Solicitação e Sair
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmitJoinRequest} className="mt-6 space-y-4 text-left">
              <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 text-xs text-slate-300">
                <p className="font-semibold text-[#F472B6] mb-1">Apresentação Obrigatória do Pretendente:</p>
                <p className="text-slate-400">
                  Para salas privadas de paquera e amizade, apresente-se com carinho e diga o porquê você
                  gostaria de participar desta conversa.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Sua Apresentação e Motivo para Entrar:
                </label>
                <textarea
                  required
                  rows={4}
                  value={presentationText}
                  onChange={(e) => setPresentationText(e.target.value)}
                  placeholder="Olá! Sou de São Paulo, busco uma boa conversa sobre música e novas amizades sinceras..."
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3 text-xs text-[#E2E8F0] placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={onLeaveRoom}
                  className="w-1/3 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2.5 text-xs font-semibold text-slate-300 hover:bg-[#334155]"
                >
                  Voltar
                </button>
                <button
                  type="submit"
                  disabled={!presentationText.trim()}
                  className="w-2/3 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2.5 text-xs font-black text-black shadow-lg hover:brightness-110 active:scale-98 transition disabled:opacity-50"
                >
                  <span>Enviar Apresentação para o Anfitrião</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  // ==============================================================================
  // VIEW: STANDARD CONFERENCE TEMPLATE (TABELA EXCEL/HTML MOSAICO 15+PALESTRANTE)
  // ==============================================================================
  if (conferenceViewMode === 'standard_template') {
    return (
      <div className="relative h-[calc(100vh-65px)] w-full flex flex-col bg-slate-950 overflow-hidden">
        {/* Barra superior de alternância de modo */}
        <div className="bg-slate-900/95 border-b border-slate-800 px-4 py-1.5 flex items-center justify-between text-xs z-30 shrink-0">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/40 text-[11px] flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Template Padrão Ativo: Tabela Mosaico (15 + Palestrante Câmera 0)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setConferenceViewMode('classic')}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition font-medium border border-slate-700 text-xs"
              title="Alternar para visualização em grade livre clássica"
            >
              Alternar p/ Grade Flexível
            </button>
          </div>
        </div>

        {/* Banner de Tarifas Chamasso & Modo Somente Visualização */}
        {tariffSettings.billingEnabled && (
          <div
            className={`px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs border-b shrink-0 z-20 ${
              !hasCredits
                ? 'bg-amber-950/90 border-amber-500/40 text-amber-200'
                : 'bg-[#0F172A] border-[#1E293B] text-slate-300'
            }`}
          >
            <div className="flex items-center gap-2">
              {!hasCredits ? (
                <>
                  <Lock className="h-4 w-4 text-amber-400 shrink-0" />
                  <span>
                    <strong className="text-amber-300">Modo Somente Visualização:</strong> Sem PASQcoin disponível. Transmitir áudio/vídeo e interagir requer saldo PASQ positivo.
                  </span>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Consumo: 1 PASQ = {pasqcoinSettings.secondsPerCoin}s</span>
                  </div>
                  <span className="text-slate-600">|</span>
                  <span className="font-mono text-white font-bold">
                    Saldo PASQcoin: {formatPasq(pasqcoinBalance)} PASQ
                  </span>
                  <span className="text-slate-400 text-[11px]">({formatRemainingTime(pasqcoinBalance * pasqcoinSettings.secondsPerCoin)} restantes)</span>
                </>
              )}
            </div>

            <button
              onClick={() => setShowRechargeModal(true)}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-3 py-1 text-xs font-black text-black hover:brightness-110 shadow transition cursor-pointer"
            >
              <CreditCard className="h-3.5 w-3.5" />
              <span>{!hasCredits ? 'Comprar PASQcoin' : '+ Comprar PASQcoin'}</span>
            </button>
          </div>
        )}

        <div className="flex-1 overflow-hidden">
          <StandardConferenceTemplate
            room={room}
            currentUser={currentUser}
            isModerator={isModerator}
            onLeaveRoom={onLeaveRoom}
            onOpenLiveModal={() => setIsLiveModalOpen(true)}
            onOpenFriendshipModal={(target) => {
              setFriendshipTarget(target);
            }}
            hasCredits={hasCredits}
            onOpenRecharge={() => setShowRechargeModal(true)}
          />
        </div>

        {isLiveModalOpen && (
          <LiveTransmissionModal
            isOpen={isLiveModalOpen}
            onClose={() => setIsLiveModalOpen(false)}
            currentUser={currentUser}
          />
        )}

        {showRechargeModal && (
          <RechargeModal
            isOpen={showRechargeModal}
            onClose={() => setShowRechargeModal(false)}
            currentUser={currentUser}
            onRechargeSuccess={(newPasqcoins, statusMessage) => {
              setPasqcoinBalance(newPasqcoins);
              setPurchaseStatusNotice(statusMessage || 'Compra confirmada e PASQcoin creditado na carteira.');
              if (newPasqcoins > 0) {
                setHasCredits(true);
                setBillingNotice(null);
                if (firstMessageSent) setPasqcoinActive(true);
              }
            }}
          />
        )}
      </div>
    );
  }

  // ==============================================================================
  // VIEW: SALA DE CONFERÊNCIA AO VIVO
  // ==============================================================================
  return (
    <div className="relative flex h-[calc(100vh-65px)] w-full flex-col bg-[#0A0C10] text-[#E2E8F0] overflow-hidden select-none">
      {/* Floating Reactions overlay */}
      <div className="pointer-events-none absolute inset-0 z-30 overflow-hidden">
        {floatingReactions.map((r) => (
          <div
            key={r.id}
            style={{ left: `${r.left}%` }}
            className="absolute bottom-24 text-4xl animate-bounce duration-1000 transform -translate-x-1/2 drop-shadow-[0_0_10px_rgba(255,255,255,0.8)]"
          >
            {r.emoji}
          </div>
        ))}
      </div>

      {/* Top Meeting Header */}
      <div className="flex items-center justify-between border-b border-[#1E293B] bg-[#0F172A]/95 px-4 py-2.5">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2.5">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                if (window.confirm('Deseja sair da sala e voltar para a página inicial?')) {
                  onLeaveRoom();
                }
              }}
              title="Voltar para a página inicial"
              className="relative w-8 h-8 rounded-xl overflow-hidden border border-[#22D3EE]/50 shadow-[0_0_12px_rgba(34,211,238,0.4)] shrink-0 bg-[#0A0C10] block cursor-pointer transition-transform hover:scale-105 active:scale-95"
            >
              <img
                src="/fenix_chamas.gif"
                alt="chamasso live chat"
                className="w-full h-full object-cover"
              />
            </a>
            <h2 className="text-sm sm:text-base font-bold text-white truncate max-w-[180px] sm:max-w-xs md:max-w-md">
              {room.name}
            </h2>
            <span className="rounded-md border border-[#22D3EE]/30 bg-[#1E293B] px-2 py-0.5 text-[10px] font-semibold text-[#22D3EE] capitalize">
              {room.category}
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 rounded-full border border-[#22D3EE]/30 bg-[#1E293B] px-2.5 py-0.5 text-[10px] font-medium text-[#22D3EE]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#22D3EE] animate-pulse" />
            <span>WSS Seguro • WebRTC Mesh</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Moderator badge */}
          {isModerator && (
            <span className="inline-flex items-center gap-1 rounded-md border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-bold text-amber-300">
              <Crown className="h-3 w-3" />
              <span>Você é o Moderador</span>
            </span>
          )}

          {/* Pending Admission Requests for Moderator */}
          {isModerator && pendingJoinRequests.length > 0 && (
            <div className="relative">
              <span className="animate-pulse rounded-full bg-[#F472B6] px-2 py-0.5 text-[10px] font-bold text-black">
                {pendingJoinRequests.length} pedido(s) de entrada
              </span>
            </div>
          )}

          <button
            onClick={() => setConferenceViewMode('standard_template')}
            className="flex items-center gap-1.5 rounded-xl border border-indigo-500/50 bg-indigo-950/60 px-3 py-1 text-xs font-bold text-indigo-300 hover:bg-indigo-900/80 transition shadow-md"
            title="Alternar para o Template de Videoconferência Padrão (Tabela Mosaico 15+Palestrante)"
          >
            <Crown className="h-3.5 w-3.5 text-amber-400" />
            <span className="hidden sm:inline">Template Mosaico 15</span>
          </button>

          <button
            onClick={() => setIsLiveModalOpen(true)}
            className="flex items-center gap-1.5 rounded-xl border border-rose-500/40 bg-rose-950/40 px-3 py-1 text-xs font-bold text-rose-300 hover:bg-rose-900/60 transition shadow-md"
            title="Transmitir sua câmera ao vivo ou assistir lives"
          >
            <Radio className="h-3.5 w-3.5 text-rose-400 animate-pulse" />
            <span className="hidden sm:inline">Live Câmera</span>
          </button>

          <button
            onClick={copyRoomInvite}
            className="flex items-center gap-1 rounded-xl border border-[#1E293B] bg-[#1E293B] px-2.5 py-1 text-xs font-medium text-slate-300 hover:border-[#22D3EE]/40 hover:text-white transition"
            title="Copiar Link de Convite da Sala"
          >
            {copiedLink ? <Check className="h-3.5 w-3.5 text-[#22D3EE]" /> : <Copy className="h-3.5 w-3.5" />}
            <span className="hidden md:inline">{copiedLink ? 'Link Copiado' : 'Copiar Convite'}</span>
          </button>
        </div>
      </div>

      {/* Banner de Tarifas Chamasso & Modo Somente Visualização */}
      {tariffSettings.billingEnabled && (
        <div
          className={`px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs border-b shrink-0 z-20 ${
            !hasCredits
              ? 'bg-amber-950/90 border-amber-500/40 text-amber-200'
              : 'bg-[#0F172A] border-[#1E293B] text-slate-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {!hasCredits ? (
              <>
                <Lock className="h-4 w-4 text-amber-400 shrink-0" />
                <span>
                  <strong className="text-amber-300">Modo Somente Visualização:</strong> Sem PASQcoin disponível. Transmitir áudio/vídeo e interagir requer saldo PASQ positivo.
                </span>
              </>
            ) : (
              <>
                <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Consumo: 1 PASQ = {pasqcoinSettings.secondsPerCoin}s</span>
                </div>
                <span className="text-slate-600">|</span>
                <span className="font-mono text-white font-bold">
                  Saldo PASQcoin: {formatPasq(pasqcoinBalance)} PASQ
                </span>
                <span className="text-slate-400 text-[11px]">({formatRemainingTime(pasqcoinBalance * pasqcoinSettings.secondsPerCoin)} restantes)</span>
              </>
            )}
          </div>

          <button
            onClick={() => setShowRechargeModal(true)}
            className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-3 py-1 text-xs font-black text-black hover:brightness-110 shadow transition cursor-pointer"
          >
            <CreditCard className="h-3.5 w-3.5" />
            <span>{!hasCredits ? 'Comprar PASQcoin' : '+ Comprar PASQcoin'}</span>
          </button>
        </div>
      )}

      {/* Main Conference Content: Video Grid + Optional Drawer */}
      <div className="relative flex flex-1 overflow-hidden">
        {/* VIDEO GRID */}
        <div className="flex-1 p-3 sm:p-4 overflow-y-auto">
          <div
            className={`grid h-full w-full gap-3 ${
              participants.length <= 1
                ? 'grid-cols-1'
                : participants.length === 2
                ? 'grid-cols-1 md:grid-cols-2'
                : participants.length <= 4
                ? 'grid-cols-2'
                : 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4'
            }`}
          >
            {/* Local Video Tile (Current User) */}
            <div className="group relative flex items-center justify-center overflow-hidden rounded-2xl border border-[#1E293B] bg-[#0F172A] shadow-xl">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className={`h-full w-full object-cover transform ${
                  isScreenSharing ? '' : '-scale-x-100'
                } ${isVideoOff ? 'hidden' : 'block'}`}
              />

              {isVideoOff && (
                <div className="flex flex-col items-center justify-center p-6 text-center">
                  <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-tr from-[#22D3EE] via-indigo-500 to-[#F472B6] p-[2px] shadow-2xl shadow-[#22D3EE]/20 mb-3">
                    <div className="flex h-full w-full items-center justify-center rounded-3xl bg-[#0A0C10] text-2xl font-black text-white">
                      {currentUser.name.charAt(0).toUpperCase()}
                    </div>
                  </div>
                  <p className="text-sm font-bold text-white">
                    {currentUser.name} {currentUser.lastName} (Você)
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">Câmera desativada</p>
                </div>
              )}

              {/* Tile Overlay Badge */}
              <div className="absolute bottom-3 left-3 flex items-center gap-2 rounded-lg bg-[#0A0C10]/80 px-2.5 py-1 text-xs font-medium text-[#E2E8F0] backdrop-blur-md border border-[#1E293B]/60">
                <span>{currentUser.name} (Você)</span>
                {isModerator && <Crown className="h-3 w-3 text-amber-400" title="Moderador" />}
                {isHandRaised && (
                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-[#F472B6] text-[10px] text-black font-bold">
                    ✋
                  </span>
                )}
                {isAudioMuted ? (
                  <MicOff className="h-3.5 w-3.5 text-rose-400" />
                ) : (
                  <span className="flex h-2 w-2 rounded-full bg-[#22D3EE] animate-ping" />
                )}
              </div>
            </div>

            {/* Remote Participants Tiles */}
            {participants
              .filter((p) => p.userId !== currentUser.id)
              .map((p) => (
                <div
                  key={p.id}
                  className="group relative flex items-center justify-center overflow-hidden rounded-2xl border border-[#1E293B] bg-[#0F172A] shadow-xl"
                >
                  <RemoteVideo stream={remoteStreams[p.id]} hidden={p.isVideoOff} />
                  {(!remoteStreams[p.id] || p.isVideoOff) && <div className="flex flex-col items-center justify-center p-6 text-center">
                    <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-tr from-[#22D3EE] via-indigo-500 to-[#F472B6] p-[2px] shadow-2xl mb-3">
                      <div className="flex h-full w-full items-center justify-center rounded-3xl bg-[#0A0C10] text-2xl font-black text-white">
                        {p.name.charAt(0).toUpperCase()}
                      </div>
                    </div>
                    <p className="text-sm font-bold text-white">{p.name}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">{p.isVideoOff ? 'Câmera desativada' : 'Conectando mídia...'}</p>
                  </div>}

                  {/* Tile Overlay Badge */}
                  <div className="absolute bottom-3 left-3 flex items-center gap-2 rounded-lg bg-[#0A0C10]/80 px-2.5 py-1 text-xs font-medium text-[#E2E8F0] backdrop-blur-md border border-[#1E293B]/60">
                    <span>{p.name}</span>
                    {p.isModerator && <Crown className="h-3 w-3 text-amber-400" title="Moderador" />}
                    {p.isHandRaised && (
                      <span className="flex h-4 w-4 items-center justify-center rounded-full bg-[#F472B6] text-[10px] text-black font-bold">
                        ✋
                      </span>
                    )}
                    {p.isAudioMuted ? (
                      <MicOff className="h-3.5 w-3.5 text-rose-400" />
                    ) : (
                      <Mic className="h-3.5 w-3.5 text-[#22D3EE]" />
                    )}
                  </div>

                  {/* Moderator Controls for this participant */}
                  {isModerator && (
                    <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => setBanTarget(p)}
                        className="flex items-center gap-1 rounded-lg border border-rose-500/40 bg-rose-950/80 px-2.5 py-1 text-[11px] font-semibold text-rose-300 hover:bg-rose-900 transition shadow-md"
                        title="Bloquear usuário por minutos/horas/dias/meses"
                      >
                        <Ban className="h-3 w-3" />
                        <span>Bloquear</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
          </div>
        </div>

        {/* RIGHT SIDE DRAWER: CHAT OR PARTICIPANTS */}
        {activeDrawer !== 'none' && (
          <aside className="w-80 sm:w-96 flex flex-col border-l border-[#1E293B] bg-[#0F172A] z-20">
            <div className="flex items-center justify-between border-b border-[#1E293B] p-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                {activeDrawer === 'chat' ? (
                  <>
                    <MessageSquare className="h-4 w-4 text-[#22D3EE]" />
                    <span>Chat da Sala & Arquivos</span>
                  </>
                ) : (
                  <>
                    <Users className="h-4 w-4 text-[#F472B6]" />
                    <span>Participantes ({participants.length})</span>
                  </>
                )}
              </h3>
              <button
                onClick={() => setActiveDrawer('none')}
                className="rounded-lg p-1 text-slate-400 hover:bg-[#1E293B] hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* CHAT CONTENT */}
            {activeDrawer === 'chat' && (
              <div className="flex flex-1 flex-col overflow-hidden">
                {/* TELA ADMINISTRATIVA PASQCOIN DENTRO DO CHAT */}
                <div className="border-b border-[#1E293B] bg-[#0A0C10]/95 p-3 shrink-0 shadow-inner">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-tr from-[#22D3EE] to-[#F472B6] text-black font-black shadow-[0_0_12px_rgba(34,211,238,0.4)]">
                        <Coins className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-black uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-[#22D3EE] to-[#F472B6]">
                            PAINEL ADMINISTRATIVO PASQCOIN
                          </span>
                          <span className="rounded bg-[#22D3EE]/20 border border-[#22D3EE]/40 px-1 py-0.2 text-[9px] font-mono font-bold text-[#22D3EE]">
                            {pasqcoinSettings.secondsPerCoin}s / PASQ
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400">
                          Desbloqueio de tempo & recursos da sala
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setShowPasqcoinAdminDetails(!showPasqcoinAdminDetails)}
                      className="rounded-lg border border-[#1E293B] bg-[#1E293B] px-2 py-1 text-[10px] font-semibold text-slate-300 hover:text-white transition"
                    >
                      {showPasqcoinAdminDetails ? 'Ocultar' : 'Expandir'}
                    </button>
                  </div>

                  {showPasqcoinAdminDetails && (
                    <div className="space-y-2 mt-2 pt-2 border-t border-[#1E293B]/70 text-xs">
                      {/* Status da contagem progressiva */}
                      <div className="flex items-center justify-between bg-[#0F172A] p-2 rounded-xl border border-[#1E293B]">
                        <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
                          <Zap className={`h-3.5 w-3.5 ${pasqcoinActive ? 'text-[#22D3EE] animate-pulse' : 'text-slate-500'}`} />
                          Status do Contador:
                        </span>
                        {pasqcoinActive ? (
                          <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
                            Contagem Regressiva Ativa • ciclo {pasqcoinProgressSec}s
                          </span>
                        ) : firstMessageSent ? (
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded-full">
                            Pausado (Sem saldo)
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
                            Inicia na 1ª mensagem enviada
                          </span>
                        )}
                      </div>

                      {/* Barra de Progresso Progressivo (1 até secondsPerCoin) */}
                      <div>
                        <div className="flex items-center justify-between text-[11px] mb-1">
                          <span className="text-slate-300 font-medium">Consumo dentro do PASQ atual:</span>
                          <span className="font-mono font-bold text-[#22D3EE]">
                            {pasqcoinProgressSec}s / {pasqcoinSettings.secondsPerCoin}s
                          </span>
                        </div>
                        <div className="w-full h-2.5 bg-[#0F172A] rounded-full overflow-hidden border border-[#1E293B] relative">
                          <div
                            className="h-full bg-gradient-to-r from-[#22D3EE] via-indigo-500 to-[#F472B6] transition-all duration-1000 rounded-full"
                            style={{
                              width: `${Math.min(
                                100,
                                Math.max(0, (pasqcoinProgressSec / (pasqcoinSettings.secondsPerCoin || 60)) * 100)
                              )}%`,
                            }}
                          />
                        </div>
                        <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-0.5">
                          <span>1s (Início)</span>
                          <span>{Math.round((pasqcoinProgressSec / (pasqcoinSettings.secondsPerCoin || 60)) * 100)}%</span>
                          <span>desconto fracionário por segundo</span>
                        </div>
                      </div>

                      {/* Resumo da Carteira & Compra rápida */}
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] p-2 text-left">
                          <span className="text-[10px] text-slate-400 block font-medium">Saldo PASQcoin:</span>
                          <div className="flex items-center gap-1 mt-0.5">
                            <span className="text-base font-black font-mono text-white">
                              {formatPasq(pasqcoinBalance)}
                            </span>
                            <span className="text-[10px] font-extrabold text-[#22D3EE]">PASQ</span>
                          </div>
                          <span className="text-[9px] text-slate-500">
                            Tempo restante: {formatRemainingTime(pasqcoinBalance * (pasqcoinSettings.secondsPerCoin || 60))}
                          </span>
                        </div>

                        <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] p-2 text-left">
                          <span className="text-[10px] text-slate-400 block font-medium">Consumidas Nesta Sessão:</span>
                          <div className="flex items-center gap-1 mt-0.5">
                            <span className="text-base font-black font-mono text-amber-300">
                              {formatPasq(pasqcoinsConsumedThisSession)}
                            </span>
                            <span className="text-[10px] font-extrabold text-amber-400">PASQ</span>
                          </div>
                          <span className="text-[9px] text-emerald-400 font-semibold">
                            ✓ Funções Desbloqueadas
                          </span>
                        </div>
                      </div>

                      {purchaseStatusNotice && (
                        <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-2 py-1.5 text-[10px] text-emerald-300">
                          {purchaseStatusNotice}
                        </div>
                      )}

                      {/* Compra de PASQcoin via checkout oficial */}
                      <div className="pt-1">
                        <span className="text-[10px] text-slate-400 block mb-1 font-medium">
                          Comprar PASQcoin:
                        </span>
                        <button
                          type="button"
                          onClick={() => handleQuickBuyPasqcoins(0)}
                          className="w-full rounded-lg border border-[#22D3EE]/30 bg-[#1E293B] py-2 text-[10px] font-bold text-[#22D3EE] hover:bg-[#22D3EE]/20 hover:border-[#22D3EE] transition"
                        >
                          Comprar PASQcoin via PIX / Mercado Pago
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {messages.map((msg) => {
                    const isMe = msg.senderId === currentUser.id;
                    const isSys = msg.senderId === 'system';

                    if (isSys) {
                      return (
                        <div key={msg.id} className="text-center my-2">
                          <span className="rounded-full bg-[#0A0C10] border border-[#1E293B] px-3 py-1 text-[11px] text-slate-400">
                            {msg.text}
                          </span>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mb-0.5">
                          <span className="font-semibold text-slate-300">
                            {msg.senderNickname || msg.senderName}
                          </span>
                          {msg.isModerator && (
                            <span className="text-amber-400 font-bold text-[9px]">[MOD]</span>
                          )}
                          <span>
                            {new Date(msg.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>

                        <div
                          className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed ${
                            isMe
                              ? 'bg-[#22D3EE] text-black font-semibold rounded-br-none shadow-md shadow-[#22D3EE]/10'
                              : 'bg-[#1E293B] border border-[#1E293B] text-[#E2E8F0] rounded-bl-none'
                          }`}
                        >
                          {msg.text && <p className="whitespace-pre-wrap break-words">{msg.text}</p>}

                          {/* Plugin Incorporado de Vídeo (YouTube, Twitch, Vimeo, MP4) */}
                          {msg.videoEmbed && <VideoEmbedPlayer embed={msg.videoEmbed} />}

                          {/* Player de Áudio Incorporado (WAV ou MP3) */}
                          {msg.audioAttachment && <AudioPlayer audio={msg.audioAttachment} />}

                          {/* Prévia de Imagens e Arquivos dentro do chat */}
                          {msg.file && (
                            <div className="mt-2 rounded-xl border border-black/10 bg-[#0A0C10]/60 p-2">
                              {isImageValid(msg.file.name, msg.file.type) ? (
                                <img
                                  src={msg.file.url}
                                  alt={msg.file.name}
                                  className="max-h-48 w-full rounded-lg object-cover mb-2 cursor-pointer hover:opacity-90 transition"
                                  onClick={() => window.open(msg.file?.url, '_blank')}
                                />
                              ) : (
                                <div className="flex items-center gap-2 text-xs mb-1">
                                  <FileText className="h-4 w-4 text-[#22D3EE]" />
                                  <span className="font-medium truncate">{msg.file.name}</span>
                                </div>
                              )}
                              <a
                                href={msg.file.url}
                                download={msg.file.name}
                                className="flex items-center justify-center gap-1.5 rounded-lg bg-[#22D3EE]/20 py-1 text-[11px] font-bold text-[#22D3EE] hover:bg-[#22D3EE]/30 transition"
                              >
                                <Download className="h-3 w-3" />
                                <span>Baixar Arquivo ({formatFileSize(msg.file.size)})</span>
                              </a>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  <div ref={chatBottomRef} />
                </div>

                {/* Seletor de Emojis do Chat da Sala */}
                {showChatEmojis && (
                  <div className="border-t border-[#1E293B] bg-[#0A0C10] p-2 grid grid-cols-8 gap-1">
                    {['❤️', '🔥', '😍', '👏', '🥂', '😂', '🎉', '🚀', '💬', '🎵', '✨', '💯', '👑', '🌹', '💃', '💋'].map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => {
                          setChatInput((prev) => prev + emoji);
                          setShowChatEmojis(false);
                        }}
                        className="h-8 rounded-lg text-base hover:bg-[#1E293B] transition"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                )}

                {/* Chat Input & File attachment */}
                <form onSubmit={handleSendMessage} className="border-t border-[#1E293B] p-3 bg-[#0A0C10]">
                  <div className="flex items-center gap-2">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                      accept="image/png,image/jpeg,image/gif,audio/wav,audio/mp3,audio/mpeg,video/mp4,.png,.jpeg,.jpg,.gif,.wav,.mp3,.mp4"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="rounded-xl border border-[#1E293B] bg-[#1E293B] p-2 text-slate-400 hover:bg-[#334155] hover:text-[#22D3EE] transition"
                      title="Enviar foto, áudio WAV/MP3 ou vídeo MP4 (máx 33MB)"
                    >
                      <Paperclip className="h-4 w-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setShowChatEmojis(!showChatEmojis)}
                      className="rounded-xl border border-[#1E293B] bg-[#1E293B] p-2 text-slate-400 hover:bg-[#334155] hover:text-[#22D3EE] transition"
                      title="Inserir Emoticons"
                    >
                      <Smile className="h-4 w-4" />
                    </button>

                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Mensagem ou link de vídeo YouTube..."
                      className="flex-1 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-2 text-xs text-[#E2E8F0] placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
                    />

                    <button
                      type="submit"
                      disabled={!chatInput.trim()}
                      className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] p-2 text-black shadow-md hover:brightness-110 disabled:opacity-40 transition"
                    >
                      <Send className="h-4 w-4" />
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* PARTICIPANTS CONTENT */}
            {activeDrawer === 'participants' && (
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {participants.map((p) => {
                  const isMe = p.userId === currentUser.id;
                  return (
                    <div
                      key={p.id}
                      className="flex items-center justify-between rounded-xl border border-[#1E293B] bg-[#0A0C10]/60 p-2.5"
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#22D3EE] to-[#F472B6] text-xs font-black text-black">
                          {p.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="truncate text-left">
                          <p className="text-xs font-semibold text-slate-200 truncate">
                            {p.name} {isMe && '(Você)'}
                          </p>
                          <p className="text-[10px] text-slate-400 flex items-center gap-1">
                            {p.isModerator ? (
                              <span className="text-amber-400 font-semibold flex items-center gap-0.5">
                                <Crown className="h-3 w-3" /> Moderador
                              </span>
                            ) : (
                              'Convidado'
                            )}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        {!isMe && (
                          <button
                            onClick={() => {
                              setFriendshipTarget({ id: p.userId, name: p.name });
                              setFriendshipStatusNotice(null);
                              setFriendshipMessage('');
                            }}
                            className="rounded p-1 text-[#F472B6] hover:bg-[#F472B6]/20 transition"
                            title={`Solicitar Amizade para ${p.name}`}
                          >
                            <UserPlus className="h-3.5 w-3.5" />
                          </button>
                        )}

                        {p.isAudioMuted ? (
                          <MicOff className="h-3.5 w-3.5 text-rose-400" />
                        ) : (
                          <Mic className="h-3.5 w-3.5 text-[#22D3EE]" />
                        )}

                        {isModerator && !isMe && (
                          <button
                            onClick={() => setBanTarget(p)}
                            className="rounded p-1 text-slate-400 hover:bg-rose-950 hover:text-rose-400 transition"
                            title="Bloquear usuário"
                          >
                            <Ban className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </aside>
        )}
      </div>

      {/* MODERATOR ADMISSION REQUESTS DIALOG (Para Salas Privadas) */}
      {isModerator && pendingJoinRequests.length > 0 && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 w-full max-w-md p-4">
          <div className="rounded-2xl border border-amber-500/50 bg-[#0F172A] p-4 shadow-2xl text-[#E2E8F0] animate-in fade-in slide-in-from-top-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                <Shield className="h-4 w-4" />
                Pedido de Ingresso na Sala Privada
              </span>
              <span className="text-[10px] text-slate-400">
                1 de {pendingJoinRequests.length} pendente(s)
              </span>
            </div>

            {/* Timer de 400 segundos com contagem regressiva e remoção automática */}
            <div className="mb-3 rounded-xl border border-amber-500/30 bg-[#0A0C10] p-2.5">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-amber-300 flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5 text-amber-400 animate-pulse" />
                  Visível por mais:
                </span>
                <span className="font-mono font-bold text-amber-400">
                  {pendingJoinRequests[0].secondsRemaining ?? 400}s / 400s
                </span>
              </div>
              <div className="h-1.5 w-full bg-[#1E293B] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-400 to-[#22D3EE] transition-all duration-1000"
                  style={{
                    width: `${Math.min(
                      100,
                      Math.max(0, ((pendingJoinRequests[0].secondsRemaining ?? 400) / 400) * 100)
                    )}%`,
                  }}
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-1.5">
                Caso não aprove ou reprove neste prazo, o pedido sumirá automaticamente.
              </p>
            </div>

            <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3 mb-3">
              <p className="text-xs font-bold text-white">
                {pendingJoinRequests[0].userName}{' '}
                <span className="font-normal text-slate-400">({pendingJoinRequests[0].userEmail})</span>
              </p>
              <p className="text-[11px] text-[#22D3EE] font-semibold mt-1">Apresentação do Pretendente:</p>
              <p className="text-xs text-slate-300 italic mt-0.5 leading-relaxed bg-[#0F172A] p-2 rounded-lg border border-[#1E293B]">
                "{pendingJoinRequests[0].presentationMessage}"
              </p>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => handleModerateRequest(pendingJoinRequests[0].id, 'reject')}
                className="flex-1 rounded-xl border border-rose-500/40 bg-rose-950/40 py-2 text-xs font-bold text-rose-300 hover:bg-rose-900/50 transition"
              >
                Recusar Entrada
              </button>
              <button
                onClick={() => handleModerateRequest(pendingJoinRequests[0].id, 'approve')}
                className="flex-1 rounded-xl bg-gradient-to-r from-[#22D3EE] to-emerald-400 py-2 text-xs font-black text-black shadow-md hover:brightness-110 transition"
              >
                Liberar Acesso
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODERATOR BAN MODAL: Estipular minutos, horas, dias, meses */}
      {banTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/80 backdrop-blur-md">
          <div className="relative w-full max-w-md rounded-2xl border border-rose-500/40 bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
            <button
              onClick={() => setBanTarget(null)}
              className="absolute right-4 top-4 rounded-lg p-1.5 text-slate-400 hover:bg-[#1E293B] hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400">
                <Ban className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Bloquear Usuário da Sala</h3>
                <p className="text-xs text-slate-400">
                  Moderador:{' '}
                  <strong className="text-slate-200">
                    {currentUser.name} {currentUser.lastName}
                  </strong>
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-4">
              Você está prestes a bloquear <strong>{banTarget.name}</strong>. O usuário ficará bloqueado de
              qualquer sala criada por você durante o tempo estipulado.
            </p>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Quantidade de Tempo:</label>
                  <input
                    type="number"
                    min="1"
                    value={banDurationAmount}
                    onChange={(e) => setBanDurationAmount(e.target.value)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-rose-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Unidade:</label>
                  <select
                    value={banDurationUnit}
                    onChange={(e) => setBanDurationUnit(e.target.value as any)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-rose-400 focus:outline-none"
                  >
                    <option value="minutes">Minutos</option>
                    <option value="hours">Horas</option>
                    <option value="days">Dias</option>
                    <option value="months">Meses</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Motivo do Bloqueio:</label>
                <input
                  type="text"
                  value={banReason}
                  onChange={(e) => setBanReason(e.target.value)}
                  placeholder="Ex: Conduta inadequada na transmissão"
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-rose-400 focus:outline-none"
                />
              </div>
            </div>

            <div className="mt-6 flex gap-2">
              <button
                type="button"
                onClick={() => setBanTarget(null)}
                className="w-1/3 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155]"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleApplyBan}
                className="w-2/3 rounded-xl bg-rose-600 py-2 text-xs font-bold text-white shadow-lg hover:bg-rose-500 transition"
              >
                Confirmar Bloqueio
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QUICK FRIENDSHIP REQUEST MODAL IN MEETING */}
      {friendshipTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/80 backdrop-blur-md">
          <div className="w-full max-w-sm rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 shadow-2xl text-[#E2E8F0] animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-[#1E293B] pb-3 mb-3">
              <div className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-[#F472B6]" />
                <h3 className="text-sm font-black uppercase italic tracking-tight text-white">
                  Solicitar Amizade
                </h3>
              </div>
              <button
                onClick={() => setFriendshipTarget(null)}
                className="rounded-lg p-1 text-slate-400 hover:bg-[#1E293B]"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300 mb-3">
              Enviar solicitação de amizade para{' '}
              <strong className="text-white">{friendshipTarget.name}</strong>.
            </p>

            {friendshipStatusNotice && (
              <div className="mb-3 p-2.5 rounded-xl border border-[#22D3EE]/30 bg-[#22D3EE]/10 text-xs text-[#22D3EE]">
                {friendshipStatusNotice}
              </div>
            )}

            <form onSubmit={handleSendFriendship} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Selecione o Nível de Relacionamento:
                </label>
                <select
                  value={selectedRelLevel}
                  onChange={(e) => setSelectedRelLevel(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                >
                  {relationshipLevels.map((lvl) => (
                    <option key={lvl.id} value={lvl.id}>
                      {lvl.icon || '✨'} {lvl.name} ({lvl.description})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-300 mb-1">
                  Mensagem Personalizada (Opcional):
                </label>
                <textarea
                  rows={2}
                  value={friendshipMessage}
                  onChange={(e) => setFriendshipMessage(e.target.value)}
                  placeholder="Gostei do papo na sala, vamos manter contato..."
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-[#E2E8F0] focus:border-[#22D3EE] focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t border-[#1E293B]">
                <button
                  type="button"
                  onClick={() => setFriendshipTarget(null)}
                  className="w-1/3 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155]"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="w-2/3 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2 text-xs font-black text-black hover:brightness-110 shadow-md"
                >
                  Enviar Solicitação
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BOTTOM CONTROLS BAR */}
      <div className="flex items-center justify-between border-t border-[#1E293B] bg-[#0F172A]/95 px-4 py-3 sm:px-6">
        {/* Left info: Time & Room name */}
        <div className="hidden sm:flex items-center gap-3">
          <span className="font-mono text-xs font-semibold text-slate-400">
            {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
          <span className="text-[#1E293B]">|</span>
          <span className="text-xs font-medium text-slate-300 truncate max-w-[150px]">{room.name}</span>
        </div>

        {/* Center: Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3 mx-auto sm:mx-0">
          {/* Microfone */}
          <button
            onClick={handleToggleAudio}
            className={`flex h-11 w-11 items-center justify-center rounded-full transition shadow-lg ${
              isAudioMuted
                ? 'bg-rose-600 text-white hover:bg-rose-500'
                : 'border border-[#1E293B] bg-[#1E293B] text-[#E2E8F0] hover:bg-[#334155]'
            }`}
            title={isAudioMuted ? 'Ativar microfone (M)' : 'Desativar microfone (M)'}
          >
            {isAudioMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
          </button>

          {/* Câmera */}
          <button
            onClick={handleToggleVideo}
            className={`flex h-11 w-11 items-center justify-center rounded-full transition shadow-lg ${
              isVideoOff
                ? 'bg-rose-600 text-white hover:bg-rose-500'
                : 'border border-[#1E293B] bg-[#1E293B] text-[#E2E8F0] hover:bg-[#334155]'
            }`}
            title={isVideoOff ? 'Ativar câmera (V)' : 'Desativar câmera (V)'}
          >
            {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
          </button>

          {/* Compartilhar Tela */}
          <button
            onClick={handleToggleScreenShare}
            className={`flex h-11 w-11 items-center justify-center rounded-full transition shadow-lg ${
              isScreenSharing
                ? 'bg-[#22D3EE] text-black font-extrabold shadow-[0_0_15px_rgba(34,211,238,0.4)]'
                : 'border border-[#1E293B] bg-[#1E293B] text-[#E2E8F0] hover:bg-[#334155]'
            }`}
            title="Compartilhar sua tela"
          >
            <ScreenShare className="h-5 w-5" />
          </button>

          {/* Levantar a Mão */}
          <button
            onClick={handleToggleHandRaise}
            className={`flex h-11 w-11 items-center justify-center rounded-full transition shadow-lg ${
              isHandRaised
                ? 'bg-[#F472B6] text-black font-extrabold shadow-[0_0_15px_rgba(244,114,182,0.4)]'
                : 'border border-[#1E293B] bg-[#1E293B] text-[#E2E8F0] hover:bg-[#334155]'
            }`}
            title="Levantar ou abaixar a mão"
          >
            <Hand className="h-5 w-5" />
          </button>

          {/* Reações (Flyout) */}
          <div className="relative">
            <button
              onClick={() => setShowReactionsMenu(!showReactionsMenu)}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-[#1E293B] bg-[#1E293B] text-[#F472B6] hover:bg-[#334155] transition shadow-lg"
              title="Enviar Reação de Paquera & Amizade"
            >
              <Smile className="h-5 w-5 text-[#F472B6]" />
            </button>

            {showReactionsMenu && (
              <div className="absolute bottom-14 left-1/2 -translate-x-1/2 flex items-center gap-2 rounded-2xl border border-[#1E293B] bg-[#0F172A] p-2 shadow-2xl backdrop-blur-xl">
                {['❤️', '🔥', '😍', '👏', '🥂', '😂'].map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => handleSendReaction(emoji)}
                    className="flex h-9 w-9 items-center justify-center rounded-xl text-xl hover:bg-[#1E293B] hover:scale-125 transition active:scale-95"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Botão Sair da Chamada */}
          <button
            onClick={onLeaveRoom}
            className="flex h-11 px-5 items-center justify-center rounded-full bg-rose-600 font-black text-white shadow-lg hover:bg-rose-500 transition active:scale-95"
            title="Sair da Sala"
          >
            <PhoneOff className="h-5 w-5 sm:mr-2" />
            <span className="hidden sm:inline">Sair</span>
          </button>
        </div>

        {/* Right: Drawer toggles (Chat & Participants) */}
        <div className="hidden sm:flex items-center gap-2">
          {/* Chat toggle */}
          <button
            onClick={() => {
              setActiveDrawer(activeDrawer === 'chat' ? 'none' : 'chat');
              setUnreadChatCount(0);
            }}
            className={`relative flex h-10 w-10 items-center justify-center rounded-xl transition ${
              activeDrawer === 'chat'
                ? 'bg-[#22D3EE] text-black font-bold'
                : 'border border-[#1E293B] bg-[#1E293B] text-slate-300 hover:bg-[#334155]'
            }`}
            title="Abrir Chat e Envio de Arquivos"
          >
            <MessageSquare className="h-4 w-4" />
            {unreadChatCount > 0 && activeDrawer !== 'chat' && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#F472B6] text-[10px] font-bold text-black">
                {unreadChatCount}
              </span>
            )}
          </button>

          {/* Participants toggle */}
          <button
            onClick={() => setActiveDrawer(activeDrawer === 'participants' ? 'none' : 'participants')}
            className={`flex h-10 w-10 items-center justify-center rounded-xl transition ${
              activeDrawer === 'participants'
                ? 'bg-[#F472B6] text-black font-bold'
                : 'border border-[#1E293B] bg-[#1E293B] text-slate-300 hover:bg-[#334155]'
            }`}
            title="Ver Participantes"
          >
            <Users className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Janela Pop-up de Transmissão de Câmera ao Vivo */}
      <LiveTransmissionModal
        currentUser={currentUser}
        isOpen={isLiveModalOpen}
        onClose={() => setIsLiveModalOpen(false)}
      />

      {/* Modal de Recarga de Créditos Mercado Pago */}
      {showRechargeModal && (
        <RechargeModal
          isOpen={showRechargeModal}
          onClose={() => setShowRechargeModal(false)}
          currentUser={currentUser}
          onRechargeSuccess={(newPasqcoins, statusMessage) => {
            setPasqcoinBalance(newPasqcoins);
            setPurchaseStatusNotice(statusMessage || 'Compra confirmada e PASQcoin creditado na carteira.');
            if (newPasqcoins > 0) {
              setHasCredits(true);
              setBillingNotice(null);
              if (firstMessageSent) setPasqcoinActive(true);
            }
          }}
        />
      )}
    </div>
  );
};
