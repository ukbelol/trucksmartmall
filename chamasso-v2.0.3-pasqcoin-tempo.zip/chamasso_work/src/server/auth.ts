import 'dotenv/config';
import crypto from 'crypto';
import type { Request, Response, NextFunction } from 'express';

export type SessionRole = 'USER' | 'SUPER_ADMIN';
export interface SessionPayload { sub: string; role: SessionRole; email?: string; exp: number; iat: number; }

const COOKIE_NAME = 'chamasso_session';
const SESSION_TTL_SECONDS = Number(process.env.SESSION_TTL_SECONDS || 7200);
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(48).toString('hex');
if (!process.env.SESSION_SECRET) {
  console.warn('[Security] SESSION_SECRET não definido. Uma chave temporária foi gerada; sessões expirarão ao reiniciar. Defina SESSION_SECRET em produção.');
}

const b64u = (input: Buffer | string) => Buffer.from(input).toString('base64url');
function sign(data: string) { return crypto.createHmac('sha256', SESSION_SECRET).update(data).digest('base64url'); }

export function createSessionToken(input: Omit<SessionPayload, 'iat' | 'exp'>): string {
  const now = Math.floor(Date.now() / 1000);
  const header = b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const payload = b64u(JSON.stringify({ ...input, iat: now, exp: now + SESSION_TTL_SECONDS }));
  return `${header}.${payload}.${sign(`${header}.${payload}`)}`;
}

export function verifySessionToken(token?: string | null): SessionPayload | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [h, p, s] = parts;
  const expected = sign(`${h}.${p}`);
  try {
    if (!crypto.timingSafeEqual(Buffer.from(s), Buffer.from(expected))) return null;
    const payload = JSON.parse(Buffer.from(p, 'base64url').toString('utf8')) as SessionPayload;
    if (!payload.sub || !payload.role || !payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch { return null; }
}

export function readSessionFromRequest(req: Request | { headers: any }): SessionPayload | null {
  const cookie = String(req.headers?.cookie || '');
  const match = cookie.split(';').map((x: string) => x.trim()).find((x: string) => x.startsWith(`${COOKIE_NAME}=`));
  return verifySessionToken(match ? decodeURIComponent(match.slice(COOKIE_NAME.length + 1)) : null);
}

export function setSessionCookie(res: Response, token: string) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_TTL_SECONDS}${secure}`);
}
export function clearSessionCookie(res: Response) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`);
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const session = readSessionFromRequest(req);
  if (!session) return res.status(401).json({ error: 'Sessão inválida ou expirada.' });
  (req as any).auth = session;
  next();
}
export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const session = readSessionFromRequest(req);
  if (!session || session.role !== 'SUPER_ADMIN') return res.status(403).json({ error: 'Acesso restrito ao Super Admin.' });
  (req as any).auth = session;
  next();
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16);
  const derived = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('base64url')}$${derived.toString('base64url')}`;
}
export function verifyPassword(password: string, stored?: string): boolean {
  if (!stored?.startsWith('scrypt$')) return false;
  try {
    const [, saltB64, hashB64] = stored.split('$');
    const actual = crypto.scryptSync(password, Buffer.from(saltB64, 'base64url'), 64);
    const expected = Buffer.from(hashB64, 'base64url');
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch { return false; }
}
