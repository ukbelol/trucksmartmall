module.exports = {
  apps: [
    {
      name: "chamasso-live-chat",
      script: "dist/server.cjs",
      instances: 1,
      exec_mode: "fork",
      env: {
        NODE_ENV: "production",
        PORT: 3000,
        DOMAIN: "chamasso.pasquared.space",
        SECURITY_EMAIL: "rogeriogomes11@ukbelol.space"
      },
      watch: false,
      max_memory_restart: "1G",
      error_file: "/var/log/chamasso/error.log",
      out_file: "/var/log/chamasso/out.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
      autorestart: true,
      restart_delay: 4000
    }
  ]
};
