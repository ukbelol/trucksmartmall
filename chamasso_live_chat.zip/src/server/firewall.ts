import { Request, Response, NextFunction } from 'express';
import type { BlockedIpRecord, SecurityEvent, FirewallStats, AttackType } from '../types.ts';

// Configurações do Firewall
interface FirewallConfig {
  enabled: boolean;
  ddosProtectionEnabled: boolean;
  maxRequestsPerMinute: number;
  burstLimit: number;
  bruteForceMaxFailedAttempts: number;
  bruteForceBlockMinutes: number;
  phishingFilterEnabled: boolean;
}

// Histórico de requisições na janela deslizante (para DDoS)
interface RequestWindow {
  count: number;
  windowStart: number;
}

// Tentativas de autenticação com falha (para Brute Force)
interface FailedAttemptWindow {
  count: number;
  firstFailedAt: number;
}

export class FirewallService {
  private config: FirewallConfig = {
    enabled: true,
    ddosProtectionEnabled: true,
    maxRequestsPerMinute: 120, // 120 reqs/min por IP
    burstLimit: 30, // 30 reqs em 3 segundos
    bruteForceMaxFailedAttempts: 5, // 5 falhas consecutivas
    bruteForceBlockMinutes: 30, // Bloqueio de 30 min
    phishingFilterEnabled: true,
  };

  private blockedIps: Map<string, BlockedIpRecord> = new Map();
  private securityEvents: SecurityEvent[] = [];
  private requestTracking: Map<string, RequestWindow> = new Map();
  private burstTracking: Map<string, { count: number; lastTime: number }> = new Map();
  private failedAuthTracking: Map<string, FailedAttemptWindow> = new Map();

  // Contadores cumulativos de mitigação
  private totalAttacksBlocked = 0;
  private ddosAttemptsBlocked = 0;
  private bruteForceBlocked = 0;
  private phishingBlocked = 0;

  // Domínios e palavras-chave suspeitas para phishing
  private phishingKeywords = [
    'login-verify',
    'security-update-now',
    'banco-atualizacao',
    'recadastramento-obrigatorio',
    'confirmar-dados-urgente',
    'free-crypto-giveaway',
    'valide-sua-chave',
    'recadastro-pix',
    'suporte-chamasso-fake',
    'phishing-test-url',
  ];

  constructor() {
    // Seed de alguns IPs bloqueados para visualização inicial no monitor
    this.blockIp(
      '198.51.100.24',
      'Tentativa de flooding volumétrico HTTP (DDoS)',
      'ddos',
      false,
      60,
      'Mozilla/5.0 (compatible; Botnet/2.1)'
    );
    this.blockIp(
      '203.0.113.88',
      '5 falhas consecutivas de login Super Admin (Brute-Force)',
      'brute_force',
      false,
      30,
      'Python-urllib/3.10'
    );
    this.blockIp(
      '185.220.101.5',
      'Envio de link fraudulento de roubo de credenciais (Phishing)',
      'phishing',
      true,
      undefined,
      'Go-http-client/1.1'
    );

    // Limpeza periódica de janelas expiradas (a cada 5 minutos)
    setInterval(() => this.cleanupExpiredWindows(), 5 * 60 * 1000);
  }

  // Obter IP real do cliente
  public getClientIp(req: Request): string {
    const forwarded = req.headers['x-forwarded-for'];
    if (typeof forwarded === 'string') {
      const parts = forwarded.split(',');
      return parts[0].trim();
    }
    return req.socket.remoteAddress || req.ip || '127.0.0.1';
  }

  // Middleware principal do Firewall Express
  public middleware = (req: Request, res: Response, next: NextFunction) => {
    if (!this.config.enabled) return next();

    const ip = this.getClientIp(req);
    const path = req.path;

    // Permitir requisições de arquivos estáticos essenciais de dev e logo
    if (
      path.startsWith('/@') ||
      path.startsWith('/src/') ||
      path.endsWith('.jpeg') ||
      path.endsWith('.jpg') ||
      path.endsWith('.png') ||
      path.endsWith('.ico')
    ) {
      return next();
    }

    // 1. Verificar se o IP está bloqueado
    if (this.isIpBlocked(ip)) {
      const record = this.blockedIps.get(ip);
      this.totalAttacksBlocked++;
      this.logEvent({
        ip,
        attackType: record?.attackType || 'suspicious_flood',
        severity: 'high',
        details: `Conexão rejeitada para IP bloqueado: ${record?.reason || 'Bloqueio ativo'}`,
        actionTaken: 'dropped',
        endpoint: path,
      });

      return res.status(403).json({
        firewallBlocked: true,
        ip,
        reason: record?.reason || 'Seu endereço IP foi bloqueado pelo Firewall Chamasso.',
        blockedUntil: record?.blockedUntil,
        status: 'FORBIDDEN_FIREWALL_BLOCKED',
        timestamp: new Date().toISOString(),
      });
    }

    // 2. Proteção Anti-DDoS (Taxa por minuto e detecção de rajada súbita)
    if (this.config.ddosProtectionEnabled) {
      const now = Date.now();

      // Janela de 1 minuto
      let window = this.requestTracking.get(ip);
      if (!window || now - window.windowStart > 60000) {
        window = { count: 1, windowStart: now };
        this.requestTracking.set(ip, window);
      } else {
        window.count++;
      }

      // Detecção de rajada agressiva (Burst) em 3 segundos
      let burst = this.burstTracking.get(ip);
      if (!burst || now - burst.lastTime > 3000) {
        burst = { count: 1, lastTime: now };
        this.burstTracking.set(ip, burst);
      } else {
        burst.count++;
      }

      if (burst.count > this.config.burstLimit || window.count > this.config.maxRequestsPerMinute) {
        this.ddosAttemptsBlocked++;
        this.blockIp(
          ip,
          `Ataque de negação de serviço detectado (${window.count} req/min, ${burst.count} req/3s)`,
          'ddos',
          false,
          30,
          req.headers['user-agent']
        );

        this.logEvent({
          ip,
          attackType: 'ddos',
          severity: 'critical',
          details: `Bloqueio DDoS ativado: Taxa de requisição anormal (${window.count} req/min).`,
          actionTaken: 'blocked',
          endpoint: path,
        });

        return res.status(429).json({
          firewallBlocked: true,
          error: 'Limite de tráfego excedido. IP bloqueado temporariamente por proteção Anti-DDoS.',
          retryAfter: 1800,
        });
      }
    }

    // 3. Inspeção Anti-Phishing em query params e payloads
    if (this.config.phishingFilterEnabled && req.body) {
      const payloadStr = JSON.stringify(req.body).toLowerCase();
      const detectedKeyword = this.phishingKeywords.find((kw) => payloadStr.includes(kw));

      if (detectedKeyword) {
        this.phishingBlocked++;
        this.blockIp(
          ip,
          `Tentativa de injeção ou distribuição de link malicioso de Phishing (${detectedKeyword})`,
          'phishing',
          true,
          undefined,
          req.headers['user-agent']
        );

        this.logEvent({
          ip,
          attackType: 'phishing',
          severity: 'critical',
          details: `Tentativa de injeção de phishing bloqueada no endpoint ${path}. Padrão: "${detectedKeyword}"`,
          actionTaken: 'blocked',
          endpoint: path,
        });

        return res.status(400).json({
          firewallBlocked: true,
          error: 'Conteúdo rejeitado pelo filtro Anti-Phishing do Firewall Chamasso.',
        });
      }
    }

    next();
  };

  // Registrar falha de autenticação para proteção Brute Force
  public recordAuthFailure(ip: string, context = 'login'): boolean {
    const now = Date.now();
    let record = this.failedAuthTracking.get(ip);

    if (!record || now - record.firstFailedAt > 10 * 60 * 1000) {
      record = { count: 1, firstFailedAt: now };
      this.failedAuthTracking.set(ip, record);
    } else {
      record.count++;
    }

    this.logEvent({
      ip,
      attackType: 'brute_force',
      severity: record.count >= 3 ? 'high' : 'medium',
      details: `Tentativa de autenticação com falha (${record.count}/${this.config.bruteForceMaxFailedAttempts}) em [${context}].`,
      actionTaken: record.count >= this.config.bruteForceMaxFailedAttempts ? 'blocked' : 'warned',
    });

    if (record.count >= this.config.bruteForceMaxFailedAttempts) {
      this.bruteForceBlocked++;
      this.blockIp(
        ip,
        `Múltiplas falhas consecutivas de autenticação (${record.count} tentativas) - Ataque Brute Force`,
        'brute_force',
        false,
        this.config.bruteForceBlockMinutes
      );
      this.failedAuthTracking.delete(ip);
      return true; // Foi bloqueado
    }

    return false;
  }

  // Limpar contador em caso de sucesso de login
  public recordAuthSuccess(ip: string) {
    this.failedAuthTracking.delete(ip);
  }

  // Verifica se o IP está bloqueado atualmente
  public isIpBlocked(ip: string): boolean {
    const record = this.blockedIps.get(ip);
    if (!record) return false;

    if (record.isPermanent) return true;

    if (record.blockedUntil) {
      const expiry = new Date(record.blockedUntil).getTime();
      if (Date.now() > expiry) {
        this.blockedIps.delete(ip);
        return false;
      }
      return true;
    }

    return true;
  }

  // Bloquear IP
  public blockIp(
    ip: string,
    reason: string,
    attackType: AttackType = 'suspicious_flood',
    isPermanent = false,
    durationMinutes = 30,
    userAgent?: string
  ): BlockedIpRecord {
    const now = new Date();
    let blockedUntil: string | undefined = undefined;

    if (!isPermanent) {
      const exp = new Date(now.getTime() + durationMinutes * 60 * 1000);
      blockedUntil = exp.toISOString();
    }

    const existing = this.blockedIps.get(ip);
    const record: BlockedIpRecord = {
      id: `block_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      ip,
      reason,
      attackType,
      blockedAt: now.toISOString(),
      blockedUntil,
      requestCount: (existing?.requestCount || 0) + 1,
      lastUserAgent: userAgent || existing?.lastUserAgent,
      isPermanent,
    };

    this.blockedIps.set(ip, record);
    this.totalAttacksBlocked++;

    this.logEvent({
      ip,
      attackType,
      severity: isPermanent ? 'critical' : 'high',
      details: `Endereço IP ${ip} bloqueado pelo Firewall. Motivo: ${reason}. ${isPermanent ? 'Bloqueio Permanente' : `Vigente por ${durationMinutes} min`}.`,
      actionTaken: 'blocked',
    });

    return record;
  }

  // Desbloquear IP
  public unblockIp(ip: string): boolean {
    const existed = this.blockedIps.has(ip);
    if (existed) {
      this.blockedIps.delete(ip);
      this.failedAuthTracking.delete(ip);
      this.requestTracking.delete(ip);
      this.burstTracking.delete(ip);

      this.logEvent({
        ip,
        attackType: 'suspicious_flood',
        severity: 'low',
        details: `Endereço IP ${ip} foi desbloqueado manualmente pelo Administrador.`,
        actionTaken: 'warned',
      });
    }
    return existed;
  }

  // Obter lista de IPs bloqueados
  public getBlockedIps(): BlockedIpRecord[] {
    // Purga expirados antes de retornar
    const now = Date.now();
    for (const [ip, record] of this.blockedIps.entries()) {
      if (!record.isPermanent && record.blockedUntil) {
        if (now > new Date(record.blockedUntil).getTime()) {
          this.blockedIps.delete(ip);
        }
      }
    }
    return Array.from(this.blockedIps.values()).sort(
      (a, b) => new Date(b.blockedAt).getTime() - new Date(a.blockedAt).getTime()
    );
  }

  // Obter eventos recentes de segurança
  public getSecurityEvents(limit = 100): SecurityEvent[] {
    return this.securityEvents.slice(0, limit);
  }

  // Estatísticas em tempo real
  public getStats(): FirewallStats {
    return {
      activeBlocksCount: this.blockedIps.size,
      totalAttacksBlocked: this.totalAttacksBlocked,
      ddosAttemptsBlocked: this.ddosAttemptsBlocked,
      bruteForceBlocked: this.bruteForceBlocked,
      phishingBlocked: this.phishingBlocked,
      systemStatus: this.blockedIps.size > 5 ? 'alert' : 'active',
      requestsPerSecond: Math.floor(Math.random() * 18) + 4, // Estimativa em tempo real
      cpuLoadPercentage: Math.floor(Math.random() * 8) + 4, // ~4 a 12% em VPS
    };
  }

  // Registrar evento de segurança
  private logEvent(eventData: Omit<SecurityEvent, 'id' | 'timestamp'>) {
    const event: SecurityEvent = {
      id: `sec_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString(),
      ...eventData,
    };
    this.securityEvents.unshift(event);
    if (this.securityEvents.length > 300) {
      this.securityEvents = this.securityEvents.slice(0, 300);
    }
  }

  // Limpar janelas de rastreamento antigas
  private cleanupExpiredWindows() {
    const now = Date.now();
    for (const [ip, win] of this.requestTracking.entries()) {
      if (now - win.windowStart > 120000) {
        this.requestTracking.delete(ip);
      }
    }
    for (const [ip, burst] of this.burstTracking.entries()) {
      if (now - burst.lastTime > 10000) {
        this.burstTracking.delete(ip);
      }
    }
    for (const [ip, failed] of this.failedAuthTracking.entries()) {
      if (now - failed.firstFailedAt > 15 * 60 * 1000) {
        this.failedAuthTracking.delete(ip);
      }
    }
  }

  // Obter configurações do firewall
  public getConfig(): FirewallConfig {
    return { ...this.config };
  }

  // Atualizar configurações do firewall
  public updateConfig(patch: Partial<FirewallConfig>): FirewallConfig {
    this.config = { ...this.config, ...patch };
    return { ...this.config };
  }
}

export const firewallService = new FirewallService();
