import React, { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, SkipForward, ArrowRight, Sparkles, Play } from 'lucide-react';

interface IntroScreenProps {
  onEnterApp: () => void;
  targetRoute?: string;
}

export const IntroScreen: React.FC<IntroScreenProps> = ({
  onEnterApp,
  targetRoute = '/app',
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoEnded, setVideoEnded] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [countdown, setCountdown] = useState<number>(7);

  // Reiniciar a vinheta do início
  const handleReplayVideo = () => {
    setVideoEnded(false);
    setProgress(0);
    setCountdown(7);
    const video = videoRef.current;
    if (video) {
      video.currentTime = 0;
      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => setIsPlaying(true))
          .catch((err) => {
            console.warn('Erro ao reiniciar vídeo:', err);
          });
      }
    }
  };

  // Temporizador de 7 segundos no letreiro: se não clicar em entrar, reinicia o vídeo da vinheta
  useEffect(() => {
    if (!videoEnded) {
      setCountdown(7);
      return;
    }

    setCountdown(7);
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleReplayVideo();
          return 7;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [videoEnded]);

  // Tentar iniciar reprodução automática
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const playPromise = video.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          setIsPlaying(true);
        })
        .catch((err) => {
          console.warn('Autoplay com restrição do navegador:', err);
          setIsPlaying(false);
        });
    }
  }, []);

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video || !video.duration) return;
    const pct = (video.currentTime / video.duration) * 100;
    setProgress(pct);

    // Se faltar menos de 0.4s para acabar, já ativa o letreiro
    if (video.duration - video.currentTime <= 0.4 && !videoEnded) {
      setVideoEnded(true);
    }
  };

  const handleVideoEnded = () => {
    setVideoEnded(true);
  };

  const handleToggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    const newMuted = !isMuted;
    video.muted = newMuted;
    setIsMuted(newMuted);
    setHasInteracted(true);
    if (video.paused) {
      video.play().then(() => setIsPlaying(true)).catch(console.error);
    }
  };

  const handleManualPlay = () => {
    const video = videoRef.current;
    if (!video) return;
    video.play()
      .then(() => {
        setIsPlaying(true);
        setHasInteracted(true);
      })
      .catch(console.error);
  };

  const handleSkipToEnd = () => {
    const video = videoRef.current;
    if (video) {
      video.pause();
    }
    setVideoEnded(true);
  };

  const handleEnterClick = () => {
    // Redirecionamento da rota para a página com as funcionalidades do site
    window.history.pushState({}, '', targetRoute);
    onEnterApp();
  };

  return (
    <div className="relative w-full h-screen bg-[#07090E] overflow-hidden flex flex-col items-center justify-center select-none">
      {/* Background Glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#22D3EE]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#0284C7]/15 rounded-full blur-3xl pointer-events-none" />

      {/* Camada do Vídeo */}
      <div className="relative w-full h-full flex items-center justify-center">
        <video
          ref={videoRef}
          src="/chamasso_in.mp4"
          playsInline
          autoPlay
          muted={isMuted}
          onEnded={handleVideoEnded}
          onTimeUpdate={handleTimeUpdate}
          className={`w-full h-full object-contain transition-all duration-1000 ${
            videoEnded ? 'opacity-25 filter blur-sm scale-105' : 'opacity-100 scale-100'
          }`}
        />

        {/* Overlay sutil escuro para contraste ao final */}
        <div
          className={`absolute inset-0 bg-gradient-to-t from-[#07090E] via-[#07090E]/60 to-[#07090E]/80 transition-opacity duration-1000 ${
            videoEnded ? 'opacity-100' : 'opacity-20'
          }`}
        />

        {/* Botão de play inicial caso o navegador bloqueie o autoplay */}
        {!isPlaying && !videoEnded && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm">
            <button
              onClick={handleManualPlay}
              className="flex items-center gap-3 px-6 py-3.5 rounded-full bg-gradient-to-r from-[#22D3EE] to-[#0284C7] text-black font-black text-sm uppercase tracking-wider shadow-[0_0_30px_rgba(34,211,238,0.6)] hover:scale-105 active:scale-95 transition-transform"
            >
              <Play className="w-5 h-5 fill-black" />
              <span>Reproduzir Vinheta de Abertura</span>
            </button>
          </div>
        )}

        {/* Controles discretos no topo durante a reprodução */}
        {!videoEnded && (
          <div className="absolute top-4 right-4 sm:top-6 sm:right-8 z-30 flex items-center gap-3">
            <button
              onClick={handleToggleMute}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/60 border border-[#22D3EE]/30 text-xs font-semibold text-[#22D3EE] backdrop-blur-md hover:bg-black/80 hover:border-[#22D3EE] transition shadow-lg"
              title={isMuted ? 'Ativar Som' : 'Desativar Som'}
            >
              {isMuted ? (
                <>
                  <VolumeX className="w-4 h-4 text-[#F472B6]" />
                  <span className="hidden sm:inline">Sem Som (Clique p/ Ativar)</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-[#22D3EE]" />
                  <span className="hidden sm:inline">Som Ativado</span>
                </>
              )}
            </button>

            <button
              onClick={handleSkipToEnd}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-black/60 border border-slate-700 text-xs font-semibold text-slate-300 backdrop-blur-md hover:bg-slate-800 hover:text-white transition shadow-lg"
              title="Pular vinheta"
            >
              <span>Pular</span>
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Barra de progresso sutil na base do vídeo durante a reprodução */}
        {!videoEnded && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-900/80 z-20">
            <div
              className="h-full bg-gradient-to-r from-[#22D3EE] to-[#0284C7] shadow-[0_0_8px_#22d3ee] transition-all duration-150"
              style={{ width: `${progress}%` }}
            />
          </div>
        )}

        {/* LETREIRO NEON AZUL PISCANTE INTERMITENTE NO FINAL DO VÍDEO */}
        {videoEnded && (
          <div className="absolute inset-0 z-40 flex flex-col items-center justify-center p-4 text-center animate-fade-in">
            {/* Brasão/Logo Central sutil */}
            <div className="mb-6 relative">
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl overflow-hidden border-2 border-[#22D3EE] shadow-[0_0_35px_rgba(34,211,238,0.7)] bg-[#0A0C10] mx-auto transition-transform duration-700 hover:scale-110">
                <img
                  src="/fenix_chamas.gif"
                  alt="chamasso live chat"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Letreiro Neon Azul Piscante Intermitente */}
            <div className="max-w-4xl mx-auto px-4">
              <h1 className="text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-black uppercase tracking-wider italic leading-tight neon-text-blue-flicker">
                Chamasso Live Chat, Seu Point de Encontros,
              </h1>
            </div>

            {/* Espaçamento e Subtítulo Decorativo */}
            <p className="mt-4 text-xs sm:text-sm text-cyan-200/70 tracking-[0.25em] uppercase font-mono">
              Salas de Vídeo • Chat ao Vivo • Conexões Reais
            </p>

            {/* Botão de Redirecionamento: "clique aqui para entrar" com Estilo Neon Piscante */}
            <div className="mt-8 sm:mt-12 flex flex-col items-center">
              <a
                href={targetRoute}
                onClick={(e) => {
                  e.preventDefault();
                  handleEnterClick();
                }}
                className="group relative inline-flex items-center gap-3 px-8 sm:px-12 py-4 sm:py-5 rounded-2xl border-2 border-[#22D3EE] bg-[#070E1A]/85 backdrop-blur-xl text-white font-black text-base sm:text-xl uppercase tracking-widest cursor-pointer transition-all duration-300 hover:scale-105 active:scale-95 neon-box-blue-flicker"
                id="btn-entrar-chamasso"
              >
                <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-[#22D3EE] group-hover:rotate-12 transition-transform" />
                <span className="neon-text-blue-flicker text-[#E0F2FE]">
                  clique aqui para entrar
                </span>
                <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 text-[#22D3EE] group-hover:translate-x-1.5 transition-transform" />
              </a>

              {/* Indicador dos 7 segundos para reiniciar a vinheta se não houver clique */}
              <div className="mt-4 flex items-center gap-2 px-3 py-1 rounded-full bg-black/40 border border-[#22D3EE]/20 text-[11px] text-cyan-300/80 font-mono">
                <span className="w-2 h-2 rounded-full bg-[#22D3EE] animate-ping" />
                <span>Reiniciando vinheta em <strong className="text-[#22D3EE] font-bold text-xs">{countdown}s</strong> sem clique</span>
              </div>
            </div>

            {/* Botão sutil para rever a vinheta imediatamente */}
            <button
              onClick={handleReplayVideo}
              className="mt-6 text-xs text-slate-400 hover:text-[#22D3EE] transition underline underline-offset-4 cursor-pointer"
            >
              Rever vinheta agora
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
