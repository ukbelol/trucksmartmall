import React from 'react';
import { X, ShieldCheck, Lock, Database, Eye, CheckCircle2, UserCheck, KeyRound, Server } from 'lucide-react';

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyPolicyModal: React.FC<PrivacyPolicyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-2xl border border-[#22D3EE]/30 bg-[#0F172A] text-slate-200 shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1E293B] bg-[#0A0C10] px-6 py-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="rounded-xl border border-[#22D3EE]/30 bg-[#22D3EE]/10 p-2 text-[#22D3EE]">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
                Política de Privacidade & Proteção de Dados
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                Conforme a LGPD (Lei nº 13.709/2018) • chamasso live chat
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs sm:text-sm leading-relaxed text-slate-300">
          {/* Princípios e LGPD */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-[#22D3EE] font-bold text-xs uppercase tracking-wider">
              <Lock className="h-4 w-4" />
              1. Compromisso com a Privacidade e Conformidade com a LGPD
            </div>
            <p>
              O <strong className="text-white">chamasso live chat</strong> adota diretrizes rigorosas para assegurar a inviolabilidade da intimidade, da honra e da privacidade de seus usuários, em total conformidade com a <strong className="text-[#22D3EE]">Lei Geral de Proteção de Dados Pessoais (LGPD - Lei nº 13.709/2018)</strong> e o Marco Civil da Internet (Lei nº 12.965/2014).
            </p>
            <p>
              Nenhum dado pessoal coletado é comercializado, cedido ou compartilhado com terceiros para fins de propaganda sem o expresso consentimento do titular.
            </p>
          </div>

          {/* Dados Coletados */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-[#F472B6] font-bold text-xs uppercase tracking-wider">
              <UserCheck className="h-4 w-4" />
              2. Dados Pessoais Coletados e Base Legal
            </div>
            <ul className="space-y-1.5 list-disc pl-4 text-slate-300">
              <li>
                <strong className="text-white">Cadastro de Pessoa Física (CPF):</strong> Coletado para fins de validação algorítmica de unicidade de conta e prevenção a fraudes (Art. 7º, IX da LGPD), impedindo cadastros duplicados e abusos.
              </li>
              <li>
                <strong className="text-white">E-mail do Google e Nome Completo:</strong> Utilizados para identificação no sistema, envio de notificações operacionais e autenticação.
              </li>
              <li>
                <strong className="text-white">Credenciais de Autenticação em Duas Etapas (2FA):</strong> Segredo criptográfico TOTP e 11 Códigos Descartáveis de contingência gerados no registro.
              </li>
              <li>
                <strong className="text-white">Nicknames Públicos e Temporários:</strong> Nomes sociais que o próprio usuário escolhe expor aos demais participantes nas salas de conferência e chat.
              </li>
              <li>
                <strong className="text-white">Registros de Conexão e Sessão (Logs):</strong> Endereço IP, horários de acesso e duração das chamadas em observância ao Artigo 15 do Marco Civil da Internet.
              </li>
            </ul>
          </div>

          {/* Tarifas, Recargas e Mercado Pago */}
          <div className="rounded-xl border border-[#22D3EE]/30 bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-[#22D3EE] font-bold text-xs uppercase tracking-wider">
              <CheckCircle2 className="h-4 w-4" />
              3. Dados Financeiros e Processamento de Pagamentos (Mercado Pago)
            </div>
            <p>
              Para a tarifação dos serviços de bate-papo (cobrança por minuto a partir de R$ 0,01/min e recargas pré-pagas mínimas de R$ 5,00), a plataforma conecta-se de forma segura à infraestrutura de pagamentos do <strong className="text-white">Mercado Pago</strong> via API com chave pública e token secreto.
            </p>
            <p className="text-emerald-400 font-semibold">
              Importante: O chamasso live chat não armazena números de cartões de crédito, códigos de segurança (CVV) ou senhas bancárias em seus bancos de dados. Todas as transações são tokenizadas e processadas diretamente nos servidores certificados PCI-DSS do Mercado Pago.
            </p>
            <p>
              O sistema armazena apenas o registro de confirmação da transação (ID da transação, valor recarregado, quantidade de minutos creditados e data de expiração de 30 dias).
            </p>
          </div>

          {/* Armazenamento e Criptografia */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-[#38BDF8] font-bold text-xs uppercase tracking-wider">
              <Database className="h-4 w-4" />
              4. Armazenamento Seguro no SGBD PostgreSQL e Criptografia
            </div>
            <p>
              Os dados dos usuários e o histórico de transações são armazenados em servidor seguro com o SGBD <strong className="text-white">PostgreSQL (banco db_chamasso)</strong> em ambiente Debian 12 com proteção de firewall e proxy reverso Apache 2.4.
            </p>
            <p>
              Todo o tráfego entre o dispositivo do usuário e a aplicação é integralmente criptografado sob protocolo <strong className="text-[#22D3EE]">HTTPS / WSS com Certificado SSL TLS 1.3</strong> no domínio <span className="font-mono text-[#22D3EE]">chamasso.pasquared.space</span>.
            </p>
          </div>

          {/* Áudio, Vídeo e Câmera */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-[#A855F7] font-bold text-xs uppercase tracking-wider">
              <Eye className="h-4 w-4" />
              5. Transmissão de Áudio e Vídeo em Tempo Real (WebRTC)
            </div>
            <p>
              Os fluxos de áudio e vídeo gerados pela webcam e microfone trafegam em tempo real via canais seguros P2P/SFU (WebRTC). O chamasso live chat <strong className="text-white">não realiza a gravação oculta ou armazenamento contínuo</strong> das videoconferências ou conversas privadas entre os participantes em seus discos rígidos, resguardando a privacidade das comunicações interpessoais.
            </p>
          </div>

          {/* Direitos do Titular */}
          <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10] p-4 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
              <KeyRound className="h-4 w-4" />
              6. Direitos do Titular e Encarregado de Dados (DPO)
            </div>
            <p>
              Em cumprimento ao Artigo 18 da LGPD, o titular poderá, a qualquer momento, solicitar a confirmação da existência de tratamento, a exibição de seus dados cadastrais, a correção de dados incompletos ou a exclusão de sua conta da base de dados.
            </p>
            <p className="text-slate-400">
              Para exercer qualquer direito ou esclarecer dúvidas de privacidade, entre em contato com o Encarregado pelo Tratamento de Dados Pessoais do chamasso live chat pelo e-mail: <span className="text-[#22D3EE] font-mono">roger577@ukbelol.space</span> ou suporte administrativo em <span className="text-slate-300 font-mono">rogeriogomes11@ukbelol.space</span>.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#1E293B] bg-[#0A0C10] px-6 py-3 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500 font-mono flex items-center gap-1.5">
            <Server className="h-3 w-3 text-emerald-400" />
            Servidor Seguro Debian 12 • SSL Ativo
          </span>
          <button
            onClick={onClose}
            className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-1.5 text-xs font-black text-black hover:brightness-110 transition"
          >
            Entendido e Ciente
          </button>
        </div>
      </div>
    </div>
  );
};
