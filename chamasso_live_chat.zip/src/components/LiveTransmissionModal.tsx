import React, { useState, useEffect, useRef } from 'react';
import {
  Video,
  Radio,
  Users,
  Lock,
  Globe,
  Send,
  Paperclip,
  Smile,
  X,
  Check,
  Clock,
  ShieldCheck,
  AlertCircle,
  Eye,
  Edit3,
  Sparkles,
  CameraOff,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import type { User, LiveTransmission, LiveViewRequest, ChatMessage } from '../types.ts';
import { MAX_FILE_SIZE_BYTES, MAX_FILE_SIZE_LABEL, formatFileSize, isAudioWavOrMp3, isImageValid, isVideoMp4 } from '../utils/mediaEmbed.ts';
import { VideoEmbedPlayer } from './VideoEmbedPlayer.tsx';
import { AudioPlayer } from './AudioPlayer.tsx';

interface LiveTransmissionModalProps {
  currentUser: User;
  isOpen: boolean;
  onClose: () => void;
  // Se fornecido, abre como espectador nesta live existente; caso contrário, abre formulário para iniciar a sua live
  activeLiveId?: string | null;
}

const POPULAR_EMOJIS = ['❤️', '🔥', '👏', '😍', '💋', '😂', '🎉', '🚀', '💬', '🎵', '✨', '💯', '👑', '🥂', '🌹', '💃'];

export const LiveTransmissionModal: React.FC<LiveTransmissionModalProps> = ({
  currentUser,
  isOpen,
  onClose,
  activeLiveId: initialLiveId,
}) => {
  // Estado da transmissão ativa
  const [liveData, setLiveData] = useState<LiveTransmission | null>(null);
  const [isStreamer, setIsStreamer] = useState(false);
  const [isApprovedToView, setIsApprovedToView] = useState(false);

  // Formulário para iniciar live (caso não esteja em uma)
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState<'public' | 'restricted'>('public');
  const [newFixedText, setNewFixedText] = useState(
    'Apresentação Oficial Chamasso: Respeite os participantes. Proibido conteúdo ofensivo. Conecte-se e divirta-se!'
  );
  const [isStarting, setIsStarting] = useState(false);
  const [startError, setStartError] = useState<string | null>(null);

  // Edição de texto fixo durante a live
  const [isEditingFixedText, setIsEditingFixedText] = useState(false);
  const [editedFixedText, setEditedFixedText] = useState('');

  // Chat acoplado
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  // Solicitação de visualização (para espectador em transmissão restrita)
  const [myViewRequest, setMyViewRequest] = useState<LiveViewRequest | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(0);

  // Mídia local do streamer
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Carrega ou busca a live
  useEffect(() => {
    if (!isOpen) return;

    if (initialLiveId) {
      loadExistingLive(initialLiveId);
    } else {
      // Verifica se o próprio usuário já tem uma live ativa
      checkIfUserHasLive();
    }
  }, [isOpen, initialLiveId]);

  // Polling de sincronização da live (pedidos pendentes com 33s, espectadores, texto fixo e chat)
  useEffect(() => {
    if (!isOpen || !liveData?.id) return;

    const interval = setInterval(() => {
      syncLiveData(liveData.id);
      loadLiveMessages(liveData.id);
    }, 2000);

    return () => clearInterval(interval);
  }, [isOpen, liveData?.id]);

  // Countdown timer local para o pedido de visualização do espectador (33s)
  useEffect(() => {
    if (secondsLeft <= 0) return;
    const t = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          setMyViewRequest(null);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [secondsLeft]);

  // Limpa o stream da webcam ao fechar
  useEffect(() => {
    return () => {
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const checkIfUserHasLive = async () => {
    try {
      const res = await fetch('/api/live');
      const lives: LiveTransmission[] = await res.json();
      const myLive = lives.find((l) => l.streamerId === currentUser.id && l.status === 'active');
      if (myLive) {
        setLiveData(myLive);
        setIsStreamer(true);
        setIsApprovedToView(true);
        setEditedFixedText(myLive.fixedText);
        startLocalCamera();
        loadLiveMessages(myLive.id);
      }
    } catch {
      // Ignora erro
    }
  };

  const loadExistingLive = async (liveId: string) => {
    try {
      const res = await fetch(`/api/live/${liveId}`);
      if (!res.ok) {
        setStartError('Transmissão não encontrada ou encerrada.');
        return;
      }
      const data: LiveTransmission = await res.json();
      setLiveData(data);

      const isMe = data.streamerId === currentUser.id;
      setIsStreamer(isMe);
      setEditedFixedText(data.fixedText);

      if (isMe) {
        setIsApprovedToView(true);
        startLocalCamera();
      } else {
        // Entra como espectador (checa limite de 55 espectadores)
        const joinRes = await fetch(`/api/live/${liveId}/join-viewer`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUser.id,
            userName: currentUser.name,
            userNickname: currentUser.nickname,
          }),
        });
        const joinData = await joinRes.json();
        if (!joinRes.ok) {
          alert(joinData.error || 'Não foi possível entrar na transmissão.');
          onClose();
          return;
        }
        setIsApprovedToView(joinData.isApprovedToView);
      }

      loadLiveMessages(liveId);
    } catch (err: any) {
      setStartError('Erro ao carregar transmissão ao vivo.');
    }
  };

  const syncLiveData = async (liveId: string) => {
    try {
      const res = await fetch(`/api/live/${liveId}`);
      if (!res.ok) return;
      const data: LiveTransmission = await res.json();
      setLiveData(data);

      if (data.approvedViewers?.includes(currentUser.id)) {
        setIsApprovedToView(true);
        setMyViewRequest(null);
        setSecondsLeft(0);
      }
    } catch {
      // silencioso
    }
  };

  const loadLiveMessages = async (liveId: string) => {
    try {
      const res = await fetch(`/api/live/${liveId}/messages`);
      if (res.ok) {
        const msgs = await res.json();
        setMessages(msgs);
      }
    } catch {
      // ignore
    }
  };

  const startLocalCamera = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: true,
        });
        localStreamRef.current = stream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      }
    } catch (err) {
      console.warn('Câmera não disponível no ambiente ou bloqueada:', err);
    }
  };

  const handleStartLive = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      setStartError('Informe um título para a sua transmissão ao vivo.');
      return;
    }

    setIsStarting(true);
    setStartError(null);

    try {
      const res = await fetch('/api/live/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          streamerId: currentUser.id,
          streamerName: `${currentUser.name} ${currentUser.lastName || ''}`.trim(),
          streamerNickname: currentUser.nickname || currentUser.name,
          streamerAvatar: currentUser.avatarUrl,
          title: newTitle.trim(),
          fixedText: newFixedText.trim(),
          type: newType,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setStartError(data.error || 'Erro ao iniciar transmissão.');
        return;
      }

      setLiveData(data.live);
      setIsStreamer(true);
      setIsApprovedToView(true);
      setEditedFixedText(data.live.fixedText);
      startLocalCamera();
      loadLiveMessages(data.live.id);
    } catch {
      setStartError('Falha ao conectar com o servidor.');
    } finally {
      setIsStarting(false);
    }
  };

  const handleStopLive = async () => {
    if (!liveData || !isStreamer) return;
    if (!confirm('Deseja realmente encerrar a sua transmissão ao vivo? Todos os espectadores serão desconectados.')) {
      return;
    }

    try {
      await fetch(`/api/live/${liveData.id}/stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ streamerId: currentUser.id }),
      });

      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => track.stop());
      }
      onClose();
    } catch {
      alert('Erro ao encerrar transmissão.');
    }
  };

  const handleSaveFixedText = async () => {
    if (!liveData || !isStreamer) return;

    try {
      const res = await fetch(`/api/live/${liveData.id}/fixed-text`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          streamerId: currentUser.id,
          fixedText: editedFixedText,
        }),
      });
      if (res.ok) {
        setLiveData((prev) => (prev ? { ...prev, fixedText: editedFixedText } : null));
        setIsEditingFixedText(false);
      }
    } catch {
      alert('Erro ao salvar texto fixo.');
    }
  };

  // Solicitar ver câmera (33 segundos de duração)
  const handleRequestView = async () => {
    if (!liveData) return;

    try {
      const res = await fetch(`/api/live/${liveData.id}/request-view`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          userName: currentUser.name,
          userNickname: currentUser.nickname,
          avatarUrl: currentUser.avatarUrl,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Erro ao enviar pedido.');
        return;
      }

      if (data.approved) {
        setIsApprovedToView(true);
      } else if (data.request || data.pending) {
        setMyViewRequest(data.request || { id: data.requestId, secondsRemaining: data.secondsRemaining || 33 });
        setSecondsLeft(data.secondsRemaining || 33);
      }
    } catch {
      alert('Falha na comunicação com o servidor.');
    }
  };

  // Streamer aprova um espectador
  const handleApproveSingle = async (requestId: string) => {
    if (!liveData || !isStreamer) return;

    try {
      const res = await fetch(`/api/live/${liveData.id}/approve-view`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          streamerId: currentUser.id,
          requestId,
          approveAll: false,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        syncLiveData(liveData.id);
      } else {
        alert(data.error || 'Erro ao aprovar.');
      }
    } catch {
      alert('Falha ao aprovar pedido.');
    }
  };

  // Streamer aperta botão de selecionar todos e liberar câmera geral (até 11 pedidos simultâneos)
  const handleApproveAll = async () => {
    if (!liveData || !isStreamer) return;

    try {
      const res = await fetch(`/api/live/${liveData.id}/approve-view`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          streamerId: currentUser.id,
          approveAll: true,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        alert(data.message || 'Câmera liberada para todos os pedidos pendentes!');
        syncLiveData(liveData.id);
      } else {
        alert(data.error || 'Erro ao aprovar todos.');
      }
    } catch {
      alert('Falha ao liberar pedidos.');
    }
  };

  // Enviar mensagem de texto no chat da live
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !liveData) return;

    const text = chatInput.trim();
    setChatInput('');

    try {
      await fetch(`/api/live/${liveData.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: currentUser.id,
          senderName: currentUser.name,
          senderNickname: currentUser.nickname,
          senderAvatar: currentUser.avatarUrl,
          text,
        }),
      });
      loadLiveMessages(liveData.id);
    } catch {
      // ignore
    }
  };

  // Envio de mídia no chat da live (máximo 33 MB, WAV/MP3, PNG/GIF/JPEG, MP4)
  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !liveData) return;

    // "o tamanho máximo dos arquivos enviados não poderão ultrapassar 33 megas cada um"
    if (file.size > MAX_FILE_SIZE_BYTES) {
      alert(`O arquivo selecionado (${formatFileSize(file.size)}) excede o limite estrito de 33 MB.`);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const name = file.name.toLowerCase();
    const isAudio = file.type.startsWith('audio/') || name.endsWith('.mp3') || name.endsWith('.wav');
    if (isAudio && !isAudioWavOrMp3(file.name, file.type)) {
      alert('Atenção: Arquivos de áudio são permitidos exclusivamente nos formatos WAV e MP3.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const isImg = isImageValid(file.name, file.type);
    const isVid = isVideoMp4(file.name, file.type);

    if (!isAudio && !isImg && !isVid) {
      // Aceita arquivo genérico ou foto
      const confirmUpload = confirm(`Deseja enviar o arquivo "${file.name}" (${formatFileSize(file.size)})?`);
      if (!confirmUpload) return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64 = reader.result as string;
        await fetch(`/api/live/${liveData.id}/upload`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: file.name,
            fileType: file.type,
            fileSize: file.size,
            fileBase64: base64,
            senderId: currentUser.id,
            senderName: currentUser.name,
            senderNickname: currentUser.nickname,
          }),
        });
        loadLiveMessages(liveData.id);
      } catch {
        alert('Erro ao carregar arquivo.');
      } finally {
        setIsUploading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsDataURL(file);
  };

  const handleEmojiClick = (emoji: string) => {
    setChatInput((prev) => prev + emoji);
    setShowEmojiPicker(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-[#0A0C10]/90 backdrop-blur-lg animate-in fade-in duration-200">
      <div className="relative flex flex-col h-[95vh] w-full max-w-7xl rounded-3xl border-2 border-[#22D3EE]/50 bg-[#0A0C10] shadow-[0_0_60px_rgba(34,211,238,0.25)] overflow-hidden text-white">
        
        {/* Top Header Bar */}
        <div className="flex items-center justify-between border-b border-[#1E293B] bg-[#0F172A] px-4 sm:px-6 py-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-[#22D3EE] to-[#F472B6] text-black shadow-md shadow-[#22D3EE]/25">
              <Radio className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 rounded bg-rose-500/20 border border-rose-500/40 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-rose-400">
                  <span className="h-2 w-2 rounded-full bg-rose-500 animate-ping" />
                  Live Ao Vivo
                </span>
                <h2 className="text-sm sm:text-base font-extrabold uppercase tracking-tight text-white truncate max-w-xs sm:max-w-md">
                  {liveData ? liveData.title : 'Iniciar Transmissão de Câmera'}
                </h2>
              </div>
              <p className="text-[10px] text-slate-400">
                {liveData
                  ? `Streamer: ${liveData.streamerNickname || liveData.streamerName} • Limite: 55 Espectadores`
                  : 'Janela Pop-up de Transmissão Online'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {liveData && (
              <div className="hidden sm:flex items-center gap-1.5 rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3 py-1 text-xs text-slate-300">
                <Users className="h-3.5 w-3.5 text-[#22D3EE]" />
                <span className="font-bold text-white">{liveData.currentViewersCount || 1}</span>
                <span className="text-slate-500">/ 55 máx</span>
              </div>
            )}

            {isStreamer && (
              <button
                onClick={handleStopLive}
                className="rounded-xl border border-rose-500/40 bg-rose-950/40 px-3 py-1.5 text-xs font-bold text-rose-300 hover:bg-rose-900/60 transition"
              >
                Encerrar Live
              </button>
            )}

            <button
              onClick={onClose}
              className="rounded-xl p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
              title="Fechar Janela"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Corpo Principal: Se não houver live criada ainda, mostra formulário para abrir */}
        {!liveData ? (
          <div className="flex-1 overflow-y-auto p-6 flex items-center justify-center">
            <div className="w-full max-w-lg rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 sm:p-8">
              <div className="flex items-center gap-3 mb-5">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#22D3EE]/20 text-[#22D3EE]">
                  <Video className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black uppercase text-white">Configurar Minha Live</h3>
                  <p className="text-xs text-slate-400">
                    Transmita sua câmera ao vivo para até 55 participantes simultâneos.
                  </p>
                </div>
              </div>

              {startError && (
                <div className="mb-4 flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-950/40 p-3 text-xs text-rose-300">
                  <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" />
                  <span>{startError}</span>
                </div>
              )}

              <form onSubmit={handleStartLive} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-300 mb-1">
                    Título da Transmissão
                  </label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="Ex: Bate-Papo com a Galera, DJ Set ao Vivo, Paquera & Amizade"
                    maxLength={60}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-300 mb-1">
                    Tipo de Transmissão da Câmera
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <label
                      className={`flex flex-col rounded-xl border p-3 cursor-pointer transition ${
                        newType === 'public'
                          ? 'border-[#22D3EE] bg-[#22D3EE]/10'
                          : 'border-[#1E293B] bg-[#0A0C10] text-slate-400'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-xs font-black text-[#22D3EE]">
                          <Globe className="h-4 w-4" />
                          Pública
                        </span>
                        <input
                          type="radio"
                          name="liveType"
                          value="public"
                          checked={newType === 'public'}
                          onChange={() => setNewType('public')}
                        />
                      </div>
                      <p className="mt-1 text-[10px]">Todos os 55 espectadores assistem sua câmera livremente.</p>
                    </label>

                    <label
                      className={`flex flex-col rounded-xl border p-3 cursor-pointer transition ${
                        newType === 'restricted'
                          ? 'border-[#F472B6] bg-[#F472B6]/10'
                          : 'border-[#1E293B] bg-[#0A0C10] text-slate-400'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-xs font-black text-[#F472B6]">
                          <Lock className="h-4 w-4" />
                          Restrita
                        </span>
                        <input
                          type="radio"
                          name="liveType"
                          value="restricted"
                          checked={newType === 'restricted'}
                          onChange={() => setNewType('restricted')}
                        />
                      </div>
                      <p className="mt-1 text-[10px]">
                        Pedidos de visualização com duração de 33s. Fila máxima de 11 pedidos simultâneos.
                      </p>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-300 mb-1">
                    Texto Fixo / Apresentação / Limites ou Marketing
                  </label>
                  <textarea
                    value={newFixedText}
                    onChange={(e) => setNewFixedText(e.target.value)}
                    rows={3}
                    placeholder="Escreva seus limites de conversa, apresentação pessoal ou marketing de produtos..."
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3 text-xs text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Este texto ficará fixado permanentemente abaixo da sua câmera para todos os espectadores.
                  </p>
                </div>

                <div className="rounded-xl border border-[#1E293B] bg-[#0A0C10]/60 p-3 text-[11px] text-slate-400 space-y-1">
                  <p>• Limite fixo: <strong>55 usuários</strong> assistindo simultaneamente.</p>
                  <p>• Regra estrita: O mesmo usuário só pode transmitir <strong>1 canal por vez</strong>.</p>
                  <p>• Arquivos no chat: Máximo de <strong>33 MB</strong> (Áudios WAV/MP3, Fotos PNG/GIF/JPEG, Vídeo MP4).</p>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2.5 text-xs font-bold text-slate-300 hover:bg-[#334155]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={isStarting || !newTitle.trim()}
                    className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2.5 text-xs font-black text-black shadow-lg shadow-[#22D3EE]/25 hover:brightness-110 active:scale-95 transition disabled:opacity-50"
                  >
                    <Sparkles className="h-4 w-4 text-black" />
                    <span>{isStarting ? 'Iniciando Live...' : 'Iniciar Transmissão'}</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        ) : (
          /* Janela Dupla: Transmissão à Esquerda & Chat Acoplado à Direita */
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
            
            {/* LADO ESQUERDO (7 Colunas): Transmissão de Câmera + Texto Fixo + Pedidos 33s */}
            <div className="lg:col-span-7 flex flex-col border-b lg:border-b-0 lg:border-r border-[#1E293B] bg-[#0A0C10] overflow-y-auto p-4 sm:p-5">
              
              {/* Box de Transmissão de Vídeo (16:9 Aspect Ratio) */}
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden border border-[#22D3EE]/40 bg-black shadow-2xl">
                {isStreamer ? (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="h-full w-full object-cover"
                  />
                ) : isApprovedToView ? (
                  // Espectador com acesso liberado à câmera
                  <div className="relative h-full w-full flex items-center justify-center bg-gradient-to-b from-[#0F172A] to-black">
                    <div className="text-center p-6">
                      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#22D3EE]/20 text-[#22D3EE] mb-3 animate-pulse">
                        <Video className="h-8 w-8" />
                      </div>
                      <h4 className="text-base font-bold text-white">Transmissão em Andamento</h4>
                      <p className="text-xs text-slate-400 mt-1">
                        Você possui autorização para assistir a câmera de <strong>{liveData.streamerNickname || liveData.streamerName}</strong>.
                      </p>
                    </div>
                  </div>
                ) : (
                  // Espectador em transmissão restrita sem aprovação (Blur / Bloqueio)
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 backdrop-blur-md p-6 text-center">
                    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-500/20 text-rose-400 mb-3 border border-rose-500/30">
                      <Lock className="h-7 w-7" />
                    </div>
                    <h4 className="text-base font-black text-white uppercase tracking-tight">
                      Câmera em Modo Restrito
                    </h4>
                    <p className="text-xs text-slate-300 mt-1.5 max-w-sm">
                      O streamer configurou esta live como restrita. Solicite autorização para visualizar a câmera.
                    </p>

                    {secondsLeft > 0 ? (
                      <div className="mt-4 rounded-xl border border-amber-400/40 bg-amber-950/40 px-4 py-2 text-xs text-amber-300 flex items-center gap-2">
                        <Clock className="h-4 w-4 animate-spin text-amber-400" />
                        <span>Aguardando streamer: <strong>{secondsLeft}s restantes</strong></span>
                      </div>
                    ) : (
                      <button
                        onClick={handleRequestView}
                        className="mt-4 flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-2.5 text-xs font-black text-black shadow-lg shadow-[#22D3EE]/25 hover:brightness-110 active:scale-95 transition"
                      >
                        <Eye className="h-4 w-4 text-black" />
                        <span>Solicitar Ver Câmera (Duração: 33s)</span>
                      </button>
                    )}
                  </div>
                )}

                {/* Badges superiores na câmera */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="flex items-center gap-1.5 rounded-md bg-rose-600 px-2.5 py-1 text-[10px] font-black uppercase text-white shadow-md">
                    <span className="h-2 w-2 rounded-full bg-white animate-pulse" />
                    AO VIVO
                  </span>
                  <span
                    className={`rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wider ${
                      liveData.type === 'restricted'
                        ? 'border border-[#F472B6]/40 bg-black/60 text-[#F472B6]'
                        : 'border border-[#22D3EE]/40 bg-black/60 text-[#22D3EE]'
                    }`}
                  >
                    {liveData.type === 'restricted' ? 'Restrita' : 'Pública'}
                  </span>
                </div>

                <div className="absolute top-3 right-3 rounded-md border border-[#1E293B] bg-black/70 px-2.5 py-1 text-[10px] font-bold text-slate-200">
                  {liveData.currentViewersCount || 1} / 55 Espectadores
                </div>
              </div>

              {/* Abaixo da Transmissão: Texto Fixo / Apresentação / Limites ou Marketing */}
              <div className="mt-4 rounded-2xl border border-[#22D3EE]/30 bg-[#0F172A] p-4 text-left">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-[#22D3EE] flex items-center gap-1.5">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    Apresentação, Limites & Marketing Fixo
                  </span>
                  {isStreamer && !isEditingFixedText && (
                    <button
                      onClick={() => setIsEditingFixedText(true)}
                      className="flex items-center gap-1 text-[11px] font-semibold text-slate-400 hover:text-[#22D3EE] transition"
                    >
                      <Edit3 className="h-3 w-3" />
                      <span>Editar Texto Fixo</span>
                    </button>
                  )}
                </div>

                {isEditingFixedText ? (
                  <div className="space-y-2">
                    <textarea
                      value={editedFixedText}
                      onChange={(e) => setEditedFixedText(e.target.value)}
                      rows={3}
                      className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs text-white focus:border-[#22D3EE] focus:outline-none"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setIsEditingFixedText(false)}
                        className="rounded-lg px-3 py-1 text-xs text-slate-400 hover:bg-[#1E293B]"
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={handleSaveFixedText}
                        className="rounded-lg bg-[#22D3EE] px-3 py-1 text-xs font-bold text-black hover:brightness-110"
                      >
                        Salvar
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                    {liveData.fixedText || 'Nenhum texto fixo configurado.'}
                  </p>
                )}
              </div>

              {/* Se o streamer estiver em transmissão restrita: Painel com até 11 pedidos de visualização (33s cada) */}
              {isStreamer && liveData.type === 'restricted' && (
                <div className="mt-4 rounded-2xl border border-[#F472B6]/40 bg-[#0F172A] p-4 text-left">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                    <div>
                      <h4 className="text-xs font-black uppercase text-white flex items-center gap-1.5">
                        <Lock className="h-3.5 w-3.5 text-[#F472B6]" />
                        Pedidos de Ver Câmera (Máximo 11)
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        Cada pedido dura 33 segundos e sai automaticamente da fila após o término.
                      </p>
                    </div>

                    {liveData.pendingViewRequests.length > 0 && (
                      <button
                        onClick={handleApproveAll}
                        className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-3 py-1.5 text-xs font-black text-black shadow-md hover:brightness-110 active:scale-95 transition"
                      >
                        <Check className="h-3.5 w-3.5 text-black" />
                        <span>Selecionar Todos e Liberar Câmera Geral ({liveData.pendingViewRequests.length})</span>
                      </button>
                    )}
                  </div>

                  {liveData.pendingViewRequests.length === 0 ? (
                    <p className="text-[11px] text-slate-500 italic">
                      Nenhum pedido pendente no momento. Os pedidos aparecerão aqui quando os espectadores solicitarem.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {liveData.pendingViewRequests.map((req) => (
                        <div
                          key={req.id}
                          className="flex items-center justify-between rounded-xl border border-[#1E293B] bg-[#0A0C10] p-2.5 text-xs"
                        >
                          <div className="flex items-center gap-2">
                            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#22D3EE]/20 text-[#22D3EE] font-bold text-[11px]">
                              {req.userNickname?.[0] || req.userName?.[0] || 'U'}
                            </div>
                            <div>
                              <p className="font-bold text-white">{req.userNickname || req.userName}</p>
                              <span className="flex items-center gap-1 text-[10px] text-amber-400">
                                <Clock className="h-3 w-3" />
                                {req.secondsRemaining}s restantes
                              </span>
                            </div>
                          </div>

                          <button
                            onClick={() => handleApproveSingle(req.id)}
                            className="rounded-lg bg-[#22D3EE] px-3 py-1 text-xs font-bold text-black hover:brightness-110 transition"
                          >
                            Liberar Câmera
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* LADO DIREITO (5 Colunas): Espaço de Chat Acoplado à Transmissão */}
            <div className="lg:col-span-5 flex flex-col bg-[#0F172A] overflow-hidden">
              
              {/* Header do Chat */}
              <div className="flex items-center justify-between border-b border-[#1E293B] bg-[#0A0C10] px-4 py-2.5">
                <span className="text-xs font-extrabold uppercase tracking-wide text-white">
                  Chat ao Vivo da Transmissão
                </span>
                <span className="text-[10px] text-slate-400">
                  Fotos, Vídeos & Áudios (até 33 MB)
                </span>
              </div>

              {/* Feed de Mensagens */}
              <div className="flex-1 overflow-y-auto p-3.5 space-y-3">
                {messages.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-center text-xs text-slate-500 p-4">
                    Seja o primeiro a enviar uma mensagem na live! Envie comentários, emoticons, links de vídeo do YouTube ou arquivos de até 33 MB.
                  </div>
                ) : (
                  messages.map((msg) => {
                    const isMe = msg.senderId === currentUser.id;
                    const isMod = msg.senderId === liveData.streamerId;

                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <div className="flex items-center gap-1.5 mb-0.5 text-[10px] text-slate-400">
                          <span className="font-bold text-slate-300">
                            {msg.senderNickname || msg.senderName}
                          </span>
                          {isMod && (
                            <span className="rounded bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-1 text-[9px] font-black text-black">
                              STREAMER
                            </span>
                          )}
                          <span>
                            {new Date(msg.timestamp).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>

                        <div
                          className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-xs ${
                            isMe
                              ? 'bg-[#22D3EE] text-black font-medium'
                              : 'border border-[#1E293B] bg-[#0A0C10] text-slate-200'
                          }`}
                        >
                          {msg.text && <p className="whitespace-pre-wrap break-words">{msg.text}</p>}

                          {/* Plugin Incorporado de Vídeo (YouTube, Twitch, Vimeo, DailyMotion, MP4) */}
                          {msg.videoEmbed && <VideoEmbedPlayer embed={msg.videoEmbed} />}

                          {/* Player de Áudio Incorporado (WAV ou MP3) */}
                          {msg.audioAttachment && <AudioPlayer audio={msg.audioAttachment} />}

                          {/* Prévia de Imagem */}
                          {msg.file && isImageValid(msg.file.name, msg.file.type) && (
                            <div className="mt-2 overflow-hidden rounded-xl border border-white/20">
                              <img
                                src={msg.file.url}
                                alt={msg.file.name}
                                className="max-h-56 w-full object-cover cursor-pointer hover:scale-105 transition"
                                onClick={() => window.open(msg.file?.url, '_blank')}
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={chatBottomRef} />
              </div>

              {/* Seletor de Emojis Popover */}
              {showEmojiPicker && (
                <div className="border-t border-[#1E293B] bg-[#0A0C10] p-2 grid grid-cols-8 gap-1 animate-in fade-in">
                  {POPULAR_EMOJIS.map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => handleEmojiClick(emoji)}
                      className="h-8 rounded-lg text-base hover:bg-[#1E293B] transition"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}

              {/* Input do Chat com Envio de Anexo & Emoticons */}
              <form onSubmit={handleSendMessage} className="border-t border-[#1E293B] bg-[#0A0C10] p-2.5">
                <div className="flex items-center gap-1.5">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelected}
                    accept="image/png,image/jpeg,image/gif,audio/wav,audio/mp3,audio/mpeg,video/mp4,.png,.jpeg,.jpg,.gif,.wav,.mp3,.mp4"
                    className="hidden"
                  />

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="rounded-xl p-2 text-slate-400 hover:bg-[#1E293B] hover:text-[#22D3EE] transition"
                    title="Anexar arquivo (máx 33MB: Fotos, Áudio WAV/MP3, Vídeo MP4)"
                  >
                    <Paperclip className="h-4 w-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className="rounded-xl p-2 text-slate-400 hover:bg-[#1E293B] hover:text-[#22D3EE] transition"
                    title="Inserir Emoticons"
                  >
                    <Smile className="h-4 w-4" />
                  </button>

                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Digite sua mensagem ou link do YouTube..."
                    className="flex-1 rounded-xl border border-[#1E293B] bg-[#0F172A] px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
                  />

                  <button
                    type="submit"
                    disabled={!chatInput.trim()}
                    className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] p-2 text-black shadow-md hover:brightness-110 active:scale-95 transition disabled:opacity-40"
                    title="Enviar Mensagem"
                  >
                    <Send className="h-4 w-4 text-black" />
                  </button>
                </div>

                {isUploading && (
                  <p className="mt-1 text-[10px] text-[#22D3EE] animate-pulse">
                    Enviando arquivo (máx 33 MB)...
                  </p>
                )}
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
