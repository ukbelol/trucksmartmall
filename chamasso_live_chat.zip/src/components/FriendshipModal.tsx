import React, { useState, useEffect } from 'react';
import {
  Users,
  UserPlus,
  Heart,
  FolderPlus,
  Folder,
  ArrowRightLeft,
  Check,
  X,
  Clock,
  Search,
  Filter,
  Sparkles,
  MessageSquare,
  Trash2,
  AlertCircle,
  Coffee,
  Briefcase,
  Star,
  CheckCircle2,
} from 'lucide-react';
import type {
  User,
  UserStatus,
  RelationshipLevel,
  ContactGroup,
  UserContact,
  FriendshipRequest,
} from '../types.ts';

interface FriendshipModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onUserStatusChange?: (newStatus: UserStatus) => void;
}

export const FriendshipModal: React.FC<FriendshipModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUserStatusChange,
}) => {
  const [activeTab, setActiveTab] = useState<'contacts' | 'discover' | 'requests'>('discover');

  // Data States
  const [relationshipLevels, setRelationshipLevels] = useState<RelationshipLevel[]>([]);
  const [availableUsers, setAvailableUsers] = useState<any[]>([]);
  const [contacts, setContacts] = useState<UserContact[]>([]);
  const [groups, setGroups] = useState<ContactGroup[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<FriendshipRequest[]>([]);
  const [outgoingRequests, setOutgoingRequests] = useState<FriendshipRequest[]>([]);

  // Filters & Search
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [selectedGroupFilter, setSelectedGroupFilter] = useState<string>('todos');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);

  // Sub-Modals
  const [targetUserForRequest, setTargetUserForRequest] = useState<any | null>(null);
  const [selectedRelLevelId, setSelectedRelLevelId] = useState('');
  const [selectedSenderGroupId, setSelectedSenderGroupId] = useState('');
  const [requestMessage, setRequestMessage] = useState('');
  const [sendingRequest, setSendingRequest] = useState(false);
  const [requestSuccessNotice, setRequestSuccessNotice] = useState<string | null>(null);

  // Accept Request Modal State (requires choosing a group for the incoming contact)
  const [acceptingRequest, setAcceptingRequest] = useState<FriendshipRequest | null>(null);
  const [acceptGroupChoice, setAcceptGroupChoice] = useState('');

  // Move Contact Modal State
  const [movingContact, setMovingContact] = useState<UserContact | null>(null);
  const [targetMoveGroupId, setTargetMoveGroupId] = useState('');

  // Create Group Modal State
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupIcon, setNewGroupIcon] = useState('📁');
  const [newGroupColor, setNewGroupColor] = useState('#22D3EE');

  // Status mapping
  const statusMeta: Record<
    UserStatus,
    { label: string; dot: string; text: string; bg: string; icon: string }
  > = {
    online: {
      label: 'Online',
      dot: 'bg-emerald-400',
      text: 'text-emerald-400',
      bg: 'bg-emerald-500/10 border-emerald-500/30',
      icon: '🟢',
    },
    ocupado: {
      label: 'Ocupado',
      dot: 'bg-rose-500',
      text: 'text-rose-400',
      bg: 'bg-rose-500/10 border-rose-500/30',
      icon: '🔴',
    },
    em_almoco: {
      label: 'Em Horário de Almoço',
      dot: 'bg-amber-400',
      text: 'text-amber-400',
      bg: 'bg-amber-500/10 border-amber-500/30',
      icon: '🍔',
    },
    ausente: {
      label: 'Ausente',
      dot: 'bg-yellow-400',
      text: 'text-yellow-400',
      bg: 'bg-yellow-500/10 border-yellow-500/30',
      icon: '🟡',
    },
    invisivel: {
      label: 'Invisível (Offline)',
      dot: 'bg-slate-400',
      text: 'text-slate-400',
      bg: 'bg-slate-500/10 border-slate-500/30',
      icon: '⚪',
    },
  };

  const loadData = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const [levelsRes, usersRes, contactsRes, requestsRes] = await Promise.all([
        fetch('/api/relationship-levels'),
        fetch(`/api/users/status-list?excludeUserId=${currentUser.id}`),
        fetch(`/api/users/${currentUser.id}/contacts`),
        fetch(`/api/users/${currentUser.id}/friendship-requests`),
      ]);

      if (levelsRes.ok) {
        const levels = await levelsRes.json();
        setRelationshipLevels(levels);
        if (levels.length > 0 && !selectedRelLevelId) {
          setSelectedRelLevelId(levels[0].id);
        }
      }

      if (usersRes.ok) {
        setAvailableUsers(await usersRes.json());
      }

      if (contactsRes.ok) {
        const cData = await contactsRes.json();
        setContacts(cData.contacts || []);
        setGroups(cData.groups || []);
        if (cData.groups && cData.groups.length > 0 && !selectedSenderGroupId) {
          setSelectedSenderGroupId(cData.groups[0].id);
          setAcceptGroupChoice(cData.groups[0].id);
        }
      }

      if (requestsRes.ok) {
        const rData = await requestsRes.json();
        setIncomingRequests(rData.incoming || []);
        setOutgoingRequests(rData.outgoing || []);
      }
    } catch (err) {
      console.error('Erro ao carregar dados de amizades:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen, currentUser]);

  if (!isOpen) return null;

  // Handle Send Friendship Request
  const handleSendRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUserForRequest || !selectedRelLevelId) return;

    setSendingRequest(true);
    try {
      const res = await fetch('/api/friendship-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: currentUser.id,
          receiverId: targetUserForRequest.id,
          relationshipLevelId: selectedRelLevelId,
          senderGroupId: selectedSenderGroupId || (groups[0] ? groups[0].id : 'grp_geral'),
          message: requestMessage,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao enviar pedido de amizade.');
      }

      setRequestSuccessNotice(`Pedido de amizade enviado com sucesso para ${targetUserForRequest.name}!`);
      setTimeout(() => setRequestSuccessNotice(null), 4000);
      setTargetUserForRequest(null);
      setRequestMessage('');
      loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao enviar solicitação.');
    } finally {
      setSendingRequest(false);
    }
  };

  // Handle Respond to Request (Accept / Reject)
  const handleRespondRequest = async (requestId: string, action: 'accept' | 'reject', groupId?: string) => {
    try {
      const res = await fetch(`/api/friendship-requests/${requestId}/respond`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          action,
          receiverGroupId: groupId || acceptGroupChoice || (groups[0] ? groups[0].id : 'grp_geral'),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao responder solicitação.');
      }

      setAcceptingRequest(null);
      loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao responder pedido.');
    }
  };

  // Handle Move Contact to Group
  const handleMoveContact = async () => {
    if (!movingContact || !targetMoveGroupId) return;

    try {
      const res = await fetch(`/api/users/${currentUser.id}/contacts/move-group`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contactId: movingContact.id,
          targetGroupId: targetMoveGroupId,
        }),
      });

      if (!res.ok) throw new Error('Erro ao mover contato de grupo.');

      setMovingContact(null);
      loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao mover contato.');
    }
  };

  // Handle Create New Custom Contact Group
  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    try {
      const res = await fetch(`/api/users/${currentUser.id}/contact-groups`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newGroupName.trim(),
          icon: newGroupIcon,
          color: newGroupColor,
        }),
      });

      if (!res.ok) throw new Error('Erro ao criar grupo.');

      setNewGroupName('');
      setShowCreateGroup(false);
      loadData();
    } catch (err: any) {
      alert(err.message || 'Erro ao criar grupo.');
    }
  };

  // Handle Delete Contact
  const handleDeleteContact = async (contactId: string, name: string) => {
    if (!confirm(`Deseja remover ${name} dos seus contatos?`)) return;

    try {
      const res = await fetch(`/api/users/${currentUser.id}/contacts/${contactId}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        loadData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Filter available users
  const filteredUsers = availableUsers.filter((u) => {
    const matchesStatus = statusFilter === 'todos' || u.status === statusFilter;
    const matchesSearch =
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.bio && u.bio.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  // Filter contacts
  const filteredContacts = contacts.filter((c) => {
    const matchesGroup = selectedGroupFilter === 'todos' || c.groupId === selectedGroupFilter;
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.lastName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGroup && matchesSearch;
  });

  const pendingIncomingCount = incomingRequests.filter((r) => r.status === 'pending').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#0A0C10]/85 backdrop-blur-md">
      <div className="relative flex flex-col w-full max-w-5xl h-[90vh] max-h-[850px] rounded-3xl border border-[#1E293B] bg-[#0F172A] shadow-2xl text-[#E2E8F0] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1E293B] px-6 py-4 bg-[#0F172A]/90 shrink-0">
          <div className="flex items-center gap-3">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onClose();
              }}
              title="Ir para a página inicial"
              className="relative w-11 h-11 rounded-2xl overflow-hidden border-2 border-[#22D3EE]/50 shadow-[0_0_15px_rgba(34,211,238,0.35)] shrink-0 bg-[#0A0C10] block cursor-pointer hover:scale-105 active:scale-95 transition-transform"
            >
              <img
                src="/fenix_chamas.gif"
                alt="chamasso live chat"
                className="w-full h-full object-cover"
              />
            </a>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-white tracking-tight uppercase italic">
                  Conexões & Bate-Papo
                </h2>
                <span className="rounded-full bg-[#22D3EE]/10 border border-[#22D3EE]/30 px-2 py-0.5 text-[10px] font-bold text-[#22D3EE]">
                  chamasso live
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Solicite amizade de pessoas do bate-papo, organize em grupos e escolha os níveis de relacionamento.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-xl border border-[#1E293B] bg-[#1E293B] p-2 text-slate-400 hover:bg-[#334155] hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Success Notice Banner */}
        {requestSuccessNotice && (
          <div className="bg-emerald-500/10 border-b border-emerald-500/30 px-6 py-2.5 flex items-center gap-2 text-xs font-semibold text-emerald-300">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>{requestSuccessNotice}</span>
          </div>
        )}

        {/* Main Tabs Navigation */}
        <div className="flex items-center justify-between border-b border-[#1E293B] bg-[#0A0C10] px-6 py-2.5 shrink-0 overflow-x-auto gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('discover')}
              className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition whitespace-nowrap ${
                activeTab === 'discover'
                  ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black shadow-md'
                  : 'text-slate-400 hover:bg-[#1E293B] hover:text-white'
              }`}
            >
              <Search className="h-4 w-4" />
              <span>Explorar Pessoas ({availableUsers.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('contacts')}
              className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition whitespace-nowrap ${
                activeTab === 'contacts'
                  ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black shadow-md'
                  : 'text-slate-400 hover:bg-[#1E293B] hover:text-white'
              }`}
            >
              <Folder className="h-4 w-4" />
              <span>Meus Contatos & Grupos ({contacts.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('requests')}
              className={`relative flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition whitespace-nowrap ${
                activeTab === 'requests'
                  ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black shadow-md'
                  : 'text-slate-400 hover:bg-[#1E293B] hover:text-white'
              }`}
            >
              <UserPlus className="h-4 w-4" />
              <span>Solicitações</span>
              {pendingIncomingCount > 0 && (
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-black text-white shadow-sm">
                  {pendingIncomingCount}
                </span>
              )}
            </button>
          </div>

          {/* Quick Group Action */}
          {activeTab === 'contacts' && (
            <button
              onClick={() => setShowCreateGroup(true)}
              className="flex items-center gap-1.5 rounded-xl border border-[#22D3EE]/40 bg-[#1E293B] px-3 py-1.5 text-xs font-semibold text-[#22D3EE] hover:bg-[#334155] transition shrink-0"
            >
              <FolderPlus className="h-4 w-4" />
              <span>Novo Grupo</span>
            </button>
          )}
        </div>

        {/* Tab 1: Discover & Request Friendship */}
        {activeTab === 'discover' && (
          <div className="flex-1 flex flex-col p-6 overflow-hidden">
            {/* Filter Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-5 shrink-0">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                <input
                  type="text"
                  placeholder="Pesquisar por nome ou bio..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-10 pr-4 py-2 text-xs text-[#E2E8F0] placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
                />
              </div>

              {/* Status Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1 mr-1">
                  <Filter className="h-3.5 w-3.5" /> Status:
                </span>
                {[
                  { id: 'todos', label: 'Todos' },
                  { id: 'online', label: '🟢 Online' },
                  { id: 'ocupado', label: '🔴 Ocupado' },
                  { id: 'em_almoco', label: '🍔 Almoço' },
                  { id: 'ausente', label: '🟡 Ausente' },
                  { id: 'invisivel', label: '⚪ Invisível' },
                ].map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setStatusFilter(st.id)}
                    className={`rounded-lg px-2.5 py-1 text-[11px] font-medium transition whitespace-nowrap ${
                      statusFilter === st.id
                        ? 'bg-[#22D3EE] text-black font-bold'
                        : 'border border-[#1E293B] bg-[#1E293B] text-slate-300 hover:border-slate-600'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Users Grid */}
            <div className="flex-1 overflow-y-auto pr-1">
              {filteredUsers.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 rounded-2xl border border-dashed border-[#1E293B] text-slate-500 text-xs">
                  <Users className="h-8 w-8 text-slate-600 mb-2" />
                  <p>Nenhum usuário encontrado para este filtro.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredUsers.map((u) => {
                    const st = statusMeta[(u.status as UserStatus) || 'online'];
                    const isAlreadyContact = contacts.some((c) => c.userId === u.id);
                    const hasPendingOut = outgoingRequests.some(
                      (r) => r.receiverId === u.id && r.status === 'pending'
                    );

                    return (
                      <div
                        key={u.id}
                        className="flex flex-col justify-between rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-4.5 hover:border-[#22D3EE]/40 transition group"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-3 mb-2.5">
                            <div className="flex items-center gap-2.5">
                              <div className="relative">
                                <div className="h-11 w-11 rounded-full bg-gradient-to-br from-[#334155] to-[#1E293B] border border-[#22D3EE]/30 flex items-center justify-center font-bold text-white text-base">
                                  {u.name.charAt(0).toUpperCase()}
                                </div>
                                <span
                                  className={`absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-[#0A0C10] ${st.dot}`}
                                  title={st.label}
                                />
                              </div>
                              <div>
                                <h3 className="text-sm font-bold text-white leading-tight">
                                  {u.name} {u.lastName}
                                </h3>
                                <p className="text-[11px] text-slate-400 font-mono truncate max-w-[150px]">
                                  {u.googleEmail}
                                </p>
                              </div>
                            </div>

                            {/* Status Badge */}
                            <span
                              className={`flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[10px] font-semibold ${st.bg} ${st.text}`}
                            >
                              <span>{st.icon}</span>
                              <span>{st.label}</span>
                            </span>
                          </div>

                          {u.bio && (
                            <p className="text-xs text-slate-300 line-clamp-2 mb-3 bg-[#0F172A] p-2 rounded-xl border border-[#1E293B]/60">
                              "{u.bio}"
                            </p>
                          )}

                          {u.interests && u.interests.length > 0 && (
                            <div className="flex flex-wrap gap-1 mb-3">
                              {u.interests.map((int: string, i: number) => (
                                <span
                                  key={i}
                                  className="rounded-md bg-[#1E293B] px-2 py-0.5 text-[10px] text-slate-400"
                                >
                                  {int}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>

                        <div className="pt-2 border-t border-[#1E293B]/60">
                          {isAlreadyContact ? (
                            <div className="flex items-center justify-center gap-1.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 py-2 text-xs font-bold text-emerald-400">
                              <Check className="h-3.5 w-3.5" />
                              <span>Já é seu contato</span>
                            </div>
                          ) : hasPendingOut ? (
                            <div className="flex items-center justify-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/10 py-2 text-xs font-bold text-amber-400">
                              <Clock className="h-3.5 w-3.5" />
                              <span>Solicitação Enviada</span>
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                setTargetUserForRequest(u);
                                if (groups.length > 0) setSelectedSenderGroupId(groups[0].id);
                                if (relationshipLevels.length > 0)
                                  setSelectedRelLevelId(relationshipLevels[0].id);
                              }}
                              className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2 text-xs font-black text-black shadow-md hover:brightness-110 active:scale-98 transition"
                            >
                              <UserPlus className="h-3.5 w-3.5" />
                              <span>Solicitar Amizade</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: My Contacts & Groups */}
        {activeTab === 'contacts' && (
          <div className="flex-1 flex flex-col p-6 overflow-hidden">
            {/* Group Filter Chips */}
            <div className="flex flex-wrap items-center gap-2 mb-5 shrink-0">
              <span className="text-xs font-bold text-slate-400 mr-1 flex items-center gap-1">
                <Folder className="h-3.5 w-3.5" /> Grupos de Contatos:
              </span>
              <button
                onClick={() => setSelectedGroupFilter('todos')}
                className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                  selectedGroupFilter === 'todos'
                    ? 'bg-[#22D3EE] text-black shadow-sm'
                    : 'border border-[#1E293B] bg-[#0A0C10] text-slate-300 hover:border-slate-600'
                }`}
              >
                Todos ({contacts.length})
              </button>
              {groups.map((grp) => {
                const countInGrp = contacts.filter((c) => c.groupId === grp.id).length;
                return (
                  <button
                    key={grp.id}
                    onClick={() => setSelectedGroupFilter(grp.id)}
                    className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                      selectedGroupFilter === grp.id
                        ? 'bg-[#22D3EE] text-black shadow-sm'
                        : 'border border-[#1E293B] bg-[#0A0C10] text-slate-300 hover:border-slate-600'
                    }`}
                  >
                    <span>{grp.icon}</span>
                    <span>{grp.name}</span>
                    <span className="opacity-70 text-[10px]">({countInGrp})</span>
                  </button>
                );
              })}
            </div>

            {/* Contacts List */}
            <div className="flex-1 overflow-y-auto pr-1">
              {filteredContacts.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 rounded-2xl border border-dashed border-[#1E293B] text-slate-500 text-xs">
                  <Folder className="h-8 w-8 text-slate-600 mb-2" />
                  <p>Nenhum contato encontrado neste grupo.</p>
                  <button
                    onClick={() => setActiveTab('discover')}
                    className="mt-3 text-[#22D3EE] hover:underline font-bold"
                  >
                    Explorar pessoas no bate-papo e solicitar amizade →
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredContacts.map((c) => {
                    const st = statusMeta[(c.status as UserStatus) || 'online'];
                    return (
                      <div
                        key={c.id}
                        className="flex flex-col justify-between rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-4.5 hover:border-slate-600 transition"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-2 mb-3">
                            <div className="flex items-center gap-2.5">
                              <div className="relative">
                                <div className="h-10 w-10 rounded-full bg-[#1E293B] border border-[#22D3EE]/40 flex items-center justify-center font-bold text-white">
                                  {c.name.charAt(0).toUpperCase()}
                                </div>
                                <span
                                  className={`absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-[#0A0C10] ${st.dot}`}
                                  title={st.label}
                                />
                              </div>
                              <div>
                                <h4 className="text-sm font-bold text-white">
                                  {c.name} {c.lastName}
                                </h4>
                                <span className={`text-[10px] font-semibold ${st.text}`}>
                                  {st.icon} {st.label}
                                </span>
                              </div>
                            </div>

                            {/* Relationship Level Badge */}
                            <span
                              style={{ borderColor: c.relationshipLevelColor || '#22D3EE' }}
                              className="flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold bg-[#1E293B] text-slate-200"
                            >
                              <span>{c.relationshipLevelIcon || '✨'}</span>
                              <span>{c.relationshipLevelName}</span>
                            </span>
                          </div>

                          {/* Current Group Info */}
                          <div className="flex items-center justify-between rounded-xl bg-[#0F172A] px-3 py-2 border border-[#1E293B] text-xs mb-3">
                            <span className="text-slate-400 font-medium text-[11px]">Grupo atual:</span>
                            <span className="font-bold text-[#22D3EE]">{c.groupName || 'Geral'}</span>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 pt-2 border-t border-[#1E293B]">
                          <button
                            onClick={() => {
                              setMovingContact(c);
                              setTargetMoveGroupId(c.groupId);
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 rounded-xl border border-[#22D3EE]/30 bg-[#1E293B] py-1.5 text-xs font-semibold text-[#22D3EE] hover:bg-[#334155] transition"
                            title="Mover para outro grupo de contatos"
                          >
                            <ArrowRightLeft className="h-3.5 w-3.5" />
                            <span>Mover de Grupo</span>
                          </button>

                          <button
                            onClick={() => handleDeleteContact(c.id, c.name)}
                            className="rounded-xl border border-[#1E293B] bg-[#1E293B] p-2 text-slate-400 hover:border-rose-500/40 hover:bg-rose-500/10 hover:text-rose-400 transition"
                            title="Remover contato"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Requests (Incoming & Outgoing) */}
        {activeTab === 'requests' && (
          <div className="flex-1 flex flex-col p-6 overflow-y-auto space-y-6">
            {/* Incoming Requests */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Solicitações Recebidas ({incomingRequests.length})
                  </h3>
                  <span className="text-xs text-slate-400">
                    (Regra: Você pode aceitar, recusar ou deixar sem resposta)
                  </span>
                </div>
              </div>

              {incomingRequests.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-[#1E293B] p-6 text-center text-slate-500 text-xs">
                  Nenhuma solicitação de amizade recebida no momento.
                </div>
              ) : (
                <div className="space-y-3">
                  {incomingRequests.map((req) => {
                    const isPending = req.status === 'pending';
                    const st = statusMeta[(req.senderStatus as UserStatus) || 'online'];

                    return (
                      <div
                        key={req.id}
                        className={`flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-2xl border p-4 transition ${
                          isPending
                            ? 'border-[#22D3EE]/40 bg-[#0A0C10]'
                            : 'border-[#1E293B] bg-[#0A0C10]/50 opacity-70'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className="relative">
                            <div className="h-11 w-11 rounded-full bg-[#1E293B] border border-[#22D3EE]/40 flex items-center justify-center font-bold text-white">
                              {req.senderName.charAt(0).toUpperCase()}
                            </div>
                            <span
                              className={`absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-[#0A0C10] ${st.dot}`}
                              title={st.label}
                            />
                          </div>

                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className="text-sm font-bold text-white">
                                {req.senderName} {req.senderLastName}
                              </h4>
                              <span className={`text-[10px] font-semibold ${st.text}`}>
                                ({st.icon} {st.label})
                              </span>
                              <span
                                style={{ borderColor: req.relationshipLevelColor || '#22D3EE' }}
                                className="flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold bg-[#1E293B] text-slate-200"
                              >
                                <span>{req.relationshipLevelIcon || '❤️'}</span>
                                <span>Nível: {req.relationshipLevelName}</span>
                              </span>
                            </div>

                            {req.message && (
                              <p className="text-xs text-slate-300 italic mt-1 bg-[#0F172A] p-2 rounded-xl border border-[#1E293B]/60">
                                "{req.message}"
                              </p>
                            )}

                            <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                              <span>
                                Grupo sugerido pelo remetente: <strong className="text-slate-300">{req.senderGroupName}</strong>
                              </span>
                              <span>•</span>
                              <span>{new Date(req.createdAt).toLocaleDateString('pt-BR')}</span>
                            </div>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                          {isPending ? (
                            <>
                              <button
                                onClick={() => {
                                  setAcceptingRequest(req);
                                  if (groups.length > 0) setAcceptGroupChoice(groups[0].id);
                                }}
                                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 px-4 py-2 text-xs font-black text-black shadow-md hover:brightness-110 transition"
                              >
                                <Check className="h-3.5 w-3.5" />
                                <span>Aceitar</span>
                              </button>

                              <button
                                onClick={() => handleRespondRequest(req.id, 'reject')}
                                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 rounded-xl border border-rose-500/40 bg-rose-500/10 px-3.5 py-2 text-xs font-bold text-rose-300 hover:bg-rose-500/20 transition"
                              >
                                <X className="h-3.5 w-3.5" />
                                <span>Recusar</span>
                              </button>

                              <span className="hidden sm:inline text-[10px] text-slate-500 italic pl-1">
                                (ou deixe sem resposta)
                              </span>
                            </>
                          ) : (
                            <span
                              className={`rounded-xl px-3 py-1.5 text-xs font-bold ${
                                req.status === 'accepted'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                              }`}
                            >
                              {req.status === 'accepted' ? '✓ Aceito' : '✕ Recusado'}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Outgoing Requests */}
            <div className="pt-4 border-t border-[#1E293B]">
              <h3 className="text-sm font-black text-white uppercase tracking-wider mb-3">
                Solicitações Enviadas por Você ({outgoingRequests.length})
              </h3>

              {outgoingRequests.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-[#1E293B] p-4 text-center text-slate-500 text-xs">
                  Nenhuma solicitação enviada até o momento.
                </div>
              ) : (
                <div className="space-y-2">
                  {outgoingRequests.map((req) => (
                    <div
                      key={req.id}
                      className="flex items-center justify-between rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3.5 text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="h-8 w-8 rounded-full bg-[#1E293B] border border-slate-700 flex items-center justify-center font-bold text-slate-300">
                          {req.receiverName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-white">
                            Para: {req.receiverName} {req.receiverLastName}
                          </p>
                          <p className="text-[11px] text-slate-400">
                            Nível: {req.relationshipLevelName} ({req.relationshipLevelIcon}) • Grupo:{' '}
                            {req.senderGroupName}
                          </p>
                        </div>
                      </div>

                      <div>
                        {req.status === 'pending' ? (
                          <span className="flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-0.5 text-[10px] font-bold text-amber-400">
                            <Clock className="h-3 w-3" /> Aguardando Resposta
                          </span>
                        ) : req.status === 'accepted' ? (
                          <span className="flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-bold text-emerald-400">
                            <Check className="h-3 w-3" /> Aceito
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 rounded-full border border-rose-500/30 bg-rose-500/10 px-2.5 py-0.5 text-[10px] font-bold text-rose-400">
                            <X className="h-3 w-3" /> Recusado
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Modal: Solicitar Amizade */}
        {targetUserForRequest && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="w-full max-w-lg rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
              <div className="flex items-center justify-between border-b border-[#1E293B] pb-4 mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#22D3EE]/20 border border-[#22D3EE]/40 text-[#22D3EE] font-bold">
                    <UserPlus className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Solicitar Amizade</h3>
                    <p className="text-xs text-slate-400">
                      Para: <strong className="text-white">{targetUserForRequest.name} {targetUserForRequest.lastName}</strong>
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setTargetUserForRequest(null)}
                  className="rounded-lg p-1.5 text-slate-400 hover:bg-[#1E293B] hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleSendRequest} className="space-y-4 text-xs">
                {/* 1. Escolha o Nível de Relacionamento (Configurado no Admin) */}
                <div>
                  <label className="block font-bold text-slate-300 mb-1.5">
                    1. Selecione o Nível de Relacionamento:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                    {relationshipLevels.map((lvl) => {
                      const isSelected = selectedRelLevelId === lvl.id;
                      return (
                        <button
                          key={lvl.id}
                          type="button"
                          onClick={() => setSelectedRelLevelId(lvl.id)}
                          className={`flex items-start gap-2 rounded-xl border p-2.5 text-left transition ${
                            isSelected
                              ? 'border-[#22D3EE] bg-[#22D3EE]/10'
                              : 'border-[#1E293B] bg-[#0A0C10] hover:border-slate-600'
                          }`}
                        >
                          <span className="text-xl shrink-0">{lvl.icon}</span>
                          <div>
                            <p className="font-bold text-white leading-tight">{lvl.name}</p>
                            <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                              {lvl.description}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Escolha o Grupo onde este contato ficará salvo se aceitar */}
                <div>
                  <label className="block font-bold text-slate-300 mb-1.5">
                    2. Escolha em qual dos seus grupos deseja incluí-lo(a) quando aceitar:
                  </label>
                  <select
                    value={selectedSenderGroupId}
                    onChange={(e) => setSelectedSenderGroupId(e.target.value)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-xs text-white focus:border-[#22D3EE] focus:outline-none"
                  >
                    {groups.map((grp) => (
                      <option key={grp.id} value={grp.id}>
                        {grp.icon} {grp.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 3. Mensagem Personalizada */}
                <div>
                  <label className="block font-bold text-slate-300 mb-1.5">
                    3. Mensagem de Apresentação (opcional):
                  </label>
                  <textarea
                    rows={2}
                    value={requestMessage}
                    onChange={(e) => setRequestMessage(e.target.value)}
                    placeholder="Ex: Olá! Adorei bater papo com você na sala de paquera, vamos manter contato!"
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] p-3 text-xs text-white placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1E293B]">
                  <button
                    type="button"
                    onClick={() => setTargetUserForRequest(null)}
                    className="rounded-xl border border-[#1E293B] bg-[#1E293B] px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    disabled={sendingRequest}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-2 text-xs font-black text-black shadow-md hover:brightness-110 disabled:opacity-50 transition"
                  >
                    {sendingRequest ? 'Enviando...' : 'Enviar Solicitação de Amizade'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal: Aceitar Solicitação (Escolher Grupo de Destino do Usuário) */}
        {acceptingRequest && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="w-full max-w-md rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
              <div className="flex items-center justify-between border-b border-[#1E293B] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-400 font-bold">
                    <Check className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Aceitar Pedido de Amizade</h3>
                    <p className="text-xs text-slate-400">
                      De: {acceptingRequest.senderName} {acceptingRequest.senderLastName}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setAcceptingRequest(null)}
                  className="rounded-lg p-1 text-slate-400 hover:bg-[#1E293B]"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <p className="text-xs text-slate-300 mb-4">
                Conforme as regras do sistema, você também pode escolher em qual dos seus grupos
                incluir <strong>{acceptingRequest.senderName}</strong>:
              </p>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Escolha seu Grupo de Destino:
                  </label>
                  <select
                    value={acceptGroupChoice}
                    onChange={(e) => setAcceptGroupChoice(e.target.value)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-xs text-white focus:border-[#22D3EE] focus:outline-none"
                  >
                    {groups.map((grp) => (
                      <option key={grp.id} value={grp.id}>
                        {grp.icon} {grp.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setAcceptingRequest(null)}
                    className="rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRespondRequest(acceptingRequest.id, 'accept', acceptGroupChoice)}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 px-5 py-2 text-xs font-black text-black shadow-md hover:brightness-110"
                  >
                    <Check className="h-4 w-4" />
                    <span>Confirmar e Adicionar</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Mover Contato de Grupo */}
        {movingContact && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="w-full max-w-md rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
              <div className="flex items-center justify-between border-b border-[#1E293B] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <ArrowRightLeft className="h-5 w-5 text-[#22D3EE]" />
                  <h3 className="text-sm font-bold text-white">Mover Contato para Outro Grupo</h3>
                </div>
                <button
                  onClick={() => setMovingContact(null)}
                  className="rounded-lg p-1 text-slate-400 hover:bg-[#1E293B]"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <p className="text-xs text-slate-300 mb-3">
                Mover <strong>{movingContact.name} {movingContact.lastName}</strong> (Grupo atual:{' '}
                <span className="text-[#22D3EE]">{movingContact.groupName}</span>) para:
              </p>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Selecione o Novo Grupo:
                  </label>
                  <select
                    value={targetMoveGroupId}
                    onChange={(e) => setTargetMoveGroupId(e.target.value)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-xs text-white focus:border-[#22D3EE] focus:outline-none"
                  >
                    {groups.map((grp) => (
                      <option key={grp.id} value={grp.id}>
                        {grp.icon} {grp.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setMovingContact(null)}
                    className="rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleMoveContact}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-2 text-xs font-black text-black shadow-md hover:brightness-110"
                  >
                    <Check className="h-4 w-4" />
                    <span>Salvar Novo Grupo</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Criar Novo Grupo de Contatos */}
        {showCreateGroup && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="w-full max-w-md rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
              <div className="flex items-center justify-between border-b border-[#1E293B] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <FolderPlus className="h-5 w-5 text-[#22D3EE]" />
                  <h3 className="text-sm font-bold text-white">Criar Novo Grupo de Contatos</h3>
                </div>
                <button
                  onClick={() => setShowCreateGroup(false)}
                  className="rounded-lg p-1 text-slate-400 hover:bg-[#1E293B]"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <form onSubmit={handleCreateGroup} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-300 mb-1">Nome do Grupo:</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Viagens & Passeios, Confrades, etc."
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-xs text-white focus:border-[#22D3EE] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-300 mb-1">Ícone / Emoji do Grupo:</label>
                  <div className="flex items-center gap-2">
                    {['📁', '⭐', '❤️', '☕', '💼', '🏖️', '🎮', '🍕', '🚀', '💬'].map((ic) => (
                      <button
                        key={ic}
                        type="button"
                        onClick={() => setNewGroupIcon(ic)}
                        className={`h-9 w-9 rounded-xl border text-base transition ${
                          newGroupIcon === ic
                            ? 'border-[#22D3EE] bg-[#22D3EE]/20'
                            : 'border-[#1E293B] bg-[#0A0C10]'
                        }`}
                      >
                        {ic}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1E293B]">
                  <button
                    type="button"
                    onClick={() => setShowCreateGroup(false)}
                    className="rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-5 py-2 text-xs font-black text-black shadow-md hover:brightness-110"
                  >
                    <Check className="h-4 w-4" />
                    <span>Criar Grupo</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
