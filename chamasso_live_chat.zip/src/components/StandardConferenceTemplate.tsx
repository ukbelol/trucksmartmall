import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  Hand,
  MessageSquare,
  Users,
  Shield,
  Crown,
  Send,
  X,
  Radio,
  Eye,
  Sparkles,
  ArrowRight,
  UserCheck,
  CheckCircle2,
  Clock,
  HelpCircle,
  ExternalLink,
  Lock,
} from 'lucide-react';
import type {
  Room,
  User,
  RoomParticipant,
  StandardConferenceData,
  SpeakerQueueItem,
  HandRaiseQueueItem,
  MatrixSubRoom,
  DirectPrivateMessage,
} from '../types.ts';
import { getUserDisplayName } from '../utils/nickname.ts';

interface StandardConferenceTemplateProps {
  room: Room;
  currentUser: User;
  isModerator: boolean;
  onLeaveRoom: () => void;
  onOpenLiveModal?: () => void;
  onOpenFriendshipModal?: (target: { id: string; name: string }) => void;
  hasCredits?: boolean;
  onOpenRecharge?: () => void;
}

export const StandardConferenceTemplate: React.FC<StandardConferenceTemplateProps> = ({
  room,
  currentUser,
  isModerator,
  onLeaveRoom,
  onOpenLiveModal,
  onOpenFriendshipModal,
  hasCredits = true,
  onOpenRecharge,
}) => {
  // Estado geral recebido do servidor
  const [conferenceData, setConferenceData] = useState<StandardConferenceData | null>(null);
  const [loading, setLoading] = useState(true);

  // Sala atualmente visualizada no mosaico (padrão Sala 1 Matriz)
  const [selectedRoomNumber, setSelectedRoomNumber] = useState<number>(1);

  // Controles de mídia do usuário local (Câmera 15)
  const [localAudioMuted, setLocalAudioMuted] = useState(false);
  const [localVideoOff, setLocalVideoOff] = useState(false);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  // Modal de mensagem de texto / conversa privada com participante
  const [privateChatTarget, setPrivateChatTarget] = useState<RoomParticipant | null>(null);
  const [privateMessageText, setPrivateMessageText] = useState('');
  const [privateMessages, setPrivateMessages] = useState<DirectPrivateMessage[]>([]);
  const [privateSuccessToast, setPrivateSuccessToast] = useState<string | null>(null);

  // Solicitação de conversa privada modal
  const [privateCallModal, setPrivateCallModal] = useState<{
    target: RoomParticipant;
    status: 'calling' | 'connected' | 'rejected';
  } | null>(null);

  // Busca estado da conferência padrão
  const fetchConferenceState = async () => {
    try {
      const q = new URLSearchParams({
        userId: currentUser.id,
        userName: `${currentUser.name} ${currentUser.lastName}`.trim(),
        userNickname: currentUser.nickname || '',
        userAvatar: currentUser.avatarUrl || '',
        isModerator: String(isModerator),
      });
      const res = await fetch(`/api/standard-conference/${room.id}?${q.toString()}`);
      if (res.ok) {
        const data: StandardConferenceData = await res.json();
        setConferenceData(data);
      }
    } catch (err) {
      console.error('Erro ao buscar estado da conferência padrão:', err);
    } finally {
      setLoading(false);
    }
  };

  // Carrega mensagens privadas
  const fetchPrivateMessages = async () => {
    try {
      const res = await fetch(`/api/standard-conference/${room.id}/private-messages?userId=${currentUser.id}`);
      if (res.ok) {
        const msgs = await res.json();
        setPrivateMessages(msgs);
      }
    } catch (err) {
      console.error('Erro ao buscar mensagens privadas:', err);
    }
  };

  useEffect(() => {
    fetchConferenceState();
    fetchPrivateMessages();
    const interval = setInterval(() => {
      fetchConferenceState();
      fetchPrivateMessages();
    }, 3000);
    return () => clearInterval(interval);
  }, [room.id, currentUser.id]);

  // Inicializa webcam local para Câmera 15 Fixa
  useEffect(() => {
    let stream: MediaStream | null = null;
    navigator.mediaDevices
      ?.getUserMedia({ video: true, audio: true })
      .then((s) => {
        stream = s;
        localStreamRef.current = s;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = s;
        }
      })
      .catch((err) => {
        console.warn('Permissão de câmera local não concedida ou indisponível:', err);
      });

    return () => {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  // Toggle de mídia local
  const handleToggleLocalAudio = () => {
    if (!hasCredits) {
      alert('Saldo insuficiente para ativar o microfone. Recarregue seus créditos para transmitir áudio.');
      onOpenRecharge?.();
      return;
    }
    const nextState = !localAudioMuted;
    setLocalAudioMuted(nextState);
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((t) => {
        t.enabled = !nextState;
      });
    }
  };

  const handleToggleLocalVideo = () => {
    if (!hasCredits) {
      alert('Saldo insuficiente para ativar a câmera. Recarregue seus créditos para transmitir vídeo.');
      onOpenRecharge?.();
      return;
    }
    const nextState = !localVideoOff;
    setLocalVideoOff(nextState);
    if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach((t) => {
        t.enabled = !nextState;
      });
    }
  };

  // Ação W1: Entrar / Sair da Fila do Palestrante (Fl_01 a Fl_14)
  const handleToggleSpeakerQueue = async () => {
    if (!hasCredits) {
      alert('Saldo insuficiente para entrar na fila do palestrante. Recarregue seus créditos para falar.');
      onOpenRecharge?.();
      return;
    }
    try {
      const res = await fetch(`/api/standard-conference/${room.id}/speaker-queue`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          name: `${currentUser.name} ${currentUser.lastName}`.trim(),
          nickname: currentUser.nickname,
          avatarUrl: currentUser.avatarUrl,
        }),
      });
      if (res.ok) {
        await fetchConferenceState();
      }
    } catch (err) {
      console.error('Erro ao atualizar fila de palestrante:', err);
    }
  };

  // Ação X1: Levantar a Mão / Pedir a Palavra (com regras de cores: >=3 vermelho, 2 amarelo, 1 verde)
  const handleToggleHandRaise = async () => {
    if (!hasCredits) {
      alert('Saldo insuficiente para pedir a palavra. Recarregue seus créditos para interagir.');
      onOpenRecharge?.();
      return;
    }
    try {
      const res = await fetch(`/api/standard-conference/${room.id}/hand-raise`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          name: `${currentUser.name} ${currentUser.lastName}`.trim(),
          nickname: currentUser.nickname,
          avatarUrl: currentUser.avatarUrl,
        }),
      });
      if (res.ok) {
        await fetchConferenceState();
      }
    } catch (err) {
      console.error('Erro ao alternar mão levantada:', err);
    }
  };

  // Ação do Moderador: Passar a palavra para o próximo palestrante da fila
  const handlePromoteSpeaker = async (targetUserId?: string) => {
    try {
      const res = await fetch(`/api/standard-conference/${room.id}/promote-speaker`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nextUserId: targetUserId }),
      });
      if (res.ok) {
        await fetchConferenceState();
      }
    } catch (err) {
      console.error('Erro ao promover palestrante:', err);
    }
  };

  // Envio de mensagem privada para participante
  const handleSendPrivateMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!privateChatTarget || !privateMessageText.trim()) return;

    if (!hasCredits) {
      alert('Você está no modo somente visualização. Recarregue seus créditos para enviar mensagens privadas.');
      onOpenRecharge?.();
      return;
    }

    try {
      const res = await fetch(`/api/standard-conference/${room.id}/private-message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderId: currentUser.id,
          senderName: `${currentUser.name} ${currentUser.lastName}`.trim(),
          senderNickname: currentUser.nickname,
          senderAvatar: currentUser.avatarUrl,
          senderRoomNumber: selectedRoomNumber,
          receiverId: privateChatTarget.userId,
          receiverName: privateChatTarget.name,
          text: privateMessageText.trim(),
        }),
      });
      if (res.ok) {
        setPrivateMessageText('');
        setPrivateSuccessToast(`Mensagem privada enviada com sucesso para ${privateChatTarget.name}!`);
        setTimeout(() => setPrivateSuccessToast(null), 4000);
        await fetchPrivateMessages();
      }
    } catch (err) {
      console.error('Erro ao enviar mensagem privada:', err);
    }
  };

  // Dados calculados
  const mySpeakerQueueItem = conferenceData?.speakerQueue?.find((item) => item.userId === currentUser.id);
  const myHandRaiseItem = conferenceData?.handRaiseQueue?.find((item) => item.userId === currentUser.id);
  const handPosition = myHandRaiseItem?.position ?? null;

  // Cor do botão X1 conforme regra:
  // >= 3: Vermelho
  // == 2: Amarelo
  // == 1: Verde
  // não levantado: Estilo padrão
  let handButtonBg = 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700';
  let handButtonLabel = 'Pedir a Palavra (Comentar)';
  let handBadgeColor = '';

  if (handPosition !== null) {
    if (handPosition === 1) {
      handButtonBg = 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400 animate-pulse shadow-lg shadow-emerald-600/40 ring-2 ring-emerald-400';
      handButtonLabel = '1º na Fila - Sua vez de falar!';
      handBadgeColor = 'bg-emerald-400 text-emerald-950 font-black';
    } else if (handPosition === 2) {
      handButtonBg = 'bg-amber-500 hover:bg-amber-400 text-black border-amber-300 font-bold shadow-lg shadow-amber-500/40 ring-2 ring-amber-300';
      handButtonLabel = '2º na Fila - Prepare-se!';
      handBadgeColor = 'bg-amber-300 text-amber-950 font-black';
    } else {
      handButtonBg = 'bg-red-600 hover:bg-red-500 text-white border-red-400 font-bold shadow-lg shadow-red-600/40 ring-2 ring-red-400';
      handButtonLabel = `${handPosition}º na Fila - Aguarde`;
      handBadgeColor = 'bg-red-400 text-red-950 font-black';
    }
  }

  // Participantes da sala selecionada (Sala 1 a 8)
  const currentSubRoom = conferenceData?.matrixRooms?.find(
    (r) => r.roomNumber === selectedRoomNumber
  ) || conferenceData?.matrixRooms?.[0];

  const participantsList = currentSubRoom?.participants || [];

  // Mapeamento de slots de 1 a 14 para o mosaico
  const cameraSlots = Array.from({ length: 14 }, (_, idx) => {
    const slotNumber = idx + 1;
    const participant = participantsList[idx] || null;
    const speakerQueueItemForSlot = conferenceData?.speakerQueue?.find((s) => s.slot === slotNumber);
    return {
      slotNumber,
      participant,
      speakerQueueItemForSlot,
    };
  });

  return (
    <div className="flex flex-col h-screen w-full bg-slate-950 text-slate-100 font-sans overflow-hidden select-none">
      {/* ========================================================================= */}
      {/* TOPO: BARRA DE NAVEGAÇÃO & LINHA 1 DA TABELA (FL_01 A FL_14 + BOTÃO W1 + X1) */}
      {/* ========================================================================= */}
      <header className="bg-slate-900 border-b border-slate-800 p-2 sm:px-4 flex flex-col gap-2 z-20 shadow-md">
        {/* Header superior: Título e Status Geral */}
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-500 via-sky-500 to-emerald-500 flex items-center justify-center font-black text-white shadow-md text-sm">
              M15
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-bold text-white tracking-wide flex items-center gap-2">
                  Template de Videoconferência Padrão
                  <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                    Matriz 15 + Palestrante
                  </span>
                </h1>
              </div>
              <p className="text-xs text-slate-400">
                Visualizando: <strong className="text-sky-400">{currentSubRoom?.name || 'Sala 1 (Matriz)'}</strong> • Palestrante Central transmitido para todas as 7 salas filhas
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenLiveModal && (
              <button
                onClick={onOpenLiveModal}
                className="px-3 py-1.5 rounded-md bg-rose-600/90 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                title="Abrir Transmissão Ao Vivo Pop-up"
              >
                <Radio className="w-3.5 h-3.5 text-rose-200 animate-pulse" />
                Live Pop-up
              </button>
            )}
            <button
              onClick={onLeaveRoom}
              className="px-3 py-1.5 rounded-md bg-slate-800 hover:bg-red-700/80 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-colors"
            >
              Sair da Sala
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* LINHA 1 DA TABELA: FILA DO PALESTRANTE FL_01 A FL_14 + BOTÃO W1 + BOTÃO X1 */}
        {/* ========================================================================= */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-2 flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-3 overflow-x-auto">
          {/* Rótulo da Fila Fl_01 a Fl_14 */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-400 px-2 py-1 bg-slate-900 border border-slate-800 rounded">
              Fila Palestrante:
            </span>
          </div>

          {/* Slots Fl_01 a Fl_14 */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 xl:pb-0 scrollbar-thin scrollbar-thumb-slate-700">
            {Array.from({ length: 14 }).map((_, i) => {
              const slotNum = i + 1;
              const slotCode = `Fl_${slotNum < 10 ? '0' + slotNum : slotNum}`;
              const queueItem = conferenceData?.speakerQueue?.find((s) => s.slot === slotNum);
              const isMe = queueItem?.userId === currentUser.id;

              return (
                <div
                  key={slotCode}
                  className={`flex flex-col items-center justify-center w-14 sm:w-16 h-12 rounded border text-center transition-all flex-shrink-0 ${
                    queueItem
                      ? isMe
                        ? 'bg-indigo-950/80 border-indigo-400 text-indigo-200 shadow-sm shadow-indigo-500/30'
                        : 'bg-slate-900 border-sky-600/60 text-sky-200'
                      : 'bg-slate-900/40 border-slate-800/80 text-slate-500'
                  }`}
                  title={
                    queueItem
                      ? `${slotCode}: ${queueItem.name} (${queueItem.nickname || 'sem nick'}) - Vinculado à Câmera ${slotNum}`
                      : `${slotCode}: Posição livre para Câmera ${slotNum}`
                  }
                >
                  <span className="text-[10px] font-bold uppercase tracking-tighter">
                    {slotCode}
                  </span>
                  {queueItem ? (
                    <div className="flex items-center gap-1 mt-0.5 max-w-full px-1">
                      {queueItem.avatarUrl ? (
                        <img
                          src={queueItem.avatarUrl}
                          alt={queueItem.name}
                          className="w-3.5 h-3.5 rounded-full object-cover"
                        />
                      ) : (
                        <span className="w-3.5 h-3.5 rounded-full bg-sky-600 text-[8px] flex items-center justify-center text-white">
                          {queueItem.name.charAt(0)}
                        </span>
                      )}
                      <span className="text-[9px] font-semibold truncate max-w-[34px]">
                        {queueItem.nickname || queueItem.name.split(' ')[0]}
                      </span>
                    </div>
                  ) : (
                    <span className="text-[9px] text-slate-600 font-mono">Livre</span>
                  )}
                </div>
              );
            })}
          </div>

          {/* BOTÕES W1 E X1 DA LINHA 1 DA TABELA */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {/* BOTÃO W1: Entrar na fila para ser o palestrante da vez na Câmera 0 */}
            <button
              id="btn-w1-palestrante"
              onClick={handleToggleSpeakerQueue}
              className={`px-3 py-2 rounded-lg text-xs font-bold border transition-all flex items-center gap-1.5 shadow-sm ${
                mySpeakerQueueItem
                  ? 'bg-amber-600 hover:bg-amber-500 text-white border-amber-400 shadow-amber-600/30'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-400 shadow-indigo-600/30'
              }`}
              title="Posição W1: Solicitação de entrar na fila para ser o palestrante da vez na Câmera Posição 0 Palestrante"
            >
              <Crown className="w-3.5 h-3.5" />
              {mySpeakerQueueItem
                ? `Sair da Fila (${mySpeakerQueueItem.slot < 10 ? 'Fl_0' + mySpeakerQueueItem.slot : 'Fl_' + mySpeakerQueueItem.slot})`
                : 'Entrar na Fila Palestrante (W1)'}
            </button>

            {/* BOTÃO X1: Pedir a palavra / Levantar a mão com regras estritas de cores:
                >= 3: VERMELHO
                == 2: AMARELO
                == 1: VERDE */}
            <button
              id="btn-x1-levantar-mao"
              onClick={handleToggleHandRaise}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold border transition-all flex items-center gap-2 shadow-sm ${handButtonBg}`}
              title="Posição X1: Pedir a palavra para breve comentário. Verde = 1º (falará a seguir), Amarelo = 2º, Vermelho = 3º+"
            >
              <Hand className={`w-4 h-4 ${handPosition !== null ? 'animate-bounce' : ''}`} />
              <div className="flex flex-col text-left leading-tight">
                <span className="text-[11px] uppercase tracking-wider">{handButtonLabel}</span>
                {handPosition !== null && (
                  <span className="text-[9px] opacity-90">
                    Posição X1: {handPosition}º na fila
                  </span>
                )}
              </div>
            </button>

            {/* Ação do Moderador: Promover próximo palestrante */}
            {isModerator && (
              <button
                onClick={() => handlePromoteSpeaker()}
                className="px-2.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold border border-emerald-500 transition-colors flex items-center gap-1 shadow-sm"
                title="Moderador: Avança a fila e coloca o próximo participante na Câmera 0 Palestrante"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Passar a Vez</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Toast de sucesso de mensagem privada */}
      {privateSuccessToast && (
        <div className="bg-emerald-500 text-white text-xs px-4 py-2 font-medium flex items-center justify-between animate-fadeIn">
          <span>{privateSuccessToast}</span>
          <button onClick={() => setPrivateSuccessToast(null)} className="hover:opacity-80">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CORPO PRINCIPAL: CÂMERAS 0 E 15 (ESQUERDA) + MOSAICO 1 A 14 + SALAS (DIREITA) */}
      {/* ========================================================================= */}
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden p-2 sm:p-3 gap-2 sm:gap-3">
        {/* COLUNA ESQUERDA: CÂMERA 0 PALESTRANTE (TOPO) & CÂMERA 15 LOCAL FIXA (BAIXO) */}
        <section className="w-full lg:w-[320px] xl:w-[380px] 2xl:w-[420px] flex flex-col gap-2 sm:gap-3 flex-shrink-0 overflow-y-auto pr-1">
          {/* CÂMERA 0: TRANSMISSÃO CAMERA 0 PALESTRA (CAMERA PALESTRANTE DA VEZ) */}
          <div className="bg-slate-900 border-2 border-indigo-500/60 rounded-xl overflow-hidden flex flex-col shadow-lg shadow-indigo-950/40 relative">
            <div className="bg-indigo-950/90 px-3 py-1.5 border-b border-indigo-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                <span className="text-xs font-black text-indigo-100 uppercase tracking-wide">
                  Transmissão Câmera 0 Palestra
                </span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-900 text-indigo-200 font-mono font-bold">
                Ao Vivo P/ Todas as Salas
              </span>
            </div>

            {/* Tela de Vídeo / Transmissão da Câmera 0 */}
            <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden">
              {conferenceData?.currentSpeaker?.avatarUrl ? (
                <div className="relative w-full h-full">
                  <img
                    src={conferenceData.currentSpeaker.avatarUrl}
                    alt={conferenceData.currentSpeaker.name}
                    className="w-full h-full object-cover filter brightness-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center text-slate-400">
                  <Crown className="w-12 h-12 text-amber-400 mb-2 animate-bounce" />
                  <span className="text-xs font-bold">Câmera do Palestrante da Vez</span>
                </div>
              )}

              {/* Badges sobre o vídeo */}
              <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-2 py-1 rounded-md border border-white/10">
                <Radio className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                <span className="text-[11px] font-bold text-white">Palestrante da Vez</span>
              </div>

              {/* Ondas sonoras de fala ativa */}
              <div className="absolute top-2 right-2 flex items-center gap-1 bg-black/60 px-2 py-1 rounded-md border border-white/10">
                <div className="flex items-end gap-0.5 h-3">
                  <span className="w-1 bg-emerald-400 h-2 animate-pulse" />
                  <span className="w-1 bg-emerald-400 h-3 animate-pulse delay-75" />
                  <span className="w-1 bg-emerald-400 h-1.5 animate-pulse delay-150" />
                </div>
                <span className="text-[10px] text-emerald-300 font-semibold">Áudio e Vídeo</span>
              </div>

              {/* Rodapé da Câmera 0 */}
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-xs text-white bg-black/70 backdrop-blur-md p-2 rounded-lg border border-white/10">
                <div>
                  <h2 className="font-black text-sm text-indigo-200">
                    {conferenceData?.currentSpeaker?.name || 'Palestrante Oficial'}
                  </h2>
                  <p className="text-[11px] text-slate-300">
                    @{conferenceData?.currentSpeaker?.nickname || 'palestrante_oficial'} • Transmitindo para Salas 1 a 7
                  </p>
                </div>
                {isModerator && (
                  <button
                    onClick={() => handlePromoteSpeaker()}
                    className="px-2 py-1 rounded bg-amber-500 hover:bg-amber-400 text-black text-[11px] font-bold transition-colors"
                  >
                    Passar a Vez
                  </button>
                )}
              </div>
            </div>

            <div className="p-2 text-[11px] text-slate-400 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between">
              <span>Transmissão de áudio e vídeo centralizada</span>
              <span className="text-sky-400 font-bold">Sala Matriz 1</span>
            </div>
          </div>

          {/* CÂMERA 15 FIXA: TRANSMISSÃO MINHA CAMERA POSIÇÃO 15 (CAMERA LOCAL DO USUÁRIO) */}
          <div className="bg-slate-900 border-2 border-emerald-500/60 rounded-xl overflow-hidden flex flex-col shadow-lg shadow-emerald-950/40 relative">
            <div className="bg-emerald-950/90 px-3 py-1.5 border-b border-emerald-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-black text-emerald-100 uppercase tracking-wide">
                  Transmissão Minha Câmera Posição 15
                </span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-900 text-emerald-200 font-mono font-bold">
                Câmera Local Fixa
              </span>
            </div>

            {/* Janela de exibição da webcam do usuário */}
            <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden">
              <video
                ref={localVideoRef}
                autoPlay
                muted
                playsInline
                className={`w-full h-full object-cover transform -scale-x-100 ${
                  localVideoOff ? 'hidden' : 'block'
                }`}
              />
              {localVideoOff && (
                <div className="flex flex-col items-center justify-center text-slate-400">
                  <div className="w-14 h-14 rounded-full bg-slate-800 border-2 border-emerald-500 flex items-center justify-center text-xl font-bold text-white mb-2 shadow-inner">
                    {currentUser.name.charAt(0)}
                  </div>
                  <span className="text-xs font-semibold text-slate-300">Câmera desligada</span>
                </div>
              )}

              {/* Ordem de chegada do participante local */}
              <div className="absolute top-2 left-2 bg-black/70 backdrop-blur-md px-2 py-1 rounded border border-emerald-500/40 text-[10px] font-bold text-emerald-300 flex items-center gap-1">
                <Clock className="w-3 h-3 text-emerald-400" />
                <span>Ordem de chegada: #1 na Conferência</span>
              </div>

              {/* Indicador de Fila se estiver na fila */}
              {mySpeakerQueueItem && (
                <div className="absolute top-2 right-2 bg-amber-500/90 text-black px-2 py-0.5 rounded text-[10px] font-black shadow">
                  Fila: Fl_{mySpeakerQueueItem.slot < 10 ? '0' + mySpeakerQueueItem.slot : mySpeakerQueueItem.slot}
                </div>
              )}

              {/* Rodapé da Câmera 15 com Controles de Microfone e Câmera */}
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-xs text-white bg-black/75 backdrop-blur-md p-2 rounded-lg border border-white/10">
                <div>
                  <h3 className="font-black text-sm text-emerald-300 flex items-center gap-1">
                    {currentUser.name} {currentUser.lastName}
                    <span className="text-[10px] text-slate-400 font-normal">(Você)</span>
                  </h3>
                  <p className="text-[10px] text-slate-300">
                    {currentUser.nickname ? `@${currentUser.nickname}` : `${currentUser.name} ${currentUser.lastName}`} • Posição 15 Fixa
                  </p>
                </div>

                {/* Botões locais */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleToggleLocalAudio}
                    className={`p-1.5 rounded-md border transition-colors ${
                      localAudioMuted
                        ? 'bg-rose-600 border-rose-400 text-white'
                        : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                    }`}
                    title={localAudioMuted ? 'Ligar Microfone' : 'Silenciar Microfone'}
                  >
                    {localAudioMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-emerald-400" />}
                  </button>
                  <button
                    onClick={handleToggleLocalVideo}
                    className={`p-1.5 rounded-md border transition-colors ${
                      localVideoOff
                        ? 'bg-rose-600 border-rose-400 text-white'
                        : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                    }`}
                    title={localVideoOff ? 'Ligar Câmera' : 'Desligar Câmera'}
                  >
                    {localVideoOff ? <VideoOff className="w-3.5 h-3.5" /> : <Video className="w-3.5 h-3.5 text-emerald-400" />}
                  </button>
                </div>
              </div>
            </div>

            <div className="p-2 text-[11px] text-slate-400 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between">
              <span>Área de visualização da própria câmera local</span>
              <span className="text-emerald-400 font-bold">Fixa permanente</span>
            </div>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* CENTRO: MOSAICO DE CÂMERAS 1 A 14 (TROCA CONFORME A SALA SELECIONADA) */}
        {/* ========================================================================= */}
        <section className="flex-1 bg-slate-900/90 border border-slate-800 rounded-xl p-2 sm:p-3 flex flex-col shadow-inner overflow-hidden">
          {/* Header da Matriz Mosaico */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-slate-300">
                Mosaico de Transmissão da {currentSubRoom?.name}
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800 font-semibold">
                Câmeras 1 até 14 ({participantsList.length}/14 vagas ocupadas)
              </span>
            </div>
            <span className="text-[11px] text-slate-400">
              Clique em qualquer participante para <strong>conversa privada</strong> ou <strong>mensagem de texto</strong>
            </span>
          </div>

          {/* Grade 14 Câmeras Mosaico */}
          <div className="flex-1 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4 gap-2 overflow-y-auto pr-1">
            {cameraSlots.map(({ slotNumber, participant, speakerQueueItemForSlot }) => {
              // Verifica se o participante levantou a mão
              const handRaiseItem = conferenceData?.handRaiseQueue?.find(
                (h) => h.userId === participant?.userId
              );

              return (
                <div
                  key={`cam_${slotNumber}`}
                  className={`group relative rounded-lg border overflow-hidden flex flex-col justify-between transition-all aspect-video ${
                    participant
                      ? 'bg-slate-950 border-slate-800 hover:border-sky-500 shadow-md'
                      : 'bg-slate-950/40 border-dashed border-slate-800/80 items-center justify-center'
                  }`}
                >
                  {/* Topo do Card da Câmera */}
                  <div className="absolute top-1 left-1 right-1 z-10 flex items-center justify-between text-[10px]">
                    <span className="bg-black/80 px-1.5 py-0.5 rounded font-mono font-bold text-slate-300 border border-white/10">
                      Câmera {slotNumber}
                    </span>

                    {/* Mão levantada com cores dinâmicas: 1 = Verde, 2 = Amarelo, >=3 = Vermelho */}
                    {handRaiseItem && (
                      <span
                        className={`px-1.5 py-0.5 rounded font-black flex items-center gap-1 shadow-sm text-[10px] ${
                          handRaiseItem.position === 1
                            ? 'bg-emerald-500 text-black animate-bounce'
                            : handRaiseItem.position === 2
                            ? 'bg-amber-400 text-black'
                            : 'bg-red-600 text-white'
                        }`}
                        title={`Pediu a palavra: ${handRaiseItem.position}º lugar na fila`}
                      >
                        ✋ {handRaiseItem.position}º
                      </span>
                    )}
                  </div>

                  {/* Conteúdo do Participante ou Vaga */}
                  {participant ? (
                    <>
                      {/* Imagem / Vídeo do Participante */}
                      <div className="w-full h-full relative overflow-hidden bg-slate-900 flex items-center justify-center">
                        {participant.avatarUrl ? (
                          <img
                            src={participant.avatarUrl}
                            alt={participant.name}
                            className="w-full h-full object-cover filter brightness-90 group-hover:scale-105 transition-transform duration-300"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-lg font-bold text-slate-300">
                            {participant.name.charAt(0)}
                          </div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-80" />
                      </div>

                      {/* Informações do Rodapé */}
                      <div className="absolute bottom-1 left-1 right-1 z-10 flex items-center justify-between text-[11px]">
                        <div className="truncate max-w-[70%]">
                          <p className="font-bold text-white truncate drop-shadow">
                            {participant.name}
                          </p>
                        </div>
                        <div className="flex items-center gap-1">
                          {participant.isAudioMuted ? (
                            <MicOff className="w-3 h-3 text-rose-400" />
                          ) : (
                            <Mic className="w-3 h-3 text-emerald-400" />
                          )}
                        </div>
                      </div>

                      {/* Overlay com Ações de Contato (Conversa Privada e Mensagem de Texto) ao passar o mouse */}
                      <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1.5 p-2 z-20">
                        <span className="text-xs font-bold text-white text-center line-clamp-1">
                          {participant.name}
                        </span>
                        <div className="flex items-center gap-1.5 flex-wrap justify-center">
                          <button
                            onClick={() => {
                              setPrivateChatTarget(participant);
                            }}
                            className="px-2 py-1 rounded bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-bold flex items-center gap-1 shadow"
                            title="Mandar Mensagem de Texto Direta"
                          >
                            <MessageSquare className="w-3 h-3" />
                            Mensagem
                          </button>
                          <button
                            onClick={() => {
                              setPrivateCallModal({
                                target: participant,
                                status: 'calling',
                              });
                            }}
                            className="px-2 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold flex items-center gap-1 shadow"
                            title="Solicitar Conversa Privada 1-on-1"
                          >
                            <Lock className="w-3 h-3" />
                            Privado
                          </button>
                          {onOpenFriendshipModal && (
                            <button
                              onClick={() => onOpenFriendshipModal({ id: participant.userId, name: participant.name })}
                              className="px-2 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold flex items-center gap-1 shadow"
                              title="Solicitar Amizade"
                            >
                              <UserCheck className="w-3 h-3" />
                              Amigo
                            </button>
                          )}
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="p-2 text-center text-slate-600 flex flex-col items-center gap-1">
                      <span className="text-xs font-semibold">Transmissão Câmera Posição {slotNumber}</span>
                      <span className="text-[10px] text-slate-500 font-mono">Vaga disponível</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* ========================================================================= */}
        {/* COLUNA DIREITA: SELETOR DE SALAS (SALA 1 MATRIZ ATÉ SALA 7/8 FILHAS) */}
        {/* ========================================================================= */}
        <aside className="w-full lg:w-[220px] xl:w-[250px] bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col gap-2 flex-shrink-0">
          <div className="pb-2 border-b border-slate-800">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-sky-400" />
              Navegação de Salas
            </h2>
            <p className="text-[10px] text-slate-400 mt-0.5">
              15 membros por sala + Palestrante. Clique para visualizar o mosaico de outra sala.
            </p>
          </div>

          {/* Lista de Salas: Sala 1 Matriz até Sala 8 */}
          <div className="flex-1 flex flex-col gap-1.5 overflow-y-auto pr-0.5">
            {conferenceData?.matrixRooms?.map((subRoom) => {
              const isSelected = subRoom.roomNumber === selectedRoomNumber;
              const isMatrix = subRoom.isMatrix;

              return (
                <button
                  key={`subroom_${subRoom.roomNumber}`}
                  onClick={() => setSelectedRoomNumber(subRoom.roomNumber)}
                  className={`w-full p-2.5 rounded-lg text-left transition-all border flex flex-col gap-1 ${
                    isSelected
                      ? isMatrix
                        ? 'bg-indigo-950/90 border-indigo-400 text-white shadow-md shadow-indigo-950/50 ring-1 ring-indigo-400'
                        : 'bg-sky-950/90 border-sky-400 text-white shadow-md shadow-sky-950/50 ring-1 ring-sky-400'
                      : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/60 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black flex items-center gap-1.5">
                      {isMatrix && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                      {subRoom.name}
                    </span>
                    {isSelected && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-sky-500 text-black font-bold uppercase">
                        Vendo
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>
                      {isMatrix ? 'Sala Matriz (Moderador)' : `Sala Filha #${subRoom.roomNumber}`}
                    </span>
                    <span className="font-mono font-bold text-slate-300">
                      {subRoom.participantCount}/15
                    </span>
                  </div>

                  {/* Barra de lotação */}
                  <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${
                        isMatrix ? 'bg-indigo-500' : 'bg-sky-500'
                      }`}
                      style={{
                        width: `${Math.min(100, (subRoom.participantCount / 15) * 100)}%`,
                      }}
                    />
                  </div>
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 flex flex-col gap-1">
            <span className="flex items-center gap-1">
              <Shield className="w-3 h-3 text-indigo-400" />
              Moderador na Sala 1
            </span>
            <span className="text-[9px] text-slate-500">
              Salas filhas (2 a 7) assistem à Câmera 0 da Sala 1 e mantêm suas Câmeras 15 locais fixas.
            </span>
          </div>
        </aside>
      </main>

      {/* ========================================================================= */}
      {/* MODAL DE MENSAGEM PRIVADA DE TEXTO COM PARTICIPANTE DE QUALQUER SALA */}
      {/* ========================================================================= */}
      {privateChatTarget && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col">
            <div className="bg-slate-850 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-sky-400" />
                <h3 className="text-sm font-bold text-white">
                  Mensagem Privada para {privateChatTarget.name}
                </h3>
              </div>
              <button
                onClick={() => setPrivateChatTarget(null)}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 flex flex-col gap-3">
              <div className="flex items-center gap-3 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                {privateChatTarget.avatarUrl ? (
                  <img
                    src={privateChatTarget.avatarUrl}
                    alt={privateChatTarget.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-sky-700 flex items-center justify-center font-bold text-white">
                    {privateChatTarget.name.charAt(0)}
                  </div>
                )}
                <div>
                  <h4 className="text-xs font-bold text-white">{privateChatTarget.name}</h4>
                  <p className="text-[11px] text-slate-400">
                    Participante da {currentSubRoom?.name}
                  </p>
                </div>
              </div>

              {/* Histórico recente trocado com o participante */}
              <div className="max-h-36 overflow-y-auto flex flex-col gap-1.5 p-2 bg-slate-950 rounded-lg border border-slate-800 text-xs">
                {privateMessages
                  .filter(
                    (m) =>
                      (m.senderId === currentUser.id && m.receiverId === privateChatTarget.userId) ||
                      (m.senderId === privateChatTarget.userId && m.receiverId === currentUser.id)
                  )
                  .map((msg) => (
                    <div
                      key={msg.id}
                      className={`p-2 rounded-lg max-w-[85%] ${
                        msg.senderId === currentUser.id
                          ? 'bg-sky-600 text-white self-end'
                          : 'bg-slate-800 text-slate-200 self-start'
                      }`}
                    >
                      <p>{msg.text}</p>
                      <span className="text-[9px] opacity-75 block text-right">
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  ))}
                {privateMessages.filter(
                  (m) =>
                    (m.senderId === currentUser.id && m.receiverId === privateChatTarget.userId) ||
                    (m.senderId === privateChatTarget.userId && m.receiverId === currentUser.id)
                ).length === 0 && (
                  <p className="text-[11px] text-slate-500 text-center py-2">
                    Nenhuma mensagem anterior. Digite abaixo para iniciar a conversa privada.
                  </p>
                )}
              </div>

              {/* Form de Envio */}
              <form onSubmit={handleSendPrivateMessage} className="flex gap-2">
                <input
                  type="text"
                  value={privateMessageText}
                  onChange={(e) => setPrivateMessageText(e.target.value)}
                  placeholder={`Escreva mensagem para ${privateChatTarget.name}...`}
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                  autoFocus
                />
                <button
                  type="submit"
                  disabled={!privateMessageText.trim()}
                  className="px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1"
                >
                  <Send className="w-3.5 h-3.5" />
                  Enviar
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL DE SOLICITAÇÃO DE CONVERSA PRIVADA 1-ON-1 */}
      {/* ========================================================================= */}
      {privateCallModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-sm p-5 flex flex-col items-center text-center shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-indigo-950 border-2 border-indigo-500 flex items-center justify-center mb-3 text-indigo-300 animate-pulse">
              <Lock className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white mb-1">
              Conversa Privada 1-on-1
            </h3>
            <p className="text-xs text-slate-300 mb-4">
              Solicitando abertura de sala privativa exclusiva com{' '}
              <strong className="text-indigo-400">{privateCallModal.target.name}</strong>.
            </p>

            <div className="flex items-center gap-2 w-full">
              <button
                onClick={() => {
                  setPrivateCallModal(null);
                  setPrivateSuccessToast(`Convite de conversa privada enviado para ${privateCallModal.target.name}!`);
                  setTimeout(() => setPrivateSuccessToast(null), 4000);
                }}
                className="flex-1 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors"
              >
                Confirmar Solicitação
              </button>
              <button
                onClick={() => setPrivateCallModal(null)}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
