import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Music, Volume2 } from 'lucide-react';
import type { AudioAttachment } from '../types.ts';
import { formatFileSize } from '../utils/mediaEmbed.ts';

interface AudioPlayerProps {
  audio: AudioAttachment;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ audio }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const el = audioRef.current;
    if (!el) return;

    const onTimeUpdate = () => setCurrentTime(el.currentTime);
    const onLoadedMeta = () => setDuration(el.duration || 0);
    const onEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    el.addEventListener('timeupdate', onTimeUpdate);
    el.addEventListener('loadedmetadata', onLoadedMeta);
    el.addEventListener('ended', onEnded);

    return () => {
      el.removeEventListener('timeupdate', onTimeUpdate);
      el.removeEventListener('loadedmetadata', onLoadedMeta);
      el.removeEventListener('ended', onEnded);
    };
  }, []);

  const togglePlay = () => {
    const el = audioRef.current;
    if (!el) return;
    if (isPlaying) {
      el.pause();
      setIsPlaying(false);
    } else {
      el.play();
      setIsPlaying(true);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setCurrentTime(val);
    if (audioRef.current) {
      audioRef.current.currentTime = val;
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="my-2 flex flex-col gap-2 rounded-2xl border border-[#22D3EE]/30 bg-[#0F172A] p-3 text-slate-200 shadow-md">
      <audio ref={audioRef} src={audio.url} preload="metadata" />

      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-[#22D3EE]/20 text-[#22D3EE]">
            <Music className="h-4 w-4" />
          </div>
          <div className="truncate">
            <p className="text-xs font-bold text-white truncate">{audio.name}</p>
            <p className="text-[10px] text-slate-400">
              Formato: <span className="font-bold uppercase text-[#22D3EE]">{audio.format}</span> •{' '}
              {formatFileSize(audio.size)}
            </p>
          </div>
        </div>

        <button
          onClick={togglePlay}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black shadow-md shadow-[#22D3EE]/20 hover:brightness-110 active:scale-95 transition"
        >
          {isPlaying ? <Pause className="h-4 w-4 fill-current" /> : <Play className="h-4 w-4 fill-current ml-0.5" />}
        </button>
      </div>

      {/* Barra de progresso */}
      <div className="flex items-center gap-2 pt-1">
        <span className="font-mono text-[10px] text-slate-400 w-8">{formatTime(currentTime)}</span>
        <input
          type="range"
          min={0}
          max={duration || 100}
          step={0.1}
          value={currentTime}
          onChange={handleSeek}
          className="h-1.5 flex-1 cursor-pointer appearance-none rounded-lg bg-[#1E293B] accent-[#22D3EE]"
        />
        <span className="font-mono text-[10px] text-slate-400 w-8 text-right">{formatTime(duration)}</span>
      </div>
    </div>
  );
};
