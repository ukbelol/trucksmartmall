import React, { useState } from 'react';
import { Lock, Heart, Users, ShieldCheck, LogOut, PlusCircle, KeyRound, Sparkles, ChevronDown, Film, Radio, User as UserIcon, CreditCard } from 'lucide-react';
import type { User, UserStatus } from '../types.ts';

interface NavbarProps {
  currentUser: User | null;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onLogout: () => void;
  onOpenCreateRoom: () => void;
  onOpenAdmin: () => void;
  onOpenMyCodes: () => void;
  onOpenFriendships?: () => void;
  pendingRequestsCount?: number;
  onStatusChange?: (newStatus: UserStatus) => void;
  currentView: 'lobby' | 'room' | 'admin';
  onNavigateLobby: () => void;
  onOpenIntro?: () => void;
  onOpenNicknameModal?: () => void;
  onOpenLiveModal?: () => void;
  onOpenRecharge?: () => void;
  onOpenSocialProfile?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onOpenLogin,
  onOpenRegister,
  onLogout,
  onOpenCreateRoom,
  onOpenAdmin,
  onOpenMyCodes,
  onOpenFriendships,
  pendingRequestsCount = 0,
  onStatusChange,
  currentView = 'lobby',
  onNavigateLobby,
  onOpenIntro,
  onOpenNicknameModal,
  onOpenLiveModal,
  onOpenRecharge,
  onOpenSocialProfile,
}) => {
  const [showStatusMenu, setShowStatusMenu] = useState(false);

  const statusOptions: { id: UserStatus; label: string; icon: string; dot: string }[] = [
    { id: 'online', label: 'Online', icon: '🟢', dot: 'bg-emerald-400' },
    { id: 'ocupado', label: 'Ocupado', icon: '🔴', dot: 'bg-rose-500' },
    { id: 'em_almoco', label: 'Em Horário de Almoço', icon: '🍔', dot: 'bg-amber-400' },
    { id: 'ausente', label: 'Ausente', icon: '🟡', dot: 'bg-yellow-400' },
    { id: 'invisivel', label: 'Invisível (Offline)', icon: '⚪', dot: 'bg-slate-400' },
  ];

  const currentStatusObj =
    statusOptions.find((s) => s.id === currentUser?.status) || statusOptions[0];

  const handleSelectStatus = async (st: UserStatus) => {
    setShowStatusMenu(false);
    if (!currentUser) return;
    try {
      await fetch(`/api/users/${currentUser.id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: st }),
      });
      onStatusChange?.(st);
    } catch (err) {
      console.error('Erro ao alterar status:', err);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#1E293B] bg-[#0F172A] shadow-lg shadow-black/40">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2.5 sm:px-8">
        {/* Brand */}
        <div className="flex items-center gap-4">
          <a
            href="/app"
            onClick={(e) => {
              e.preventDefault();
              onNavigateLobby();
            }}
            className="group flex items-center gap-3 text-left focus:outline-none cursor-pointer"
            title="Lobby de Salas - chamasso live chat"
          >
            <div className="relative w-11 h-11 rounded-2xl overflow-hidden border-2 border-[#22D3EE]/50 shadow-[0_0_20px_rgba(34,211,238,0.45)] transition-all duration-300 group-hover:scale-105 group-hover:border-[#F472B6] shrink-0 bg-[#0A0C10]">
              <img
                src="/fenix_chamas.gif"
                alt="chamasso live chat"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-black tracking-tighter italic uppercase text-transparent bg-clip-text bg-gradient-to-r from-[#22D3EE] to-[#F472B6]">
                  CHAMASSO LIVE CHAT
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium tracking-wide hidden sm:block">
                Paquera & Amizade ao Vivo • Transmissões em Alta Qualidade
              </p>
            </div>
          </a>
        </div>

        {/* Server & Domain Indicator */}
        <div className="hidden xl:flex items-center gap-2.5 rounded-full border border-[#1E293B] bg-[#1E293B]/60 px-3.5 py-1 text-xs text-slate-300">
          <div className="w-2 h-2 bg-[#22D3EE] rounded-full animate-pulse" />
          <span className="font-mono text-[#22D3EE] font-medium">chamasso.pasquared.space</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">Debian 12 + Apache 2.4</span>
        </div>

        {/* Actions & User profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {currentUser ? (
            <>
              {currentView !== 'lobby' && onNavigateLobby && (
                <button
                  onClick={onNavigateLobby}
                  className="rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-1.5 text-xs font-semibold text-[#E2E8F0] hover:bg-[#334155] hover:text-white transition"
                >
                  Ver Salas
                </button>
              )}

              {onOpenCreateRoom && (
                <button
                  onClick={onOpenCreateRoom}
                  className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-3 sm:px-3.5 py-1.5 text-xs font-extrabold text-black shadow-md shadow-[#22D3EE]/20 hover:brightness-110 active:scale-95 transition"
                >
                  <PlusCircle className="h-3.5 w-3.5 text-black" />
                  <span className="hidden sm:inline">Criar Sala</span>
                </button>
              )}

              {/* Botão Live Câmera ao Vivo */}
              {onOpenLiveModal && (
                <button
                  onClick={onOpenLiveModal}
                  className="flex items-center gap-1.5 rounded-xl border border-rose-500/40 bg-rose-950/40 px-3 py-1.5 text-xs font-black text-rose-300 shadow-md hover:bg-rose-900/60 active:scale-95 transition"
                  title="Abrir Transmissão de Câmera ao Vivo (Pop-up)"
                >
                  <Radio className="h-3.5 w-3.5 text-rose-400 animate-pulse" />
                  <span className="hidden sm:inline">Live Câmera</span>
                </button>
              )}

              {/* Botão Gerenciar Nickname */}
              {onOpenNicknameModal && (
                <button
                  onClick={onOpenNicknameModal}
                  className="flex items-center gap-1.5 rounded-xl border border-[#22D3EE]/30 bg-[#1E293B] px-3 py-1.5 text-xs font-semibold text-slate-200 hover:border-[#22D3EE] transition"
                  title="Criar, gerenciar ou excluir seu Nickname permanente ou temporário"
                >
                  <UserIcon className="h-3.5 w-3.5 text-[#22D3EE]" />
                  {currentUser.nickname ? (
                    <span className="flex items-center gap-1">
                      <span className="text-white font-bold max-w-[90px] truncate">@{currentUser.nickname}</span>
                      <span className="text-[9px] font-extrabold uppercase px-1 rounded bg-[#22D3EE]/20 text-[#22D3EE]">
                        {currentUser.nicknameType === 'permanent' ? 'PERM' : 'TEMP'}
                      </span>
                    </span>
                  ) : (
                    <span className="hidden md:inline">Definir Nickname</span>
                  )}
                </button>
              )}

              {/* Botão Amizades & Contatos com Badge de solicitações */}
              {onOpenFriendships && (
                <button
                  onClick={onOpenFriendships}
                  className="relative flex items-center gap-1.5 rounded-xl border border-[#22D3EE]/30 bg-[#1E293B] px-3 py-1.5 text-xs font-semibold text-[#E2E8F0] hover:bg-[#334155] hover:border-[#22D3EE] transition"
                  title="Conexões, Amizades & Meus Grupos de Contatos"
                >
                  <Users className="h-3.5 w-3.5 text-[#22D3EE]" />
                  <span className="hidden md:inline">Amizades & Grupos</span>
                  {pendingRequestsCount > 0 && (
                    <span className="flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-black text-white">
                      {pendingRequestsCount}
                    </span>
                  )}
                </button>
              )}

              {onOpenMyCodes && (
                <button
                  onClick={onOpenMyCodes}
                  className="hidden lg:flex items-center gap-1.5 rounded-xl border border-[#22D3EE]/30 bg-[#1E293B] px-3 py-1.5 text-xs font-semibold text-[#22D3EE] hover:bg-[#334155] hover:border-[#22D3EE]/60 transition"
                  title="Visualizar Meus 11 Códigos Descartáveis 2FA"
                >
                  <KeyRound className="h-3.5 w-3.5 text-[#22D3EE]" />
                  <span>11 Códigos 2FA</span>
                </button>
              )}

              {/* Status Selector Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowStatusMenu(!showStatusMenu)}
                  className="flex items-center gap-1.5 bg-[#1E293B] px-2.5 py-1.5 rounded-xl border border-slate-700 hover:border-[#22D3EE]/50 transition text-xs"
                  title="Alterar meu status no bate-papo"
                >
                  <span className={`w-2.5 h-2.5 rounded-full ${currentStatusObj.dot}`} />
                  <span className="font-semibold text-slate-200 hidden sm:inline text-[11px]">
                    {currentStatusObj.label}
                  </span>
                  <ChevronDown className="h-3 w-3 text-slate-400" />
                </button>

                {showStatusMenu && (
                  <div className="absolute right-0 mt-1.5 w-52 rounded-2xl border border-[#1E293B] bg-[#0F172A] p-1.5 shadow-2xl z-50 text-xs">
                    <p className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-500 border-b border-[#1E293B] mb-1">
                      Status no Bate-Papo
                    </p>
                    {statusOptions.map((st) => (
                      <button
                        key={st.id}
                        onClick={() => handleSelectStatus(st.id)}
                        className={`w-full flex items-center justify-between rounded-xl px-2.5 py-2 text-left transition ${
                          currentUser?.status === st.id
                            ? 'bg-[#22D3EE]/20 text-[#22D3EE] font-bold'
                            : 'hover:bg-[#1E293B] text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span>{st.icon}</span>
                          <span>{st.label}</span>
                        </div>
                        {currentUser?.status === st.id && (
                          <span className="text-[10px] font-bold text-[#22D3EE]">✓</span>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Botão de Recarga / Saldo do Bate-Papo */}
              {onOpenRecharge && (
                <button
                  onClick={onOpenRecharge}
                  className="flex items-center gap-1.5 rounded-xl border border-emerald-500/40 bg-emerald-950/40 px-2.5 sm:px-3 py-1.5 text-xs font-bold text-emerald-300 hover:bg-emerald-900/60 transition shadow-md cursor-pointer active:scale-95"
                  title="Recarregar créditos do bate-papo (Tarifas a partir de R$ 5,00 via Mercado Pago)"
                >
                  <CreditCard className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
                  <span className="font-mono text-white font-bold">
                    R$ {(currentUser.balance ?? 0).toFixed(2).replace('.', ',')}
                  </span>
                  <span className="hidden sm:inline text-[9px] bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 px-1.5 py-0.5 rounded-md font-black tracking-wider">
                    RECARREGAR
                  </span>
                </button>
              )}

              {/* Botão Perfil Social */}
              {onOpenSocialProfile && (
                <button
                  onClick={onOpenSocialProfile}
                  className="flex items-center gap-1.5 rounded-xl border border-[#22D3EE]/40 bg-[#0F172A] px-2.5 sm:px-3 py-1.5 text-xs font-bold text-[#22D3EE] hover:bg-[#1E293B] transition shadow-md cursor-pointer active:scale-95"
                  title="Acessar meu Perfil Social (Feed, Fotos, Amigos, Status Público/Privado)"
                >
                  <span className="flex h-5 w-5 items-center justify-center rounded-lg bg-gradient-to-r from-[#22D3EE] to-[#F472B6] font-black text-black text-[11px] shadow-sm">
                    P
                  </span>
                  <span className="hidden md:inline text-[11px] font-bold text-slate-200">Meu Perfil Social</span>
                </button>
              )}

              {/* User Profile Avatar */}
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenSocialProfile}
                  className="flex items-center gap-2 bg-[#1E293B]/70 hover:bg-[#1E293B] px-2.5 py-1 rounded-full border border-[#1E293B] hover:border-[#22D3EE]/50 transition cursor-pointer"
                  title="Ver meu perfil social"
                >
                  <div className="w-7 h-7 rounded-full bg-[#334155] border border-[#22D3EE]/60 flex items-center justify-center text-xs font-bold text-[#22D3EE]">
                    {currentUser.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-xs font-medium text-[#E2E8F0] hidden xl:inline">
                    {currentUser.name} {currentUser.lastName}
                  </span>
                </button>

                <button
                  onClick={onLogout}
                  className="rounded-xl border border-[#1E293B] bg-[#1E293B] p-2 text-slate-400 hover:bg-[#334155] hover:text-[#F472B6] transition"
                  title="Sair da Conta"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2.5">
              <button
                onClick={onOpenLogin}
                className="rounded-xl border border-[#1E293B] bg-[#1E293B] px-4 py-2 text-xs font-semibold text-[#E2E8F0] hover:bg-[#334155] hover:border-[#22D3EE]/40 transition active:scale-95"
              >
                Entrar com CPF & 2FA
              </button>
              <button
                onClick={onOpenRegister}
                className="rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 py-2 text-xs font-black text-black shadow-lg shadow-[#22D3EE]/25 hover:brightness-110 transition active:scale-95"
              >
                Cadastre-se
              </button>
            </div>
          )}

          {/* Botão para Rever a Vinheta de Abertura */}
          {onOpenIntro && (
            <button
              onClick={onOpenIntro}
              title="Assistir à Vinheta de Abertura (chamasso_in.mp4)"
              className="flex items-center gap-1.5 rounded-xl border border-[#22D3EE]/30 bg-[#1E293B] px-2.5 py-1.5 text-xs font-semibold text-[#22D3EE] hover:bg-[#334155] hover:border-[#22D3EE] transition"
            >
              <Film className="h-3.5 w-3.5 text-[#22D3EE]" />
              <span className="hidden lg:inline">Vinheta</span>
            </button>
          )}

          {/* Botão Especial da Área Restrita do Super Admin:
              "o botão da área restrita deverá ser um desenho de cadeado fechado com 5x5mm quadrados de cor azul ciano,
               com rota e redirecionamento para o dashboard do super admin"
              5x5mm = ~19px x 19px */}
          <div className="ml-1 pl-2 border-l border-[#1E293B]">
            <button
              id="btn-super-admin-cadeado"
              onClick={onOpenAdmin}
              aria-label="Área Restrita do Super Administrador (Cadeado 5x5mm Azul Ciano)"
              title="Área Restrita Super Admin (roger577@ukbelol.space)"
              className="group relative flex items-center justify-center rounded-xl border border-[#22D3EE]/40 bg-[#1E293B] p-2 shadow-md shadow-[#22D3EE]/20 hover:border-[#22D3EE] hover:bg-[#334155] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#22D3EE]/50 active:scale-90"
            >
              {/* O ícone de cadeado fechado configurado com exatamente 5x5mm */}
              <Lock
                style={{ width: '5mm', height: '5mm' }}
                className="text-[#00f0ff] filter drop-shadow-[0_0_6px_rgba(0,240,255,0.7)] transition-transform duration-200 group-hover:scale-110"
              />
              <span className="sr-only">Área Restrita Super Admin</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
