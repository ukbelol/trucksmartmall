import React, { useState } from 'react';
import {
  Heart,
  Users,
  Lock,
  Globe,
  PlusCircle,
  Search,
  Sparkles,
  MessageCircleHeart,
  ShieldCheck,
  Music,
  Flame,
  Coffee,
  Clock,
  ArrowRight,
  Radio,
  Video,
  Eye,
  User as UserIcon,
  MapPin,
  Compass,
} from 'lucide-react';
import type { Room, User, LiveTransmission } from '../types.ts';
import { LocationThemeSelector } from './LocationThemeSelector.tsx';
import type { ChatTheme } from '../data/brazilLocationsAndThemes.ts';

interface RoomLobbyProps {
  rooms: Room[];
  currentUser: User | null;
  onJoinRoom: (room: Room) => void;
  onCreateRoom: () => void;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onNavigateHome?: () => void;
  securityNotice?: string | null;
  onOpenLiveModal?: (liveId?: string) => void;
  onOpenNicknameModal?: () => void;
}

export const RoomLobby: React.FC<RoomLobbyProps> = ({
  rooms,
  currentUser,
  onJoinRoom,
  onCreateRoom,
  onOpenLogin,
  onOpenRegister,
  onNavigateHome,
  securityNotice,
  onOpenLiveModal,
  onOpenNicknameModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [lives, setLives] = useState<LiveTransmission[]>([]);

  React.useEffect(() => {
    const fetchLives = async () => {
      try {
        const res = await fetch('/api/live');
        if (res.ok) {
          const data = await res.json();
          setLives(data.filter((l: LiveTransmission) => l.status === 'active'));
        }
      } catch {
        // ignore
      }
    };
    fetchLives();
    const interval = setInterval(fetchLives, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleEnterRegionalRoom = async (
    state: string,
    stateName: string,
    city: string,
    theme: ChatTheme
  ) => {
    try {
      const res = await fetch('/api/rooms/get-or-create-regional', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          state,
          stateName,
          city,
          themeId: theme.id,
          themeLabel: theme.label,
          themeCategory: theme.category === 'paquera' ? 'paquera' : 'amizade',
          userId: currentUser?.id,
          userName: currentUser ? `${currentUser.name} ${currentUser.lastName}` : 'Visitante Chamasso',
          userEmail: currentUser?.googleEmail,
        }),
      });

      if (res.ok) {
        const room = await res.json();
        onJoinRoom(room);
      }
    } catch (err) {
      console.error('Erro ao acessar sala regional:', err);
    }
  };

  const categories = [
    { id: 'all', label: 'Todas as Salas', icon: Globe },
    { id: 'cidades', label: '🗺️ Cidades & Estados', icon: MapPin },
    { id: 'amizade', label: '☕ Amizades & Papo', icon: Coffee },
    { id: 'paquera', label: '❤️ Paqueras & Match', icon: Flame },
    { id: 'romance', label: '🌹 Romance a Dois', icon: Heart },
    { id: 'musica', label: '🎵 Música & Voz', icon: Music },
  ];

  const filteredRooms = rooms.filter((r) => {
    let matchesCategory = true;
    if (selectedCategory === 'cidades') {
      matchesCategory = Boolean(r.state || r.city || r.name.includes(' - '));
    } else if (selectedCategory === 'amizade') {
      matchesCategory = r.category === 'amizade' || Boolean(r.theme && r.theme.startsWith('amizade'));
    } else if (selectedCategory === 'paquera') {
      matchesCategory = r.category === 'paquera' || Boolean(r.theme && r.theme.startsWith('paquera'));
    } else if (selectedCategory !== 'all') {
      matchesCategory = r.category === selectedCategory;
    }

    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      r.name.toLowerCase().includes(q) ||
      r.description.toLowerCase().includes(q) ||
      r.creatorName.toLowerCase().includes(q) ||
      (r.state && r.state.toLowerCase().includes(q)) ||
      (r.city && r.city.toLowerCase().includes(q)) ||
      (r.themeLabel && r.themeLabel.toLowerCase().includes(q));

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
      {/* Security alert if disposable code was consumed on login */}
      {securityNotice && (
        <div className="mb-6 rounded-2xl border border-amber-500/40 bg-[#0F172A] p-3.5 sm:p-4 text-xs text-amber-200 shadow-xl flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 sm:h-9 sm:w-9 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
              <ShieldCheck className="h-4 w-4 sm:h-5 sm:w-5" />
            </div>
            <div>
              <p className="font-bold text-amber-300 text-xs">Alerta de Segurança 2FA chamasso live chat:</p>
              <p className="text-slate-300 mt-0.5 text-[11px] sm:text-xs">{securityNotice}</p>
            </div>
          </div>
        </div>
      )}

      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-3xl border border-[#1E293B] bg-gradient-to-br from-[#0F172A] via-[#0A0C10] to-[#1E293B]/80 p-5 sm:p-8 lg:p-10 shadow-2xl mb-6 sm:mb-8">
        <div className="absolute right-0 top-0 -mr-20 -mt-20 h-72 w-72 rounded-full bg-[#F472B6]/10 blur-3xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 -mb-20 h-72 w-72 rounded-full bg-[#22D3EE]/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-6 sm:gap-8">
          <div className="max-w-2xl w-full">
            <div className="inline-flex items-center gap-2 rounded-full border border-[#22D3EE]/30 bg-[#1E293B] px-3.5 py-1 text-xs font-semibold text-[#22D3EE] mb-3 sm:mb-4">
              <Flame className="h-3.5 w-3.5 text-[#F472B6]" />
              <span className="text-[11px] sm:text-xs">Salas de Vídeo, Áudio & Conexões em Tempo Real</span>
            </div>

            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tighter italic uppercase text-white leading-tight">
              Encontre conexões reais no{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#22D3EE] to-[#F472B6]">
                chamasso live chat
              </span>
            </h1>

            <p className="mt-2.5 sm:mt-3 text-xs sm:text-sm lg:text-base text-slate-300 leading-relaxed max-w-xl font-normal">
              Salas públicas e privadas com transmissão de vídeo e áudio em alta definição, compartilhamento
              de tela, troca de arquivos e autenticação blindada com Aplicativos 2FA (TOTP) e 11 códigos
              descartáveis.
            </p>

            <div className="mt-5 sm:mt-6 flex flex-wrap items-center gap-3">
              {currentUser ? (
                <button
                  onClick={onCreateRoom}
                  className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 sm:px-5 py-2.5 sm:py-3 text-xs sm:text-sm font-black text-black shadow-xl shadow-[#22D3EE]/25 hover:brightness-110 active:scale-95 transition"
                >
                  <PlusCircle className="h-4 w-4 text-black" />
                  <span>Criar Sala Pública ou Privada</span>
                </button>
              ) : (
                <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
                  <button
                    onClick={onOpenRegister}
                    className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 sm:px-5 py-2.5 sm:py-3 text-xs sm:text-sm font-black text-black shadow-xl shadow-[#22D3EE]/25 hover:brightness-110 active:scale-95 transition"
                  >
                    <Sparkles className="h-4 w-4 text-black" />
                    <span>Cadastrar com CPF & 2FA</span>
                  </button>
                  <button
                    onClick={onOpenLogin}
                    className="flex items-center gap-2 rounded-xl border border-[#1E293B] bg-[#1E293B] px-4 sm:px-5 py-2.5 sm:py-3 text-xs sm:text-sm font-semibold text-[#E2E8F0] hover:bg-[#334155] hover:border-[#22D3EE]/40 transition"
                  >
                    <span>Entrar com CPF</span>
                    <ArrowRight className="h-4 w-4 text-[#22D3EE]" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Logotipo do site - clique redireciona para a página de salas */}
          <div className="hidden md:flex flex-col items-center shrink-0">
            <a
              href="/app"
              onClick={(e) => {
                e.preventDefault();
                if (onNavigateHome) {
                  onNavigateHome();
                } else {
                  window.history.pushState({}, '', '/app');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              title="Lobby de Salas - chamasso live chat"
              className="relative group cursor-pointer block focus:outline-none"
            >
              <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-[#22D3EE] via-[#F472B6] to-[#22D3EE] opacity-50 blur-lg transition duration-500 group-hover:opacity-80" />
              <div className="relative w-32 h-32 sm:w-40 sm:h-40 rounded-3xl overflow-hidden border-2 border-[#22D3EE]/60 bg-[#0A0C10] shadow-2xl transition-transform duration-500 group-hover:scale-105 active:scale-95">
                <img
                  src="/fenix_chamas.gif"
                  alt="chamasso live chat"
                  className="w-full h-full object-cover"
                />
              </div>
            </a>
          </div>
        </div>
      </div>

      {/* Nickname Status Banner */}
      {currentUser && (
        <div className="mb-8 rounded-2xl border border-[#22D3EE]/20 bg-[#0F172A]/90 p-4 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#22D3EE]/10 text-[#22D3EE]">
              <UserIcon className="h-5 w-5" />
            </div>
            <div>
              {currentUser.nickname ? (
                <div>
                  <p className="text-xs font-bold text-white flex items-center gap-2">
                    <span>Nickname Ativo: <span className="text-[#22D3EE]">@{currentUser.nickname}</span></span>
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-[#22D3EE]/20 text-[#22D3EE] border border-[#22D3EE]/30">
                      {currentUser.nicknameType === 'permanent' ? 'Permanente (Automático)' : 'Temporário'}
                    </span>
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {currentUser.nicknameType === 'permanent'
                      ? 'Seu nickname permanente é aplicado automaticamente em todas as salas e transmissões sem precisar redigitar.'
                      : 'Você está usando um nickname temporário. Deseja torná-lo permanente ou liberar para outros?'}
                  </p>
                </div>
              ) : (
                <div>
                  <p className="text-xs font-bold text-slate-200">
                    Você ainda não definiu um Nickname
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Crie um nickname temporário ou permanente para entrar nas salas de conferência e lives com sua identidade personalizada.
                  </p>
                </div>
              )}
            </div>
          </div>
          {onOpenNicknameModal && (
            <button
              onClick={onOpenNicknameModal}
              className="shrink-0 rounded-xl border border-[#22D3EE]/40 bg-[#1E293B] px-3.5 py-1.5 text-xs font-bold text-[#22D3EE] hover:bg-[#22D3EE]/10 transition"
            >
              {currentUser.nickname ? 'Gerenciar / Liberar Nickname' : 'Criar Meu Nickname'}
            </button>
          )}
        </div>
      )}

      {/* SEÇÃO DE TRANSMISSÕES DE CÂMERA AO VIVO (LIVES) */}
      <div className="mb-10 rounded-3xl border border-rose-500/20 bg-gradient-to-b from-[#1E112A]/50 to-[#0A0C10] p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-[#1E293B]">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-rose-500/20 text-rose-400">
              <Radio className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black italic uppercase text-white tracking-wide">
                  Transmissões de Câmera ao Vivo
                </h2>
                <span className="rounded-full bg-rose-500 px-2.5 py-0.5 text-[10px] font-black uppercase text-white tracking-widest animate-pulse">
                  AO VIVO
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Câmeras em tempo real (máx 55 espectadores por canal) com solicitação de acesso restrito de 33s.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {onOpenLiveModal && (
              <button
                onClick={() => onOpenLiveModal()}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-rose-500 to-[#F472B6] px-4 py-2 text-xs font-black text-white shadow-lg shadow-rose-500/20 hover:brightness-110 active:scale-95 transition"
              >
                <Video className="h-4 w-4 text-white" />
                <span>Iniciar Minha Live</span>
              </button>
            )}
          </div>
        </div>

        {/* Grade de transmissões ativas */}
        {lives.length === 0 ? (
          <div className="mt-6 rounded-2xl border border-[#1E293B] bg-[#0A0C10]/60 p-8 text-center">
            <Radio className="mx-auto h-8 w-8 text-slate-600 mb-2" />
            <p className="text-sm font-bold text-slate-300">Nenhuma transmissão de câmera ao vivo no momento</p>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              Seja o primeiro a transmitir sua câmera para até 55 participantes ou assista quando alguém iniciar!
            </p>
            {onOpenLiveModal && (
              <button
                onClick={() => onOpenLiveModal()}
                className="mt-4 inline-flex items-center gap-2 rounded-xl border border-rose-500/40 bg-rose-950/40 px-4 py-2 text-xs font-bold text-rose-300 hover:bg-rose-900/60 transition"
              >
                <Video className="h-3.5 w-3.5" />
                <span>Abrir Transmissão ao Vivo Agora</span>
              </button>
            )}
          </div>
        ) : (
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {lives.map((live) => (
              <div
                key={live.id}
                className="group relative overflow-hidden rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4 shadow-xl hover:border-rose-500/40 transition"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="flex h-2.5 w-2.5 rounded-full bg-rose-500 animate-ping" />
                    <span className="text-[11px] font-black uppercase tracking-wider text-rose-400">
                      AO VIVO
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-[11px] font-bold text-slate-400">
                    <Eye className="h-3.5 w-3.5 text-[#22D3EE]" />
                    <span>{live.viewersCount} / 55</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 mb-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-[#F472B6] text-sm font-black text-white">
                    {live.streamerName.charAt(0).toUpperCase()}
                  </div>
                  <div className="truncate">
                    <h3 className="text-sm font-bold text-white truncate group-hover:text-[#22D3EE] transition">
                      {live.title}
                    </h3>
                    <p className="text-[11px] text-slate-400 truncate">
                      {live.streamerNickname ? `@${live.streamerNickname}` : live.streamerName}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#1E293B]">
                  <span
                    className={`rounded-lg px-2 py-0.5 text-[10px] font-black uppercase ${
                      live.isRestricted
                        ? 'bg-purple-950/60 text-purple-300 border border-purple-500/30'
                        : 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30'
                    }`}
                  >
                    {live.isRestricted ? '🔒 Restrita (33s)' : '🌐 Pública'}
                  </span>

                  {onOpenLiveModal && (
                    <button
                      onClick={() => onOpenLiveModal(live.id)}
                      className="rounded-xl bg-gradient-to-r from-rose-500 to-[#F472B6] px-3.5 py-1.5 text-xs font-black text-white hover:brightness-110 active:scale-95 transition shadow-md"
                    >
                      Assistir Live
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Seletor de Estados / Cidades Populosas e Temas de Amizade / Paquera */}
      <LocationThemeSelector
        rooms={rooms}
        currentUser={currentUser}
        onEnterRoom={handleEnterRegionalRoom}
        onDirectJoinRoom={onJoinRoom}
      />

      {/* Controls Bar: Category filter & Search */}
      <div className="mb-6 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Categories pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold whitespace-nowrap transition ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#22D3EE] to-[#F472B6] text-black font-extrabold shadow-md shadow-[#22D3EE]/20'
                    : 'border border-[#1E293B] bg-[#0F172A] text-slate-300 hover:border-[#22D3EE]/40 hover:text-white'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${isSelected ? 'text-black' : 'text-slate-400'}`} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Search input */}
        <div className="relative min-w-[260px]">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por cidade, estado, tema ou moderador..."
            className="w-full rounded-xl border border-[#1E293B] bg-[#0F172A] pl-10 pr-4 py-2 text-xs text-[#E2E8F0] placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
          />
        </div>
      </div>

      {/* Room Grid */}
      {filteredRooms.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-[#1E293B] bg-[#0F172A]/50 p-12 text-center text-slate-400">
          <MessageCircleHeart className="mx-auto h-12 w-12 text-slate-600 mb-3" />
          <h3 className="text-base font-bold text-slate-300">Nenhuma sala encontrada</h3>
          <p className="text-xs text-slate-500 mt-1">
            Seja o primeiro a inaugurar uma sala neste momento!
          </p>
          {currentUser && (
            <button
              onClick={onCreateRoom}
              className="mt-4 inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 py-2 text-xs font-black text-black hover:brightness-110 transition"
            >
              <PlusCircle className="h-3.5 w-3.5 text-black" />
              <span>Criar Nova Sala</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredRooms.map((room) => {
            const isPublic = room.type === 'public';
            const isCreator = currentUser?.id === room.creatorId;

            return (
              <div
                key={room.id}
                className="group relative flex flex-col justify-between rounded-2xl border border-[#1E293B] bg-[#0F172A] p-5 backdrop-blur-md transition-all duration-300 hover:border-[#22D3EE]/50 hover:shadow-[0_0_20px_rgba(34,211,238,0.15)]"
              >
                <div>
                  {/* Card top badges */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span
                        className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                          isPublic
                            ? 'border border-[#22D3EE]/30 bg-[#1E293B] text-[#22D3EE]'
                            : 'border border-[#F472B6]/30 bg-[#1E293B] text-[#F472B6]'
                        }`}
                      >
                        {isPublic ? <Globe className="h-3 w-3" /> : <Lock className="h-3 w-3" />}
                        {isPublic ? 'Pública' : 'Privada com Moderação'}
                      </span>

                      {room.state && (
                        <span className="inline-flex items-center gap-1 rounded-md border border-[#22D3EE]/30 bg-[#0A0C10] px-2 py-0.5 text-[10px] font-bold text-[#22D3EE]">
                          <MapPin className="h-2.5 w-2.5" />
                          <span>{room.state}</span>
                        </span>
                      )}

                      {room.themeLabel && (
                        <span className="rounded-md border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10px] font-medium text-amber-300">
                          {room.themeLabel}
                        </span>
                      )}

                      <span className="rounded-md border border-[#1E293B] bg-[#0A0C10] px-2 py-0.5 text-[10px] font-medium text-slate-300 capitalize">
                        {room.category}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-slate-400 shrink-0">
                      <Users className="h-3.5 w-3.5 text-[#22D3EE]" />
                      <span className="font-semibold text-slate-200">
                        {room.activeParticipantsCount || 0}
                      </span>
                      <span className="text-slate-600">/</span>
                      <span className="text-slate-500">{room.maxParticipants}</span>
                    </div>
                  </div>

                  {/* Room Name & Description */}
                  <h3 className="text-base font-bold text-white group-hover:text-[#22D3EE] transition line-clamp-1">
                    {room.name}
                  </h3>
                  <p className="mt-1.5 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {room.description}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-[#1E293B] flex items-center justify-between gap-3">
                  <div className="text-left">
                    <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                      Moderador
                    </p>
                    <p className="text-xs font-medium text-slate-300 truncate max-w-[130px]">
                      {room.creatorName} {isCreator && '(Você)'}
                    </p>
                  </div>

                  <button
                    onClick={() => onJoinRoom(room)}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 py-2 text-xs font-black text-black shadow-md shadow-[#22D3EE]/20 hover:brightness-110 active:scale-95 transition"
                  >
                    <span>{isPublic ? 'Entrar na Sala' : 'Pedir Ingresso'}</span>
                    <ArrowRight className="h-3.5 w-3.5 text-black" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
