import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  QrCode,
  Copy,
  Check,
  AlertTriangle,
  Download,
  Key,
  Smartphone,
  Sparkles,
  ArrowRight,
  UserCheck,
  Eye,
  EyeOff,
  Lock,
  Mail,
  Clock,
  ExternalLink,
  HelpCircle,
} from 'lucide-react';
import { formatCPF, isValidCPF, cleanCPF } from '../utils/cpf.ts';
import { validateNicknameFormat, NICKNAME_MAX_LENGTH } from '../utils/nickname.ts';
import type { User } from '../types.ts';
import { TwoFactorAppList, POPULAR_2FA_APPS } from './TwoFactorAppList.tsx';

interface RegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: User) => void;
}

export const RegisterModal: React.FC<RegisterModalProps> = ({ isOpen, onClose, onSuccess }) => {
  // Step 1: Personal Info, Email (Username), Password & CPF validation
  // Step 2: 2FA QR code scan & 6-digit confirmation
  // Step 3: 11 Disposable Codes presentation & confirmation
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Step 1 fields
  const [name, setName] = useState('');
  const [lastName, setLastName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [cpf, setCpf] = useState('');
  const [nickname, setNickname] = useState('');
  const [googleEmail, setGoogleEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Step 1 validation feedback
  const [cpfValid, setCpfValid] = useState<boolean | null>(null);
  const [cpfError, setCpfError] = useState('');
  const [nicknameValid, setNicknameValid] = useState<boolean | null>(null);
  const [nicknameError, setNicknameError] = useState('');
  const [checkingNickname, setCheckingNickname] = useState(false);
  const [generalError, setGeneralError] = useState('');
  const [loading, setLoading] = useState(false);

  // Step 2 fields from server
  const [totpSecret, setTotpSecret] = useState('');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [disposableCodes, setDisposableCodes] = useState<string[]>([]);
  const [authCodeInput, setAuthCodeInput] = useState('');
  const [copiedSecret, setCopiedSecret] = useState(false);
  const [copiedAllCodes, setCopiedAllCodes] = useState(false);

  // Finished user
  const [registeredUser, setRegisteredUser] = useState<User | null>(null);

  if (!isOpen) return null;

  const handleNicknameChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    // Permite digitar apenas caracteres permitidos e no máximo 8
    const clean = raw.slice(0, NICKNAME_MAX_LENGTH);
    setNickname(clean);

    if (!clean.trim()) {
      setNicknameValid(null);
      setNicknameError('');
      return;
    }

    const validation = validateNicknameFormat(clean);
    if (!validation.isValid) {
      setNicknameValid(false);
      setNicknameError(validation.error || 'Formato de nickname inválido.');
      return;
    }

    // Se o formato é válido, consulta disponibilidade no servidor
    setCheckingNickname(true);
    try {
      const res = await fetch(`/api/user/nickname-check?nickname=${encodeURIComponent(clean.trim())}`);
      const data = await res.json();
      if (data.available) {
        setNicknameValid(true);
        setNicknameError('');
      } else {
        setNicknameValid(false);
        setNicknameError(data.error || 'Este nickname já está em uso no sistema.');
      }
    } catch (err) {
      setNicknameValid(true);
      setNicknameError('');
    } finally {
      setCheckingNickname(false);
    }
  };

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    const formatted = formatCPF(raw);
    setCpf(formatted);

    const clean = cleanCPF(formatted);
    if (clean.length === 11) {
      if (isValidCPF(clean)) {
        setCpfValid(true);
        setCpfError('');
      } else {
        setCpfValid(false);
        setCpfError('CPF inválido segundo a regra oficial da Receita Federal.');
      }
    } else {
      setCpfValid(null);
      setCpfError('');
    }
  };

  const handleSubmitStep1 = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError('');

    const clean = cleanCPF(cpf);
    if (!isValidCPF(clean)) {
      setCpfValid(false);
      setCpfError('O CPF informado não é válido. Digite um CPF autêntico da Receita Federal.');
      return;
    }

    // Validação opcional de nickname
    const cleanNick = nickname.trim();
    if (cleanNick) {
      const nickVal = validateNicknameFormat(cleanNick);
      if (!nickVal.isValid) {
        setNicknameValid(false);
        setNicknameError(nickVal.error || 'Nickname inválido.');
        return;
      }
    }

    if (!googleEmail.includes('@')) {
      setGeneralError('Informe um e-mail válido (ex: seuemail@gmail.com) para ser o seu usuário.');
      return;
    }

    if (!password || password.length < 6) {
      setGeneralError('A senha de acesso deve conter no mínimo 6 caracteres.');
      return;
    }

    if (password !== confirmPassword) {
      setGeneralError('A confirmação da senha não coincide com a senha informada.');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/auth/register-step1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          lastName: lastName.trim(),
          birthDate,
          cpf: clean,
          nickname: cleanNick || undefined,
          googleEmail: googleEmail.trim().toLowerCase(),
          password,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Erro ao processar cadastro.');
      }

      setTotpSecret(data.data.secret);
      setQrCodeUrl(data.data.qrCodeDataUrl);
      setDisposableCodes(data.data.disposableCodes);
      setStep(2);
    } catch (err: any) {
      setGeneralError(err.message || 'Falha ao conectar ao servidor.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitStep2 = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError('');

    if (authCodeInput.trim().length !== 6) {
      setGeneralError('O código do aplicativo autenticador deve conter exatamente 6 dígitos numéricos.');
      return;
    }

    setLoading(true);

    try {
      const clean = cleanCPF(cpf);
      const res = await fetch('/api/auth/register-step2', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          lastName: lastName.trim(),
          birthDate,
          cpf: clean,
          nickname: nickname.trim() || undefined,
          googleEmail: googleEmail.trim().toLowerCase(),
          password,
          secret: totpSecret,
          code: authCodeInput.trim(),
          disposableCodes,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Código 2FA incorreto.');
      }

      setRegisteredUser(data.user);
      setStep(3); // Go to disposable codes screen
    } catch (err: any) {
      setGeneralError(err.message || 'Erro ao validar código 2FA.');
    } finally {
      setLoading(false);
    }
  };

  const copySecret = () => {
    navigator.clipboard.writeText(totpSecret);
    setCopiedSecret(true);
    setTimeout(() => setCopiedSecret(false), 2000);
  };

  const copyAllCodes = () => {
    const text = `=== CHAMASSO LIVE CHAT - 11 CÓDIGOS DESCARTÁVEIS ===\nUsuário: ${name} ${lastName}\nCPF: ${cpf}\nE-mail: ${googleEmail}\n\n${disposableCodes.join(
      '\n'
    )}\n\n* Cada código só pode ser usado 1 vez em substituição ao 2FA.\n* Sempre que utilizado, você receberá alerta por e-mail.`;
    navigator.clipboard.writeText(text);
    setCopiedAllCodes(true);
    setTimeout(() => setCopiedAllCodes(false), 2500);
  };

  const downloadCodesTxt = () => {
    const text = `=== CHAMASSO LIVE CHAT - 11 CÓDIGOS DESCARTÁVEIS DE SEGURANÇA ===
Nome: ${name} ${lastName}
CPF: ${cpf}
E-mail Google: ${googleEmail}
Data de Criação: ${new Date().toLocaleString('pt-BR')}

LISTA DOS 11 CÓDIGOS DESCARTÁVEIS (USO ÚNICO CADA):
${disposableCodes.map((c, i) => `${i + 1}. ${c}`).join('\n')}

IMPORTANTE:
- Cada código descarta o anterior e só pode ser utilizado 1 única vez.
- O sistema notificará você via e-mail a cada código descartável utilizado.
- Guarde este arquivo em local seguro.
Domínio: chamasso.pasquared.space
Suporte: rogeriogomes11@ukbelol.space
`;
    const element = document.createElement('a');
    const file = new Blob([text], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `chamasso-11-codigos-descartaveis-${cleanCPF(cpf)}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleFinish = () => {
    if (registeredUser) {
      onSuccess(registeredUser);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 sm:p-8 shadow-2xl text-[#E2E8F0] my-8">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              onClose();
            }}
            title="Ir para a página inicial"
            className="mx-auto block relative w-16 h-16 rounded-2xl overflow-hidden border-2 border-[#22D3EE]/60 shadow-[0_0_20px_rgba(34,211,238,0.45)] mb-3 bg-[#0A0C10] cursor-pointer hover:scale-105 active:scale-95 transition-transform"
          >
            <img
              src="/fenix_chamas.gif"
              alt="chamasso live chat"
              className="w-full h-full object-cover"
            />
          </a>
          <h2 className="text-xl sm:text-2xl font-black uppercase italic tracking-tight text-white">
            Cadastro no <span className="bg-gradient-to-r from-[#22D3EE] to-[#F472B6] bg-clip-text text-transparent">chamasso live chat</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Plataforma de Bate-Papo, Paquera & Amizade com Autenticação 2FA
          </p>

          {/* Stepper indicator */}
          <div className="mt-4 flex items-center justify-center gap-2">
            <div
              className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-black ${
                step >= 1 ? 'bg-[#22D3EE] text-black' : 'bg-[#1E293B] text-slate-400'
              }`}
            >
              1
            </div>
            <div className={`h-0.5 w-8 ${step >= 2 ? 'bg-[#22D3EE]' : 'bg-[#1E293B]'}`} />
            <div
              className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-black ${
                step >= 2 ? 'bg-[#22D3EE] text-black' : 'bg-[#1E293B] text-slate-400'
              }`}
            >
              2
            </div>
            <div className={`h-0.5 w-8 ${step >= 3 ? 'bg-[#22D3EE]' : 'bg-[#1E293B]'}`} />
            <div
              className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-black ${
                step >= 3 ? 'bg-[#22D3EE] text-black' : 'bg-[#1E293B] text-slate-400'
              }`}
            >
              3
            </div>
          </div>
          <p className="text-[11px] text-[#22D3EE] font-bold mt-1">
            {step === 1 && 'Etapa 1: Dados Pessoais & Validação de CPF'}
            {step === 2 && 'Etapa 2: Vincular Aplicativo Autenticador (2FA - TOTP)'}
            {step === 3 && 'Etapa 3: Seus 11 Códigos Descartáveis de Segurança'}
          </p>
        </div>

        {generalError && (
          <div className="mb-4 flex items-center gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300">
            <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />
            <span>{generalError}</span>
          </div>
        )}

        {/* STEP 1: FORMULÁRIO COM VALIDAÇÃO DE CPF */}
        {step === 1 && (
          <form onSubmit={handleSubmitStep1} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Nome *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: Carlos"
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-sm text-[#E2E8F0] placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Sobrenome *</label>
                <input
                  type="text"
                  required
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="Ex: Silva"
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-sm text-[#E2E8F0] placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Data de Nascimento *</label>
                <input
                  type="date"
                  required
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3.5 py-2.5 text-sm text-[#E2E8F0] placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  CPF (Validado pelo Sistema) *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    maxLength={14}
                    value={cpf}
                    onChange={handleCpfChange}
                    placeholder="000.000.000-00"
                    className={`w-full rounded-xl border bg-[#0A0C10] px-3.5 py-2.5 text-sm text-[#E2E8F0] placeholder-slate-600 focus:outline-none transition ${
                      cpfValid === true
                        ? 'border-emerald-500 focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400'
                        : cpfValid === false
                        ? 'border-rose-500 focus:border-rose-400 focus:ring-1 focus:ring-rose-400'
                        : 'border-[#1E293B] focus:border-[#22D3EE]'
                    }`}
                  />
                  {cpfValid === true && (
                    <span className="absolute right-2.5 top-2.5 text-emerald-400" title="CPF Válido">
                      <Check className="h-4 w-4" />
                    </span>
                  )}
                </div>
                {cpfError ? (
                  <p className="text-[11px] text-rose-400 mt-1">{cpfError}</p>
                ) : (
                  <p className="text-[10px] text-slate-400 mt-1">
                    Verificação automática com os dígitos verificadores oficiais.
                  </p>
                )}
              </div>
            </div>

            {/* NICKNAME OPCIONAL */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10]/60 p-3.5">
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-[#22D3EE]" />
                  <span>Nickname / Apelido no Bate-Papo</span>
                  <span className="text-[10px] uppercase font-bold text-[#F472B6] bg-[#F472B6]/10 px-1.5 py-0.5 rounded border border-[#F472B6]/30">
                    Opcional
                  </span>
                </label>
                <span className="text-[11px] font-mono text-slate-400">
                  {nickname.length}/{NICKNAME_MAX_LENGTH}
                </span>
              </div>
              <div className="relative">
                <input
                  type="text"
                  maxLength={NICKNAME_MAX_LENGTH}
                  value={nickname}
                  onChange={handleNicknameChange}
                  placeholder="Ex: fenix_99 (até 8 chars)"
                  className={`w-full rounded-xl border bg-[#0F172A] px-3.5 py-2.5 text-sm text-[#E2E8F0] placeholder-slate-600 focus:outline-none transition ${
                    nicknameValid === true
                      ? 'border-emerald-500 focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400'
                      : nicknameValid === false
                      ? 'border-rose-500 focus:border-rose-400 focus:ring-1 focus:ring-rose-400'
                      : 'border-[#1E293B] focus:border-[#22D3EE]'
                  }`}
                />
                {checkingNickname && (
                  <span className="absolute right-3 top-3 text-[10px] text-cyan-400 animate-pulse">
                    Verificando...
                  </span>
                )}
                {!checkingNickname && nicknameValid === true && (
                  <span className="absolute right-3 top-2.5 text-emerald-400 flex items-center gap-1 text-[11px]" title="Nickname disponível!">
                    <Check className="h-4 w-4" />
                    <span className="hidden sm:inline">Disponível</span>
                  </span>
                )}
              </div>
              {nicknameError ? (
                <p className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                  <span>{nicknameError}</span>
                </p>
              ) : (
                <p className="text-[10px] text-slate-400 mt-1.5 leading-relaxed">
                  Permite até 8 caracteres (letras, números e <code>-</code>, <code>.</code>, <code>_</code>). Se deixar em branco, você poderá criá-lo depois no seu perfil. Sem nickname, seu <strong>nome real de cadastro</strong> será usado automaticamente nas salas e conversas.
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                E-mail Google (Seu Usuário de Acesso) *
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={googleEmail}
                  onChange={(e) => setGoogleEmail(e.target.value)}
                  placeholder="seuemail@gmail.com"
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-10 pr-3.5 py-2.5 text-sm text-[#E2E8F0] placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
                />
                <Mail className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              </div>
              <p className="text-[10px] text-cyan-400/90 mt-1 font-medium">
                Este e-mail será o seu usuário principal de login no sistema.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Senha de Acesso *
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-10 pr-10 py-2.5 text-sm text-[#E2E8F0] placeholder-slate-600 focus:border-[#22D3EE] focus:outline-none focus:ring-1 focus:ring-[#22D3EE]"
                  />
                  <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <p className="text-[10px] text-slate-400 mt-1">Mínimo de 6 caracteres.</p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Confirmar Senha de Acesso *
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repita sua senha"
                    className={`w-full rounded-xl border bg-[#0A0C10] pl-10 pr-3.5 py-2.5 text-sm text-[#E2E8F0] placeholder-slate-600 focus:outline-none ${
                      confirmPassword && password !== confirmPassword
                        ? 'border-rose-500 focus:border-rose-400'
                        : confirmPassword && password === confirmPassword
                        ? 'border-emerald-500 focus:border-emerald-400'
                        : 'border-[#1E293B] focus:border-[#22D3EE]'
                    }`}
                  />
                  <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                </div>
                {confirmPassword && password !== confirmPassword && (
                  <p className="text-[10px] text-rose-400 mt-1">As senhas não coincidem.</p>
                )}
                {confirmPassword && password === confirmPassword && (
                  <p className="text-[10px] text-emerald-400 mt-1">Senhas conferem perfeitamente.</p>
                )}
              </div>
            </div>

            <div className="rounded-xl border border-amber-500/20 bg-amber-500/10 p-3 text-[11px] text-amber-300 flex items-start gap-2">
              <ShieldCheck className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" />
              <span>
                <strong>Segurança Obrigatória:</strong> Após salvar seu e-mail e senha, o sistema exigirá a
                configuração do seu aplicativo autenticador <strong>(2FA - TOTP)</strong> (Google Authenticator, Microsoft Authenticator, 2FAS, Authy, Bitwarden, etc.) e fornecerá seus 11 códigos descartáveis.
              </span>
            </div>

            <button
              type="submit"
              disabled={loading || cpfValid === false}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2.5 text-sm font-black text-black shadow-lg hover:brightness-110 active:scale-98 transition disabled:opacity-50"
            >
              {loading ? (
                <span>Validando Dados & Gerando 2FA...</span>
              ) : (
                <>
                  <span>Avançar para Configuração 2FA (TOTP)</span>
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* STEP 2: VINCULAÇÃO DE APLICATIVO AUTENTICADOR (QR CODE, APPS COMPATÍVEIS & CÓDIGO 6 DÍGITOS) */}
        {step === 2 && (
          <form onSubmit={handleSubmitStep2} className="space-y-4">
            <div className="rounded-2xl border border-[#22D3EE]/30 bg-[#22D3EE]/10 p-3.5 text-xs text-cyan-200 flex items-start gap-2.5">
              <Smartphone className="h-5 w-5 text-[#22D3EE] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white">Vincule seu Aplicativo Autenticador (2FA):</span> Abra o seu aplicativo favorito no celular (Android, iPhone ou PC), toque em <strong>Escanear QR Code</strong> (ou <strong>+</strong>) e aponte para o código abaixo.
              </div>
            </div>

            {/* Vitrine de Aplicativos 2FA Recomendados */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10]/80 p-3">
              <TwoFactorAppList compact={true} />
            </div>

            {/* QR Code Container & Chave Manual */}
            <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#0A0C10] border border-[#1E293B]">
              {qrCodeUrl ? (
                <div className="relative group">
                  <img
                    src={qrCodeUrl}
                    alt="QR Code Autenticador 2FA"
                    className="w-48 h-48 rounded-xl shadow-md border-2 border-white/10 bg-white p-1"
                  />
                  <div className="absolute inset-x-0 -bottom-2 flex justify-center">
                    <span className="rounded-full bg-black/90 border border-cyan-500/40 px-2.5 py-0.5 text-[9px] font-bold text-[#22D3EE] shadow-md">
                      Padrão Universal RFC 6238 (TOTP)
                    </span>
                  </div>
                </div>
              ) : (
                <div className="w-48 h-48 flex items-center justify-center text-slate-500">
                  Carregando QR Code...
                </div>
              )}

              {/* Secret key for copy-paste */}
              <div className="mt-4 w-full max-w-sm flex items-center justify-between gap-2 rounded-xl border border-[#1E293B] bg-[#0F172A] px-3 py-1.5 text-xs">
                <div className="truncate">
                  <span className="text-slate-400">Chave secreta manual: </span>
                  <span className="font-mono font-bold text-[#22D3EE]">{totpSecret}</span>
                </div>
                <button
                  type="button"
                  onClick={copySecret}
                  className="flex items-center gap-1 rounded bg-[#1E293B] px-2 py-1 text-[11px] font-medium text-slate-200 hover:bg-[#22D3EE] hover:text-black transition shrink-0"
                  title="Copiar chave secreta manual"
                >
                  {copiedSecret ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  <span>{copiedSecret ? 'Copiado' : 'Copiar'}</span>
                </button>
              </div>
            </div>

            {/* Input para confirmar o código de 6 dígitos */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0F172A] p-4 text-center">
              <label className="block text-xs font-bold text-slate-200 mb-1.5">
                Digite o código de 6 dígitos gerado no seu App Autenticador:
              </label>
              <div className="flex justify-center my-2">
                <input
                  type="text"
                  maxLength={6}
                  required
                  autoFocus
                  value={authCodeInput}
                  onChange={(e) => setAuthCodeInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000"
                  className="w-52 text-center tracking-[0.4em] font-mono text-2xl font-bold rounded-xl border border-[#22D3EE]/50 bg-[#0A0C10] py-2.5 text-[#22D3EE] focus:border-[#22D3EE] focus:outline-none focus:ring-2 focus:ring-[#22D3EE]/40"
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                O código de 6 dígitos se renova a cada <strong>30 segundos</strong> no seu aplicativo autenticador.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="w-1/3 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2.5 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition"
              >
                Voltar
              </button>
              <button
                type="submit"
                disabled={loading || authCodeInput.length !== 6}
                className="w-2/3 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-2.5 text-xs font-black text-black shadow-md hover:brightness-110 active:scale-98 transition disabled:opacity-50"
              >
                {loading ? 'Validando 2FA...' : 'Confirmar e Ativar 2FA'}
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: SEUS 11 CÓDIGOS DESCARTÁVEIS DE SEGURANÇA */}
        {step === 3 && (
          <div className="space-y-4">
            <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/20 p-3.5 text-xs text-emerald-200">
              <div className="flex items-center gap-2 font-bold text-emerald-400 mb-1">
                <UserCheck className="h-4 w-4" />
                Conta Criada e Autenticação 2FA Vinculada com Sucesso!
              </div>
              <p className="text-slate-300 leading-relaxed">
                Abaixo estão gerados os seus <strong>11 códigos descartáveis exclusivos</strong>. Eles podem ser
                utilizados no login caso você perca o acesso ao seu aplicativo autenticador.
              </p>
            </div>

            <div className="rounded-2xl border border-amber-500/30 bg-amber-950/20 p-3 text-[11px] text-amber-200">
              <strong>Regra de Segurança:</strong> Cada código só pode ser usado <strong>1 única vez</strong>.
              Sempre que um desses 11 códigos for utilizado para login, você receberá um alerta automático de
              segurança no seu e-mail (<strong>{googleEmail}</strong>).
            </div>

            {/* Grid dos 11 Códigos */}
            <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-[#22D3EE] flex items-center gap-1.5">
                  <Key className="h-3.5 w-3.5" />
                  11 Códigos Descartáveis de Uso Único
                </span>
                <span className="text-[10px] text-slate-400">11 disponíveis</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {disposableCodes.map((code, index) => (
                  <div
                    key={code}
                    className="flex items-center justify-between rounded-xl border border-[#1E293B] bg-[#0F172A] px-2.5 py-1.5 font-mono text-xs text-slate-200 shadow-sm"
                  >
                    <span className="text-slate-500 text-[10px] mr-1">{index + 1}.</span>
                    <span className="font-semibold text-[#22D3EE]">{code}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Botões de Ação para Salvar os Códigos */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={copyAllCodes}
                className="flex items-center justify-center gap-2 rounded-xl border border-[#22D3EE]/40 bg-[#22D3EE]/10 py-2.5 text-xs font-semibold text-[#22D3EE] hover:bg-[#22D3EE]/20 transition"
              >
                {copiedAllCodes ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                <span>{copiedAllCodes ? 'Códigos Copiados!' : 'Copiar Todos os 11 Códigos'}</span>
              </button>

              <button
                type="button"
                onClick={downloadCodesTxt}
                className="flex items-center justify-center gap-2 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2.5 text-xs font-semibold text-slate-200 hover:bg-[#334155] transition"
              >
                <Download className="h-4 w-4" />
                <span>Baixar Arquivo .TXT</span>
              </button>
            </div>

            {/* Botão Concluir e Entrar */}
            <button
              type="button"
              onClick={handleFinish}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] py-3 text-sm font-black text-black shadow-xl hover:brightness-110 active:scale-98 transition"
            >
              <Sparkles className="h-4 w-4" />
              <span>Concluir e Acessar o chamasso live chat</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
