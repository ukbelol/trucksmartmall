import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  TrendingDown,
  TrendingUp,
  Users,
  ShieldCheck,
  ShieldAlert,
  Ban,
  CheckCircle,
  PlusCircle,
  RefreshCw,
  Search,
  Lock,
  Unlock,
  Sparkles,
  Calendar,
  AlertCircle,
} from 'lucide-react';

interface Bill {
  id: string;
  type: 'payable' | 'receivable';
  title: string;
  description?: string;
  amount: number;
  dueDate: string;
  status: 'pending' | 'paid' | 'overdue' | 'cancelled';
  paidAt?: string;
  category: string;
  entityName?: string;
  entityDocument?: string;
  createdAt: string;
}

interface FinancialClient {
  id: string;
  name: string;
  lastName: string;
  googleEmail: string;
  cpf: string;
  balance: number;
  hasFreeAccess?: boolean;
  isBlocked?: boolean;
  blockReason?: string;
  financialNotes?: string;
  totalSpent?: number;
  lastPaymentAt?: string;
  pasqcoins?: number;
}

export const FinancialAdminTab: React.FC = () => {
  const [subTab, setSubTab] = useState<'payable' | 'receivable' | 'clients'>('clients');
  const [loading, setLoading] = useState(false);
  const [billsToPay, setBillsToPay] = useState<Bill[]>([]);
  const [billsToReceive, setBillsToReceive] = useState<Bill[]>([]);
  const [clients, setClients] = useState<FinancialClient[]>([]);
  const [totals, setTotals] = useState({
    totalPayable: 0,
    totalReceivable: 0,
    paidPayable: 0,
    receivedAmount: 0,
    netBalance: 0,
    freeAccessCount: 0,
    positiveCount: 0,
    negativeCount: 0,
  });

  // Client search and filter
  const [clientSearch, setClientSearch] = useState('');
  const [clientFilter, setClientFilter] = useState<'all' | 'positive' | 'negative' | 'free' | 'blocked'>('all');

  // Modal / Form state for new bill
  const [showAddBillModal, setShowAddBillModal] = useState(false);
  const [billType, setBillType] = useState<'payable' | 'receivable'>('payable');
  const [billTitle, setBillTitle] = useState('');
  const [billDesc, setBillDesc] = useState('');
  const [billAmount, setBillAmount] = useState('');
  const [billDueDate, setBillDueDate] = useState('');
  const [billCategory, setBillCategory] = useState('Infraestrutura');
  const [billEntity, setBillEntity] = useState('');
  const [billEntityDoc, setBillEntityDoc] = useState('');

  const loadFinancialData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/financial/overview');
      if (res.ok) {
        const data = await res.json();
        setBillsToPay(data.billsToPay || []);
        setBillsToReceive(data.billsToReceive || []);
        setClients(data.clients || []);
        setTotals(data.totals || {
          totalPayable: 0,
          totalReceivable: 0,
          paidPayable: 0,
          receivedAmount: 0,
          netBalance: 0,
          freeAccessCount: 0,
          positiveCount: 0,
          negativeCount: 0,
        });
      }
    } catch (err) {
      console.error('Erro ao carregar dados financeiros:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFinancialData();
  }, []);

  const handleCreateBill = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(billAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      alert('Informe um valor monetário válido.');
      return;
    }
    if (!billTitle.trim()) {
      alert('Informe o título da conta.');
      return;
    }

    try {
      const endpoint = billType === 'payable' ? '/api/admin/financial/payable' : '/api/admin/financial/receivable';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: billTitle.trim(),
          description: billDesc.trim(),
          amount: amountNum,
          dueDate: billDueDate || new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
          category: billCategory,
          entityName: billEntity.trim(),
          entityDocument: billEntityDoc.trim(),
        }),
      });

      if (!res.ok) throw new Error('Falha ao registrar conta');
      setShowAddBillModal(false);
      setBillTitle('');
      setBillDesc('');
      setBillAmount('');
      setBillEntity('');
      setBillEntityDoc('');
      loadFinancialData();
    } catch (err: any) {
      alert(err.message || 'Erro ao criar conta');
    }
  };

  const handleToggleBillStatus = async (bill: Bill) => {
    const newStatus = bill.status === 'paid' ? 'pending' : 'paid';
    try {
      const endpoint = bill.type === 'payable'
        ? `/api/admin/financial/payable/${bill.id}`
        : `/api/admin/financial/receivable/${bill.id}`;

      await fetch(endpoint, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: newStatus,
          paidAt: newStatus === 'paid' ? new Date().toISOString() : null,
        }),
      });
      loadFinancialData();
    } catch (err) {
      console.error('Erro ao alterar status da conta:', err);
    }
  };

  const handleDeleteBill = async (bill: Bill) => {
    if (!confirm(`Deseja excluir permanentemente a conta "${bill.title}"?`)) return;
    try {
      const endpoint = bill.type === 'payable'
        ? `/api/admin/financial/payable/${bill.id}`
        : `/api/admin/financial/receivable/${bill.id}`;
      await fetch(endpoint, { method: 'DELETE' });
      loadFinancialData();
    } catch (err) {
      console.error('Erro ao excluir conta:', err);
    }
  };

  const handleUpdateClientStatus = async (
    userId: string,
    updates: { isBlocked?: boolean; hasFreeAccess?: boolean; blockReason?: string }
  ) => {
    try {
      const res = await fetch(`/api/admin/financial/clients/${userId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (!res.ok) throw new Error('Erro ao atualizar cliente');
      loadFinancialData();
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar status do cliente.');
    }
  };

  const filteredClients = clients.filter((c) => {
    const searchMatch =
      c.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
      c.lastName.toLowerCase().includes(clientSearch.toLowerCase()) ||
      c.googleEmail.toLowerCase().includes(clientSearch.toLowerCase()) ||
      (c.cpf && c.cpf.includes(clientSearch));

    if (!searchMatch) return false;

    if (clientFilter === 'positive') return (c.balance || 0) > 0;
    if (clientFilter === 'negative') return (c.balance || 0) < 0;
    if (clientFilter === 'free') return !!c.hasFreeAccess;
    if (clientFilter === 'blocked') return !!c.isBlocked;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header Financeiro */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#1E293B] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-emerald-400" />
              Gestão Financeira & Controle de Clientes
            </h2>
            <span className="rounded bg-emerald-500/20 border border-emerald-500/40 px-2 py-0.5 text-[10px] font-bold text-emerald-400">
              SISTEMA INTEGRADO
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Sub-menus completos: Contas a Pagar, Contas a Receber e Lista de Clientes com Saldo & Acesso Free.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadFinancialData}
            disabled={loading}
            className="flex items-center gap-1.5 rounded-xl border border-[#1E293B] bg-[#1E293B] px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-[#334155] transition disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin text-[#22D3EE]' : ''}`} />
            <span>Atualizar Dados</span>
          </button>
          <button
            onClick={() => {
              setBillType('payable');
              setShowAddBillModal(true);
            }}
            className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-3.5 py-2 text-xs font-bold text-black hover:brightness-110 transition shadow-md"
          >
            <PlusCircle className="h-4 w-4" />
            <span>Lançar Nova Conta</span>
          </button>
        </div>
      </div>

      {/* Resumo dos Indicadores Financeiros */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="rounded-2xl border border-rose-500/30 bg-rose-950/20 p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-rose-400">Contas a Pagar</span>
            <TrendingDown className="h-4 w-4 text-rose-400" />
          </div>
          <p className="text-2xl font-black font-mono text-white mt-1">
            R$ {totals.totalPayable.toFixed(2).replace('.', ',')}
          </p>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 pt-2 border-t border-rose-500/20">
            <span>Quitadas: R$ {totals.paidPayable.toFixed(2).replace('.', ',')}</span>
            <span className="font-semibold text-rose-300">{billsToPay.length} lançamentos</span>
          </div>
        </div>

        <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/20 p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">Contas a Receber</span>
            <TrendingUp className="h-4 w-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black font-mono text-white mt-1">
            R$ {totals.totalReceivable.toFixed(2).replace('.', ',')}
          </p>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 pt-2 border-t border-emerald-500/20">
            <span>Recebidas: R$ {totals.receivedAmount.toFixed(2).replace('.', ',')}</span>
            <span className="font-semibold text-emerald-300">{billsToReceive.length} lançamentos</span>
          </div>
        </div>

        <div className="rounded-2xl border border-[#22D3EE]/30 bg-cyan-950/20 p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#22D3EE]">Saldo Operacional</span>
            <DollarSign className="h-4 w-4 text-[#22D3EE]" />
          </div>
          <p className={`text-2xl font-black font-mono mt-1 ${totals.netBalance >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            R$ {totals.netBalance.toFixed(2).replace('.', ',')}
          </p>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 pt-2 border-t border-[#22D3EE]/20">
            <span>Previsão Líquida</span>
            <span className="font-semibold text-[#22D3EE]">{totals.netBalance >= 0 ? 'Superávit' : 'Déficit'}</span>
          </div>
        </div>

        <div className="rounded-2xl border border-indigo-500/30 bg-indigo-950/20 p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">Acesso Free & Isenção</span>
            <Sparkles className="h-4 w-4 text-indigo-400" />
          </div>
          <p className="text-2xl font-black font-mono text-white mt-1">
            {totals.freeAccessCount} <span className="text-xs font-normal text-slate-400">clientes free</span>
          </p>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 pt-2 border-t border-indigo-500/20">
            <span className="text-emerald-400 font-semibold">{totals.positiveCount} positivos</span>
            <span className="text-rose-400 font-semibold">{totals.negativeCount} devedores</span>
          </div>
        </div>
      </div>

      {/* Sub-menus de Navegação */}
      <div className="flex items-center gap-2 border-b border-[#1E293B] pb-2">
        <button
          onClick={() => setSubTab('clients')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
            subTab === 'clients'
              ? 'bg-gradient-to-r from-[#22D3EE] to-emerald-400 text-black shadow-md'
              : 'text-slate-400 hover:bg-[#1E293B] hover:text-white'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>Lista de Clientes & Saldos ({clients.length})</span>
        </button>

        <button
          onClick={() => setSubTab('payable')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
            subTab === 'payable'
              ? 'bg-rose-600 text-white shadow-md'
              : 'text-slate-400 hover:bg-[#1E293B] hover:text-white'
          }`}
        >
          <TrendingDown className="h-4 w-4" />
          <span>Contas a Pagar ({billsToPay.length})</span>
        </button>

        <button
          onClick={() => setSubTab('receivable')}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-bold transition ${
            subTab === 'receivable'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-slate-400 hover:bg-[#1E293B] hover:text-white'
          }`}
        >
          <TrendingUp className="h-4 w-4" />
          <span>Contas a Receber ({billsToReceive.length})</span>
        </button>
      </div>

      {/* SUB-MENU 1: CLIENTES */}
      {subTab === 'clients' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md w-full">
              <Search className="absolute left-3.5 top-2.5 h-4 w-4 text-slate-500" />
              <input
                type="text"
                placeholder="Buscar por nome, e-mail ou CPF..."
                value={clientSearch}
                onChange={(e) => setClientSearch(e.target.value)}
                className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto">
              <button
                onClick={() => setClientFilter('all')}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                  clientFilter === 'all' ? 'bg-[#22D3EE] text-black' : 'bg-[#1E293B] text-slate-400 hover:text-white'
                }`}
              >
                Todos ({clients.length})
              </button>
              <button
                onClick={() => setClientFilter('positive')}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                  clientFilter === 'positive' ? 'bg-emerald-500 text-black' : 'bg-[#1E293B] text-slate-400 hover:text-emerald-400'
                }`}
              >
                Positivos ({totals.positiveCount})
              </button>
              <button
                onClick={() => setClientFilter('negative')}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                  clientFilter === 'negative' ? 'bg-rose-500 text-white' : 'bg-[#1E293B] text-slate-400 hover:text-rose-400'
                }`}
              >
                Negativos ({totals.negativeCount})
              </button>
              <button
                onClick={() => setClientFilter('free')}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                  clientFilter === 'free' ? 'bg-indigo-500 text-white' : 'bg-[#1E293B] text-slate-400 hover:text-indigo-400'
                }`}
              >
                Acesso Free ({totals.freeAccessCount})
              </button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-[#1E293B] bg-[#0F172A] shadow-xl">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="border-b border-[#1E293B] bg-[#0A0C10] text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                <tr>
                  <th className="px-4 py-3">Cliente / CPF</th>
                  <th className="px-4 py-3">E-mail Cadastrado</th>
                  <th className="px-4 py-3">Saldo Reais</th>
                  <th className="px-4 py-3">Pasqcoins</th>
                  <th className="px-4 py-3">Status de Cobrança</th>
                  <th className="px-4 py-3">Status da Conta</th>
                  <th className="px-4 py-3 text-right">Ações Administrativas</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]/60">
                {filteredClients.map((client) => {
                  const isPositive = (client.balance || 0) >= 0;
                  return (
                    <tr key={client.id} className="hover:bg-[#1E293B]/40 transition">
                      <td className="px-4 py-3">
                        <div className="font-bold text-white">
                          {client.name} {client.lastName}
                        </div>
                        <div className="font-mono text-[11px] text-[#22D3EE]">{client.cpf}</div>
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-300">{client.googleEmail}</td>
                      <td className="px-4 py-3 font-mono font-bold">
                        <span
                          className={`inline-block px-2 py-0.5 rounded ${
                            isPositive
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          R$ {(client.balance || 0).toFixed(2).replace('.', ',')}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono font-bold text-amber-300">
                        {client.pasqcoins ?? 0} PASQ
                      </td>
                      <td className="px-4 py-3">
                        {client.hasFreeAccess ? (
                          <span className="inline-flex items-center gap-1 rounded bg-indigo-950 border border-indigo-700 px-2 py-0.5 text-[10px] font-black uppercase text-indigo-300">
                            <Sparkles className="h-3 w-3 text-indigo-400" />
                            Acesso Free Sem Custos
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-400">Tarifação Padrão</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {client.isBlocked ? (
                          <span className="inline-flex items-center gap-1 rounded bg-rose-950 border border-rose-800 px-2 py-0.5 text-[10px] font-bold text-rose-300">
                            <Lock className="h-3 w-3" />
                            Conta Bloqueada
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded bg-emerald-950 border border-emerald-800 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                            <Unlock className="h-3 w-3" />
                            Ativa
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Botão de Acesso Free Sem Custos */}
                          <button
                            onClick={() =>
                              handleUpdateClientStatus(client.id, {
                                hasFreeAccess: !client.hasFreeAccess,
                              })
                            }
                            className={`rounded-lg px-2.5 py-1 text-[11px] font-bold border transition ${
                              client.hasFreeAccess
                                ? 'border-amber-500/40 bg-amber-950/40 text-amber-300 hover:bg-amber-900'
                                : 'border-indigo-500/40 bg-indigo-950/40 text-indigo-300 hover:bg-indigo-900'
                            }`}
                            title={
                              client.hasFreeAccess
                                ? 'Remover acesso gratuito (voltar a tarifar)'
                                : 'Deixar acesso livre sem custos em qualquer sala'
                            }
                          >
                            {client.hasFreeAccess ? 'Cobrança Normal' : 'Isentar (Free)'}
                          </button>

                          {/* Botão Bloquear / Desbloquear Conta */}
                          <button
                            onClick={() => {
                              const willBlock = !client.isBlocked;
                              let reason = client.blockReason;
                              if (willBlock) {
                                reason = prompt('Motivo do bloqueio financeiro da conta:', 'Inadimplência ou restrição administrativa') || 'Bloqueio administrativo';
                              }
                              handleUpdateClientStatus(client.id, {
                                isBlocked: willBlock,
                                blockReason: reason,
                              });
                            }}
                            className={`rounded-lg px-2.5 py-1 text-[11px] font-bold border transition ${
                              client.isBlocked
                                ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300 hover:bg-emerald-900'
                                : 'border-rose-500/40 bg-rose-950/40 text-rose-300 hover:bg-rose-900'
                            }`}
                          >
                            {client.isBlocked ? 'Desbloquear' : 'Bloquear Conta'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-MENU 2: CONTAS A PAGAR */}
      {subTab === 'payable' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingDown className="h-4 w-4 text-rose-400" />
              Relação de Despesas & Contas a Pagar
            </h3>
            <button
              onClick={() => {
                setBillType('payable');
                setShowAddBillModal(true);
              }}
              className="flex items-center gap-1 rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-500 transition"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              <span>Nova Despesa</span>
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-[#1E293B] bg-[#0F172A] shadow-xl">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="border-b border-[#1E293B] bg-[#0A0C10] text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                <tr>
                  <th className="px-4 py-3">Título / Categoria</th>
                  <th className="px-4 py-3">Fornecedor / Favorecido</th>
                  <th className="px-4 py-3">Vencimento</th>
                  <th className="px-4 py-3">Valor</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]/60">
                {billsToPay.map((bill) => (
                  <tr key={bill.id} className="hover:bg-[#1E293B]/40 transition">
                    <td className="px-4 py-3">
                      <div className="font-bold text-white">{bill.title}</div>
                      <div className="text-[10px] text-slate-400">{bill.category}</div>
                    </td>
                    <td className="px-4 py-3 text-slate-300">{bill.entityName || 'N/A'}</td>
                    <td className="px-4 py-3 font-mono text-slate-300">{bill.dueDate}</td>
                    <td className="px-4 py-3 font-mono font-bold text-rose-400">
                      R$ {bill.amount.toFixed(2).replace('.', ',')}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          bill.status === 'paid'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        }`}
                      >
                        {bill.status === 'paid' ? 'Pago' : 'Pendente'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleToggleBillStatus(bill)}
                          className="rounded-lg px-2.5 py-1 text-[11px] font-semibold border border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700 transition"
                        >
                          {bill.status === 'paid' ? 'Marcar Pendente' : 'Marcar Pago'}
                        </button>
                        <button
                          onClick={() => handleDeleteBill(bill)}
                          className="rounded-lg px-2 py-1 text-[11px] font-semibold border border-rose-800/40 bg-rose-950/40 text-rose-300 hover:bg-rose-900 transition"
                        >
                          Excluir
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-MENU 3: CONTAS A RECEBER */}
      {subTab === 'receivable' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-emerald-400" />
              Relação de Receitas & Faturamento a Receber
            </h3>
            <button
              onClick={() => {
                setBillType('receivable');
                setShowAddBillModal(true);
              }}
              className="flex items-center gap-1 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-500 transition"
            >
              <PlusCircle className="h-3.5 w-3.5" />
              <span>Nova Receita</span>
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-[#1E293B] bg-[#0F172A] shadow-xl">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="border-b border-[#1E293B] bg-[#0A0C10] text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                <tr>
                  <th className="px-4 py-3">Título / Categoria</th>
                  <th className="px-4 py-3">Pagador / Cliente</th>
                  <th className="px-4 py-3">Vencimento</th>
                  <th className="px-4 py-3">Valor</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1E293B]/60">
                {billsToReceive.map((bill) => (
                  <tr key={bill.id} className="hover:bg-[#1E293B]/40 transition">
                    <td className="px-4 py-3">
                      <div className="font-bold text-white">{bill.title}</div>
                      <div className="text-[10px] text-slate-400">{bill.category}</div>
                    </td>
                    <td className="px-4 py-3 text-slate-300">{bill.entityName || 'N/A'}</td>
                    <td className="px-4 py-3 font-mono text-slate-300">{bill.dueDate}</td>
                    <td className="px-4 py-3 font-mono font-bold text-emerald-400">
                      R$ {bill.amount.toFixed(2).replace('.', ',')}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          bill.status === 'paid'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        }`}
                      >
                        {bill.status === 'paid' ? 'Recebido' : 'Pendente'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleToggleBillStatus(bill)}
                          className="rounded-lg px-2.5 py-1 text-[11px] font-semibold border border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700 transition"
                        >
                          {bill.status === 'paid' ? 'Marcar Pendente' : 'Marcar Recebido'}
                        </button>
                        <button
                          onClick={() => handleDeleteBill(bill)}
                          className="rounded-lg px-2 py-1 text-[11px] font-semibold border border-rose-800/40 bg-rose-950/40 text-rose-300 hover:bg-rose-900 transition"
                        >
                          Excluir
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Lançar Conta */}
      {showAddBillModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-lg rounded-2xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <PlusCircle className="h-5 w-5 text-emerald-400" />
              Lançar {billType === 'payable' ? 'Conta a Pagar' : 'Conta a Receber'}
            </h3>

            <form onSubmit={handleCreateBill} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Tipo de Lançamento:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setBillType('payable')}
                    className={`py-2 rounded-xl text-xs font-bold border transition ${
                      billType === 'payable'
                        ? 'border-rose-500 bg-rose-950/60 text-rose-300'
                        : 'border-[#1E293B] bg-[#0A0C10] text-slate-400'
                    }`}
                  >
                    Conta a Pagar (Despesa)
                  </button>
                  <button
                    type="button"
                    onClick={() => setBillType('receivable')}
                    className={`py-2 rounded-xl text-xs font-bold border transition ${
                      billType === 'receivable'
                        ? 'border-emerald-500 bg-emerald-950/60 text-emerald-300'
                        : 'border-[#1E293B] bg-[#0A0C10] text-slate-400'
                    }`}
                  >
                    Conta a Receber (Receita)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Título / Descrição:</label>
                <input
                  type="text"
                  required
                  value={billTitle}
                  onChange={(e) => setBillTitle(e.target.value)}
                  placeholder="Ex: Hospedagem VPS Cloud, Licença Servidor..."
                  className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Valor (R$):</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={billAmount}
                    onChange={(e) => setBillAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3 py-2 text-xs font-mono text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Data de Vencimento:</label>
                  <input
                    type="date"
                    required
                    value={billDueDate}
                    onChange={(e) => setBillDueDate(e.target.value)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3 py-2 text-xs text-white focus:border-[#22D3EE] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Categoria:</label>
                  <select
                    value={billCategory}
                    onChange={(e) => setBillCategory(e.target.value)}
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3 py-2 text-xs text-white focus:border-[#22D3EE] focus:outline-none"
                  >
                    <option value="Infraestrutura">Infraestrutura & VPS</option>
                    <option value="Telecom & Link">Telecom & Conectividade</option>
                    <option value="Segurança">Segurança & Firewall</option>
                    <option value="Licenças & Software">Licenças & Softwares</option>
                    <option value="Recargas Chamasso">Recargas Chamasso</option>
                    <option value="Venda Pasqcoins">Venda Pasqcoins</option>
                    <option value="Outros">Outros</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Fornecedor / Cliente:</label>
                  <input
                    type="text"
                    value={billEntity}
                    onChange={(e) => setBillEntity(e.target.value)}
                    placeholder="Nome da empresa ou cliente"
                    className="w-full rounded-xl border border-[#1E293B] bg-[#0A0C10] px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-[#22D3EE] focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#1E293B]">
                <button
                  type="button"
                  onClick={() => setShowAddBillModal(false)}
                  className="rounded-xl border border-[#1E293B] bg-[#1E293B] px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-5 py-2 text-xs font-black text-black hover:brightness-110 shadow-md"
                >
                  Salvar Conta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
