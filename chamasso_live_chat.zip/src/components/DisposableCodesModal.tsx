import React, { useState } from 'react';
import { X, Key, Copy, Check, Download, AlertTriangle, ShieldCheck, Mail } from 'lucide-react';
import type { User } from '../types.ts';

interface DisposableCodesModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
}

export const DisposableCodesModal: React.FC<DisposableCodesModalProps> = ({ isOpen, onClose, user }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const codes = user.disposableCodes || [];
  const remainingCount = codes.filter((c) => !c.used).length;

  const copyAll = () => {
    const text = `=== CHAMASSO LIVE CHAT - CÓDIGOS DESCARTÁVEIS ===\nUsuário: ${user.name} ${user.lastName}\nCPF: ${user.cpf}\nE-mail: ${user.googleEmail}\n\n${codes
      .map((c) => `${c.code} [${c.used ? 'USADO' : 'DISPONÍVEL'}]`)
      .join('\n')}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadTxt = () => {
    const text = `=== CHAMASSO LIVE CHAT - 11 CÓDIGOS DESCARTÁVEIS ===
Usuário: ${user.name} ${user.lastName}
CPF: ${user.cpf}
E-mail Google: ${user.googleEmail}
Gerado em: ${new Date(user.createdAt).toLocaleString('pt-BR')}

CÓDIGOS:
${codes.map((c, i) => `${i + 1}. ${c.code} -> ${c.used ? `USADO em ${new Date(c.usedAt || '').toLocaleString('pt-BR')}` : 'DISPONÍVEL'}`).join('\n')}

Lembre-se: Sempre que um código descartável é utilizado para efetuar login, um alerta de segurança é enviado para ${user.googleEmail}.
`;
    const element = document.createElement('a');
    const file = new Blob([text], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `chamasso-codigos-${user.cpf}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0A0C10]/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg rounded-3xl border border-[#1E293B] bg-[#0F172A] p-6 shadow-2xl text-[#E2E8F0]">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-2 text-slate-400 hover:bg-[#1E293B] hover:text-white transition"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              onClose();
            }}
            title="Ir para a página inicial"
            className="relative w-12 h-12 rounded-2xl overflow-hidden border-2 border-[#22D3EE]/50 shadow-[0_0_15px_rgba(34,211,238,0.4)] shrink-0 bg-[#0A0C10] block cursor-pointer hover:scale-105 active:scale-95 transition-transform"
          >
            <img
              src="/fenix_chamas.gif"
              alt="chamasso live chat"
              className="w-full h-full object-cover"
            />
          </a>
          <div>
            <h3 className="text-xl font-black uppercase italic tracking-tight text-white">Seus 11 Códigos Descartáveis</h3>
            <p className="text-xs text-slate-400">
              {remainingCount} de 11 códigos disponíveis para autenticação
            </p>
          </div>
        </div>

        <div className="mb-4 rounded-2xl border border-[#22D3EE]/30 bg-[#22D3EE]/10 p-3 text-xs text-cyan-200 flex items-start gap-2.5">
          <Mail className="h-4 w-4 text-[#22D3EE] shrink-0 mt-0.5" />
          <div>
            <strong>Notificação Automática por E-mail:</strong> Cada código descartável pode ser usado apenas{' '}
            <strong>uma vez</strong>. Sempre que você ou alguém fizer login com um desses códigos, você será
            notificado no seu e-mail: <strong className="text-white">{user.googleEmail}</strong>.
          </div>
        </div>

        <div className="rounded-2xl border border-[#1E293B] bg-[#0A0C10] p-3">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-60 overflow-y-auto">
            {codes.map((item, index) => (
              <div
                key={item.code}
                className={`flex items-center justify-between rounded-xl border px-2.5 py-2 font-mono text-xs ${
                  item.used
                    ? 'border-[#1E293B] bg-[#0F172A]/50 text-slate-500 line-through'
                    : 'border-[#22D3EE]/30 bg-[#0F172A] text-[#22D3EE] font-bold'
                }`}
              >
                <span>{item.code}</span>
                {item.used ? (
                  <span className="text-[9px] uppercase px-1 py-0.5 rounded bg-rose-950/60 text-rose-400 font-sans">
                    Usado
                  </span>
                ) : (
                  <span className="text-[9px] uppercase px-1 py-0.5 rounded bg-emerald-950/60 text-emerald-400 font-sans">
                    Ativo
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6 flex flex-col sm:flex-row gap-2">
          <button
            onClick={copyAll}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl border border-[#22D3EE]/40 bg-[#22D3EE]/10 py-2.5 text-xs font-semibold text-[#22D3EE] hover:bg-[#22D3EE]/20 transition"
          >
            {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
            <span>{copied ? 'Copiados com Sucesso!' : 'Copiar Lista'}</span>
          </button>
          <button
            onClick={downloadTxt}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl border border-[#1E293B] bg-[#1E293B] py-2.5 text-xs font-semibold text-slate-200 hover:bg-[#334155] transition"
          >
            <Download className="h-4 w-4" />
            <span>Baixar Arquivo .TXT</span>
          </button>
        </div>
      </div>
    </div>
  );
};
