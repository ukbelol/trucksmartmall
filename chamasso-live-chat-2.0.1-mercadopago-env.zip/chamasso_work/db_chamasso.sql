-- ==============================================================================
-- SCRIPT DE CRIAÇÃO E CONFIGURAÇÃO DO BANCO DE DADOS: CHAMASSO LIVE CHAT
-- SGBD Recomendado: PostgreSQL 14 / 15 / 16
-- Nome do Banco: db_chamasso
-- Usuário Padrão do Banco: user_chamasso
-- Super Admin de Gerenciamento: roger577@ukbelol.space
-- ==============================================================================

-- 1. Criação do Banco de Dados e Usuário de Acesso (Executar como postgres)
DO
$do$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'user_chamasso') THEN
      CREATE ROLE user_chamasso WITH LOGIN ENCRYPTED PASSWORD 'CHANGE_ME_DB_PASSWORD';
   END IF;
END
$do$;

-- Garantir privilégios
ALTER ROLE user_chamasso CREATEDB;

-- Criação do banco se não existir
SELECT 'CREATE DATABASE db_chamasso OWNER user_chamasso ENCODING ''UTF8'''
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'db_chamasso')\gexec

GRANT ALL PRIVILEGES ON DATABASE db_chamasso TO user_chamasso;

\connect db_chamasso;

-- Conceder permissões no schema public
GRANT ALL ON SCHEMA public TO user_chamasso;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO user_chamasso;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO user_chamasso;

-- ==============================================================================
-- 2. CRIAÇÃO DAS TABELAS DO SISTEMA
-- ==============================================================================

-- Tabela: Configurações Gerais do Sistema (Persistente)
CREATE TABLE IF NOT EXISTS system_settings (
    key VARCHAR(100) PRIMARY KEY,
    value JSONB NOT NULL,
    description TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: Super Administradores do Painel de Controle
CREATE TABLE IF NOT EXISTS super_admins (
    id VARCHAR(100) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'SUPER_ADMIN' NOT NULL,
    permissions JSONB DEFAULT '["ALL"]'::jsonb NOT NULL,
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: Usuários Cadastrados
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    last_name VARCHAR(150) NOT NULL,
    birth_date DATE,
    cpf VARCHAR(20) UNIQUE,
    google_email VARCHAR(255) UNIQUE,
    photo_url TEXT,
    balance NUMERIC(10, 2) DEFAULT 0.00 NOT NULL,
    first_interaction_at TIMESTAMP WITH TIME ZONE,
    recharge_expires_at TIMESTAMP WITH TIME ZONE,
    is_blocked BOOLEAN DEFAULT FALSE NOT NULL,
    block_reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: Códigos Descartáveis de Segurança (2FA / 11 Códigos)
CREATE TABLE IF NOT EXISTS user_disposable_codes (
    id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL,
    used BOOLEAN DEFAULT FALSE NOT NULL,
    used_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: Salas de Conferência e Chat
CREATE TABLE IF NOT EXISTS rooms (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(50) DEFAULT 'geral' NOT NULL,
    type VARCHAR(20) DEFAULT 'public' NOT NULL,
    creator_id VARCHAR(100),
    creator_name VARCHAR(150),
    creator_email VARCHAR(255),
    max_participants INTEGER DEFAULT 120 NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: Níveis de Relacionamento (Amizade / Chat)
CREATE TABLE IF NOT EXISTS relationship_levels (
    id VARCHAR(100) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    icon VARCHAR(20) NOT NULL,
    color VARCHAR(30) NOT NULL,
    is_default BOOLEAN DEFAULT FALSE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: Solicitações e Conexões de Amizade
CREATE TABLE IF NOT EXISTS friendships (
    id VARCHAR(100) PRIMARY KEY,
    user1_id VARCHAR(100) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user2_id VARCHAR(100) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(30) DEFAULT 'pending' NOT NULL,
    relationship_level_id VARCHAR(100) REFERENCES relationship_levels(id) ON DELETE SET NULL,
    requested_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_user_pair UNIQUE (user1_id, user2_id)
);

-- Tabela: Estado de Videoconferência Padrão (Matriz 15 + Fila de Palestrantes)
CREATE TABLE IF NOT EXISTS standard_conferences (
    room_id VARCHAR(100) PRIMARY KEY REFERENCES rooms(id) ON DELETE CASCADE,
    current_speaker JSONB,
    speaker_queue JSONB DEFAULT '[]'::jsonb NOT NULL,
    hand_raised_queue JSONB DEFAULT '[]'::jsonb NOT NULL,
    child_rooms JSONB DEFAULT '[]'::jsonb NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: Transações e Recargas de Saldo (Mercado Pago / PIX)
CREATE TABLE IF NOT EXISTS recharge_transactions (
    id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_name VARCHAR(150) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    amount NUMERIC(10, 2) NOT NULL,
    minutes_granted INTEGER NOT NULL,
    status VARCHAR(30) DEFAULT 'pending' NOT NULL,
    payment_method VARCHAR(30) DEFAULT 'pix' NOT NULL,
    pix_qr_code TEXT,
    pix_copy_paste TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE
);

-- Tabela: Logs de Auditoria e Segurança
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(100) PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    action VARCHAR(100) NOT NULL,
    actor VARCHAR(255) NOT NULL,
    details TEXT,
    level VARCHAR(30) DEFAULT 'info' NOT NULL
);

-- Tabela: Notificações de Segurança do Sistema
CREATE TABLE IF NOT EXISTS security_notifications (
    id VARCHAR(100) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) DEFAULT 'system' NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices de Otimização
CREATE INDEX IF NOT EXISTS idx_users_google_email ON users(google_email);
CREATE INDEX IF NOT EXISTS idx_users_cpf ON users(cpf);
CREATE INDEX IF NOT EXISTS idx_disposable_codes_user ON user_disposable_codes(user_id);
CREATE INDEX IF NOT EXISTS idx_rooms_category ON rooms(category);
CREATE INDEX IF NOT EXISTS idx_friendships_user1 ON friendships(user1_id);
CREATE INDEX IF NOT EXISTS idx_friendships_user2 ON friendships(user2_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp DESC);

-- ==============================================================================
-- 3. CARGA INICIAL (SEEDS) & CRIAÇÃO DO SUPER ADMIN
-- ==============================================================================

-- Super Admin é provisionado pela aplicação a partir de SUPER_ADMIN_EMAIL e
-- SUPER_ADMIN_PASSWORD/SUPER_ADMIN_PASSWORD_HASH. Nenhuma senha é mantida neste SQL.

-- Configurações Iniciais do Sistema
INSERT INTO system_settings (key, value, description)
VALUES 
    ('app_info', '{"appName": "chamasso live chat", "version": "1.0.0", "environment": "production"}'::jsonb, 'Informações gerais da aplicação'),
    ('domain_config', '{"domain": "chamasso.pasquared.space", "adminEmail": "rogeriogomes11@ukbelol.space", "sslEnabled": true}'::jsonb, 'Configuração de domínio e certificados SSL'),
    ('conference_defaults', '{"maxMatrixCameras": 15, "speakerSlots": 14, "maxChildRooms": 8, "allowRaiseHand": true}'::jsonb, 'Parâmetros da videoconferência padrão'),
    ('security_policy', '{"requireCpf": true, "require2FA": true, "totalDisposableCodes": 11, "sessionTimeoutMinutes": 120}'::jsonb, 'Política de autenticação e códigos de segurança'),
    ('tariffs_config', '{"billingEnabled": true, "ratePerMinute": 0.01, "minRechargeAmount": 5.0, "rechargeValidityDays": 30}'::jsonb, 'Tarifas Chamasso: Cobrança por minuto (R$ 0,01) e validade de recargas'),
    ('mercadopago_config', '{"activeEnvironment":"test","test":{"publicKey":"","accessToken":"","webhookUrl":"https://chamasso.pasquared.space/api/payments/mercadopago/webhook?environment=test","redirectUrl":"https://chamasso.pasquared.space/app?payment=success&environment=test"},"production":{"publicKey":"","accessToken":"","webhookUrl":"https://chamasso.pasquared.space/api/payments/mercadopago/webhook?environment=production","redirectUrl":"https://chamasso.pasquared.space/app?payment=success&environment=production"}}'::jsonb, 'Configuração Mercado Pago separada por ambiente Teste e Produção')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP;

-- Níveis de Relacionamento Padrão
INSERT INTO relationship_levels (id, name, description, icon, color, is_default)
VALUES 
    ('rel_conhecido', 'Conhecido', 'Conversas casuais e primeiro contato no chat.', '👋', '#94A3B8', TRUE),
    ('rel_colega', 'Colega', 'Interação frequente nas salas públicas de conversa.', '🤝', '#38BDF8', TRUE),
    ('rel_amigo', 'Amigo', 'Troca de mensagens diretas e chamadas de vídeo abertas.', '⭐', '#34D399', TRUE),
    ('rel_amigo_proximo', 'Amigo Próximo', 'Acesso prioritário a salas privadas e bate-papo íntimo.', '💜', '#A855F7', TRUE),
    ('rel_melhor_amigo', 'Melhor Amigo', 'Vínculo de alta confiança com notificações exclusivas.', '💎', '#F59E0B', TRUE),
    ('rel_alma_gemea', 'Alma Gêmea', 'Conexão romântica especial para paquera e relacionamento.', '💖', '#EC4899', TRUE)
ON CONFLICT (id) DO NOTHING;

-- Salas Padrão Iniciais
INSERT INTO rooms (id, name, description, category, type, creator_id, creator_name, creator_email, max_participants)
VALUES 
    (
        'sala-matriz-padrao',
        '🏛️ Auditório Matriz 15 (Template Padrão)',
        'Template de videoconferência padrão com matriz mosaico de 15 câmeras, Câmera 0 Palestrante, Câmera 15 Local fixa, filas Fl_01 a Fl_14 e 8 salas.',
        'geral',
        'public',
        'adm_roger577_master',
        'Super Admin',
        'roger577@ukbelol.space',
        120
    ),
    (
        'sala-paquera-vip',
        '❤️ Encontros & Paquera Ao Vivo',
        'Sala pública para quem busca um novo amor ou um papo descontraído com vídeo e áudio.',
        'paquera',
        'public',
        'adm_roger577_master',
        'Super Admin',
        'roger577@ukbelol.space',
        50
    ),
    (
        'sala-amizades-brasil',
        '☕ Café & Amizades Brasil',
        'Espaço agradável para fazer novos amigos, trocar ideias e bater papo com pessoas de todo o país.',
        'amizade',
        'public',
        'adm_roger577_master',
        'Super Admin',
        'roger577@ukbelol.space',
        80
    )
ON CONFLICT (id) DO NOTHING;

-- Log de inicialização do Banco
INSERT INTO audit_logs (id, action, actor, details, level)
VALUES (
    'log_init_db_' || floor(extract(epoch from now())),
    'DATABASE_INITIALIZED',
    'system_setup',
    'Banco db_chamasso criado com tabelas, índices e Super Admin roger577@ukbelol.space provisionado.',
    'security'
);
