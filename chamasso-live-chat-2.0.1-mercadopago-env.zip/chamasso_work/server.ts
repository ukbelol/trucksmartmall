import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { WebSocketServer, WebSocket } from 'ws';
import QRCode from 'qrcode';
import { createServer as createViteServer } from 'vite';
import { dbManager } from './src/server/db.ts';
import { firewallService } from './src/server/firewall.ts';
import { supabaseBackupService } from './src/server/supabaseBackup.ts';
import { createSessionToken, setSessionCookie, clearSessionCookie, readSessionFromRequest, requireAdmin, hashPassword, verifyPassword } from './src/server/auth.ts';
import { isValidCPF, cleanCPF, formatCPF } from './src/utils/cpf.ts';
import {
  generateBase32Secret,
  generate11DisposableCodes,
  generateTotpUri,
  verifyTotp,
} from './src/utils/totp.ts';
import type {
  User,
  Room,
  RoomParticipant,
  JoinRequest,
  ModeratorBan,
  ChatMessage,
  SecurityNotification,
  AuditLog,
  UserStatus,
  RelationshipLevel,
  ContactGroup,
  UserContact,
  FriendshipRequest,
  LiveTransmission,
  LiveViewRequest,
  SpeakerQueueItem,
  HandRaiseQueueItem,
  MatrixSubRoom,
  StandardConferenceData,
  DirectPrivateMessage,
  SocialPost,
  SocialComment,
  SocialReactionType,
  PasqcoinTransaction,
} from './src/types.ts';
import {
  MAX_FILE_SIZE_BYTES,
  extractVideoEmbed,
  isAudioWavOrMp3,
  isImageValid,
  isVideoMp4,
} from './src/utils/mediaEmbed.ts';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const server = http.createServer(app);

// Increase JSON body limit for chat attachments / files
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Ativa proteção ativa do Firewall contra DDoS, Phishing e Brute-Force
app.use(firewallService.middleware);

// Exige sessão para mutações da API, exceto cadastro/login e webhook externo validado pelo provedor.
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.path.startsWith('/auth/') || req.path === '/payments/mercadopago/webhook') return next();
  const session = readSessionFromRequest(req);
  if (!session) return res.status(401).json({ error: 'Autenticação obrigatória para esta operação.' });
  const origin = req.get('origin');
  if (origin) {
    try { if (new URL(origin).host !== req.get('host')) return res.status(403).json({ error: 'Origem não autorizada.' }); } catch { return res.status(403).json({ error: 'Origem inválida.' }); }
  }
  (req as any).auth = session;
  next();
});

// In-memory data store for live chat
const users: Map<string, User> = new Map();
const rooms: Map<string, Room> = new Map();
const joinRequests: Map<string, JoinRequest> = new Map();
const moderatorBans: ModeratorBan[] = [];
const roomMessages: Map<string, ChatMessage[]> = new Map();
const securityNotifications: SecurityNotification[] = [];
const auditLogs: AuditLog[] = [];
const relationshipLevels: Map<string, RelationshipLevel> = new Map();
const friendshipRequests: Map<string, FriendshipRequest> = new Map();

// Nicknames permanentes registrados (lowercase nickname -> userId)
const permanentNicknames: Map<string, string> = new Map();

// Regras de validação estritas para Nickname (máximo 8 caracteres, letras, números, "-", "." e "_")
const NICKNAME_MAX_LENGTH = 8;
const NICKNAME_REGEX = /^[a-zA-Z0-9._-]{1,8}$/;

function validateNicknameString(nick: string): { isValid: boolean; error?: string } {
  const clean = nick.trim();
  if (!clean) {
    return { isValid: false, error: 'O nickname não pode ser vazio.' };
  }
  if (clean.length > NICKNAME_MAX_LENGTH) {
    return {
      isValid: false,
      error: `O nickname deve conter no máximo ${NICKNAME_MAX_LENGTH} caracteres (você digitou ${clean.length}).`,
    };
  }
  if (!NICKNAME_REGEX.test(clean)) {
    return {
      isValid: false,
      error: 'O nickname deve conter apenas letras, números e os caracteres ".", "-" e "_".',
    };
  }
  return { isValid: true };
}

// Transmissões ao vivo (Live Camera): transmissionId -> LiveTransmission
const liveTransmissions: Map<string, LiveTransmission> = new Map();
// Mapeamento de streamer ativo: streamerId -> transmissionId (apenas 1 transmissão por usuário!)
const streamerActiveLiveMap: Map<string, string> = new Map();
// Mensagens do chat acoplado à transmissão ao vivo: liveId -> ChatMessage[]
const liveChatMessages: Map<string, ChatMessage[]> = new Map();

// Seed default demo user and rooms
function initSeedData() {
  const seedSecret = generateBase32Secret(20);
  const seedDisposable = generate11DisposableCodes().map((code) => ({
    code,
    used: false,
  }));

  // Initial Contact Groups Template
  const defaultGroups: ContactGroup[] = [
    { id: 'grp_geral', name: 'Geral', icon: '📁', color: '#94A3B8' },
    { id: 'grp_favoritos', name: 'Favoritos', icon: '⭐', color: '#FACC15' },
    { id: 'grp_paquera', name: 'Paqueras & Crush', icon: '❤️', color: '#F472B6' },
    { id: 'grp_amigos', name: 'Amigos Próximos', icon: '☕', color: '#22D3EE' },
    { id: 'grp_trabalho', name: 'Trabalho & Networking', icon: '💼', color: '#38BDF8' },
  ];

  // Pre-created Relationship Levels (Níveis de Relacionamento Padrão)
  const defaultLevels: RelationshipLevel[] = [
    {
      id: 'rel_amizade',
      name: 'Amizade & Conexão',
      description: 'Conversas amigáveis, troca de ideias, companheirismo e bom papo no chat.',
      icon: '☕',
      color: '#22D3EE',
      isDefault: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'rel_paquera',
      name: 'Paquera & Crush',
      description: 'Interesse amoroso, flerte descontraído, sintonia e química a dois.',
      icon: '❤️',
      color: '#F472B6',
      isDefault: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'rel_vip',
      name: 'Melhores Amigos / VIP',
      description: 'Círculo exclusivo com prioridade máxima de contato, intimidade e confidência.',
      icon: '⭐',
      color: '#FACC15',
      isDefault: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'rel_networking',
      name: 'Networking & Profissional',
      description: 'Troca profissional de alto nível, tecnologia, parcerias e negócios.',
      icon: '💼',
      color: '#38BDF8',
      isDefault: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'rel_match',
      name: 'Namoro Sério / Match',
      description: 'Compromisso sério, busca de relacionamento duradouro e exclusividade.',
      icon: '💍',
      color: '#C084FC',
      isDefault: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'rel_familia',
      name: 'Família & Círculo Íntimo',
      description: 'Pessoas de extrema confiança, histórico familiar ou amizade de longa data.',
      icon: '🏡',
      color: '#34D399',
      isDefault: true,
      createdAt: new Date().toISOString(),
    },
  ];

  for (const lvl of defaultLevels) {
    relationshipLevels.set(lvl.id, lvl);
  }

  const demoUser: User = {
    id: 'user_demo_1',
    name: 'Ukbelol',
    lastName: 'Pasquared',
    birthDate: '1985-05-15',
    cpf: '52998224725', // Valid Brazilian CPF for testing
    googleEmail: 'rogeriogomes11@ukbelol.space',
    twoFactorSecret: seedSecret,
    twoFactorEnabled: true,
    disposableCodes: seedDisposable,
    isBlocked: false,
    createdAt: new Date().toISOString(),
    bio: 'Criador da plataforma chamasso live chat. Amizades e conexões sinceras!',
    interests: ['Paquera', 'Música', 'Tecnologia', 'Bate-papo'],
    status: 'online',
    contactGroups: [...defaultGroups],
    contacts: [],
  };
  users.set(demoUser.id, demoUser);

  // Additional active users with varied statuses for chat and friendship requests:
  // online, ocupado, em horário de almoço, ausente, invisível=offline
  const additionalUsers: User[] = [
    {
      id: 'user_camila',
      name: 'Camila',
      lastName: 'Santos',
      birthDate: '1994-08-20',
      cpf: '33333333333',
      googleEmail: 'camila.santos@gmail.com',
      twoFactorSecret: generateBase32Secret(20),
      twoFactorEnabled: true,
      disposableCodes: [],
      isBlocked: false,
      createdAt: new Date().toISOString(),
      bio: 'Adoro tomar um bom café, bater papo e conhecer pessoas legais!',
      interests: ['Paquera', 'Viagens', 'Música'],
      status: 'online', // 🟢 Online
      contactGroups: [...defaultGroups],
      contacts: [],
    },
    {
      id: 'user_bruno',
      name: 'Bruno',
      lastName: 'Oliveira',
      birthDate: '1991-03-12',
      cpf: '44444444444',
      googleEmail: 'bruno.tech@gmail.com',
      twoFactorSecret: generateBase32Secret(20),
      twoFactorEnabled: true,
      disposableCodes: [],
      isBlocked: false,
      createdAt: new Date().toISOString(),
      bio: 'Desenvolvedor em sprint de código. Deixe uma mensagem que respondo assim que pausar.',
      interests: ['Networking', 'Tecnologia', 'Games'],
      status: 'ocupado', // 🔴 Ocupado
      contactGroups: [...defaultGroups],
      contacts: [],
    },
    {
      id: 'user_larissa',
      name: 'Larissa',
      lastName: 'Mendes',
      birthDate: '1996-11-05',
      cpf: '55555555555',
      googleEmail: 'larissa.mendes@gmail.com',
      twoFactorSecret: generateBase32Secret(20),
      twoFactorEnabled: true,
      disposableCodes: [],
      isBlocked: false,
      createdAt: new Date().toISOString(),
      bio: 'No meu horário de almoço delicioso 🍽️. Volto em instantes para o bate-papo!',
      interests: ['Amizade', 'Gastronomia', 'Séries'],
      status: 'em_almoco', // 🍔 Em Horário de Almoço
      contactGroups: [...defaultGroups],
      contacts: [],
    },
    {
      id: 'user_thiago',
      name: 'Thiago',
      lastName: 'Ramos',
      birthDate: '1989-07-28',
      cpf: '66666666666',
      googleEmail: 'thiago.ramos@gmail.com',
      twoFactorSecret: generateBase32Secret(20),
      twoFactorEnabled: true,
      disposableCodes: [],
      isBlocked: false,
      createdAt: new Date().toISOString(),
      bio: 'Longe do teclado no momento. Pode enviar pedido de amizade!',
      interests: ['Música', 'Esportes', 'Cinema'],
      status: 'ausente', // 🟡 Ausente
      contactGroups: [...defaultGroups],
      contacts: [],
    },
    {
      id: 'user_beatriz',
      name: 'Beatriz',
      lastName: 'Costa',
      birthDate: '1998-02-14',
      cpf: '77777777777',
      googleEmail: 'beatriz.costa@gmail.com',
      twoFactorSecret: generateBase32Secret(20),
      twoFactorEnabled: true,
      disposableCodes: [],
      isBlocked: false,
      createdAt: new Date().toISOString(),
      bio: 'Navegando em modo invisível / offline. Aberta a novas conexões de confiança.',
      interests: ['Fotografia', 'Arte', 'Livros'],
      status: 'invisivel', // ⚪ Invisível = Offline
      contactGroups: [...defaultGroups],
      contacts: [],
    },
  ];

  for (const u of additionalUsers) {
    users.set(u.id, u);
  }

  // Pre-seed an incoming friendship request for Ukbelol from Camila
  const seedReqId = 'req_camila_rogerio_1';
  friendshipRequests.set(seedReqId, {
    id: seedReqId,
    senderId: 'user_camila',
    senderName: 'Camila',
    senderLastName: 'Santos',
    senderAvatar: '',
    senderStatus: 'online',
    receiverId: demoUser.id,
    receiverName: demoUser.name,
    receiverLastName: demoUser.lastName,
    receiverAvatar: '',
    receiverStatus: 'online',
    relationshipLevelId: 'rel_paquera',
    relationshipLevelName: 'Paquera & Crush',
    relationshipLevelIcon: '❤️',
    relationshipLevelColor: '#F472B6',
    senderGroupId: 'grp_paquera',
    senderGroupName: 'Paqueras & Crush',
    message: 'Oi Ukbelol! Adorei a sua sala e a ideia da plataforma. Vamos nos conectar?',
    status: 'pending',
    createdAt: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
  });

  // Initial Rooms for Paquera & Amizade por Estados / Cidades e Temas
  const initialRooms: Room[] = [
    {
      id: 'sala-matriz-padrao',
      name: '🏛️ Auditório Matriz 15 (Template Padrão)',
      description: 'Template de videoconferência padrão com matriz mosaico de 15 câmeras, Câmera 0 Palestrante, Câmera 15 Local fixa, filas Fl_01 a Fl_14 e 8 salas.',
      category: 'geral',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 120,
      activeParticipantsCount: 15,
      participants: [],
      bans: [],
    },
    // --- SÃO PAULO (SP) ---
    {
      id: 'sala-sp-amizade-sincera',
      name: '🌆 SP - São Paulo (Capital): Amizade Sincera ☕',
      description: 'Bate-papo aberto, descontraído e amizades sinceras para quem mora ou frequenta São Paulo.',
      category: 'amizade',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 80,
      activeParticipantsCount: 12,
      participants: [],
      bans: [],
      state: 'SP',
      stateName: 'São Paulo',
      city: 'São Paulo (Capital)',
      theme: 'amizade_sincera',
      themeLabel: 'Amizade Sincera',
    },
    {
      id: 'sala-sp-amizade-colorida',
      name: '🎨 SP - São Paulo: Amizade Colorida & Conexões',
      description: 'Pessoas livres e desimpedidas de São Paulo em busca de carinho, cumplicidade leve e amizade colorida.',
      category: 'amizade',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 60,
      activeParticipantsCount: 8,
      participants: [],
      bans: [],
      state: 'SP',
      stateName: 'São Paulo',
      city: 'São Paulo (Capital)',
      theme: 'amizade_colorida',
      themeLabel: 'Amizade Colorida',
    },
    {
      id: 'sala-sp-paquera-sincera',
      name: '❤️ SP - São Paulo: Paquera Sincera & Match',
      description: 'Sala paulistana para quem busca encontros reais com respeito, química e afeto.',
      category: 'paquera',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 70,
      activeParticipantsCount: 14,
      participants: [],
      bans: [],
      state: 'SP',
      stateName: 'São Paulo',
      city: 'São Paulo (Capital)',
      theme: 'paquera_sincera',
      themeLabel: 'Paquera Sincera',
    },
    {
      id: 'sala-sp-paquera-colorida',
      name: '🔥 SP - São Paulo: Paquera Colorida & Flerte',
      description: 'Clima quente, flerte e conversas descontraídas na capital e grande SP.',
      category: 'paquera',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 50,
      activeParticipantsCount: 9,
      participants: [],
      bans: [],
      state: 'SP',
      stateName: 'São Paulo',
      city: 'São Paulo (Capital)',
      theme: 'paquera_colorida',
      themeLabel: 'Paquera Colorida',
    },
    {
      id: 'sala-sp-amizade-carnaval',
      name: '🎭 SP - Campinas & Interior: Amizade de Carnaval',
      description: 'Blocos de rua, folia, esquenta de feriadão e amizades carnavalescas.',
      category: 'amizade',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 50,
      activeParticipantsCount: 5,
      participants: [],
      bans: [],
      state: 'SP',
      stateName: 'São Paulo',
      city: 'Campinas',
      theme: 'amizade_carnaval',
      themeLabel: 'Amizade de Carnaval',
    },
    {
      id: 'sala-sp-paquera-anonovo',
      name: '🎆 SP - Santos & Litoral: Paquera de Ano Novo 🥂',
      description: 'Brinde na praia, contagem regressiva e romance de ano novo no litoral paulista.',
      category: 'paquera',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 50,
      activeParticipantsCount: 6,
      participants: [],
      bans: [],
      state: 'SP',
      stateName: 'São Paulo',
      city: 'Santos & Baixada',
      theme: 'paquera_anonovo',
      themeLabel: 'Paquera de Ano Novo',
    },

    // --- RIO DE JANEIRO (RJ) ---
    {
      id: 'sala-rj-paquera-carnaval',
      name: '🎭 RJ - Rio de Janeiro: Paquera de Carnaval 💋',
      description: 'Folia carioca, camarotes, blocos de Copacabana a Ipanema e paquera intensa!',
      category: 'paquera',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 80,
      activeParticipantsCount: 16,
      participants: [],
      bans: [],
      state: 'RJ',
      stateName: 'Rio de Janeiro',
      city: 'Rio de Janeiro (Capital)',
      theme: 'paquera_carnaval',
      themeLabel: 'Paquera de Carnaval',
    },
    {
      id: 'sala-rj-amizade-anonovo',
      name: '🎆 RJ - Rio de Janeiro: Amizade de Ano Novo & Réveillon',
      description: 'Encontros na praia, queima de fogos em Copacabana e amizades para a virada.',
      category: 'amizade',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 60,
      activeParticipantsCount: 10,
      participants: [],
      bans: [],
      state: 'RJ',
      stateName: 'Rio de Janeiro',
      city: 'Rio de Janeiro (Capital)',
      theme: 'amizade_anonovo',
      themeLabel: 'Amizade de Ano Novo',
    },
    {
      id: 'sala-rj-amizade-sincera',
      name: '☕ RJ - Niterói & Rio: Amizade Sincera Carioca',
      description: 'Papo leve, praias, trilhas e boas conversas com pessoas do Rio de Janeiro.',
      category: 'amizade',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 50,
      activeParticipantsCount: 7,
      participants: [],
      bans: [],
      state: 'RJ',
      stateName: 'Rio de Janeiro',
      city: 'Niterói',
      theme: 'amizade_sincera',
      themeLabel: 'Amizade Sincera',
    },

    // --- MINAS GERAIS (MG) ---
    {
      id: 'sala-mg-amizade-sincera',
      name: '🧀 MG - Belo Horizonte: Amizade Sincera & Boteco',
      description: 'Acolhimento mineiro, conversa boa e amizades verdadeiras de BH e cidades vizinhas.',
      category: 'amizade',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 60,
      activeParticipantsCount: 11,
      participants: [],
      bans: [],
      state: 'MG',
      stateName: 'Minas Gerais',
      city: 'Belo Horizonte (Capital)',
      theme: 'amizade_sincera',
      themeLabel: 'Amizade Sincera',
    },
    {
      id: 'sala-mg-paquera-colorida',
      name: '🔥 MG - Belo Horizonte & Uberlândia: Paquera Colorida',
      description: 'Flerte gostoso no melhor estilo mineirinho, com charme e sem complicação.',
      category: 'paquera',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 50,
      activeParticipantsCount: 8,
      participants: [],
      bans: [],
      state: 'MG',
      stateName: 'Minas Gerais',
      city: 'Belo Horizonte (Capital)',
      theme: 'paquera_colorida',
      themeLabel: 'Paquera Colorida',
    },

    // --- BAHIA (BA) ---
    {
      id: 'sala-ba-paquera-carnaval',
      name: '🎭 BA - Salvador: Paquera de Carnaval & Axé 🥁',
      description: 'Farol da Barra, Ondina, Campo Grande e a paquera mais animada do Brasil!',
      category: 'paquera',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 80,
      activeParticipantsCount: 15,
      participants: [],
      bans: [],
      state: 'BA',
      stateName: 'Bahia',
      city: 'Salvador (Capital)',
      theme: 'paquera_carnaval',
      themeLabel: 'Paquera de Carnaval',
    },
    {
      id: 'sala-ba-amizade-sincera',
      name: '☀️ BA - Salvador & Porto Seguro: Amizade Sincera',
      description: 'Energia positiva, boas vibrações e papo aberto para novas amizades baianas.',
      category: 'amizade',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 50,
      activeParticipantsCount: 6,
      participants: [],
      bans: [],
      state: 'BA',
      stateName: 'Bahia',
      city: 'Salvador (Capital)',
      theme: 'amizade_sincera',
      themeLabel: 'Amizade Sincera',
    },

    // --- PARANÁ (PR) & SUL ---
    {
      id: 'sala-pr-paquera-sincera',
      name: '❤️ PR - Curitiba: Paquera Sincera & Conexão',
      description: 'Encontros, cafés e bate-papo sincero em Curitiba, Londrina e Maringá.',
      category: 'paquera',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 50,
      activeParticipantsCount: 7,
      participants: [],
      bans: [],
      state: 'PR',
      stateName: 'Paraná',
      city: 'Curitiba (Capital)',
      theme: 'paquera_sincera',
      themeLabel: 'Paquera Sincera',
    },
    {
      id: 'sala-rs-amizade-colorida',
      name: '🧉 RS - Porto Alegre: Amizade Colorida Gaúcha',
      description: 'Papo agradável, química leve e amizades coloridas em Porto Alegre e Serra.',
      category: 'amizade',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 50,
      activeParticipantsCount: 8,
      participants: [],
      bans: [],
      state: 'RS',
      stateName: 'Rio Grande do Sul',
      city: 'Porto Alegre (Capital)',
      theme: 'amizade_colorida',
      themeLabel: 'Amizade Colorida',
    },

    // --- DISTRITO FEDERAL (DF) ---
    {
      id: 'sala-df-amizade-sincera',
      name: '🏛️ DF - Brasília: Amizade Sincera & Networking',
      description: 'Conexões no Plano Piloto, Águas Claras, Taguatinga e todo o DF.',
      category: 'amizade',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 60,
      activeParticipantsCount: 9,
      participants: [],
      bans: [],
      state: 'DF',
      stateName: 'Distrito Federal',
      city: 'Brasília (Plano Piloto)',
      theme: 'amizade_sincera',
      themeLabel: 'Amizade Sincera',
    },

    // --- PERNAMBUCO & CEARÁ ---
    {
      id: 'sala-pe-paquera-carnaval',
      name: '🎭 PE - Recife & Olinda: Paquera de Carnaval do Frevo',
      description: 'Ladeiras de Olinda, Marco Zero e muito flerte ao som do frevo e maracatu!',
      category: 'paquera',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 60,
      activeParticipantsCount: 11,
      participants: [],
      bans: [],
      state: 'PE',
      stateName: 'Pernambuco',
      city: 'Recife (Capital)',
      theme: 'paquera_carnaval',
      themeLabel: 'Paquera de Carnaval',
    },
    {
      id: 'sala-ce-paquera-anonovo',
      name: '🎆 CE - Fortaleza: Paquera de Ano Novo na Praia de Iracema',
      description: 'Réveillon no aterro da Praia de Iracema, brinde à beira-mar e novos romances!',
      category: 'paquera',
      type: 'public',
      creatorId: demoUser.id,
      creatorName: `${demoUser.name} ${demoUser.lastName}`,
      creatorEmail: demoUser.googleEmail,
      createdAt: new Date().toISOString(),
      maxParticipants: 50,
      activeParticipantsCount: 8,
      participants: [],
      bans: [],
      state: 'CE',
      stateName: 'Ceará',
      city: 'Fortaleza (Capital)',
      theme: 'paquera_anonovo',
      themeLabel: 'Paquera de Ano Novo',
    },
  ];

  for (const r of initialRooms) {
    rooms.set(r.id, r);
    roomMessages.set(r.id, [
      {
        id: `msg_welcome_${r.id}`,
        roomId: r.id,
        senderId: 'system',
        senderName: 'chamasso live chat',
        text: `Bem-vindo à sala "${r.name}". Respeite todos os participantes e aproveite os recursos de áudio, vídeo e compartilhamento!`,
        timestamp: new Date().toISOString(),
      },
    ]);
  }

  auditLogs.push({
    id: `log_init_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'SYSTEM_BOOT',
    actor: 'Sistema',
    details: 'Servidor chamasso live chat iniciado com suporte a persistência SGBD (PostgreSQL).',
    level: 'info',
  });

  // Sincronização de persistência do Banco de Dados (db_chamasso)
  try {
    const persistedUsers = dbManager.getUsers();
    if (persistedUsers && persistedUsers.length > 0) {
      for (const u of persistedUsers) {
        users.set(u.id, u);
        if (u.nickname && u.nickname.trim().length > 0) {
          permanentNicknames.set(u.nickname.trim().toLowerCase(), u.id);
        }
      }
    } else {
      for (const u of users.values()) {
        dbManager.saveUser(u);
        if (u.nickname && u.nickname.trim().length > 0) {
          permanentNicknames.set(u.nickname.trim().toLowerCase(), u.id);
        }
      }
    }

    const persistedRooms = dbManager.getRooms();
    if (persistedRooms && persistedRooms.length > 0) {
      for (const r of persistedRooms) {
        rooms.set(r.id, r);
        const persistedMessages = dbManager.getRoomMessages(r.id);
        if (persistedMessages.length) roomMessages.set(r.id, persistedMessages);
      }
    } else {
      for (const r of rooms.values()) {
        dbManager.saveRoom(r);
      }
    }

    const persistedLevels = dbManager.getRelationshipLevels();
    if (persistedLevels && persistedLevels.length > 0) {
      for (const l of persistedLevels) {
        relationshipLevels.set(l.id, l);
      }
    } else {
      for (const l of relationshipLevels.values()) {
        dbManager.saveRelationshipLevel(l);
      }
    }

    dbManager.ensureSuperAdminCredentials();
  } catch (err) {
    console.error('Erro ao sincronizar persistência do banco:', err);
  }
}

initSeedData();

// ==============================================================================
// AUTHENTICATION ROUTES (Cadastro com Validação de CPF e 2FA Google Authenticator)
// ==============================================================================

function hashUserPassword(password: string): string { return hashPassword(password); }
function verifyUserPassword(password: string, stored?: string): boolean {
  if (!stored) return false;
  if (stored.startsWith('scrypt$')) return verifyPassword(password, stored);
  const legacy = crypto.createHash('sha256').update(password + '_chamasso_pwd_salt_2026').digest('hex');
  return crypto.timingSafeEqual(Buffer.from(legacy), Buffer.from(stored));
}

// POST /api/auth/register-step1
// Valida dados pessoais, valida CPF oficial, valida e-mail Google, senha de acesso, nickname (opcional), gera segredo TOTP e QR Code
app.post('/api/auth/register-step1', async (req, res) => {
  try {
    const { name, lastName, birthDate, cpf, googleEmail, password, nickname } = req.body;

    if (!name || !lastName || !birthDate || !cpf || !googleEmail) {
      return res.status(400).json({ error: 'Todos os campos obrigatórios devem ser preenchidos para o cadastro.' });
    }

    if (!password || password.trim().length < 6) {
      return res.status(400).json({ error: 'Configure uma senha de acesso com no mínimo 6 caracteres.' });
    }

    const cleanCpfValue = cleanCPF(cpf);

    // Validação estrita do CPF com algoritmo da Receita Federal
    if (!isValidCPF(cleanCpfValue)) {
      return res.status(400).json({
        error: 'O CPF informado não é válido segundo a Receita Federal do Brasil. Verifique os dígitos e tente novamente.',
      });
    }

    // Validação de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(googleEmail)) {
      return res.status(400).json({ error: 'Por favor, informe um endereço de e-mail válido.' });
    }

    // Validação opcional de Nickname
    let cleanNickname: string | undefined = undefined;
    if (nickname && typeof nickname === 'string' && nickname.trim().length > 0) {
      const nickValidation = validateNicknameString(nickname);
      if (!nickValidation.isValid) {
        return res.status(400).json({ error: nickValidation.error });
      }
      cleanNickname = nickname.trim();
      const lower = cleanNickname.toLowerCase();

      // Checa unicidade no sistema
      const existingOwner = permanentNicknames.get(lower);
      if (existingOwner) {
        return res.status(400).json({
          error: `O nickname "${cleanNickname}" já está cadastrado no sistema. Escolha outro ou deixe em branco para definir mais tarde.`,
        });
      }
      for (const u of users.values()) {
        if (u.nickname && u.nickname.trim().toLowerCase() === lower) {
          return res.status(400).json({
            error: `O nickname "${cleanNickname}" já está cadastrado no sistema. Escolha outro ou deixe em branco para definir mais tarde.`,
          });
        }
      }
    }

    // Verificar se CPF já está cadastrado
    for (const u of users.values()) {
      if (u.cpf === cleanCpfValue) {
        return res.status(400).json({ error: 'Já existe uma conta cadastrada com este CPF.' });
      }
      if (u.googleEmail.toLowerCase() === googleEmail.toLowerCase()) {
        return res.status(400).json({ error: 'Este e-mail já está vinculado a outra conta.' });
      }
    }

    // Gera chave secreta Base32 para o Google Authenticator
    const secret = generateBase32Secret(20);
    const otpUri = generateTotpUri(googleEmail, secret, 'chamasso live chat');

    // Gera QR Code em Data URL
    const qrCodeDataUrl = await QRCode.toDataURL(otpUri, {
      width: 280,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    });

    // Gera os 11 códigos descartáveis
    const rawDisposableCodes = generate11DisposableCodes();

    res.json({
      success: true,
      data: {
        tempUserId: `temp_${Date.now()}_${cleanCpfValue.slice(0, 4)}`,
        name,
        lastName,
        birthDate,
        cpf: cleanCpfValue,
        formattedCpf: formatCPF(cleanCpfValue),
        googleEmail,
        password,
        nickname: cleanNickname,
        secret,
        qrCodeDataUrl,
        otpUri,
        disposableCodes: rawDisposableCodes,
      },
    });
  } catch (err: any) {
    console.error('Erro no registro etapa 1:', err);
    res.status(500).json({ error: 'Erro interno ao processar cadastro inicial.' });
  }
});

// POST /api/auth/register-step2
// Valida o código do Google Authenticator digitado pelo usuário e finaliza a vinculação com senha, nickname (se houver) e perfil social
app.post('/api/auth/register-step2', (req, res) => {
  try {
    const { name, lastName, birthDate, cpf, googleEmail, secret, code, disposableCodes, password, nickname } = req.body;

    if (!cpf || !secret || !code) {
      return res.status(400).json({ error: 'Dados incompletos para validação do 2FA.' });
    }

    // Validação do código de 6 dígitos gerado pelo Google Authenticator
    const isTotpValid = verifyTotp(secret, code);
    if (!isTotpValid) {
      return res.status(400).json({
        error: 'Código de 6 dígitos inválido ou expirado. Abra o Google Authenticator e digite o código atual.',
      });
    }

    const cleanCpfValue = cleanCPF(cpf);
    const userId = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    const codesList = (disposableCodes || []).map((c: string) => ({
      code: c,
      used: false,
    }));

    // Se informou nickname, valida e registra
    let userNickname: string | undefined = undefined;
    let userNicknameType: 'permanent' | 'temporary' | undefined = undefined;
    if (nickname && typeof nickname === 'string' && nickname.trim().length > 0) {
      const cleanNick = nickname.trim();
      const validation = validateNicknameString(cleanNick);
      if (validation.isValid) {
        userNickname = cleanNick;
        userNicknameType = 'permanent';
        permanentNicknames.set(cleanNick.toLowerCase(), userId);
      }
    }

    const newUser: User = {
      id: userId,
      name,
      lastName,
      birthDate,
      cpf: cleanCpfValue,
      googleEmail,
      nickname: userNickname,
      nicknameType: userNicknameType,
      passwordHash: password ? hashUserPassword(password) : undefined,
      twoFactorSecret: secret,
      twoFactorEnabled: true,
      disposableCodes: codesList,
      isBlocked: false,
      createdAt: new Date().toISOString(),
      bio: 'Novo membro na Rede Social e Live Chat Chamasso.',
      interests: ['Paquera', 'Amizade', 'Rede Social'],
      coverUrl: '/fenix_chamas.gif',
      profilePrivacy: 'public',
      privacySettings: {
        whoCanSeePosts: 'public',
        whoCanAddFriend: 'everyone',
        whoCanSeeFriendsList: 'public',
        whoCanMessage: 'everyone',
        isProfileRestricted: false,
      },
      balance: 0,
      pasqcoins: 0,
    };

    users.set(userId, newUser);
    dbManager.saveUser(newUser);

    // Registra notificação e auditoria
    auditLogs.push({
      id: `log_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'USER_REGISTERED',
      actor: `${name} ${lastName}`,
      details: `Usuário cadastrado com sucesso. E-mail de login: ${googleEmail}. Nickname: ${userNickname || 'Não informado (usará nome real)'}. 2FA Google Authenticator vinculado. CPF: ${formatCPF(cleanCpfValue)}`,
      level: 'info',
    });

    res.json({
      success: true,
      user: {
        id: newUser.id,
        name: newUser.name,
        lastName: newUser.lastName,
        nickname: newUser.nickname,
        nicknameType: newUser.nicknameType,
        birthDate: newUser.birthDate,
        cpf: newUser.cpf,
        formattedCpf: formatCPF(newUser.cpf),
        googleEmail: newUser.googleEmail,
        twoFactorEnabled: true,
        disposableCodes: newUser.disposableCodes,
        coverUrl: newUser.coverUrl,
        profilePrivacy: newUser.profilePrivacy,
        privacySettings: newUser.privacySettings,
        balance: newUser.balance || 0,
        pasqcoins: newUser.pasqcoins || 0,
      },
    });
  } catch (err: any) {
    console.error('Erro no registro etapa 2:', err);
    res.status(500).json({ error: 'Erro interno ao validar autenticação 2FA.' });
  }
});

// POST /api/auth/check-user ou /api/auth/check-cpf
// Checa se o e-mail ou CPF existe, valida senha (se fornecida) e confirma necessidade do 2FA
const handleCheckUser = (req: express.Request, res: express.Response) => {
  const { identifier, cpf, email, password } = req.body;
  const lookup = (identifier || email || cpf || '').trim();

  if (!lookup) {
    return res.status(400).json({ error: 'Informe seu e-mail de acesso ou CPF.' });
  }

  const cleanLookupCpf = cleanCPF(lookup);
  let foundUser: User | null = null;

  for (const u of users.values()) {
    if (
      u.googleEmail.toLowerCase() === lookup.toLowerCase() ||
      (cleanLookupCpf && cleanLookupCpf.length === 11 && u.cpf === cleanLookupCpf)
    ) {
      foundUser = u;
      break;
    }
  }

  if (!foundUser) {
    return res.status(404).json({
      error: 'Usuário não encontrado. Verifique seu e-mail/CPF ou realize seu cadastro.',
    });
  }

  if (foundUser.isBlocked) {
    return res.status(403).json({
      error: `Sua conta está bloqueada pelo administrador. Motivo: ${foundUser.blockReason || 'Violação das diretrizes da comunidade.'}`,
    });
  }

  // Se senha foi fornecida e o usuário tem senha cadastrada, valida
  if (password && foundUser.passwordHash) {
    if (!verifyUserPassword(password, foundUser.passwordHash)) {
      return res.status(401).json({ error: 'Senha de acesso incorreta. Digite sua senha cadastrada.' });
    }
  }

  res.json({
    exists: true,
    userId: foundUser.id,
    userName: `${foundUser.name} ${foundUser.lastName}`,
    email: foundUser.googleEmail,
    emailMasked: foundUser.googleEmail.replace(/(.{2})(.*)(?=@)/, '$1***'),
    requiresPassword: !!foundUser.passwordHash,
    requires2FA: true,
  });
};

app.post('/api/auth/check-user', handleCheckUser);
app.post('/api/auth/check-cpf', handleCheckUser);

// POST /api/auth/login
// Efetua login com e-mail/CPF + senha de acesso + código 2FA (Google Authenticator ou código descartável)
app.post('/api/auth/login', (req, res) => {
  try {
    const { identifier, cpf, email, password, twoFactorCode } = req.body;

    const lookup = (identifier || email || cpf || '').trim();

    if (!lookup || !twoFactorCode) {
      return res.status(400).json({ error: 'E-mail/CPF e Código 2FA são obrigatórios.' });
    }

    const cleanLookupCpf = cleanCPF(lookup);
    let user: User | null = null;

    for (const u of users.values()) {
      if (
        u.googleEmail.toLowerCase() === lookup.toLowerCase() ||
        (cleanLookupCpf && cleanLookupCpf.length === 11 && u.cpf === cleanLookupCpf)
      ) {
        user = u;
        break;
      }
    }

    if (!user) {
      return res.status(404).json({ error: 'Usuário não encontrado com as credenciais informadas.' });
    }

    if (user.isBlocked) {
      return res.status(403).json({
        error: `Acesso negado. Sua conta está temporariamente bloqueada: ${user.blockReason || 'Entre em contato com o suporte.'}`,
      });
    }

    // Se o usuário possui senha configurada, valida
    if (user.passwordHash) {
      if (!password) {
        return res.status(400).json({ error: 'Por favor, informe a senha de acesso da sua conta.' });
      }
      if (!verifyUserPassword(password, user.passwordHash)) {
        return res.status(401).json({ error: 'Senha de acesso incorreta.' });
      }
      // Migração transparente de hashes SHA-256 legados para scrypt.
      if (!user.passwordHash.startsWith('scrypt$')) {
        user.passwordHash = hashUserPassword(password);
        dbManager.saveUser(user);
      }
    }

    const sanitizedCode = twoFactorCode.trim().toUpperCase();
    let authenticated = false;
    let usedDisposable = false;
    let matchedDisposableCode = '';

    // 1. Tentar validar com o código de 6 dígitos TOTP do Google Authenticator
    if (/^\d{6}$/.test(sanitizedCode)) {
      authenticated = verifyTotp(user.twoFactorSecret, sanitizedCode);
    }

    // 2. Se não bateu com TOTP, verificar se é um dos 11 códigos descartáveis
    if (!authenticated && user.disposableCodes) {
      const codeIndex = user.disposableCodes.findIndex(
        (c) => c.code.toUpperCase() === sanitizedCode && !c.used
      );

      if (codeIndex !== -1) {
        authenticated = true;
        usedDisposable = true;
        matchedDisposableCode = user.disposableCodes[codeIndex].code;

        // Invalida o código descartável (uso único)
        user.disposableCodes[codeIndex].used = true;
        user.disposableCodes[codeIndex].usedAt = new Date().toISOString();

        // Cria notificação de segurança por e-mail para o usuário
        const notification: SecurityNotification = {
          id: `sec_notif_${Date.now()}`,
          userId: user.id,
          userEmail: user.googleEmail,
          type: 'disposable_code_used',
          title: 'Alerta de Segurança chamasso live chat',
          message: `O código descartável de uso único ${matchedDisposableCode} foi utilizado para autenticar na sua conta. Códigos restantes: ${
            user.disposableCodes.filter((c) => !c.used).length
          }/11. Se você não reconhece esta atividade, entre em contato imediatamente com rogeriogomes11@ukbelol.space.`,
          codeUsed: matchedDisposableCode,
          timestamp: new Date().toISOString(),
          read: false,
        };
        securityNotifications.unshift(notification);

        // Registro de Auditoria
        auditLogs.unshift({
          id: `log_disposable_${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'DISPOSABLE_CODE_CONSUMED',
          actor: `${user.name} ${user.lastName} (${user.googleEmail})`,
          details: `Código descartável ${matchedDisposableCode} consumido com sucesso. Notificação de segurança enviada.`,
          level: 'security',
        });
      }
    }

    if (!authenticated) {
      return res.status(401).json({
        error:
          'Código 2FA incorreto ou código descartável já utilizado. Verifique seu aplicativo Google Authenticator ou use um código descartável válido.',
      });
    }

    auditLogs.unshift({
      id: `log_login_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'USER_LOGIN_SUCCESS',
      actor: `${user.name} ${user.lastName}`,
      details: `Login realizado com sucesso via ${usedDisposable ? 'Código Descartável' : 'Google Authenticator TOTP'}.`,
      level: 'info',
    });

    const sessionToken = createSessionToken({ sub: user.id, role: 'USER', email: user.googleEmail });
    setSessionCookie(res, sessionToken);
    dbManager.saveUser(user);

    res.json({
      success: true,
      usedDisposable,
      matchedDisposableCode: usedDisposable ? matchedDisposableCode : undefined,
      user: {
        id: user.id,
        name: user.name,
        lastName: user.lastName,
        birthDate: user.birthDate,
        cpf: user.cpf,
        formattedCpf: formatCPF(user.cpf),
        googleEmail: user.googleEmail,
        twoFactorEnabled: true,
        disposableCodes: user.disposableCodes,
        bio: user.bio,
        interests: user.interests,
        coverUrl: user.coverUrl,
        profilePrivacy: user.profilePrivacy,
        privacySettings: user.privacySettings,
        city: user.city,
        work: user.work,
        education: user.education,
        relationshipStatus: user.relationshipStatus,
        balance: user.balance || 0,
        pasqcoins: user.pasqcoins || 0,
      },
    });
  } catch (err: any) {
    console.error('Erro no login:', err);
    res.status(500).json({ error: 'Erro interno ao processar login.' });
  }
});

// POST /api/auth/admin-login
// Autenticação da Área Restrita do Super Admin
app.post('/api/auth/admin-login', (req, res) => {
  const { user, password } = req.body;

  // Verificação no banco de dados e credenciais oficiais
  const verifiedAdmin = dbManager.verifySuperAdmin(user, password);

  if (verifiedAdmin) {
    const logItem: AuditLog = {
      id: `log_admin_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'SUPER_ADMIN_LOGIN',
      actor: verifiedAdmin.email,
      details: 'Super Administrador autenticado com sucesso e todas as permissões concedidas (ALL).',
      level: 'security',
    };
    auditLogs.unshift(logItem);
    dbManager.addAuditLog(logItem);

    const sessionToken = createSessionToken({ sub: verifiedAdmin.id, role: 'SUPER_ADMIN', email: verifiedAdmin.email });
    setSessionCookie(res, sessionToken);
    return res.json({
      success: true,
      admin: {
        user: verifiedAdmin.email,
        role: verifiedAdmin.role,
        permissions: verifiedAdmin.permissions,
      },
    });
  }

  return res.status(401).json({ error: 'Credenciais de Super Administrador inválidas. Verifique o usuário e a senha informados.' });
});

// Sessões e proteção da área administrativa
app.post('/api/auth/logout', (_req, res) => { clearSessionCookie(res); res.json({ success: true }); });
app.get('/api/auth/session', (req, res) => {
  const session = readSessionFromRequest(req);
  res.json({ authenticated: !!session, session: session ? { sub: session.sub, role: session.role, email: session.email } : null });
});
app.use('/api/admin', requireAdmin);

// Configuração pública de ICE. TURN deve usar credenciais próprias/temporárias em produção.
app.get('/api/webrtc/config', (_req, res) => {
  const iceServers: any[] = [{ urls: (process.env.STUN_URLS || 'stun:stun.l.google.com:19302').split(',') }];
  if (process.env.TURN_URLS && process.env.TURN_USERNAME && process.env.TURN_PASSWORD) {
    iceServers.push({ urls: process.env.TURN_URLS.split(','), username: process.env.TURN_USERNAME, credential: process.env.TURN_PASSWORD });
  }
  res.json({ mode: process.env.WEBRTC_MODE || 'p2p', iceServers, sfuUrl: process.env.SFU_URL || null });
});

// GET /api/admin/db-status
// Status e métricas do SGBD PostgreSQL / Armazenamento Persistente
app.get('/api/admin/db-status', (req, res) => {
  res.json(dbManager.getStatus());
});

// GET /api/admin/settings
// Obtém configurações persistentes do sistema
app.get('/api/admin/settings', (req, res) => {
  res.json(dbManager.getSettings());
});

// PUT /api/admin/settings/:key
// Salva ou atualiza uma configuração persistente
app.put('/api/admin/settings/:key', (req, res) => {
  const { key } = req.params;
  const { value, description } = req.body;
  const updated = dbManager.saveSetting(key, value, description);
  res.json({ success: true, setting: updated });
});

// GET /api/admin/schema-sql
// Retorna o script SQL completo db_chamasso.sql
app.get('/api/admin/schema-sql', (req, res) => {
  try {
    const sqlPath = path.join(process.cwd(), 'db_chamasso.sql');
    if (fs.existsSync(sqlPath)) {
      const content = fs.readFileSync(sqlPath, 'utf-8');
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      return res.send(content);
    }
    return res.status(404).json({ error: 'Arquivo db_chamasso.sql não encontrado.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Erro ao carregar script SQL.' });
  }
});

// ==============================================================================
// TARIFAS CHAMASSO & MERCADO PAGO INTEGRATION
// ==============================================================================

// GET /api/tariffs/settings - Retorna tarifas vigentes (cobrança por minuto, recarga mínima, validade)
app.get('/api/tariffs/settings', (req, res) => {
  res.json(dbManager.getTariffSettings());
});

// PUT /api/admin/tariffs/settings - Super Admin ajusta tarifas, ativa/desativa cobrança e taxa de desbloqueio
app.put('/api/admin/tariffs/settings', (req, res) => {
  const { billingEnabled, unlockFeeEnabled, ratePerMinute, minRechargeAmount, rechargeValidityDays } = req.body;

  const current = dbManager.getTariffSettings();

  const parsedBillingEnabled = typeof billingEnabled === 'boolean'
    ? billingEnabled
    : (billingEnabled === 'false' || billingEnabled === 0 ? false : (billingEnabled === 'true' || billingEnabled === 1 ? true : current.billingEnabled));

  const parsedUnlockFeeEnabled = typeof unlockFeeEnabled === 'boolean'
    ? unlockFeeEnabled
    : (unlockFeeEnabled === 'false' || unlockFeeEnabled === 0 ? false : (unlockFeeEnabled === 'true' || unlockFeeEnabled === 1 ? true : current.unlockFeeEnabled));

  const parsedRate = typeof ratePerMinute === 'number'
    ? ratePerMinute
    : parseFloat(ratePerMinute);

  const parsedMinRecharge = typeof minRechargeAmount === 'number'
    ? minRechargeAmount
    : parseFloat(minRechargeAmount);

  const parsedValidity = typeof rechargeValidityDays === 'number'
    ? rechargeValidityDays
    : parseInt(rechargeValidityDays, 10);

  const updated = dbManager.saveTariffSettings({
    billingEnabled: parsedBillingEnabled,
    unlockFeeEnabled: parsedUnlockFeeEnabled,
    ratePerMinute: !isNaN(parsedRate) && parsedRate >= 0 ? parsedRate : current.ratePerMinute,
    minRechargeAmount: !isNaN(parsedMinRecharge) && parsedMinRecharge >= 1 ? parsedMinRecharge : current.minRechargeAmount,
    rechargeValidityDays: !isNaN(parsedValidity) && parsedValidity >= 1 ? parsedValidity : current.rechargeValidityDays,
  });

  const logItem: AuditLog = {
    id: `log_tariff_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'TARIFF_SETTINGS_UPDATED',
    actor: 'Super Admin',
    details: `Tarifas atualizadas: Cobrança ${updated.billingEnabled ? 'ATIVADA' : 'DESATIVADA'}, Taxa Desbloqueio: ${updated.unlockFeeEnabled ? 'ATIVADA' : 'DESATIVADA'}, Tarifa: R$ ${updated.ratePerMinute}/min, Mínimo recarga: R$ ${updated.minRechargeAmount}, Validade: ${updated.rechargeValidityDays} dias.`,
    level: 'warn',
  };
  auditLogs.unshift(logItem);
  dbManager.addAuditLog(logItem);

  broadcastGlobal({
    type: 'tariffs_settings_changed',
    settings: updated,
  });

  res.json({ success: true, settings: updated });
});

// ==============================================================================
// PASQCOIN - MOEDA VIRTUAL DE TEMPO E DESBLOQUEIO DO CHAT
// ==============================================================================

// GET /api/pasqcoin/settings - Consulta parâmetros e estoque da moeda virtual
app.get('/api/pasqcoin/settings', (req, res) => {
  const settings = dbManager.getPasqcoinSettings();
  res.json(settings);
});

// PUT /api/admin/pasqcoin/settings - Super Admin atualiza parâmetros e regras da Pasqcoin
app.put('/api/admin/pasqcoin/settings', (req, res) => {
  const {
    enabled,
    secondsPerCoin,
    pricePerCoin,
    batchSize,
    autoReplenishThresholdPercent,
    autoReplenishEnabled,
    expirationDays,
  } = req.body;

  const current = dbManager.getPasqcoinSettings();
  const updated = dbManager.savePasqcoinSettings({
    enabled: typeof enabled === 'boolean' ? enabled : current.enabled,
    secondsPerCoin: typeof secondsPerCoin === 'number' && secondsPerCoin > 0 ? secondsPerCoin : (parseFloat(secondsPerCoin) || current.secondsPerCoin),
    pricePerCoin: typeof pricePerCoin === 'number' && pricePerCoin >= 0 ? pricePerCoin : (parseFloat(pricePerCoin) || current.pricePerCoin),
    batchSize: typeof batchSize === 'number' && batchSize > 0 ? batchSize : (parseInt(batchSize, 10) || current.batchSize),
    autoReplenishThresholdPercent: typeof autoReplenishThresholdPercent === 'number' && autoReplenishThresholdPercent > 0 ? autoReplenishThresholdPercent : (parseInt(autoReplenishThresholdPercent, 10) || current.autoReplenishThresholdPercent),
    autoReplenishEnabled: typeof autoReplenishEnabled === 'boolean' ? autoReplenishEnabled : current.autoReplenishEnabled,
    expirationDays: typeof expirationDays === 'number' && expirationDays >= 1 ? expirationDays : (parseInt(expirationDays, 10) || current.expirationDays || 30),
  });

  const logItem: AuditLog = {
    id: `log_pasq_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'PASQCOIN_SETTINGS_UPDATED',
    actor: 'Super Admin',
    details: `Parâmetros da Pasqcoin atualizados: ${updated.secondsPerCoin}s por moeda, R$ ${updated.pricePerCoin}, lote de ${updated.batchSize}, gatilho de reposição ${updated.autoReplenishThresholdPercent}%, validade: ${updated.expirationDays} dias.`,
    level: 'warn',
  };
  auditLogs.unshift(logItem);
  dbManager.addAuditLog(logItem);

  broadcastGlobal({
    type: 'pasqcoin_settings_changed',
    settings: updated,
  });

  res.json({ success: true, settings: updated });
});

// POST /api/admin/pasqcoin/mint - Super Admin gera manualmente um lote de 1.141 pasqcoins (ou valor customizado)
app.post('/api/admin/pasqcoin/mint', (req, res) => {
  const amount = parseInt(req.body.amount, 10) || 1141;
  const notes = req.body.notes || `Geração de lote de ${amount} pasqcoins pelo Super Admin.`;

  const result = dbManager.mintPasqcoinBatch(amount, 'manual_admin', notes);

  const logItem: AuditLog = {
    id: `log_pasq_mint_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'PASQCOIN_MINT_BATCH',
    actor: 'Super Admin',
    details: `Novo lote de ${amount} Pasqcoins gerado com sucesso. Estoque disponível: ${result.settings.availableReserve} PASQ.`,
    level: 'info',
  };
  auditLogs.unshift(logItem);
  dbManager.addAuditLog(logItem);

  broadcastGlobal({
    type: 'pasqcoin_minted',
    batch: result.batch,
    settings: result.settings,
  });

  res.json({
    success: true,
    message: `${amount} Pasqcoins geradas com sucesso e disponibilizadas para compra!`,
    batch: result.batch,
    settings: result.settings,
  });
});

// GET /api/admin/pasqcoin/batches - Lista todos os lotes emitidos
app.get('/api/admin/pasqcoin/batches', (req, res) => {
  res.json(dbManager.getPasqcoinBatches());
});

// GET /api/admin/pasqcoin/transactions - Lista todas as transações e compras de Pasqcoins
app.get('/api/admin/pasqcoin/transactions', (req, res) => {
  res.json(dbManager.getPasqcoinTransactions());
});

// POST /api/pasqcoin/buy - Usuário compra Pasqcoins com saldo da conta ou PIX
app.post('/api/pasqcoin/buy', (req, res) => {
  try {
    const { userId, amountCoins, paymentMethod } = req.body;
    if (!userId || !amountCoins) {
      return res.status(400).json({ error: 'userId e amountCoins são obrigatórios.' });
    }

    const result = dbManager.buyPasqcoin(userId, parseInt(amountCoins, 10), paymentMethod || 'balance');

    // Atualiza cache em memória
    const memUser = users.get(userId);
    if (memUser) {
      memUser.pasqcoins = result.user.pasqcoins;
      memUser.balance = result.user.balance;
    }

    broadcastGlobal({
      type: 'pasqcoin_purchased',
      userId,
      amountCoins,
      settings: result.settings,
    });

    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Erro ao adquirir Pasqcoins.' });
  }
});

// POST /api/admin/pasqcoin/credit-user - Super Admin bonifica/concede Pasqcoins a um usuário
app.post('/api/admin/pasqcoin/credit-user', (req, res) => {
  try {
    const { userId, amountCoins, notes } = req.body;
    if (!userId || !amountCoins) {
      return res.status(400).json({ error: 'userId e amountCoins são obrigatórios.' });
    }

    const result = dbManager.adminCreditPasqcoins(userId, parseInt(amountCoins, 10), notes);

    const memUser = users.get(userId);
    if (memUser) {
      memUser.pasqcoins = result.user.pasqcoins;
    }

    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Erro ao creditar Pasqcoins ao usuário.' });
  }
});

// GET /api/admin/mercadopago/settings - Super Admin consulta credenciais do ambiente solicitado
app.get('/api/admin/mercadopago/settings', (req, res) => {
  const requested = String(req.query.environment || '').toLowerCase();
  const environment = requested === 'test' || requested === 'production' ? requested : undefined;
  res.json(dbManager.getMercadoPagoSettings(environment as 'test' | 'production' | undefined));
});

// PUT /api/admin/mercadopago/environment - Alterna o ambiente ativo sem sobrescrever credenciais
app.put('/api/admin/mercadopago/environment', (req, res) => {
  const requested = String(req.body.environment || '').toLowerCase();
  if (requested !== 'test' && requested !== 'production') {
    return res.status(400).json({ error: 'Ambiente inválido. Use test ou production.' });
  }
  const settings = dbManager.setMercadoPagoActiveEnvironment(requested);
  const logItem: AuditLog = {
    id: `log_mp_env_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'MERCADOPAGO_ENVIRONMENT_CHANGED',
    actor: 'Super Admin',
    details: `Ambiente ativo Mercado Pago alterado para ${requested === 'test' ? 'TESTE' : 'PRODUÇÃO'}.`,
    level: 'security',
  };
  auditLogs.unshift(logItem);
  dbManager.addAuditLog(logItem);
  res.json({ success: true, settings });
});

// PUT /api/admin/mercadopago/settings - Salva SOMENTE o ambiente selecionado e o torna ativo
app.put('/api/admin/mercadopago/settings', (req, res) => {
  const { publicKey, accessToken, webhookUrl, redirectUrl, sandboxMode } = req.body;
  const requested = String(req.body.environment || '').toLowerCase();
  const environment: 'test' | 'production' = requested === 'test' || requested === 'production'
    ? requested
    : (sandboxMode === true ? 'test' : 'production');

  const current = dbManager.getMercadoPagoSettings(environment);
  const updated = dbManager.saveMercadoPagoSettings({
    publicKey: typeof publicKey === 'string' ? publicKey.trim() : current.publicKey,
    accessToken: typeof accessToken === 'string' ? accessToken.trim() : current.accessToken,
    webhookUrl: typeof webhookUrl === 'string' ? webhookUrl.trim() : current.webhookUrl,
    redirectUrl: typeof redirectUrl === 'string' ? redirectUrl.trim() : current.redirectUrl,
    sandboxMode: environment === 'test',
    environment,
  }, environment);

  const logItem: AuditLog = {
    id: `log_mp_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'MERCADOPAGO_SETTINGS_UPDATED',
    actor: 'Super Admin',
    details: `Configurações Mercado Pago atualizadas para o ambiente ${environment === 'test' ? 'TESTE' : 'PRODUÇÃO'} (Webhook: ${updated.webhookUrl}).`,
    level: 'security',
  };
  auditLogs.unshift(logItem);
  dbManager.addAuditLog(logItem);

  res.json({ success: true, settings: updated });
});

// POST /api/admin/mercadopago/test - Testa o token do ambiente atualmente exibido no painel
app.post('/api/admin/mercadopago/test', async (req, res) => {
  const requested = String(req.body.environment || '').toLowerCase();
  const environment: 'test' | 'production' = requested === 'test' ? 'test' : 'production';
  const { accessToken } = req.body;
  const token = accessToken || dbManager.getMercadoPagoSettings(environment).accessToken;

  if (!token) {
    return res.status(400).json({ error: `Nenhum Access Token informado para o ambiente ${environment === 'test' ? 'TESTE' : 'PRODUÇÃO'}.` });
  }

  try {
    const mpRes = await fetch('https://api.mercadopago.com/users/me', {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (mpRes.ok) {
      const data = await mpRes.json();
      return res.json({
        success: true,
        message: `Conexão com o Mercado Pago (${environment === 'test' ? 'TESTE' : 'PRODUÇÃO'}) bem-sucedida!`,
        seller: { id: data.id, nickname: data.nickname, email: data.email },
      });
    }

    const errData = await mpRes.json().catch(() => ({}));
    return res.json({
      success: false,
      message: errData.message || `Credenciais inválidas ou token expirado no ambiente ${environment === 'test' ? 'TESTE' : 'PRODUÇÃO'}.`,
    });
  } catch (err: any) {
    return res.json({ success: false, message: `Erro ao contatar API do Mercado Pago: ${err.message}` });
  }
});

// GET /api/admin/transactions - Lista todas as transações de recarga
app.get('/api/admin/transactions', (req, res) => {
  res.json(dbManager.getRechargeTransactions());
});

// ==============================================================================
// PASQCOIN CONSUMPTION NO CHAT
// ==============================================================================
app.post('/api/pasqcoin/consume', (req, res) => {
  try {
    const { userId, roomId, seconds } = req.body;
    if (!userId) return res.status(400).json({ error: 'userId obrigatório' });
    const result = dbManager.consumePasqcoinForChat(userId, roomId || 'general', seconds);
    const memUser = users.get(userId);
    if (memUser) {
      memUser.pasqcoins = result.user.pasqcoins;
    }
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Erro ao consumir Pasqcoin' });
  }
});

// ==============================================================================
// RESET DE 11 CÓDIGOS DESCARTÁVEIS COM ENVIO POR E-MAIL E ANEXO TXT
// ==============================================================================
app.post('/api/admin/users/:id/reset-disposable-codes', (req, res) => {
  const resetResult = dbManager.resetUserDisposableCodes(req.params.id);
  if (!resetResult) {
    return res.status(404).json({ error: 'Usuário não encontrado para redefinição de códigos.' });
  }

  const { user, codes, txtContent } = resetResult;

  // Atualiza cache em memória
  const memUser = users.get(user.id);
  if (memUser) {
    memUser.disposableCodes = user.disposableCodes;
  }

  // Notificação de segurança enviada por e-mail com anexo
  const notif: SecurityNotification = {
    id: `sec_reset_${Date.now()}`,
    userId: user.id,
    userEmail: user.googleEmail,
    type: 'disposable_code_used',
    title: 'Novos 11 Códigos Descartáveis 2FA Emitidos (Anexo .txt Enviado)',
    message: `O Super Administrador gerou 11 novos códigos de emergência para sua conta. O arquivo codigos_2fa_descartaveis_chamasso.txt foi despachado para o e-mail cadastrado (${user.googleEmail}).`,
    timestamp: new Date().toISOString(),
    read: false,
  };
  securityNotifications.unshift(notif);
  dbManager.addSecurityNotification(notif);

  const logItem: AuditLog = {
    id: `log_reset_codes_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'DISPOSABLE_CODES_RESET_AND_EMAILED',
    actor: 'Super Admin',
    details: `11 novos códigos descartáveis gerados e despachados para o e-mail ${user.googleEmail} com arquivo codigos_2fa_descartaveis_chamasso.txt em anexo.`,
    level: 'security',
  };
  auditLogs.unshift(logItem);
  dbManager.addAuditLog(logItem);

  broadcastGlobal({
    type: 'user_codes_reset',
    userId: user.id,
    userEmail: user.googleEmail,
  });

  res.json({
    success: true,
    message: `11 novos códigos provisórios gerados e enviados para o e-mail cadastrado (${user.googleEmail}) com o arquivo TXT anexo.`,
    user,
    codes,
    email: user.googleEmail,
    fileName: 'codigos_2fa_descartaveis_chamasso.txt',
    txtContent,
  });
});

// Download do arquivo .txt com os 11 códigos descartáveis
app.get('/api/admin/users/:id/download-disposable-codes-txt', (req, res) => {
  const user = dbManager.getUser(req.params.id);
  if (!user) {
    return res.status(404).send('Usuário não encontrado.');
  }

  const codes = (user.disposableCodes || []).map((c) => c.code);
  const txtContent = `=====================================================================
CHAMASSO LIVE CHAT - REDE SOCIAL & SEGURANÇA 2FA
CÓDIGOS PROVISÓRIOS / DESCARTÁVEIS DE RECUPERAÇÃO E ACESSO
=====================================================================

Usuário: ${user.name} ${user.lastName}
E-mail: ${user.googleEmail}
CPF: ${user.cpf || 'Não informado'}
Data de Emissão: ${new Date().toLocaleString('pt-BR')}
Domínio do Sistema: chamasso.pasquared.space

INSTRUÇÕES IMPORTANTES:
1. Estes 11 códigos de 8 dígitos são de uso único e emergencial.
2. Cada código pode ser utilizado apenas UMA única vez para autenticação em 2 etapas.
3. Guarde este arquivo em local seguro e confidencial. Não compartilhe com terceiros.
4. Quando restar apenas 1 código, solicite nova redefinição na administração.

LISTA DE 11 CÓDIGOS DESCARTÁVEIS VÁLIDOS:
---------------------------------------------------------------------
${codes.map((c, idx) => `[ Código ${String(idx + 1).padStart(2, '0')} / 11 ] : ${c}`).join('\n')}
---------------------------------------------------------------------

Suporte Técnico Chamasso: suporte@chamasso.pasquared.space
Servidor Seguro: https://chamasso.pasquared.space
=====================================================================`;

  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="codigos_2fa_descartaveis_chamasso.txt"`);
  res.send(txtContent);
});

// ==============================================================================
// BACKUP DE SEGURANÇA E SINCRONIZAÇÃO NA NUVEM SUPABASE
// ==============================================================================
app.get('/api/admin/supabase/status', (req, res) => {
  const config = supabaseBackupService.getConfig();
  const history = supabaseBackupService.getHistory();
  res.json({
    status: 'connected',
    config,
    history,
    supabaseUrl: config.supabaseUrl,
    anonKeyConfigured: !!config.anonKey,
    serviceRoleConfigured: !!config.serviceRoleKey,
    nextSyncAt: config.nextSyncAt,
  });
});

app.post('/api/admin/supabase/config', (req, res) => {
  try {
    const { supabaseUrl, anonKey, serviceRoleKey, dbHost, dbPort, dbUser, dbPassword, dbName } = req.body;
    const updated = supabaseBackupService.updateConfig({
      supabaseUrl: supabaseUrl || undefined,
      anonKey: anonKey || undefined,
      serviceRoleKey: serviceRoleKey || undefined,
      dbHost: dbHost || undefined,
      dbPort: dbPort ? parseInt(dbPort, 10) : undefined,
      dbUser: dbUser || undefined,
      dbPassword: dbPassword || undefined,
      dbName: dbName || undefined,
    });

    const logItem: AuditLog = {
      id: `log_supa_cfg_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'SUPABASE_CONFIG_UPDATED',
      actor: 'Super Admin',
      details: `Credenciais do Supabase atualizadas pelo painel Super Admin (URL: ${updated.supabaseUrl}).`,
      level: 'info',
    };
    auditLogs.unshift(logItem);
    dbManager.addAuditLog(logItem);

    res.json({ success: true, message: 'Credenciais do Supabase salvas com sucesso!', config: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Erro ao salvar credenciais do Supabase' });
  }
});

app.post('/api/admin/supabase/test-connection', async (req, res) => {
  try {
    const testResult = await supabaseBackupService.testConnection();
    const logItem: AuditLog = {
      id: `log_supa_test_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'SUPABASE_CONNECTION_TEST',
      actor: 'Super Admin',
      details: `Teste de conexão com Supabase: ${testResult.success ? 'SUCESSO' : 'FALHA'} (${testResult.latencyMs}ms).`,
      level: testResult.success ? 'info' : 'warn',
    };
    auditLogs.unshift(logItem);
    dbManager.addAuditLog(logItem);

    res.json(testResult);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Erro ao testar conexão com Supabase' });
  }
});

app.post('/api/admin/supabase/sync', async (req, res) => {
  try {
    const result = await supabaseBackupService.syncWithCloud('admin_button');
    const logItem: AuditLog = {
      id: `log_supa_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'SUPABASE_CLOUD_SYNC_COMPLETED',
      actor: 'Super Admin',
      details: `Sincronização com Supabase executada: ${result.message}`,
      level: 'info',
    };
    auditLogs.unshift(logItem);
    dbManager.addAuditLog(logItem);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Erro ao sincronizar com o Supabase' });
  }
});

app.post('/api/admin/supabase/populate', async (req, res) => {
  try {
    const result = await supabaseBackupService.populateSupabaseFromLocal();
    const logItem: AuditLog = {
      id: `log_supa_pop_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'SUPABASE_TABLES_POPULATED',
      actor: 'Super Admin',
      details: `Tabelas do Supabase criadas e populadas a partir do banco local (${result.totalRecords} registros).`,
      level: 'info',
    };
    auditLogs.unshift(logItem);
    dbManager.addAuditLog(logItem);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Erro ao popular tabelas no Supabase' });
  }
});

app.post('/api/admin/supabase/restore', async (req, res) => {
  try {
    const result = await supabaseBackupService.restoreFromCloud(true);
    const logItem: AuditLog = {
      id: `log_supa_res_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'SUPABASE_CLOUD_DATA_RESTORED',
      actor: 'Super Admin',
      details: `Recuperação de contingência executada com sucesso a partir da cópia de segurança na nuvem (${result.recordsCount} registros).`,
      level: 'warn',
    };
    auditLogs.unshift(logItem);
    dbManager.addAuditLog(logItem);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Erro ao restaurar banco de dados' });
  }
});

// ==============================================================================
// FIREWALL DE SEGURANÇA (DDoS, PHISHING, BRUTE-FORCE) & PAINEL DE MONITORAMENTO
// ==============================================================================
app.get('/api/admin/firewall/status', (req, res) => {
  res.json({
    stats: firewallService.getStats(),
    blockedIps: firewallService.getBlockedIps(),
    securityEvents: firewallService.getSecurityEvents(50),
    config: firewallService.getConfig(),
  });
});

app.post('/api/admin/firewall/unblock-ip', (req, res) => {
  const { ip } = req.body;
  if (!ip) return res.status(400).json({ error: 'IP é obrigatório.' });

  const unblocked = firewallService.unblockIp(ip);
  const logItem: AuditLog = {
    id: `log_unblock_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'FIREWALL_IP_UNBLOCKED',
    actor: 'Super Admin',
    details: `IP ${ip} foi desbloqueado manualmente pelo Super Administrador.`,
    level: 'security',
  };
  auditLogs.unshift(logItem);
  dbManager.addAuditLog(logItem);

  res.json({ success: true, unblocked, ip, message: `IP ${ip} desbloqueado com sucesso.` });
});

app.post('/api/admin/firewall/block-ip', (req, res) => {
  const { ip, reason, attackType, isPermanent, durationMinutes } = req.body;
  if (!ip) return res.status(400).json({ error: 'IP é obrigatório.' });

  const record = firewallService.blockIp(
    ip,
    reason || 'Bloqueio manual pelo Super Admin',
    attackType || 'suspicious_flood',
    Boolean(isPermanent),
    durationMinutes ? parseInt(durationMinutes, 10) : 60
  );

  const logItem: AuditLog = {
    id: `log_block_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'FIREWALL_IP_BLOCKED',
    actor: 'Super Admin',
    details: `IP ${ip} bloqueado manualmente. Motivo: ${reason || 'Bloqueio administrativo'}.`,
    level: 'security',
  };
  auditLogs.unshift(logItem);
  dbManager.addAuditLog(logItem);

  res.json({ success: true, record });
});

app.post('/api/admin/firewall/simulate-test', (req, res) => {
  const { attackType } = req.body;
  const testIp = `192.0.2.${Math.floor(Math.random() * 200) + 10}`;
  let reason = '';
  let type: any = 'ddos';

  if (attackType === 'phishing') {
    type = 'phishing';
    reason = 'Detecção e bloqueio preventivo de payload malicioso com link suspeito de phishing.';
  } else if (attackType === 'brute_force') {
    type = 'brute_force';
    reason = '5 tentativas consecutivas de ataque por força bruta contra credenciais de login.';
  } else {
    type = 'ddos';
    reason = 'Disparo volumétrico anômalo de 150 reqs/segundo (DDoS HTTP Flood). Mitigado.';
  }

  const record = firewallService.blockIp(testIp, reason, type, false, 30, 'AttackSimulator/2.0');

  res.json({
    success: true,
    message: `Simulação de ataque [${type.toUpperCase()}] executada. O Firewall mitigou e adicionou o IP ${testIp} na lista de bloqueios.`,
    record,
    stats: firewallService.getStats(),
  });
});

app.put('/api/admin/firewall/config', (req, res) => {
  const updated = firewallService.updateConfig(req.body);
  res.json({ success: true, config: updated });
});

// ==============================================================================
// ÁREA FINANCEIRA (CONTAS A PAGAR, CONTAS A RECEBER E GESTÃO DE CLIENTES)
// ==============================================================================
app.get('/api/admin/financial/overview', (req, res) => {
  const billsToPay = dbManager.getBillsToPay();
  const billsToReceive = dbManager.getBillsToReceive();

  // Lista de todos os clientes registrados
  const allUsers = Array.from(users.values());
  const clients = allUsers.map((u) => ({
    id: u.id,
    name: `${u.name} ${u.lastName}`,
    email: u.googleEmail,
    cpf: u.cpf,
    formattedCpf: formatCPF(u.cpf),
    balance: u.balance || 0,
    isNegative: (u.balance || 0) < 0,
    isPositive: (u.balance || 0) > 0,
    isZero: (u.balance || 0) === 0,
    isBlocked: Boolean(u.isBlocked),
    blockReason: u.blockReason,
    isFreeAccess: Boolean(u.isFreeAccess),
    pasqcoins: u.pasqcoins || 0,
    firstInteractionAt: u.firstInteractionAt,
    rechargeExpiresAt: u.rechargeExpiresAt,
  }));

  // Resumo financeiro
  const totalToPayPending = billsToPay
    .filter((b) => b.status === 'pending')
    .reduce((sum, b) => sum + Number(b.amount || 0), 0);
  const totalToPayPaid = billsToPay
    .filter((b) => b.status === 'paid')
    .reduce((sum, b) => sum + Number(b.amount || 0), 0);

  const totalToReceivePending = billsToReceive
    .filter((b) => b.status === 'pending')
    .reduce((sum, b) => sum + Number(b.amount || 0), 0);
  const totalToReceiveReceived = billsToReceive
    .filter((b) => b.status === 'received')
    .reduce((sum, b) => sum + Number(b.amount || 0), 0);

  const positiveClientsCount = clients.filter((c) => c.balance > 0).length;
  const negativeClientsCount = clients.filter((c) => c.balance < 0).length;
  const freeAccessClientsCount = clients.filter((c) => c.isFreeAccess).length;
  const blockedClientsCount = clients.filter((c) => c.isBlocked).length;

  res.json({
    billsToPay,
    billsToReceive,
    clients,
    summary: {
      totalToPayPending,
      totalToPayPaid,
      totalToReceivePending,
      totalToReceiveReceived,
      projectedNetBalance: totalToReceiveReceived - totalToPayPaid,
      positiveClientsCount,
      negativeClientsCount,
      freeAccessClientsCount,
      blockedClientsCount,
    },
  });
});

// Contas a Pagar - Criar ou Atualizar
app.post('/api/admin/financial/bills-to-pay', (req, res) => {
  try {
    const saved = dbManager.saveBillToPay(req.body);
    res.json({ success: true, bill: saved });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Erro ao salvar conta a pagar.' });
  }
});

// Contas a Pagar - Excluir
app.delete('/api/admin/financial/bills-to-pay/:id', (req, res) => {
  const deleted = dbManager.deleteBillToPay(req.params.id);
  res.json({ success: deleted });
});

// Contas a Receber - Criar ou Atualizar
app.post('/api/admin/financial/bills-to-receive', (req, res) => {
  try {
    const saved = dbManager.saveBillToReceive(req.body);
    res.json({ success: true, bill: saved });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Erro ao salvar conta a receber.' });
  }
});

// Contas a Receber - Excluir
app.delete('/api/admin/financial/bills-to-receive/:id', (req, res) => {
  const deleted = dbManager.deleteBillToReceive(req.params.id);
  res.json({ success: deleted });
});

// Gerenciar Cliente: Bloquear, Desbloquear, Conceder Acesso Free sem custos, Ajustar Saldo
app.put('/api/admin/financial/client-status', (req, res) => {
  const { userId, isBlocked, isFreeAccess, blockReason, balanceAdjust } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'userId é obrigatório.' });
  }

  const updatedUser = dbManager.updateClientFinancialStatus(
    userId,
    typeof isBlocked === 'boolean' ? isBlocked : undefined,
    typeof isFreeAccess === 'boolean' ? isFreeAccess : undefined,
    blockReason,
    typeof balanceAdjust === 'number' ? balanceAdjust : undefined
  );

  if (!updatedUser) {
    return res.status(404).json({ error: 'Cliente não encontrado.' });
  }

  // Atualiza cache em memória
  const mem = users.get(userId);
  if (mem) {
    if (typeof isBlocked === 'boolean') mem.isBlocked = isBlocked;
    if (typeof isFreeAccess === 'boolean') mem.isFreeAccess = isFreeAccess;
    if (blockReason !== undefined) mem.blockReason = blockReason;
    if (typeof balanceAdjust === 'number') mem.balance = balanceAdjust;
  }

  const logItem: AuditLog = {
    id: `log_fin_client_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'CLIENT_FINANCIAL_STATUS_UPDATED',
    actor: 'Super Admin',
    details: `Cliente ${updatedUser.name} (${updatedUser.googleEmail}): Bloqueado=${updatedUser.isBlocked}, Acesso Free=${updatedUser.isFreeAccess}, Saldo=R$ ${updatedUser.balance}.`,
    level: 'info',
  };
  auditLogs.unshift(logItem);
  dbManager.addAuditLog(logItem);

  broadcastGlobal({
    type: 'client_status_changed',
    user: updatedUser,
  });

  res.json({ success: true, user: updatedUser });
});

// GET /api/users/:id/balance - Consulta saldo do usuário e regras ativas
app.get('/api/users/:id/balance', (req, res) => {
  const info = dbManager.getUserBalanceInfo(req.params.id);
  const memoryUser = users.get(req.params.id);
  if (memoryUser) {
    memoryUser.balance = info.balance;
    memoryUser.firstInteractionAt = info.firstInteractionAt;
    memoryUser.rechargeExpiresAt = info.rechargeExpiresAt;
  }
  res.json(info);
});

// POST /api/users/:id/first-interaction - Registra primeira entrada em sala/contato e inicia contagem de 30 dias
app.post('/api/users/:id/first-interaction', (req, res) => {
  const updatedUser = dbManager.registerFirstInteractionIfNeeded(req.params.id);
  if (updatedUser) {
    const memUser = users.get(req.params.id);
    if (memUser) {
      memUser.firstInteractionAt = updatedUser.firstInteractionAt;
      memUser.rechargeExpiresAt = updatedUser.rechargeExpiresAt;
    }
  }
  const info = dbManager.getUserBalanceInfo(req.params.id);
  res.json({ success: true, ...info });
});

// POST /api/users/:id/create-recharge-pix - Gera transação e QR Code PIX Mercado Pago
app.post('/api/users/:id/create-recharge-pix', async (req, res) => {
  const userId = req.params.id;
  const user = users.get(userId) || dbManager.getUser(userId);

  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const { amount, method } = req.body;
  const tariff = dbManager.getTariffSettings();
  const numAmount = Number(amount);

  if (isNaN(numAmount) || numAmount < tariff.minRechargeAmount) {
    return res.status(400).json({
      error: `O valor mínimo para recarga de créditos é de R$ ${tariff.minRechargeAmount.toFixed(2).replace('.', ',')}.`,
    });
  }

  const txId = `mp_tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const pixCopyPaste = `00020126580014br.gov.bcb.pix0136${txId}520400005303986540${numAmount.toFixed(2)}5802BR5917CHAMASSO LIVE CHAT6009SAO PAULO62070503***6304`;

  let qrCodeDataUrl = '';
  try {
    qrCodeDataUrl = await QRCode.toDataURL(pixCopyPaste, {
      errorCorrectionLevel: 'M',
      margin: 2,
      width: 280,
      color: {
        dark: '#020617',
        light: '#FFFFFF',
      },
    });
  } catch (qrErr) {
    console.error('Erro ao gerar QRCode:', qrErr);
  }

  dbManager.createRechargeTransaction({
    id: txId,
    userId,
    userName: `${user.name} ${user.lastName}`,
    userEmail: user.googleEmail,
    amount: numAmount,
    method: method || 'pix',
    status: 'pending',
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 1000 * 60 * 30).toISOString(),
    pixQrCodeUrl: qrCodeDataUrl,
    pixCopyPaste,
  });

  res.json({
    transactionId: txId,
    amount: numAmount,
    pixCopyPaste,
    pixQrCodeUrl: qrCodeDataUrl,
    minRechargeAmount: tariff.minRechargeAmount,
    status: 'pending',
  });
});

// POST /api/users/:id/recharge - Confirmação e crédito de saldo na carteira
app.post('/api/users/:id/recharge', (req, res) => {
  const userId = req.params.id;
  const { amount, transactionId, method } = req.body;

  const numAmount = Number(amount);
  if (isNaN(numAmount) || numAmount <= 0) {
    return res.status(400).json({ error: 'Valor de recarga inválido.' });
  }

  const updatedUser = dbManager.addUserBalance(userId, numAmount, transactionId, method || 'pix');
  if (!updatedUser) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const memUser = users.get(userId);
  if (memUser) {
    memUser.balance = updatedUser.balance;
    memUser.firstInteractionAt = updatedUser.firstInteractionAt;
    memUser.rechargeExpiresAt = updatedUser.rechargeExpiresAt;
  }

  auditLogs.unshift({
    id: `log_rec_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'USER_RECHARGE_APPROVED',
    actor: `${updatedUser.name} ${updatedUser.lastName}`,
    details: `Recarga aprovada de R$ ${numAmount.toFixed(2)} via ${method || 'PIX'}. Novo saldo: R$ ${updatedUser.balance.toFixed(2)}.`,
    level: 'info',
  });

  res.json({
    success: true,
    newBalance: updatedUser.balance,
    user: updatedUser,
  });
});

// POST /api/users/:id/deduct-minute - Desconta 1 minuto de interação se tarifação estiver ativa
app.post('/api/users/:id/deduct-minute', (req, res) => {
  const userId = req.params.id;
  const result = dbManager.deductMinuteBalance(userId);

  if (result.deducted || result.deductedPasqcoin) {
    const memUser = users.get(userId);
    if (memUser) {
      memUser.balance = result.balance;
      if (typeof result.pasqcoins === 'number') {
        memUser.pasqcoins = result.pasqcoins;
      }
    }
  }

  res.json(result);
});

// POST /api/payments/mercadopago/webhook - Endpoint de Webhooks do Mercado Pago
app.post('/api/payments/mercadopago/webhook', async (req, res) => {
  const body = req.body;
  const topic = req.query.topic || body?.type || body?.action;
  const id = req.query.id || body?.data?.id;

  console.log(`[Mercado Pago Webhook] Recebido evento: ${topic} - ID: ${id}`);

  // Se o webhook informar pagamento aprovado
  if (body?.action === 'payment.created' || body?.action === 'payment.updated') {
    // Processamento seguro do evento
  }

  res.status(200).json({ status: 'received' });
});

// ==============================================================================
// ROOMS & MODERATION ROUTES
// ==============================================================================

// GET /api/rooms
// Lista salas ativas
app.get('/api/rooms', (req, res) => {
  const roomList = Array.from(rooms.values()).map((r) => ({
    ...r,
    activeParticipantsCount: r.participants.length,
  }));
  res.json(roomList);
});

// POST /api/rooms
// Criar sala de bate-papo pública ou privada
app.post('/api/rooms', (req, res) => {
  try {
    const {
      name,
      description,
      category,
      type,
      creatorId,
      creatorName,
      creatorEmail,
      maxParticipants,
      state,
      stateName,
      city,
      theme,
      themeLabel,
    } = req.body;

    if (!name || !type || !creatorId) {
      return res.status(400).json({ error: 'Nome, tipo e criador são obrigatórios.' });
    }

    const roomId = `sala-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;

    const newRoom: Room = {
      id: roomId,
      name,
      description: description || 'Sala de bate-papo ao vivo chamasso.',
      category: category || 'paquera',
      type: type === 'private' ? 'private' : 'public',
      creatorId,
      creatorName: creatorName || 'Anfitrião',
      creatorEmail: creatorEmail || '',
      createdAt: new Date().toISOString(),
      maxParticipants: maxParticipants ? Number(maxParticipants) : 50,
      activeParticipantsCount: 0,
      participants: [],
      bans: [],
      state: state || undefined,
      stateName: stateName || undefined,
      city: city || undefined,
      theme: theme || undefined,
      themeLabel: themeLabel || undefined,
    };

    rooms.set(roomId, newRoom);
    dbManager.saveRoom(newRoom);
    roomMessages.set(roomId, [
      {
        id: `msg_create_${roomId}`,
        roomId,
        senderId: 'system',
        senderName: 'chamasso live chat',
        text: `Sala "${name}" criada pelo moderador ${creatorName}.`,
        timestamp: new Date().toISOString(),
      },
    ]);

    auditLogs.unshift({
      id: `log_room_${Date.now()}`,
      timestamp: new Date().toISOString(),
      action: 'ROOM_CREATED',
      actor: creatorName,
      details: `Sala ${newRoom.type === 'public' ? 'Pública' : 'Privada'} criada: "${name}" (${roomId})`,
      level: 'info',
    });

    res.json(newRoom);
  } catch (err: any) {
    res.status(500).json({ error: 'Erro ao criar sala.' });
  }
});

// POST /api/rooms/get-or-create-regional
// Obtém sala existente para estado/cidade/tema ou cria instantaneamente
app.post('/api/rooms/get-or-create-regional', (req, res) => {
  try {
    const {
      state,
      stateName,
      city,
      themeId,
      themeLabel,
      themeCategory,
      userId,
      userName,
      userEmail,
    } = req.body;

    if (!state || !city || !themeId) {
      return res.status(400).json({ error: 'Estado, cidade e tema são obrigatórios.' });
    }

    // Busca se já existe sala com esse estado, cidade e tema
    const existing = Array.from(rooms.values()).find((r) => {
      const matchState = r.state === state || (r.name.includes(state) && r.name.includes(city));
      const matchTheme = r.theme === themeId || r.name.toLowerCase().includes((themeLabel || '').toLowerCase());
      return matchState && matchTheme;
    });

    if (existing) {
      return res.json(existing);
    }

    // Se não existir, gera o nome e cria a sala regional imediatamente
    const themeIcons: Record<string, string> = {
      amizade_sincera: '☕',
      amizade_colorida: '🎨',
      amizade_carnaval: '🎭',
      amizade_anonovo: '🎆',
      paquera_sincera: '❤️',
      paquera_colorida: '🔥',
      paquera_carnaval: '🎭',
      paquera_anonovo: '🥂',
      paquera_namoro: '💍',
      amizade_geral: '💬',
      idade_18_25: '⚡',
      idade_26_35: '🌟',
      idade_36_49: '🍷',
      idade_50_plus: '👑',
    };

    const icon = themeIcons[themeId] || '💬';
    const roomName = `${icon} ${state} - ${city}: ${themeLabel || 'Bate-Papo'}`;
    const roomDescription = `Sala de bate-papo de ${city} (${stateName || state}) com tema ${themeLabel || 'Conversas'}. Aberta para áudio, vídeo, câmera e mensagens!`;

    const roomId = `sala-${state.toLowerCase()}-${themeId.replace(/_/g, '-')}-${Date.now().toString(36)}`;

    const newRoom: Room = {
      id: roomId,
      name: roomName,
      description: roomDescription,
      category: (themeCategory as any) || (themeId.startsWith('paquera') ? 'paquera' : 'amizade'),
      type: 'public',
      creatorId: userId || 'user_demo_1',
      creatorName: userName || 'Ukbelol Pasquared',
      creatorEmail: userEmail || 'rogeriogomes11@ukbelol.space',
      createdAt: new Date().toISOString(),
      maxParticipants: 75,
      activeParticipantsCount: 1,
      participants: [],
      bans: [],
      state,
      stateName: stateName || state,
      city,
      theme: themeId,
      themeLabel: themeLabel || themeId,
    };

    rooms.set(roomId, newRoom);
    dbManager.saveRoom(newRoom);
    roomMessages.set(roomId, [
      {
        id: `msg_create_${roomId}`,
        roomId,
        senderId: 'system',
        senderName: 'chamasso live chat',
        text: `Sala "${roomName}" aberta para ${city} (${state})! Respeite as regras e aproveite o chat.`,
        timestamp: new Date().toISOString(),
      },
    ]);

    res.json(newRoom);
  } catch (err: any) {
    res.status(500).json({ error: 'Erro ao obter ou criar sala regional.' });
  }
});

// GET /api/rooms/:id
app.get('/api/rooms/:id', (req, res) => {
  const room = rooms.get(req.params.id);
  if (!room) {
    return res.status(404).json({ error: 'Sala não encontrada.' });
  }

  // Verificar se o usuário solicitante está banido pelo moderador desta sala
  const userId = req.query.userId as string;
  if (userId) {
    const activeBan = moderatorBans.find(
      (b) =>
        b.userId === userId &&
        b.moderatorId === room.creatorId &&
        new Date(b.expiresAt).getTime() > Date.now()
    );

    if (activeBan) {
      return res.status(403).json({
        error: `Você está temporariamente bloqueado pelo moderador ${activeBan.moderatorName} até ${new Date(
          activeBan.expiresAt
        ).toLocaleString('pt-BR')}. Motivo: ${activeBan.reason}`,
        isBanned: true,
        banExpiresAt: activeBan.expiresAt,
      });
    }
  }

  const messages = roomMessages.get(req.params.id) || [];
  res.json({
    ...room,
    messages,
  });
});

// DELETE /api/rooms/:id
app.delete('/api/rooms/:id', (req, res) => {
  const room = rooms.get(req.params.id);
  if (!room) {
    return res.status(404).json({ error: 'Sala não encontrada.' });
  }

  rooms.delete(req.params.id);
  dbManager.deleteRoom(req.params.id);
  roomMessages.delete(req.params.id);
  dbManager.deleteRoomMessages(req.params.id);

  // Fecha eventuais WebSockets associados
  broadcastToRoom(req.params.id, {
    type: 'room_closed',
    message: 'Esta sala foi encerrada pelo moderador ou administrador.',
  });

  res.json({ success: true, message: 'Sala excluída com sucesso.' });
});

// REGRA DE SALA PRIVADA: Tempo limite de 400 segundos para resposta do anfitrião
const JOIN_REQUEST_TIMEOUT_SECONDS = 400;

// Rotina automática em segundo plano: expira e remove pedidos sem resposta após 400 segundos
function checkAndExpireJoinRequests() {
  const now = Date.now();
  for (const [, req] of joinRequests.entries()) {
    if (req.status === 'pending') {
      const elapsed = Math.floor((now - new Date(req.createdAt).getTime()) / 1000);
      if (elapsed >= JOIN_REQUEST_TIMEOUT_SECONDS) {
        req.status = 'expired';

        // Notifica o moderador da sala para remover o pedido da tela imediatamente
        broadcastToRoom(req.roomId, {
          type: 'join_request_expired',
          requestId: req.id,
          userId: req.userId,
          roomId: req.roomId,
          message: 'O pedido de entrada expirou após 400 segundos sem resposta do anfitrião.',
        });

        // Notifica globalmente para o pretendente ser avisado onde quer que esteja
        broadcastGlobal({
          type: 'join_request_expired',
          requestId: req.id,
          userId: req.userId,
          roomId: req.roomId,
          message: 'O pedido de entrada expirou após 400 segundos sem resposta do anfitrião. Você pode refazer a solicitação.',
        });
      }
    }
  }
}
setInterval(checkAndExpireJoinRequests, 1000);

// GET /api/rooms/:id/join-requests
// Retorna a lista de pedidos pendentes válidos (não expirados dentro dos 400 segundos) para o moderador
app.get('/api/rooms/:id/join-requests', (req, res) => {
  const now = Date.now();
  const list = Array.from(joinRequests.values())
    .filter((r) => r.roomId === req.params.id && r.status === 'pending')
    .filter((r) => {
      const elapsed = Math.floor((now - new Date(r.createdAt).getTime()) / 1000);
      return elapsed < JOIN_REQUEST_TIMEOUT_SECONDS;
    })
    .map((r) => {
      const elapsed = Math.floor((now - new Date(r.createdAt).getTime()) / 1000);
      return {
        ...r,
        secondsRemaining: Math.max(0, JOIN_REQUEST_TIMEOUT_SECONDS - elapsed),
        timeoutSeconds: JOIN_REQUEST_TIMEOUT_SECONDS,
      };
    });
  res.json(list);
});

// GET /api/rooms/:id/join-request-status
// Pretendente consulta o status do seu pedido e tempo restante de 400s
app.get('/api/rooms/:id/join-request-status', (req, res) => {
  const { userId, requestId } = req.query;
  let found: JoinRequest | null = null;
  if (requestId) {
    found = joinRequests.get(requestId as string) || null;
  } else if (userId) {
    const userReqs = Array.from(joinRequests.values()).filter(
      (r) => r.roomId === req.params.id && r.userId === userId
    );
    if (userReqs.length > 0) {
      userReqs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      found = userReqs[0];
    }
  }

  if (!found) {
    return res.json({ status: 'none', canRetry: true });
  }

  const now = Date.now();
  const elapsed = Math.floor((now - new Date(found.createdAt).getTime()) / 1000);
  if (found.status === 'pending' && elapsed >= JOIN_REQUEST_TIMEOUT_SECONDS) {
    found.status = 'expired';
  }

  const secondsRemaining = Math.max(0, JOIN_REQUEST_TIMEOUT_SECONDS - elapsed);
  res.json({
    requestId: found.id,
    status: found.status,
    secondsRemaining,
    timeoutSeconds: JOIN_REQUEST_TIMEOUT_SECONDS,
    createdAt: found.createdAt,
    expiresAt: found.expiresAt,
    canRetry: found.status === 'expired' || found.status === 'rejected',
  });
});

// POST /api/rooms/:id/join-request
// Solicitação de ingresso em sala privada com apresentação pessoal do pretendente (visível por 400s)
app.post('/api/rooms/:id/join-request', (req, res) => {
  const room = rooms.get(req.params.id);
  if (!room) {
    return res.status(404).json({ error: 'Sala não encontrada.' });
  }

  const { userId, userName, userEmail, presentationMessage, avatarUrl } = req.body;

  if (!userId || !presentationMessage) {
    return res.status(400).json({ error: 'A apresentação pessoal é obrigatória para ingressar nesta sala privada.' });
  }

  const now = Date.now();

  // Se o usuário já tiver uma solicitação anterior para esta sala:
  for (const existing of joinRequests.values()) {
    if (existing.roomId === room.id && existing.userId === userId && existing.status === 'pending') {
      const elapsed = Math.floor((now - new Date(existing.createdAt).getTime()) / 1000);
      if (elapsed < JOIN_REQUEST_TIMEOUT_SECONDS) {
        // Atualiza a mensagem e renova/informa o tempo restante
        existing.presentationMessage = presentationMessage;
        existing.userName = userName || existing.userName;
        const secondsRemaining = JOIN_REQUEST_TIMEOUT_SECONDS - elapsed;
        return res.json({
          success: true,
          requestId: existing.id,
          status: 'pending',
          secondsRemaining,
          timeoutSeconds: JOIN_REQUEST_TIMEOUT_SECONDS,
          createdAt: existing.createdAt,
          expiresAt: existing.expiresAt,
          message: 'Solicitação em andamento aguardando resposta do moderador.',
        });
      } else {
        // Já se passaram 400 segundos: marca como expirada e permite refazer imediatamente!
        existing.status = 'expired';
      }
    }
  }

  const requestId = `req_${now}_${userId}`;
  const createdAt = new Date(now).toISOString();
  const expiresAt = new Date(now + JOIN_REQUEST_TIMEOUT_SECONDS * 1000).toISOString();
  const request: JoinRequest = {
    id: requestId,
    roomId: room.id,
    userId,
    userName: userName || 'Visitante',
    userEmail: userEmail || '',
    presentationMessage,
    avatarUrl,
    status: 'pending',
    createdAt,
    expiresAt,
    timeoutSeconds: JOIN_REQUEST_TIMEOUT_SECONDS,
    secondsRemaining: JOIN_REQUEST_TIMEOUT_SECONDS,
  };

  joinRequests.set(requestId, request);

  // Notifica o moderador da sala via WebSocket
  broadcastToRoom(room.id, {
    type: 'new_join_request',
    request,
  });

  res.json({
    success: true,
    requestId,
    status: 'pending',
    createdAt,
    expiresAt,
    timeoutSeconds: JOIN_REQUEST_TIMEOUT_SECONDS,
    secondsRemaining: JOIN_REQUEST_TIMEOUT_SECONDS,
  });
});

// POST /api/rooms/:id/moderate-request
// Moderador aprova ou recusa a entrada de quem pediu ingresso (somente dentro dos 400 segundos)
app.post('/api/rooms/:id/moderate-request', (req, res) => {
  const { requestId, action, moderatorId } = req.body;
  const request = joinRequests.get(requestId);

  if (!request) {
    return res.status(404).json({ error: 'Solicitação não encontrada ou já respondida.' });
  }

  const elapsed = Math.floor((Date.now() - new Date(request.createdAt).getTime()) / 1000);
  if (request.status === 'expired' || elapsed >= JOIN_REQUEST_TIMEOUT_SECONDS) {
    request.status = 'expired';
    return res.status(410).json({
      error: 'Esta solicitação expirou após 400 segundos sem resposta do moderador e não pode mais ser aprovada.',
      status: 'expired',
    });
  }

  request.status = action === 'approve' ? 'approved' : 'rejected';

  // Notifica via WebSocket tanto a sala quanto o pretendente específico
  broadcastToRoom(request.roomId, {
    type: 'join_request_decision',
    requestId,
    userId: request.userId,
    status: request.status,
    message:
      request.status === 'approved'
        ? 'Seu pedido de ingresso foi aprovado pelo anfitrião!'
        : 'O anfitrião recusou seu pedido de entrada no momento.',
  });

  res.json({ success: true, status: request.status });
});

// POST /api/rooms/:id/ban-user
// Moderador bloqueia usuário por minutos, horas, dias ou meses de todas as suas salas
app.post('/api/rooms/:id/ban-user', (req, res) => {
  const { userId, userName, moderatorId, moderatorName, durationAmount, durationUnit, reason } = req.body;

  if (!userId || !moderatorId || !durationAmount || !durationUnit) {
    return res.status(400).json({ error: 'Dados insuficientes para aplicar bloqueio.' });
  }

  const now = new Date();
  const amount = Number(durationAmount);
  let expiresAt = new Date(now);

  switch (durationUnit) {
    case 'minutes':
      expiresAt.setMinutes(expiresAt.getMinutes() + amount);
      break;
    case 'hours':
      expiresAt.setHours(expiresAt.getHours() + amount);
      break;
    case 'days':
      expiresAt.setDate(expiresAt.getDate() + amount);
      break;
    case 'months':
      expiresAt.setMonth(expiresAt.getMonth() + amount);
      break;
    default:
      expiresAt.setHours(expiresAt.getHours() + 1);
  }

  const banRecord: ModeratorBan = {
    id: `ban_${Date.now()}`,
    userId,
    userName: userName || 'Usuário',
    moderatorId,
    moderatorName: moderatorName || 'Moderador',
    roomId: req.params.id,
    bannedAt: now.toISOString(),
    expiresAt: expiresAt.toISOString(),
    durationLabel: `${amount} ${durationUnit}`,
    reason: reason || 'Bloqueado pelo moderador da sala.',
  };

  moderatorBans.push(banRecord);

  // Envia evento de kick/ban para desconectar o usuário imediatamente da sala
  broadcastToRoom(req.params.id, {
    type: 'user_banned',
    userId,
    moderatorName,
    expiresAt: expiresAt.toISOString(),
    reason: banRecord.reason,
  });

  auditLogs.unshift({
    id: `log_ban_${Date.now()}`,
    timestamp: now.toISOString(),
    action: 'USER_BANNED_BY_MODERATOR',
    actor: moderatorName,
    details: `Usuário ${userName} bloqueado por ${amount} ${durationUnit}. Expira em: ${expiresAt.toLocaleString('pt-BR')}`,
    level: 'warn',
  });

  res.json({ success: true, ban: banRecord });
});

// POST /api/rooms/:id/upload
// Envio de arquivos no chat da sala (fotos png/gif/jpeg, áudios wav/mp3, vídeos mp4) - Limite estrito de 33 MB
app.post('/api/rooms/:id/upload', (req, res) => {
  const { fileName, fileType, fileSize, fileBase64, senderId, senderName, senderNickname } = req.body;

  if (!fileName || !fileBase64) {
    return res.status(400).json({ error: 'Arquivo inválido.' });
  }

  // "o tamanho máximo dos arquivos enviados não poderão ultrapassar 33 megas cada um"
  if (fileSize && fileSize > MAX_FILE_SIZE_BYTES) {
    return res.status(400).json({
      error: 'O tamanho máximo do arquivo não pode ultrapassar 33 MB.',
    });
  }

  // "arquivos de audio somente formato wav e mp3"
  const isAudio = fileType?.startsWith('audio/') || fileName.endsWith('.mp3') || fileName.endsWith('.wav');
  if (isAudio && !isAudioWavOrMp3(fileName, fileType)) {
    return res.status(400).json({
      error: 'Arquivos de áudio são permitidos exclusivamente nos formatos WAV e MP3.',
    });
  }

  const isAudioFile = isAudioWavOrMp3(fileName, fileType);
  const isVideoFile = isVideoMp4(fileName, fileType);
  const isImg = isImageValid(fileName, fileType);

  const message: ChatMessage = {
    id: `msg_file_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    roomId: req.params.id,
    senderId,
    senderName,
    senderNickname,
    text: isAudioFile
      ? `🎵 Enviou áudio (${fileName.toLowerCase().endsWith('.wav') ? 'WAV' : 'MP3'}): ${fileName}`
      : isVideoFile
      ? `🎬 Enviou vídeo (MP4): ${fileName}`
      : isImg
      ? `🖼️ Enviou imagem: ${fileName}`
      : `📎 Enviou arquivo: ${fileName}`,
    file: {
      name: fileName,
      url: fileBase64, // Data URL
      size: fileSize || 0,
      type: fileType || 'application/octet-stream',
    },
    audioAttachment: isAudioFile
      ? {
          name: fileName,
          url: fileBase64,
          format: fileName.toLowerCase().endsWith('.wav') ? 'wav' : 'mp3',
          size: fileSize || 0,
        }
      : undefined,
    timestamp: new Date().toISOString(),
  };

  const msgs = roomMessages.get(req.params.id) || [];
  msgs.push(message);
  roomMessages.set(req.params.id, msgs);

  broadcastToRoom(req.params.id, {
    type: 'new_chat_message',
    message,
  });

  res.json({ success: true, message });
});

// ==============================================================================
// SUPER ADMIN DASHBOARD ENDPOINTS
// ==============================================================================

app.get('/api/admin/users', (req, res) => {
  const userList = Array.from(users.values()).map((u) => ({
    id: u.id,
    name: u.name,
    lastName: u.lastName,
    birthDate: u.birthDate,
    cpf: u.cpf,
    formattedCpf: formatCPF(u.cpf),
    googleEmail: u.googleEmail,
    twoFactorEnabled: u.twoFactorEnabled,
    disposableCodesRemaining: (u.disposableCodes || []).filter((c) => !c.used).length,
    disposableCodesTotal: (u.disposableCodes || []).length,
    disposableCodes: u.disposableCodes,
    isBlocked: u.isBlocked,
    blockReason: u.blockReason,
    createdAt: u.createdAt,
  }));
  res.json(userList);
});

app.post('/api/admin/users', (req, res) => {
  const { name, lastName, birthDate, cpf, googleEmail } = req.body;
  const cleanCpfValue = cleanCPF(cpf);

  if (!isValidCPF(cleanCpfValue)) {
    return res.status(400).json({ error: 'CPF inválido.' });
  }

  const userId = `usr_admin_${Date.now()}`;
  const secret = generateBase32Secret(20);
  const codes = generate11DisposableCodes().map((c) => ({ code: c, used: false }));

  const newUser: User = {
    id: userId,
    name,
    lastName,
    birthDate,
    cpf: cleanCpfValue,
    googleEmail,
    twoFactorSecret: secret,
    twoFactorEnabled: true,
    disposableCodes: codes,
    isBlocked: false,
    createdAt: new Date().toISOString(),
  };

  users.set(userId, newUser);
  res.json(newUser);
});

app.put('/api/admin/users/:id', (req, res) => {
  const user = users.get(req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const { name, lastName, isBlocked, blockReason, resetDisposableCodes } = req.body;

  if (name) user.name = name;
  if (lastName) user.lastName = lastName;
  if (typeof isBlocked === 'boolean') {
    user.isBlocked = isBlocked;
    user.blockReason = blockReason || (isBlocked ? 'Bloqueado pelo Administrador.' : '');
  }
  if (resetDisposableCodes) {
    user.disposableCodes = generate11DisposableCodes().map((c) => ({ code: c, used: false }));
  }

  users.set(user.id, user);
  dbManager.saveUser(user);
  res.json(user);
});

app.delete('/api/admin/users/:id', (req, res) => {
  if (!users.has(req.params.id)) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }
  users.delete(req.params.id);
  dbManager.deleteUser(req.params.id);
  res.json({ success: true, message: 'Usuário removido pelo Super Admin.' });
});

app.get('/api/admin/stats', (req, res) => {
  res.json({
    system: {
      platform: 'Linux Debian 12 (Bookworm) / x86_64',
      webServer: 'Apache 2.4.59 (mod_proxy, mod_proxy_wstunnel, mod_ssl)',
      sslDomain: 'chamasso.pasquared.space',
      sslIssuer: "Let's Encrypt Authority",
      sslEmail: 'rogeriogomes11@ukbelol.space',
      processManager: 'PM2 v5.3+ (ecosystem.config.cjs)',
      nodeVersion: process.version,
      uptimeSeconds: Math.floor(process.uptime()),
      memoryUsageMB: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
    },
    counts: {
      totalUsers: users.size,
      totalRooms: rooms.size,
      activeBans: moderatorBans.length,
      auditLogsCount: auditLogs.length,
    },
  });
});

app.get('/api/admin/logs', (req, res) => {
  res.json({
    auditLogs: auditLogs.slice(0, 100),
    securityNotifications: securityNotifications.slice(0, 100),
  });
});

// ==============================================================================
// NÍVEIS DE RELACIONAMENTO & AMIZADES / BATE-PAPO
// ==============================================================================

// GET /api/relationship-levels
app.get('/api/relationship-levels', (req, res) => {
  res.json(Array.from(relationshipLevels.values()));
});

// POST /api/relationship-levels - Super Admin cria novo nível
app.post('/api/relationship-levels', (req, res) => {
  const { name, description, icon, color } = req.body;
  if (!name || !description) {
    return res.status(400).json({ error: 'Nome e descrição do nível são obrigatórios.' });
  }

  const id = `rel_custom_${Date.now()}`;
  const newLevel: RelationshipLevel = {
    id,
    name,
    description,
    icon: icon || '✨',
    color: color || '#22D3EE',
    isDefault: false,
    createdAt: new Date().toISOString(),
  };

  relationshipLevels.set(id, newLevel);
  dbManager.saveRelationshipLevel(newLevel);
  auditLogs.unshift({
    id: `log_rel_${Date.now()}`,
    timestamp: new Date().toISOString(),
    action: 'RELATIONSHIP_LEVEL_CREATED',
    actor: 'Super Admin',
    details: `Novo nível de relacionamento criado: "${name}" (${newLevel.icon})`,
    level: 'info',
  });

  res.json(newLevel);
});

// PUT /api/relationship-levels/:id
app.put('/api/relationship-levels/:id', (req, res) => {
  const level = relationshipLevels.get(req.params.id);
  if (!level) {
    return res.status(404).json({ error: 'Nível de relacionamento não encontrado.' });
  }

  const { name, description, icon, color } = req.body;
  if (name) level.name = name;
  if (description) level.description = description;
  if (icon) level.icon = icon;
  if (color) level.color = color;

  relationshipLevels.set(level.id, level);
  dbManager.saveRelationshipLevel(level);
  res.json(level);
});

// DELETE /api/relationship-levels/:id
app.delete('/api/relationship-levels/:id', (req, res) => {
  const level = relationshipLevels.get(req.params.id);
  if (!level) {
    return res.status(404).json({ error: 'Nível de relacionamento não encontrado.' });
  }
  relationshipLevels.delete(req.params.id);
  dbManager.deleteRelationshipLevel(req.params.id);
  res.json({ success: true, message: 'Nível de relacionamento excluído.' });
});

// POST /api/relationship-levels/reset-defaults
app.post('/api/relationship-levels/reset-defaults', (req, res) => {
  relationshipLevels.clear();
  initSeedData();
  dbManager.setAllRelationshipLevels(Array.from(relationshipLevels.values()));
  res.json(Array.from(relationshipLevels.values()));
});

// GET /api/users/status-list
// Lista usuários para descoberta no chat com status: online, ocupado, em_almoco, ausente, invisivel
app.get('/api/users/status-list', (req, res) => {
  const excludeUserId = req.query.excludeUserId as string;
  const list = Array.from(users.values())
    .filter((u) => u.id !== excludeUserId)
    .map((u) => ({
      id: u.id,
      name: u.name,
      lastName: u.lastName,
      googleEmail: u.googleEmail,
      status: u.status || 'online',
      bio: u.bio || '',
      interests: u.interests || [],
      avatarUrl: u.avatarUrl,
    }));
  res.json(list);
});

// PUT /api/users/:id/status
// Usuário altera seu status no chat
app.put('/api/users/:id/status', (req, res) => {
  const user = users.get(req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const { status } = req.body;
  const validStatuses: UserStatus[] = ['online', 'ocupado', 'em_almoco', 'ausente', 'invisivel'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: 'Status inválido.' });
  }

  user.status = status;
  users.set(user.id, user);

  broadcastGlobal({
    type: 'user_status_changed',
    userId: user.id,
    status,
    userName: `${user.name} ${user.lastName}`,
  });

  res.json({ success: true, status: user.status });
});

// ==============================================================================
// REDE SOCIAL & PROFILE LANDING PAGE ENDPOINTS
// ==============================================================================

// GET /api/feed - Feed de publicações da Rede Social Chamasso
app.get('/api/feed', (req, res) => {
  const { authorId, viewerId } = req.query;
  const posts = dbManager.getSocialPosts({
    authorId: authorId ? String(authorId) : undefined,
    viewerId: viewerId ? String(viewerId) : undefined,
  });
  res.json(posts);
});

// POST /api/feed/posts - Criar publicação na linha do tempo / feed social
app.post('/api/feed/posts', (req, res) => {
  try {
    const {
      authorId,
      authorName,
      authorLastName,
      authorAvatar,
      authorEmail,
      authorNickname,
      content,
      mediaType,
      mediaUrl,
      mediaName,
      privacy,
    } = req.body;

    if (!authorId || (!content?.trim() && !mediaUrl)) {
      return res.status(400).json({ error: 'O post precisa de um autor e de conteúdo ou mídia.' });
    }

    const postId = `post_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newPost: SocialPost = {
      id: postId,
      authorId,
      authorName: authorName || 'Membro',
      authorLastName: authorLastName || '',
      authorAvatar: authorAvatar || '/fenix_chamas.gif',
      authorEmail: authorEmail || '',
      authorNickname: authorNickname || '',
      content: content ? content.trim() : '',
      mediaType: mediaType || undefined,
      mediaUrl: mediaUrl || undefined,
      mediaName: mediaName || undefined,
      privacy: privacy === 'friends' ? 'friends' : 'public',
      createdAt: new Date().toISOString(),
      reactions: {},
      comments: [],
      sharesCount: 0,
    };

    dbManager.saveSocialPost(newPost);

    broadcastGlobal({
      type: 'new_social_post',
      post: newPost,
    });

    res.json({ success: true, post: newPost });
  } catch (err: any) {
    console.error('Erro ao criar post no feed:', err);
    res.status(500).json({ error: 'Falha ao publicar na rede social.' });
  }
});

// POST /api/feed/posts/:id/react - Reagir a publicação (Like, Love, Care, Haha, Wow, Sad, Angry)
app.post('/api/feed/posts/:id/react', (req, res) => {
  const { userId, reaction } = req.body;
  const postId = req.params.id;

  if (!userId || !reaction) {
    return res.status(400).json({ error: 'userId e reaction são obrigatórios.' });
  }

  const validReactions: SocialReactionType[] = ['like', 'love', 'care', 'haha', 'wow', 'sad', 'angry'];
  if (!validReactions.includes(reaction)) {
    return res.status(400).json({ error: 'Tipo de reação inválido.' });
  }

  const updated = dbManager.reactToPost(postId, userId, reaction);
  if (!updated) {
    return res.status(404).json({ error: 'Publicação não encontrada.' });
  }

  broadcastGlobal({
    type: 'social_post_reaction_updated',
    postId,
    userId,
    reaction,
    reactions: updated.reactions,
  });

  res.json({ success: true, post: updated });
});

// POST /api/feed/posts/:id/comments - Comentar em publicação
app.post('/api/feed/posts/:id/comments', (req, res) => {
  const { authorId, authorName, authorAvatar, content } = req.body;
  const postId = req.params.id;

  if (!authorId || !content?.trim()) {
    return res.status(400).json({ error: 'Comentário não pode estar vazio.' });
  }

  const newComment: SocialComment = {
    id: `comm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    postId,
    authorId,
    authorName: authorName || 'Membro',
    authorAvatar: authorAvatar || '/fenix_chamas.gif',
    content: content.trim(),
    createdAt: new Date().toISOString(),
    likes: [],
  };

  const updated = dbManager.commentOnPost(postId, newComment);
  if (!updated) {
    return res.status(404).json({ error: 'Publicação não encontrada.' });
  }

  broadcastGlobal({
    type: 'new_social_comment',
    postId,
    comment: newComment,
  });

  res.json({ success: true, post: updated, comment: newComment });
});

// DELETE /api/feed/posts/:id - Remover publicação
app.delete('/api/feed/posts/:id', (req, res) => {
  const { requesterId } = req.body;
  const postId = req.params.id;
  const ok = dbManager.deleteSocialPost(postId, requesterId);
  if (!ok) {
    return res.status(403).json({ error: 'Sem autorização para excluir esta publicação.' });
  }

  broadcastGlobal({
    type: 'social_post_deleted',
    postId,
  });

  res.json({ success: true, postId });
});

// GET /api/users/:id/landing-page - Retorna Landing Page do perfil do usuário
app.get('/api/users/:id/landing-page', (req, res) => {
  const targetId = req.params.id;
  const viewerId = req.query.viewerId ? String(req.query.viewerId) : undefined;

  const landingData = dbManager.getSocialLandingPageData(targetId, viewerId);
  if (!landingData) {
    return res.status(404).json({ error: 'Perfil de usuário não encontrado.' });
  }

  res.json(landingData);
});

// PUT /api/users/:id/profile - Atualiza dados do perfil (Capa, Avatar, Bio, Cidade, Trabalho, etc.)
app.put('/api/users/:id/profile', (req, res) => {
  const targetId = req.params.id;
  const updatedUser = dbManager.updateUserProfile(targetId, req.body);
  if (!updatedUser) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  // Atualiza também no mapa em memória do servidor
  const existing = users.get(targetId);
  if (existing) {
    users.set(targetId, { ...existing, ...updatedUser });
  }

  res.json({ success: true, user: updatedUser });
});

// PUT /api/users/:id/privacy - Configura privacidade do perfil (Público vs Restrito)
app.put('/api/users/:id/privacy', (req, res) => {
  const targetId = req.params.id;
  const { profilePrivacy, privacySettings } = req.body;

  const updatedUser = dbManager.updateUserPrivacy(targetId, profilePrivacy, privacySettings);
  if (!updatedUser) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const existing = users.get(targetId);
  if (existing) {
    users.set(targetId, { ...existing, ...updatedUser });
  }

  res.json({ success: true, user: updatedUser });
});

// ==============================================================================
// PASQCOIN NO CHAT: CONTAGEM PROGRESSIVA AO ENVIAR PRIMEIRA MENSAGEM
// ==============================================================================

// POST /api/pasqcoin/chat-session/first-message - Notifica primeira mensagem enviada no chat
app.post('/api/pasqcoin/chat-session/first-message', (req, res) => {
  const { userId, roomId } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'userId obrigatório.' });
  }

  const user = users.get(userId) || dbManager.getUser(userId);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const pasqSettings = dbManager.getPasqcoinSettings();

  res.json({
    success: true,
    hasStarted: true,
    secondsPerCoin: pasqSettings.secondsPerCoin || 60,
    pasqcoinsRemaining: user.pasqcoins || 0,
    canStartCount: (user.pasqcoins || 0) > 0,
    message: 'Primeira mensagem detectada. Contagem progressiva ativada no painel administrativo do chat.',
  });
});

// POST /api/pasqcoin/chat-session/consume-coin - Debita 1 Pasqcoin ao atingir o limite de segundos
app.post('/api/pasqcoin/chat-session/consume-coin', (req, res) => {
  const { userId, roomId, secondsElapsed } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'userId obrigatório.' });
  }

  const user = users.get(userId) || dbManager.getUser(userId);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const pasqSettings = dbManager.getPasqcoinSettings();
  const currentCoins = user.pasqcoins || 0;

  if (currentCoins <= 0) {
    return res.status(400).json({
      error: 'Saldo de Pasqcoins esgotado. Recarregue para continuar a contagem progressiva.',
      pasqcoinsRemaining: 0,
    });
  }

  // Desconta 1 Pasqcoin
  const newCoins = Math.max(0, currentCoins - 1);
  user.pasqcoins = newCoins;
  users.set(userId, user);
  dbManager.saveUser(user);

  // Registra a transação de uso
  const tx: PasqcoinTransaction = {
    id: `tx_pasq_use_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId,
    userName: `${user.name} ${user.lastName}`,
    userEmail: user.googleEmail,
    type: 'chat_usage',
    amountCoins: -1,
    chatDurationSeconds: secondsElapsed || pasqSettings.secondsPerCoin || 60,
    roomId: roomId || undefined,
    timestamp: new Date().toISOString(),
    balanceAfter: newCoins,
  };
  dbManager.addPasqcoinTransaction(tx);

  res.json({
    success: true,
    deducted: 1,
    pasqcoinsRemaining: newCoins,
    secondsPerCoin: pasqSettings.secondsPerCoin || 60,
    hasMoreCoins: newCoins > 0,
  });
});

// GET /api/users/:id/friendship-requests
app.get('/api/users/:id/friendship-requests', (req, res) => {
  const userId = req.params.id;
  const all = Array.from(friendshipRequests.values());
  const incoming = all.filter((r) => r.receiverId === userId);
  const outgoing = all.filter((r) => r.senderId === userId);

  res.json({ incoming, outgoing });
});

// POST /api/friendship-requests
// Solicitar amizade com alguém do bate-papo (online, ocupado, almoço, ausente, invisível)
app.post('/api/friendship-requests', (req, res) => {
  const { senderId, receiverId, relationshipLevelId, senderGroupId, message } = req.body;

  if (!senderId || !receiverId || !relationshipLevelId) {
    return res.status(400).json({ error: 'Dados insuficientes para enviar a solicitação.' });
  }

  if (senderId === receiverId) {
    return res.status(400).json({ error: 'Você não pode enviar solicitação para si mesmo.' });
  }

  const sender = users.get(senderId);
  const receiver = users.get(receiverId);
  const relLevel = relationshipLevels.get(relationshipLevelId);

  if (!sender || !receiver || !relLevel) {
    return res.status(404).json({ error: 'Remetente, destinatário ou nível de relacionamento não encontrado.' });
  }

  // Verifica se já existe solicitação pendente
  const existing = Array.from(friendshipRequests.values()).find(
    (r) =>
      r.status === 'pending' &&
      ((r.senderId === senderId && r.receiverId === receiverId) ||
        (r.senderId === receiverId && r.receiverId === senderId))
  );

  if (existing) {
    return res.status(400).json({ error: 'Já existe uma solicitação pendente entre vocês.' });
  }

  const senderGroups = sender.contactGroups || [
    { id: 'grp_geral', name: 'Geral', icon: '📁', color: '#94A3B8' },
  ];
  const targetGroup = senderGroups.find((g) => g.id === senderGroupId) || senderGroups[0];

  const reqId = `freq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const newRequest: FriendshipRequest = {
    id: reqId,
    senderId: sender.id,
    senderName: sender.name,
    senderLastName: sender.lastName,
    senderAvatar: sender.avatarUrl,
    senderStatus: sender.status || 'online',
    receiverId: receiver.id,
    receiverName: receiver.name,
    receiverLastName: receiver.lastName,
    receiverAvatar: receiver.avatarUrl,
    receiverStatus: receiver.status || 'online',
    relationshipLevelId: relLevel.id,
    relationshipLevelName: relLevel.name,
    relationshipLevelIcon: relLevel.icon,
    relationshipLevelColor: relLevel.color,
    senderGroupId: targetGroup.id,
    senderGroupName: targetGroup.name,
    message: message || '',
    status: 'pending',
    createdAt: new Date().toISOString(),
  };

  friendshipRequests.set(reqId, newRequest);

  broadcastGlobal({
    type: 'new_friendship_request',
    request: newRequest,
  });

  res.json({ success: true, request: newRequest });
});

// POST /api/friendship-requests/:id/respond
// Quem recebeu o convite aceita ou não o pedido, ou deixa sem resposta.
// Se aceitar, o usuário fará parte do grupo escolhido por quem solicitou, e quem aceitou também define seu grupo.
app.post('/api/friendship-requests/:id/respond', (req, res) => {
  const { action, receiverGroupId } = req.body;
  const request = friendshipRequests.get(req.params.id);

  if (!request) {
    return res.status(404).json({ error: 'Solicitação não encontrada.' });
  }

  if (request.status !== 'pending') {
    return res.status(400).json({ error: 'Esta solicitação já foi respondida.' });
  }

  if (action === 'reject') {
    request.status = 'rejected';
    request.respondedAt = new Date().toISOString();
    friendshipRequests.set(request.id, request);

    broadcastGlobal({
      type: 'friendship_request_rejected',
      requestId: request.id,
      senderId: request.senderId,
      receiverId: request.receiverId,
    });

    return res.json({ success: true, status: 'rejected' });
  }

  if (action === 'accept') {
    request.status = 'accepted';
    request.respondedAt = new Date().toISOString();

    const sender = users.get(request.senderId);
    const receiver = users.get(request.receiverId);

    if (sender && receiver) {
      const receiverGroups = receiver.contactGroups || [
        { id: 'grp_geral', name: 'Geral', icon: '📁', color: '#94A3B8' },
      ];
      const targetReceiverGroup =
        receiverGroups.find((g) => g.id === receiverGroupId) || receiverGroups[0];

      request.receiverGroupId = targetReceiverGroup.id;
      request.receiverGroupName = targetReceiverGroup.name;

      // 1. Contato para o remetente no grupo escolhido pelo remetente
      if (!sender.contacts) sender.contacts = [];
      const contactForSender: UserContact = {
        id: `ct_${Date.now()}_${receiver.id}`,
        userId: receiver.id,
        name: receiver.name,
        lastName: receiver.lastName,
        email: receiver.googleEmail,
        status: receiver.status || 'online',
        relationshipLevelId: request.relationshipLevelId,
        relationshipLevelName: request.relationshipLevelName,
        relationshipLevelIcon: request.relationshipLevelIcon,
        relationshipLevelColor: request.relationshipLevelColor,
        groupId: request.senderGroupId,
        groupName: request.senderGroupName,
        addedAt: new Date().toISOString(),
      };
      sender.contacts = sender.contacts.filter((c) => c.userId !== receiver.id);
      sender.contacts.push(contactForSender);
      users.set(sender.id, sender);

      // 2. Contato para o receptor no grupo escolhido pelo receptor
      if (!receiver.contacts) receiver.contacts = [];
      const contactForReceiver: UserContact = {
        id: `ct_${Date.now() + 1}_${sender.id}`,
        userId: sender.id,
        name: sender.name,
        lastName: sender.lastName,
        email: sender.googleEmail,
        status: sender.status || 'online',
        relationshipLevelId: request.relationshipLevelId,
        relationshipLevelName: request.relationshipLevelName,
        relationshipLevelIcon: request.relationshipLevelIcon,
        relationshipLevelColor: request.relationshipLevelColor,
        groupId: targetReceiverGroup.id,
        groupName: targetReceiverGroup.name,
        addedAt: new Date().toISOString(),
      };
      receiver.contacts = receiver.contacts.filter((c) => c.userId !== sender.id);
      receiver.contacts.push(contactForReceiver);
      users.set(receiver.id, receiver);
    }

    friendshipRequests.set(request.id, request);

    broadcastGlobal({
      type: 'friendship_request_accepted',
      requestId: request.id,
      request,
    });

    return res.json({ success: true, status: 'accepted', request });
  }

  res.status(400).json({ error: 'Ação inválida.' });
});

// GET /api/users/:id/contacts
app.get('/api/users/:id/contacts', (req, res) => {
  const user = users.get(req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const contacts = (user.contacts || []).map((c) => {
    const friend = users.get(c.userId);
    return {
      ...c,
      status: friend ? friend.status || 'online' : c.status,
    };
  });

  const defaultGroups: ContactGroup[] = [
    { id: 'grp_geral', name: 'Geral', icon: '📁', color: '#94A3B8' },
    { id: 'grp_favoritos', name: 'Favoritos', icon: '⭐', color: '#FACC15' },
    { id: 'grp_paquera', name: 'Paqueras & Crush', icon: '❤️', color: '#F472B6' },
    { id: 'grp_amigos', name: 'Amigos Próximos', icon: '☕', color: '#22D3EE' },
    { id: 'grp_trabalho', name: 'Trabalho & Networking', icon: '💼', color: '#38BDF8' },
  ];

  res.json({
    contacts,
    groups: user.contactGroups && user.contactGroups.length > 0 ? user.contactGroups : defaultGroups,
  });
});

// POST /api/users/:id/contacts/move-group
// Permite mover o contato para outro grupo
app.post('/api/users/:id/contacts/move-group', (req, res) => {
  const user = users.get(req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const { contactId, targetGroupId } = req.body;
  if (!user.contacts) user.contacts = [];

  const contact = user.contacts.find((c) => c.id === contactId || c.userId === contactId);
  if (!contact) {
    return res.status(404).json({ error: 'Contato não encontrado na sua lista.' });
  }

  const groups = user.contactGroups || [];
  const targetGroup = groups.find((g) => g.id === targetGroupId);

  contact.groupId = targetGroupId;
  contact.groupName = targetGroup ? targetGroup.name : targetGroupId;
  users.set(user.id, user);

  res.json({ success: true, contact });
});

// POST /api/users/:id/contact-groups
app.post('/api/users/:id/contact-groups', (req, res) => {
  const user = users.get(req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const { name, icon, color } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Nome do grupo é obrigatório.' });
  }

  if (!user.contactGroups) user.contactGroups = [];
  const newGroup: ContactGroup = {
    id: `grp_${Date.now()}`,
    name,
    icon: icon || '📁',
    color: color || '#22D3EE',
  };

  user.contactGroups.push(newGroup);
  users.set(user.id, user);

  res.json(newGroup);
});

// DELETE /api/users/:id/contacts/:contactId
app.delete('/api/users/:id/contacts/:contactId', (req, res) => {
  const user = users.get(req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const contactId = req.params.contactId;
  user.contacts = (user.contacts || []).filter((c) => c.id !== contactId && c.userId !== contactId);
  users.set(user.id, user);

  res.json({ success: true, message: 'Contato removido.' });
});

// ==============================================================================
// NICKNAME MANAGEMENT (TEMPORÁRIO OU PERMANENTE)
// ==============================================================================

// GET /api/user/nickname-check - Verifica disponibilidade de nickname
app.get('/api/user/nickname-check', (req, res) => {
  const { nickname, userId } = req.query;
  if (!nickname || typeof nickname !== 'string') {
    return res.status(400).json({ available: false, error: 'Nickname não fornecido.' });
  }

  const clean = nickname.trim();
  const validation = validateNicknameString(clean);
  if (!validation.isValid) {
    return res.json({ available: false, error: validation.error });
  }

  const lower = clean.toLowerCase();
  const ownerId = permanentNicknames.get(lower);

  // Se já pertencer ao próprio usuário, está disponível para ele
  if (ownerId && ownerId !== userId) {
    return res.json({ available: false, error: 'Este nickname já está cadastrado no sistema por outro usuário.' });
  }

  for (const u of users.values()) {
    if (u.id !== userId && u.nickname && u.nickname.trim().toLowerCase() === lower) {
      return res.json({ available: false, error: 'Este nickname já está cadastrado no sistema por outro usuário.' });
    }
  }

  res.json({ available: true, nickname: clean });
});

// POST /api/user/nickname - Salva ou atualiza nickname (temporário ou permanente)
app.post('/api/user/nickname', (req, res) => {
  const { userId, nickname, type } = req.body;
  const user = users.get(userId);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  if (!nickname || typeof nickname !== 'string') {
    return res.status(400).json({ error: 'Nickname é obrigatório.' });
  }

  const cleanNickname = nickname.trim();
  const validation = validateNicknameString(cleanNickname);
  if (!validation.isValid) {
    return res.status(400).json({ error: validation.error });
  }

  const nicknameType: 'temporary' | 'permanent' = type === 'temporary' ? 'temporary' : 'permanent';
  const lower = cleanNickname.toLowerCase();

  // Verifica se o nickname já está registrado por outro usuário como permanente ou em outro cadastro
  const existingOwner = permanentNicknames.get(lower);
  if (existingOwner && existingOwner !== userId) {
    return res.status(400).json({
      error: `O nickname "${cleanNickname}" já está cadastrado no sistema. Escolha outro nome exclusivo.`,
    });
  }

  for (const u of users.values()) {
    if (u.id !== userId && u.nickname && u.nickname.trim().toLowerCase() === lower) {
      return res.status(400).json({
        error: `O nickname "${cleanNickname}" já está cadastrado no sistema por outro usuário. Escolha outro nome exclusivo.`,
      });
    }
  }

  // Se o usuário tinha um nickname permanente anterior diferente, libera o antigo!
  if (user.nickname && user.nicknameType === 'permanent') {
    const oldLower = user.nickname.toLowerCase();
    if (oldLower !== lower) {
      permanentNicknames.delete(oldLower);
    }
  }

  // Se o novo for permanente, registra no índice de exclusividade
  if (nicknameType === 'permanent') {
    permanentNicknames.set(lower, userId);
  } else {
    // Se mudou para temporário, desocupa o nickname permanente se ele ocupava antes
    if (user.nickname) {
      permanentNicknames.delete(user.nickname.toLowerCase());
    }
  }

  user.nickname = cleanNickname;
  user.nicknameType = nicknameType;
  users.set(user.id, user);
  dbManager.saveUser(user);

  res.json({
    success: true,
    user: {
      ...user,
      nickname: cleanNickname,
      nicknameType,
    },
    message:
      nicknameType === 'permanent'
        ? 'Nickname permanente salvo com sucesso! Será usado automaticamente ao entrar em qualquer sala ou conversa.'
        : 'Nickname temporário definido para a sessão.',
  });
});

// DELETE /api/user/nickname - Exclui o nickname do usuário, liberando-o para qualquer pessoa
app.delete('/api/user/nickname', (req, res) => {
  const { userId } = req.body;
  const user = users.get(userId);
  if (!user) {
    return res.status(404).json({ error: 'Usuário não encontrado.' });
  }

  const previousNick = user.nickname;
  if (previousNick) {
    // Libera o nickname para qualquer um usar
    permanentNicknames.delete(previousNick.toLowerCase());
    user.nickname = undefined;
    user.nicknameType = undefined;
    users.set(user.id, user);
    dbManager.saveUser(user);
  }

  res.json({
    success: true,
    message: `O nickname "${previousNick || ''}" foi excluído e está livre para qualquer pessoa usar.`,
    user,
  });
});

// ==============================================================================
// TRANSMISSÕES AO VIVO (LIVE CAMERA & CHAT ACOPLADO)
// ==============================================================================

// GET /api/live - Lista transmissões ao vivo ativas
app.get('/api/live', (req, res) => {
  const now = Date.now();
  const list = Array.from(liveTransmissions.values())
    .filter((t) => t.status === 'active')
    .map((t) => {
      // Limpa pedidos pendentes expirados (33 segundos)
      t.pendingViewRequests = t.pendingViewRequests.filter((req) => {
        const elapsed = (now - new Date(req.requestedAt).getTime()) / 1000;
        return elapsed < 33;
      }).map((req) => {
        const elapsed = (now - new Date(req.requestedAt).getTime()) / 1000;
        return {
          ...req,
          secondsRemaining: Math.max(0, Math.ceil(33 - elapsed)),
        };
      });

      return {
        ...t,
        currentViewersCount: t.currentViewers.length,
      };
    });

  res.json(list);
});

// GET /api/live/:id - Detalhes da transmissão
app.get('/api/live/:id', (req, res) => {
  const transmission = liveTransmissions.get(req.params.id);
  if (!transmission || transmission.status === 'ended') {
    return res.status(404).json({ error: 'Transmissão ao vivo não encontrada ou já encerrada.' });
  }

  const now = Date.now();
  // Limpa pedidos expirados (> 33 segundos)
  transmission.pendingViewRequests = transmission.pendingViewRequests.filter((r) => {
    const elapsed = (now - new Date(r.requestedAt).getTime()) / 1000;
    return elapsed < 33;
  }).map((r) => {
    const elapsed = (now - new Date(r.requestedAt).getTime()) / 1000;
    return {
      ...r,
      secondsRemaining: Math.max(0, Math.ceil(33 - elapsed)),
    };
  });

  res.json({
    ...transmission,
    currentViewersCount: transmission.currentViewers.length,
  });
});

// POST /api/live/start - Inicia uma nova transmissão de câmera ao vivo
app.post('/api/live/start', (req, res) => {
  const { streamerId, streamerName, streamerNickname, streamerAvatar, title, fixedText, type } = req.body;

  if (!streamerId || !title) {
    return res.status(400).json({ error: 'Identificador do usuário e título da live são obrigatórios.' });
  }

  // "o mesmo usuário não deverá ter permissão de transmitir mais de um canal, ou seja, so pode transmitir somente uma sala"
  const existingLiveId = streamerActiveLiveMap.get(streamerId);
  if (existingLiveId) {
    const existing = liveTransmissions.get(existingLiveId);
    if (existing && existing.status === 'active') {
      return res.status(400).json({
        error: 'Você já possui uma transmissão ao vivo ativa! Não é permitido transmitir mais de um canal simultaneamente. Encerre sua transmissão anterior para abrir uma nova.',
        activeLiveId: existingLiveId,
      });
    }
  }

  const liveId = `live_${Date.now()}_${streamerId.substring(0, 8)}`;
  const newLive: LiveTransmission = {
    id: liveId,
    streamerId,
    streamerName: streamerName || 'Apresentador',
    streamerNickname: streamerNickname || streamerName || 'Apresentador',
    streamerAvatar,
    title: title.trim(),
    fixedText: fixedText?.trim() || 'Sejam bem-vindos à minha transmissão ao vivo!',
    type: type === 'restricted' ? 'restricted' : 'public',
    maxViewers: 55, // Limite estrito de 55 usuários assistindo
    currentViewersCount: 1,
    currentViewers: [streamerId],
    pendingViewRequests: [],
    approvedViewers: [streamerId], // Streamer já é aprovado para ver sua própria câmera
    createdAt: new Date().toISOString(),
    status: 'active',
  };

  liveTransmissions.set(liveId, newLive);
  streamerActiveLiveMap.set(streamerId, liveId);
  liveChatMessages.set(liveId, [
    {
      id: `msg_live_init_${Date.now()}`,
      roomId: liveId,
      senderId: 'system',
      senderName: 'chamasso live',
      text: `🔴 Transmissão iniciada: "${newLive.title}" (${newLive.type === 'restricted' ? 'Transmissão Restrita' : 'Transmissão Pública'}). Limite de 55 espectadores.`,
      timestamp: new Date().toISOString(),
    },
  ]);

  broadcastGlobal({
    type: 'live_started',
    live: newLive,
  });

  res.json({ success: true, live: newLive });
});

// POST /api/live/:id/stop - Encerra a transmissão ao vivo
app.post('/api/live/:id/stop', (req, res) => {
  const { streamerId } = req.body;
  const live = liveTransmissions.get(req.params.id);
  if (!live) {
    return res.status(404).json({ error: 'Transmissão não encontrada.' });
  }

  if (live.streamerId !== streamerId) {
    return res.status(403).json({ error: 'Apenas o streamer que criou a transmissão pode encerrá-la.' });
  }

  live.status = 'ended';
  streamerActiveLiveMap.delete(streamerId);

  broadcastToRoom(live.id, {
    type: 'live_ended',
    liveId: live.id,
  });

  res.json({ success: true, message: 'Transmissão ao vivo encerrada com sucesso.' });
});

// PUT /api/live/:id/fixed-text - Atualiza o texto fixo abaixo da transmissão (apresentação, limites, marketing)
app.put('/api/live/:id/fixed-text', (req, res) => {
  const { streamerId, fixedText } = req.body;
  const live = liveTransmissions.get(req.params.id);
  if (!live) {
    return res.status(404).json({ error: 'Transmissão não encontrada.' });
  }

  if (live.streamerId !== streamerId) {
    return res.status(403).json({ error: 'Apenas o streamer pode editar o texto fixo.' });
  }

  live.fixedText = fixedText || '';
  liveTransmissions.set(live.id, live);

  broadcastToRoom(live.id, {
    type: 'live_fixed_text_updated',
    liveId: live.id,
    fixedText: live.fixedText,
  });

  res.json({ success: true, fixedText: live.fixedText });
});

// POST /api/live/:id/join-viewer - Entra como espectador (limite máximo de 55 usuários)
app.post('/api/live/:id/join-viewer', (req, res) => {
  const { userId, userName, userNickname } = req.body;
  const live = liveTransmissions.get(req.params.id);
  if (!live || live.status === 'ended') {
    return res.status(404).json({ error: 'Transmissão não encontrada ou já encerrada.' });
  }

  // "cada transmissão deverá ter o limite de 55 usuários assistindo"
  if (!live.currentViewers.includes(userId) && live.currentViewers.length >= 55) {
    return res.status(400).json({
      error: 'Esta transmissão atingiu a capacidade máxima de 55 usuários assistindo simultaneamente. Tente novamente mais tarde.',
    });
  }

  if (!live.currentViewers.includes(userId)) {
    live.currentViewers.push(userId);
    live.currentViewersCount = live.currentViewers.length;
  }

  // Se a transmissão for pública, o usuário já tem acesso à câmera
  if (live.type === 'public' && !live.approvedViewers.includes(userId)) {
    live.approvedViewers.push(userId);
  }

  res.json({
    success: true,
    live,
    isApprovedToView: live.approvedViewers.includes(userId),
    currentViewersCount: live.currentViewers.length,
  });
});

// POST /api/live/:id/leave-viewer
app.post('/api/live/:id/leave-viewer', (req, res) => {
  const { userId } = req.body;
  const live = liveTransmissions.get(req.params.id);
  if (live) {
    live.currentViewers = live.currentViewers.filter((id) => id !== userId);
    live.currentViewersCount = live.currentViewers.length;
    // Remove de pedidos pendentes se houver
    live.pendingViewRequests = live.pendingViewRequests.filter((r) => r.userId !== userId);
  }
  res.json({ success: true });
});

// POST /api/live/:id/request-view - Solicitação para ver a câmera em transmissão restrita (duração 33s, max 11 pedidos)
app.post('/api/live/:id/request-view', (req, res) => {
  const { userId, userName, userNickname, avatarUrl } = req.body;
  const live = liveTransmissions.get(req.params.id);
  if (!live || live.status === 'ended') {
    return res.status(404).json({ error: 'Transmissão não encontrada.' });
  }

  if (live.approvedViewers.includes(userId)) {
    return res.json({ success: true, approved: true, message: 'Você já possui permissão para visualizar esta câmera.' });
  }

  const now = Date.now();
  // Limpa pedidos que já ultrapassaram 33 segundos
  live.pendingViewRequests = live.pendingViewRequests.filter((r) => {
    const elapsed = (now - new Date(r.requestedAt).getTime()) / 1000;
    return elapsed < 33;
  });

  // "cada usuario que estiver transmitindo video, só poderá receber até 11 pedidos de visualizar a camera por vez simultaneamente"
  if (live.pendingViewRequests.length >= 11) {
    return res.status(400).json({
      error: 'A fila de pedidos de visualização está cheia no momento (máximo de 11 pedidos pendentes simultâneos). Aguarde a liberação pelo streamer.',
    });
  }

  // Verifica se o usuário já tem um pedido ativo
  const existingReq = live.pendingViewRequests.find((r) => r.userId === userId);
  if (existingReq) {
    const elapsed = (now - new Date(existingReq.requestedAt).getTime()) / 1000;
    return res.json({
      success: true,
      pending: true,
      requestId: existingReq.id,
      secondsRemaining: Math.max(0, Math.ceil(33 - elapsed)),
      message: 'Seu pedido já foi enviado ao streamer e está em análise.',
    });
  }

  // "cada solicitação de ver a camera deverá ter a duração de 33 segundos e depois sair da lista e deverá ser removida da lista de pedidos pendentes de visualização da camera"
  const newRequest: LiveViewRequest = {
    id: `req_live_${Date.now()}_${userId}`,
    transmissionId: live.id,
    userId,
    userName: userName || 'Participante',
    userNickname: userNickname || userName || 'Participante',
    avatarUrl,
    requestedAt: new Date(now).toISOString(),
    expiresAt: new Date(now + 33 * 1000).toISOString(),
    secondsRemaining: 33,
  };

  live.pendingViewRequests.push(newRequest);

  broadcastToRoom(live.id, {
    type: 'live_view_request_received',
    liveId: live.id,
    request: newRequest,
    pendingCount: live.pendingViewRequests.length,
  });

  res.json({
    success: true,
    request: newRequest,
    message: 'Solicitação de visualização da câmera enviada! Válida por 33 segundos.',
  });
});

// POST /api/live/:id/approve-view - Libera um a um OU "Selecionar Todos" e liberar câmera geral para os 11 pedidos ou menos
app.post('/api/live/:id/approve-view', (req, res) => {
  const { streamerId, requestId, approveAll } = req.body;
  const live = liveTransmissions.get(req.params.id);
  if (!live) {
    return res.status(404).json({ error: 'Transmissão não encontrada.' });
  }

  if (live.streamerId !== streamerId) {
    return res.status(403).json({ error: 'Apenas o streamer pode liberar visualização da câmera.' });
  }

  if (approveAll) {
    // "apertar o botão de selecionar todos e liberar a camera geral para os 11 pedidos ou menos pois o máximo é 11 pendentes para liberação"
    const approvedUserIds: string[] = [];
    for (const reqItem of live.pendingViewRequests) {
      if (!live.approvedViewers.includes(reqItem.userId)) {
        live.approvedViewers.push(reqItem.userId);
        approvedUserIds.push(reqItem.userId);
      }
    }
    const totalLiberados = live.pendingViewRequests.length;
    live.pendingViewRequests = [];

    broadcastToRoom(live.id, {
      type: 'live_all_viewers_approved',
      liveId: live.id,
      approvedUserIds,
    });

    return res.json({
      success: true,
      message: `Câmera liberada para todos os ${totalLiberados} pedidos pendentes!`,
      approvedCount: totalLiberados,
    });
  }

  // Liberação individual (uma a uma)
  const targetReq = live.pendingViewRequests.find((r) => r.id === requestId);
  if (!targetReq) {
    return res.status(404).json({ error: 'Pedido de visualização não encontrado ou já expirado.' });
  }

  if (!live.approvedViewers.includes(targetReq.userId)) {
    live.approvedViewers.push(targetReq.userId);
  }
  live.pendingViewRequests = live.pendingViewRequests.filter((r) => r.id !== requestId);

  broadcastToRoom(live.id, {
    type: 'live_single_viewer_approved',
    liveId: live.id,
    userId: targetReq.userId,
    userName: targetReq.userName,
  });

  res.json({
    success: true,
    message: `Acesso à câmera liberado com sucesso para ${targetReq.userName}!`,
    userId: targetReq.userId,
  });
});

// POST /api/live/:id/reject-view - Rejeita solicitação
app.post('/api/live/:id/reject-view', (req, res) => {
  const { streamerId, requestId } = req.body;
  const live = liveTransmissions.get(req.params.id);
  if (!live || live.streamerId !== streamerId) {
    return res.status(403).json({ error: 'Não autorizado.' });
  }

  live.pendingViewRequests = live.pendingViewRequests.filter((r) => r.id !== requestId);
  res.json({ success: true });
});

// GET /api/live/:id/messages - Mensagens do chat da transmissão
app.get('/api/live/:id/messages', (req, res) => {
  const msgs = liveChatMessages.get(req.params.id) || [];
  res.json(msgs);
});

// POST /api/live/:id/messages - Envia mensagem de texto com detecção de YouTube / Streams no chat da live
app.post('/api/live/:id/messages', (req, res) => {
  const { senderId, senderName, senderNickname, senderAvatar, text } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'Mensagem vazia.' });
  }

  const liveId = req.params.id;
  const videoEmbed = extractVideoEmbed(text);

  const message: ChatMessage = {
    id: `msg_live_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    roomId: liveId,
    senderId,
    senderName,
    senderNickname,
    senderAvatar,
    text: text.trim(),
    videoEmbed: videoEmbed || undefined,
    timestamp: new Date().toISOString(),
  };

  const current = liveChatMessages.get(liveId) || [];
  current.push(message);
  liveChatMessages.set(liveId, current);

  broadcastToRoom(liveId, {
    type: 'new_chat_message',
    message,
  });

  res.json({ success: true, message });
});

// POST /api/live/:id/upload - Envio de mídias acopladas à live (fotos, áudio mp3/wav, vídeo mp4) - Limite estrito de 33 MB
app.post('/api/live/:id/upload', (req, res) => {
  const { fileName, fileType, fileSize, fileBase64, senderId, senderName, senderNickname } = req.body;

  if (!fileName || !fileBase64) {
    return res.status(400).json({ error: 'Arquivo inválido.' });
  }

  // "o tamanho máximo dos arquivos enviados não poderão ultrapassar 33 megas cada um"
  if (fileSize && fileSize > MAX_FILE_SIZE_BYTES) {
    return res.status(400).json({
      error: 'O tamanho máximo do arquivo não pode ultrapassar 33 MB.',
    });
  }

  // "arquivos de audio somente formato wav e mp3"
  const isAudio = fileType?.startsWith('audio/') || fileName.endsWith('.mp3') || fileName.endsWith('.wav');
  if (isAudio && !isAudioWavOrMp3(fileName, fileType)) {
    return res.status(400).json({
      error: 'Arquivos de áudio são permitidos exclusivamente nos formatos WAV e MP3.',
    });
  }

  const liveId = req.params.id;
  const isAudioFile = isAudioWavOrMp3(fileName, fileType);
  const isVideoFile = isVideoMp4(fileName, fileType);

  const message: ChatMessage = {
    id: `msg_live_file_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    roomId: liveId,
    senderId,
    senderName,
    senderNickname,
    text: isAudioFile
      ? `🎵 Enviou áudio (${fileName.endsWith('.wav') ? 'WAV' : 'MP3'}): ${fileName}`
      : isVideoFile
      ? `🎬 Enviou vídeo (MP4): ${fileName}`
      : `📎 Enviou mídia: ${fileName}`,
    file: {
      name: fileName,
      url: fileBase64,
      size: fileSize || 0,
      type: fileType || 'application/octet-stream',
    },
    audioAttachment: isAudioFile
      ? {
          name: fileName,
          url: fileBase64,
          format: fileName.toLowerCase().endsWith('.wav') ? 'wav' : 'mp3',
          size: fileSize || 0,
        }
      : undefined,
    timestamp: new Date().toISOString(),
  };

  const current = liveChatMessages.get(liveId) || [];
  current.push(message);
  liveChatMessages.set(liveId, current);

  broadcastToRoom(liveId, {
    type: 'new_chat_message',
    message,
  });

  res.json({ success: true, message });
});

// ==============================================================================
// STANDARD CONFERENCE TEMPLATE (Tabela Excel/HTML Mosaico 15+Palestrante)
// ==============================================================================

interface StoredStandardConference extends StandardConferenceData {
  privateMessages: DirectPrivateMessage[];
}

const standardConferences: Map<string, StoredStandardConference> = new Map();

function getOrCreateStandardConference(
  roomId: string,
  user?: { id: string; name: string; nickname?: string; avatarUrl?: string },
  isModerator: boolean = false
): StoredStandardConference {
  let conf = standardConferences.get(roomId);
  if (conf) {
    return conf;
  }

  // Exemplos de participantes iniciais distribuídos entre a Sala Matriz e as Salas Filhas
  const sampleParticipants: { name: string; nickname: string; avatarUrl: string }[] = [
    { name: 'Ana Clara Silveira', nickname: 'anaclara', avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150' },
    { name: 'Carlos Eduardo Lima', nickname: 'carlosedu', avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150' },
    { name: 'Beatriz Vasconcelos', nickname: 'biavasc', avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150' },
    { name: 'Lucas Mendes Rocha', nickname: 'lucasrocha', avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150' },
    { name: 'Juliana Ferreira', nickname: 'juferreira', avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150' },
    { name: 'Marcos Vinicius Paiva', nickname: 'marcosv', avatarUrl: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150' },
    { name: 'Camila Albuquerque', nickname: 'camila_alb', avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150' },
    { name: 'Thiago Henrique Dias', nickname: 'thiagodias', avatarUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150' },
    { name: 'Fernanda Nogueira', nickname: 'fer_nog', avatarUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150' },
    { name: 'Rodrigo Fontes', nickname: 'rodrigof', avatarUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150' },
    { name: 'Mariana Duarte', nickname: 'mariduarte', avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150' },
    { name: 'Gabriel Santana', nickname: 'gabrielsant', avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150' },
    { name: 'Patricia Ramos', nickname: 'patyramos', avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150' },
    { name: 'Daniel Antunes', nickname: 'danantunes', avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150' },
  ];

  // Gera até 8 salas: Sala 1 (Matriz do Moderador) + Sala 2 a 8 (Filhas)
  const matrixRooms: MatrixSubRoom[] = [];
  for (let roomNum = 1; roomNum <= 8; roomNum++) {
    const isMatrix = roomNum === 1;
    const roomParts: RoomParticipant[] = [];

    // Preenche com participantes fictícios distribuídos
    const countForThisRoom = isMatrix ? 12 : 6 + ((roomNum * 2) % 7);
    for (let i = 0; i < countForThisRoom && i < 14; i++) {
      const pIndex = (roomNum * 2 + i) % sampleParticipants.length;
      const sample = sampleParticipants[pIndex];
      roomParts.push({
        id: `part_room${roomNum}_${i}`,
        userId: `usr_demo_r${roomNum}_${i}`,
        name: sample.name,
        avatarUrl: sample.avatarUrl,
        isModerator: isMatrix && i === 0,
        isAudioMuted: i % 3 !== 0,
        isVideoOff: false,
        isScreenSharing: false,
        isHandRaised: i % 4 === 0,
        joinedAt: new Date(Date.now() - (15 - i) * 60000).toISOString(),
      });
    }

    matrixRooms.push({
      roomNumber: roomNum,
      name: isMatrix ? 'Sala 1 (Matriz do Moderador)' : `Sala ${roomNum} (Extensão Filha)`,
      isMatrix,
      participantCount: roomParts.length,
      maxParticipants: 15,
      participants: roomParts,
    });
  }

  // Palestrante inicial da Câmera 0
  const initialSpeaker = {
    userId: isModerator && user ? user.id : 'usr_moderador_master',
    name: isModerator && user ? user.name : 'Dr. Roberto Meirelles (Moderador & Palestrante)',
    nickname: isModerator && user ? user.nickname : 'palestrante_master',
    avatarUrl: isModerator && user ? user.avatarUrl : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    startedAt: new Date().toISOString(),
    isAudioMuted: false,
    isVideoOff: false,
  };

  // Fila do Palestrante: Fl_01 a Fl_14
  const speakerQueue: SpeakerQueueItem[] = [
    {
      slot: 1,
      userId: 'usr_demo_r1_1',
      name: 'Carlos Eduardo Lima',
      nickname: 'carlosedu',
      avatarUrl: sampleParticipants[1].avatarUrl,
      requestedAt: new Date(Date.now() - 300000).toISOString(),
    },
    {
      slot: 2,
      userId: 'usr_demo_r1_3',
      name: 'Lucas Mendes Rocha',
      nickname: 'lucasrocha',
      avatarUrl: sampleParticipants[3].avatarUrl,
      requestedAt: new Date(Date.now() - 200000).toISOString(),
    },
    {
      slot: 3,
      userId: 'usr_demo_r1_4',
      name: 'Juliana Ferreira',
      nickname: 'juferreira',
      avatarUrl: sampleParticipants[4].avatarUrl,
      requestedAt: new Date(Date.now() - 100000).toISOString(),
    },
  ];

  // Fila de Mão Levantada para Comentar (posição 1 = verde, 2 = amarelo, >=3 = vermelho)
  const handRaiseQueue: HandRaiseQueueItem[] = [
    {
      userId: 'usr_demo_r1_2',
      name: 'Beatriz Vasconcelos',
      nickname: 'biavasc',
      avatarUrl: sampleParticipants[2].avatarUrl,
      requestedAt: new Date(Date.now() - 240000).toISOString(),
      position: 1, // Verde
    },
    {
      userId: 'usr_demo_r1_5',
      name: 'Marcos Vinicius Paiva',
      nickname: 'marcosv',
      avatarUrl: sampleParticipants[5].avatarUrl,
      requestedAt: new Date(Date.now() - 180000).toISOString(),
      position: 2, // Amarelo
    },
    {
      userId: 'usr_demo_r1_6',
      name: 'Camila Albuquerque',
      nickname: 'camila_alb',
      avatarUrl: sampleParticipants[6].avatarUrl,
      requestedAt: new Date(Date.now() - 120000).toISOString(),
      position: 3, // Vermelho
    },
    {
      userId: 'usr_demo_r1_7',
      name: 'Thiago Henrique Dias',
      nickname: 'thiagodias',
      avatarUrl: sampleParticipants[7].avatarUrl,
      requestedAt: new Date(Date.now() - 60000).toISOString(),
      position: 4, // Vermelho
    },
  ];

  conf = {
    roomId,
    currentSpeaker: initialSpeaker,
    speakerQueue,
    handRaiseQueue,
    matrixRooms,
    privateMessages: [],
  };

  standardConferences.set(roomId, conf);
  return conf;
}

// GET /api/standard-conference/:roomId
app.get('/api/standard-conference/:roomId', (req, res) => {
  const { roomId } = req.params;
  const userId = req.query.userId as string;
  const userName = (req.query.userName as string) || 'Participante';
  const userNickname = req.query.userNickname as string;
  const userAvatar = req.query.userAvatar as string;
  const isModerator = req.query.isModerator === 'true';

  const userObj = userId ? { id: userId, name: userName, nickname: userNickname, avatarUrl: userAvatar } : undefined;
  const conf = getOrCreateStandardConference(roomId, userObj, isModerator);

  // Se o usuário estiver acessando e não estiver em nenhuma sala, insere na Sala 1
  if (userObj) {
    let userFound = false;
    for (const subRoom of conf.matrixRooms) {
      if (subRoom.participants.some((p) => p.userId === userObj.id)) {
        userFound = true;
        break;
      }
    }
    if (!userFound && conf.matrixRooms.length > 0) {
      const room1 = conf.matrixRooms[0];
      if (room1.participants.length < 14) {
        room1.participants.push({
          id: `part_${userObj.id}`,
          userId: userObj.id,
          name: userObj.name,
          avatarUrl: userObj.avatarUrl,
          isModerator,
          isAudioMuted: false,
          isVideoOff: false,
          isScreenSharing: false,
          isHandRaised: false,
          joinedAt: new Date().toISOString(),
        });
        room1.participantCount = room1.participants.length;
      }
    }
  }

  res.json({
    roomId: conf.roomId,
    currentSpeaker: conf.currentSpeaker,
    speakerQueue: conf.speakerQueue,
    handRaiseQueue: conf.handRaiseQueue,
    matrixRooms: conf.matrixRooms,
  });
});

// POST /api/standard-conference/:roomId/speaker-queue
// Botão w1: Entrar ou sair da fila para ser o palestrante da vez na Câmera 0
app.post('/api/standard-conference/:roomId/speaker-queue', (req, res) => {
  const { roomId } = req.params;
  const { userId, name, nickname, avatarUrl } = req.body;

  if (!userId || !name) {
    return res.status(400).json({ error: 'userId e name são obrigatórios.' });
  }

  const conf = getOrCreateStandardConference(roomId);
  const existingIndex = conf.speakerQueue.findIndex((item) => item.userId === userId);

  if (existingIndex >= 0) {
    // Sai da fila
    conf.speakerQueue.splice(existingIndex, 1);
    // Reorganiza os slots de 1 a N
    conf.speakerQueue.forEach((item, idx) => {
      item.slot = idx + 1;
    });

    broadcastToRoom(roomId, {
      type: 'standard_conference_update',
      action: 'speaker_queue_updated',
      speakerQueue: conf.speakerQueue,
    });

    return res.json({
      success: true,
      inQueue: false,
      speakerQueue: conf.speakerQueue,
    });
  }

  // Verifica limite de 14 posições na fila (Fl_01 a Fl_14)
  if (conf.speakerQueue.length >= 14) {
    return res.status(400).json({
      error: 'A fila de palestrante atingiu a capacidade máxima de 14 posições (Fl_01 a Fl_14).',
    });
  }

  const newSlot = conf.speakerQueue.length + 1;
  const newItem: SpeakerQueueItem = {
    slot: newSlot,
    userId,
    name,
    nickname,
    avatarUrl,
    requestedAt: new Date().toISOString(),
  };

  conf.speakerQueue.push(newItem);

  broadcastToRoom(roomId, {
    type: 'standard_conference_update',
    action: 'speaker_queue_updated',
    speakerQueue: conf.speakerQueue,
  });

  res.json({
    success: true,
    inQueue: true,
    slot: newSlot,
    speakerQueue: conf.speakerQueue,
  });
});

// POST /api/standard-conference/:roomId/hand-raise
// Botão x1: Levantar ou abaixar a mão para comentar/pedir a palavra
// Regra de cores:
// Posição 1 = Verde (próximo a falar)
// Posição 2 = Amarelo
// Posição >= 3 = Vermelho
app.post('/api/standard-conference/:roomId/hand-raise', (req, res) => {
  const { roomId } = req.params;
  const { userId, name, nickname, avatarUrl } = req.body;

  if (!userId || !name) {
    return res.status(400).json({ error: 'userId e name são obrigatórios.' });
  }

  const conf = getOrCreateStandardConference(roomId);
  const existingIdx = conf.handRaiseQueue.findIndex((item) => item.userId === userId);

  if (existingIdx >= 0) {
    // Abaixar a mão
    conf.handRaiseQueue.splice(existingIdx, 1);
    // Recalcular posições
    conf.handRaiseQueue.forEach((item, idx) => {
      item.position = idx + 1;
    });

    broadcastToRoom(roomId, {
      type: 'standard_conference_update',
      action: 'hand_raise_updated',
      handRaiseQueue: conf.handRaiseQueue,
    });

    return res.json({
      success: true,
      isHandRaised: false,
      position: null,
      handRaiseQueue: conf.handRaiseQueue,
    });
  }

  // Entra na fila de pedir a palavra
  const nextPos = conf.handRaiseQueue.length + 1;
  const newHand: HandRaiseQueueItem = {
    userId,
    name,
    nickname,
    avatarUrl,
    requestedAt: new Date().toISOString(),
    position: nextPos,
  };

  conf.handRaiseQueue.push(newHand);

  broadcastToRoom(roomId, {
    type: 'standard_conference_update',
    action: 'hand_raise_updated',
    handRaiseQueue: conf.handRaiseQueue,
  });

  res.json({
    success: true,
    isHandRaised: true,
    position: nextPos,
    colorCode: nextPos === 1 ? 'green' : nextPos === 2 ? 'yellow' : 'red',
    handRaiseQueue: conf.handRaiseQueue,
  });
});

// POST /api/standard-conference/:roomId/promote-speaker
// Passa a vez para o próximo da fila ou define palestrante da Câmera 0
app.post('/api/standard-conference/:roomId/promote-speaker', (req, res) => {
  const { roomId } = req.params;
  const { nextUserId } = req.body;

  const conf = getOrCreateStandardConference(roomId);

  if (conf.speakerQueue.length === 0 && !nextUserId) {
    return res.status(400).json({ error: 'Não há ninguém na fila de palestrante.' });
  }

  let nextSpeakerItem: SpeakerQueueItem | undefined;
  if (nextUserId) {
    const idx = conf.speakerQueue.findIndex((s) => s.userId === nextUserId);
    if (idx >= 0) {
      nextSpeakerItem = conf.speakerQueue.splice(idx, 1)[0];
    }
  } else {
    nextSpeakerItem = conf.speakerQueue.shift();
  }

  if (nextSpeakerItem) {
    conf.currentSpeaker = {
      userId: nextSpeakerItem.userId,
      name: nextSpeakerItem.name,
      nickname: nextSpeakerItem.nickname,
      avatarUrl: nextSpeakerItem.avatarUrl,
      startedAt: new Date().toISOString(),
      isAudioMuted: false,
      isVideoOff: false,
    };

    // Reorganiza posições dos slots
    conf.speakerQueue.forEach((item, idx) => {
      item.slot = idx + 1;
    });

    broadcastToRoom(roomId, {
      type: 'standard_conference_update',
      action: 'speaker_promoted',
      currentSpeaker: conf.currentSpeaker,
      speakerQueue: conf.speakerQueue,
    });
  }

  res.json({
    success: true,
    currentSpeaker: conf.currentSpeaker,
    speakerQueue: conf.speakerQueue,
  });
});

// POST /api/standard-conference/:roomId/private-message
// Envia mensagem privada direta para membro de qualquer sala (Sala 1 a 7/8)
app.post('/api/standard-conference/:roomId/private-message', (req, res) => {
  const { roomId } = req.params;
  const { senderId, senderName, senderNickname, senderAvatar, senderRoomNumber, receiverId, receiverName, text } =
    req.body;

  if (!senderId || !receiverId || !text) {
    return res.status(400).json({ error: 'Dados incompletos para mensagem privada.' });
  }

  const conf = getOrCreateStandardConference(roomId);
  const msg: DirectPrivateMessage = {
    id: `pmsg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    senderId,
    senderName,
    senderNickname,
    senderAvatar,
    senderRoomNumber: senderRoomNumber || 1,
    receiverId,
    receiverName,
    text,
    timestamp: new Date().toISOString(),
  };

  conf.privateMessages.push(msg);

  broadcastToRoom(roomId, {
    type: 'direct_private_message',
    message: msg,
  });

  res.json({ success: true, message: msg });
});

// GET /api/standard-conference/:roomId/private-messages
app.get('/api/standard-conference/:roomId/private-messages', (req, res) => {
  const { roomId } = req.params;
  const userId = req.query.userId as string;

  const conf = getOrCreateStandardConference(roomId);
  const userMsgs = conf.privateMessages.filter(
    (m) => m.senderId === userId || m.receiverId === userId
  );

  res.json(userMsgs);
});

// ==============================================================================
// WEBSOCKET SERVER (WebRTC Signaling, In-Room Chat, Reações, Moderação em Tempo Real)
// ==============================================================================

const wss = new WebSocketServer({ server, path: '/ws' });

// Mapeamento de conexões por sala: roomId -> Map<clientId, { ws, participantData }>
const roomSockets = new Map<string, Map<string, { ws: WebSocket; participant: RoomParticipant }>>();
const waitingSockets = new Map<string, Map<string, WebSocket>>();

function broadcastGlobal(message: any) {
  const payload = JSON.stringify(message);
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) {
      try {
        client.send(payload);
      } catch (err) {
        // ignore closed
      }
    }
  }
}

function broadcastToRoom(roomId: string, message: any, excludeClientId?: string) {
  const clients = roomSockets.get(roomId);
  const payload = JSON.stringify(message);

  if (clients) {
    for (const [cId, client] of clients.entries()) {
      if (excludeClientId && cId === excludeClientId) continue;
      if (client.ws.readyState === WebSocket.OPEN) {
        try {
          client.ws.send(payload);
        } catch (e) {
          console.error('Erro ao enviar mensagem WS:', e);
        }
      }
    }
  }

  // Se houver pretendentes aguardando aprovação nesta sala, envia eventos pertinentes
  const waitClients = waitingSockets.get(roomId);
  if (waitClients) {
    for (const [, ws] of waitClients.entries()) {
      if (ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(payload);
        } catch (e) {
          // ignore
        }
      }
    }
  }
}

wss.on('connection', (ws: WebSocket, req) => {
  const url = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`);
  const session = readSessionFromRequest(req as any);
  if (!session || session.role !== 'USER') {
    ws.close(1008, 'Authentication required');
    return;
  }
  const roomId = url.searchParams.get('roomId') || 'global';
  const userId = session.sub;
  const registeredUser = users.get(userId);
  if (!registeredUser) { ws.close(1008, 'User not found'); return; }
  const avatarUrl = registeredUser.avatarUrl || undefined;
  const effectiveDisplayName = (registeredUser.nickname && registeredUser.nickname.trim().length > 0)
    ? registeredUser.nickname.trim()
    : `${registeredUser.name} ${registeredUser.lastName || ''}`.trim();
  const userName = effectiveDisplayName;

  if (roomId === 'global') {
    ws.send(JSON.stringify({ type: 'global_init', status: 'connected', userId }));
    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong' }));
        }
      } catch (e) {
        // ignore parse error
      }
    });
    return;
  }

  const room = rooms.get(roomId);
  if (!room) {
    ws.close(1008, 'Room not found');
    return;
  }

  // Verifica ban de moderador
  const activeBan = moderatorBans.find(
    (b) =>
      b.userId === userId &&
      b.moderatorId === room.creatorId &&
      new Date(b.expiresAt).getTime() > Date.now()
  );

  if (activeBan) {
    ws.send(
      JSON.stringify({
        type: 'error_banned',
        message: `Você está temporariamente bloqueado nesta sala até ${new Date(
          activeBan.expiresAt
        ).toLocaleString('pt-BR')}. Motivo: ${activeBan.reason}`,
      })
    );
    ws.close(1008, 'User banned by moderator');
    return;
  }

  const isWaitingAdmission = url.searchParams.get('waitingAdmission') === 'true';
  if (isWaitingAdmission) {
    if (!waitingSockets.has(roomId)) {
      waitingSockets.set(roomId, new Map());
    }
    waitingSockets.get(roomId)!.set(userId, ws);
    ws.send(JSON.stringify({ type: 'waiting_admission_connected', roomId, userId }));
    ws.on('close', () => {
      waitingSockets.get(roomId)?.delete(userId);
    });
    return;
  }

  if (!roomSockets.has(roomId)) {
    roomSockets.set(roomId, new Map());
  }
  const clients = roomSockets.get(roomId)!;

  const clientId = `${userId}_${Date.now()}`;
  const participant: RoomParticipant = {
    id: clientId,
    userId,
    name: effectiveDisplayName,
    avatarUrl,
    isModerator: room.creatorId === userId,
    isAudioMuted: false,
    isVideoOff: false,
    isScreenSharing: false,
    isHandRaised: false,
    joinedAt: new Date().toISOString(),
  };

  clients.set(clientId, { ws, participant });

  // Atualiza lista de participantes da sala
  room.participants = Array.from(clients.values()).map((c) => c.participant);
  room.activeParticipantsCount = room.participants.length;

  // Envia estado inicial da sala para o cliente conectado
  ws.send(
    JSON.stringify({
      type: 'room_init',
      roomId,
      clientId,
      participants: room.participants,
      messages: roomMessages.get(roomId) || [],
    })
  );

  // Notifica os demais participantes sobre a nova entrada
  broadcastToRoom(
    roomId,
    {
      type: 'participant_joined',
      participant,
      activeParticipantsCount: room.participants.length,
    },
    clientId
  );

  // Mensagem de boas-vindas no chat
  const joinMsg: ChatMessage = {
    id: `msg_join_${Date.now()}`,
    roomId,
    senderId: 'system',
    senderName: 'chamasso live chat',
    text: `${effectiveDisplayName} entrou na sala.`,
    timestamp: new Date().toISOString(),
  };
  const currentMsgs = roomMessages.get(roomId) || [];
  currentMsgs.push(joinMsg);
  roomMessages.set(roomId, currentMsgs);
  dbManager.saveRoomMessages(roomId, currentMsgs);

  broadcastToRoom(roomId, {
    type: 'new_chat_message',
    message: joinMsg,
  });

  // Manipulação de mensagens recebidas pelo WebSocket
  ws.on('message', (raw) => {
    try {
      const data = JSON.parse(raw.toString());

      switch (data.type) {
        // Sinalização WebRTC: offer, answer, ice-candidate
        case 'webrtc_offer':
        case 'webrtc_answer':
        case 'webrtc_ice_candidate':
          // Reencaminha para o destinatário específico
          if (data.targetClientId && clients.has(data.targetClientId)) {
            clients.get(data.targetClientId)!.ws.send(
              JSON.stringify({
                ...data,
                fromClientId: clientId,
              })
            );
          } else {
            // Se broadcast geral
            broadcastToRoom(
              roomId,
              {
                ...data,
                fromClientId: clientId,
              },
              clientId
            );
          }
          break;

        // Chat de texto
        case 'chat_message': {
          const videoEmbed = extractVideoEmbed(data.text);
          const chatMsg: ChatMessage = {
            id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            roomId,
            senderId: userId,
            senderName: userName,
            senderNickname: data.senderNickname,
            senderAvatar: avatarUrl,
            isModerator: participant.isModerator,
            text: data.text,
            videoEmbed: videoEmbed || undefined,
            timestamp: new Date().toISOString(),
          };
          const msgs = roomMessages.get(roomId) || [];
          msgs.push(chatMsg);
          roomMessages.set(roomId, msgs);
          dbManager.saveRoomMessages(roomId, msgs);

          broadcastToRoom(roomId, {
            type: 'new_chat_message',
            message: chatMsg,
          });
          break;
        }

        // Reações ao vivo (corações, palmas, fogo, etc.)
        case 'reaction':
          broadcastToRoom(roomId, {
            type: 'reaction_broadcast',
            reaction: data.reaction,
            senderName: userName,
            senderId: userId,
          });
          break;

        // Mudança de estado de mídia (mudo, câmera, tela, mão levantada)
        case 'media_state_change':
          if (typeof data.isAudioMuted === 'boolean') participant.isAudioMuted = data.isAudioMuted;
          if (typeof data.isVideoOff === 'boolean') participant.isVideoOff = data.isVideoOff;
          if (typeof data.isScreenSharing === 'boolean') participant.isScreenSharing = data.isScreenSharing;
          if (typeof data.isHandRaised === 'boolean') participant.isHandRaised = data.isHandRaised;

          broadcastToRoom(roomId, {
            type: 'participant_updated',
            participant,
          });
          break;

        // Moderador mudo forçado
        case 'moderator_mute_participant':
          if (participant.isModerator && data.targetClientId && clients.has(data.targetClientId)) {
            const target = clients.get(data.targetClientId)!;
            target.participant.isAudioMuted = true;
            target.ws.send(
              JSON.stringify({
                type: 'forced_muted_by_moderator',
                moderatorName: userName,
              })
            );
            broadcastToRoom(roomId, {
              type: 'participant_updated',
              participant: target.participant,
            });
          }
          break;

        default:
          break;
      }
    } catch (err) {
      console.error('Erro no processamento da mensagem WS:', err);
    }
  });

  ws.on('close', () => {
    clients.delete(clientId);
    room.participants = Array.from(clients.values()).map((c) => c.participant);
    room.activeParticipantsCount = room.participants.length;

    broadcastToRoom(roomId, {
      type: 'participant_left',
      clientId,
      userId,
      userName,
      activeParticipantsCount: room.participants.length,
    });

    const leaveMsg: ChatMessage = {
      id: `msg_leave_${Date.now()}`,
      roomId,
      senderId: 'system',
      senderName: 'chamasso live chat',
      text: `${userName} saiu da sala.`,
      timestamp: new Date().toISOString(),
    };
    const msgs = roomMessages.get(roomId) || [];
    msgs.push(leaveMsg);
    roomMessages.set(roomId, msgs);
          dbManager.saveRoomMessages(roomId, msgs);

    broadcastToRoom(roomId, {
      type: 'new_chat_message',
      message: leaveMsg,
    });
  });
});

// ==============================================================================
// VITE MIDDLEWARE (DEV) & STATIC FILES (PRODUCTION)
// ==============================================================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[chamasso live chat] Servidor ativo em http://0.0.0.0:${PORT}`);
    console.log(`[chamasso live chat] Compatível com Debian 12 + Apache VirtualHost chamasso.pasquared.space`);
  });
}

startServer();
