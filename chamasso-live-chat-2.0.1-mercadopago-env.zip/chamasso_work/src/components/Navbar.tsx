import React, { useState } from 'react';
import { Lock, Heart, Users, ShieldCheck, LogOut, PlusCircle, KeyRound, Sparkles, ChevronDown, Film, Radio, User as UserIcon, CreditCard, Menu, X, Home, UserCheck } from 'lucide-react';
import type { User, UserStatus } from '../types.ts';

interface NavbarProps {
  currentUser: User | null;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onLogout: () => void;
  onOpenCreateRoom: () => void;
  onOpenAdmin: () => void;
  onOpenMyCodes: () => void;
  onOpenFriendships?: () => void;
  pendingRequestsCount?: number;
  onStatusChange?: (newStatus: UserStatus) => void;
  currentView: 'lobby' | 'room' | 'admin';
  onNavigateLobby: () => void;
  onOpenIntro?: () => void;
  onOpenNicknameModal?: () => void;
  onOpenLiveModal?: () => void;
  onOpenRecharge?: () => void;
  onOpenSocialProfile?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onOpenLogin,
  onOpenRegister,
  onLogout,
  onOpenCreateRoom,
  onOpenAdmin,
  onOpenMyCodes,
  onOpenFriendships,
  pendingRequestsCount = 0,
  onStatusChange,
  currentView = 'lobby',
  onNavigateLobby,
  onOpenIntro,
  onOpenNicknameModal,
  onOpenLiveModal,
  onOpenRecharge,
  onOpenSocialProfile,
}) => {
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const [showMobileDropdown, setShowMobileDropdown] = useState(false);

  const statusOptions: { id: UserStatus; label: string; icon: string; dot: string }[] = [
    { id: 'online', label: 'Online', icon: '🟢', dot: 'bg-emerald-400' },
    { id: 'ocupado', label: 'Ocupado', icon: '🔴', dot: 'bg-rose-500' },
    { id: 'em_almoco', label: 'Em Horário de Almoço', icon: '🍔', dot: 'bg-amber-400' },
    { id: 'ausente', label: 'Ausente', icon: '🟡', dot: 'bg-yellow-400' },
    { id: 'invisivel', label: 'Invisível (Offline)', icon: '⚪', dot: 'bg-slate-400' },
  ];

  const currentStatusObj =
    statusOptions.find((s) => s.id === currentUser?.status) || statusOptions[0];

  const handleSelectStatus = async (st: UserStatus) => {
    setShowStatusMenu(false);
    if (!currentUser) return;
    try {
      await fetch(`/api/users/${currentUser.id}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: st }),
      });
      onStatusChange?.(st);
    } catch (err) {
      console.error('Erro ao alterar status:', err);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#1E293B] bg-[#0F172A] shadow-lg shadow-black/40">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2.5 sm:px-8">
        {/* Brand */}
        <div className="flex items-center gap-4">
          <a
            href="/app"
            onClick={(e) => {
              e.preventDefault();
              onNavigateLobby();
            }}
            className="group flex items-center gap-3 text-left focus:outline-none cursor-pointer"
            title="Lobby de Salas - chamasso live chat"
          >
            <div className="relative w-11 h-11 rounded-2xl overflow-hidden border-2 border-[#22D3EE]/50 shadow-[0_0_20px_rgba(34,211,238,0.45)] transition-all duration-300 group-hover:scale-105 group-hover:border-[#F472B6] shrink-0 bg-[#0A0C10]">
              <img
                src="/fenix_chamas.gif"
                alt="chamasso live chat"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-black tracking-tighter italic uppercase text-transparent bg-clip-text bg-gradient-to-r from-[#22D3EE] to-[#F472B6]">
                  CHAMASSO LIVE CHAT
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium tracking-wide hidden sm:block">
                Paquera & Amizade ao Vivo • Transmissões em Alta Qualidade
              </p>
            </div>
          </a>
        </div>

        {/* Server & Domain Indicator */}
        <div className="hidden xl:flex items-center gap-2.5 rounded-full border border-[#1E293B] bg-[#1E293B]/60 px-3.5 py-1 text-xs text-slate-300">
          <div className="w-2 h-2 bg-[#22D3EE] rounded-full animate-pulse" />
          <span className="font-mono text-[#22D3EE] font-medium">chamasso.pasquared.space</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">Debian 12 + Apache 2.4</span>
        </div>

        {/* Actions & User profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Botão de Menu Vertical Drop-Down Unificado (Posicionado no Canto Direito Superior) */}
          <div className="relative">
            <button
              onClick={() => setShowMobileDropdown(!showMobileDropdown)}
              className="flex items-center gap-2 rounded-xl border border-[#22D3EE]/40 bg-[#1E293B] px-3.5 py-2 text-xs font-bold text-[#22D3EE] hover:bg-[#334155] hover:border-[#22D3EE] shadow-md shadow-[#22D3EE]/10 transition active:scale-95"
              title="Menu Principal e Opções do Sistema"
            >
              <Menu className="h-4 w-4 text-[#22D3EE]" />
              <span className="hidden sm:inline">Menu Principal</span>
              {pendingRequestsCount > 0 && (
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-black text-white">
                  {pendingRequestsCount}
                </span>
              )}
            </button>

            {showMobileDropdown && (
              <div className="absolute right-0 mt-2 w-72 sm:w-80 rounded-2xl border border-[#1E293B] bg-[#0F172A] p-3 shadow-2xl z-50 text-xs text-slate-200 animate-in fade-in zoom-in-95 duration-150">
                {currentUser ? (
                  <>
                    {/* User Info Header in Dropdown */}
                    <div className="flex items-center gap-3 p-2 rounded-xl bg-[#1E293B]/80 border border-slate-700/60 mb-2.5">
                      <div className="w-10 h-10 rounded-full bg-[#334155] border-2 border-[#22D3EE]/60 flex items-center justify-center text-sm font-black text-[#22D3EE] shrink-0">
                        {currentUser.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="overflow-hidden">
                        <p className="font-bold text-white truncate text-xs">
                          {currentUser.name} {currentUser.lastName}
                        </p>
                        <p className="text-[11px] text-[#22D3EE] truncate font-mono">
                          {currentUser.nickname ? `@${currentUser.nickname}` : currentUser.googleEmail}
                        </p>
                      </div>
                    </div>

                    {/* Balance / Recharge */}
                    {onOpenRecharge && (
                      <button
                        onClick={() => {
                          setShowMobileDropdown(false);
                          onOpenRecharge();
                        }}
                        className="w-full flex items-center justify-between rounded-xl bg-emerald-950/40 border border-emerald-500/40 p-2.5 text-emerald-300 font-bold hover:bg-emerald-900/50 mb-2 transition"
                      >
                        <div className="flex items-center gap-2">
                          <CreditCard className="h-4 w-4 text-emerald-400" />
                          <span>Saldo Disponível</span>
                        </div>
                        <span className="font-mono text-white">
                          R$ {(currentUser.balance ?? 0).toFixed(2).replace('.', ',')}
                        </span>
                      </button>
                    )}

                    {/* Status selection in vertical menu */}
                    <div className="mb-2.5 p-2 rounded-xl bg-[#1E293B]/40 border border-[#1E293B]">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                        Status Atual: <span className="text-white">{currentStatusObj.label}</span>
                      </p>
                      <div className="grid grid-cols-2 gap-1">
                        {statusOptions.map((st) => (
                          <button
                            key={st.id}
                            onClick={() => {
                              handleSelectStatus(st.id);
                              setShowMobileDropdown(false);
                            }}
                            className={`flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-[11px] transition ${
                              currentUser?.status === st.id
                                ? 'bg-[#22D3EE]/20 text-[#22D3EE] font-bold border border-[#22D3EE]/40'
                                : 'hover:bg-[#1E293B] text-slate-300'
                            }`}
                          >
                            <span>{st.icon}</span>
                            <span className="truncate">{st.label.split(' ')[0]}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-1 border-t border-[#1E293B] pt-2">
                      {currentView !== 'lobby' && onNavigateLobby && (
                        <button
                          onClick={() => {
                            setShowMobileDropdown(false);
                            onNavigateLobby();
                          }}
                          className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 hover:bg-[#1E293B] text-slate-200 transition"
                        >
                          <Home className="h-4 w-4 text-[#22D3EE]" />
                          <span>Ver Lobby de Salas</span>
                        </button>
                      )}

                      {onOpenCreateRoom && (
                        <button
                          onClick={() => {
                            setShowMobileDropdown(false);
                            onOpenCreateRoom();
                          }}
                          className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 hover:bg-[#1E293B] text-[#22D3EE] font-semibold transition"
                        >
                          <PlusCircle className="h-4 w-4 text-[#22D3EE]" />
                          <span>Criar Nova Sala</span>
                        </button>
                      )}

                      {onOpenLiveModal && (
                        <button
                          onClick={() => {
                            setShowMobileDropdown(false);
                            onOpenLiveModal();
                          }}
                          className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 hover:bg-[#1E293B] text-rose-300 font-semibold transition"
                        >
                          <Radio className="h-4 w-4 text-rose-400 animate-pulse" />
                          <span>Live Câmera ao Vivo</span>
                        </button>
                      )}

                      {onOpenNicknameModal && (
                        <button
                          onClick={() => {
                            setShowMobileDropdown(false);
                            onOpenNicknameModal();
                          }}
                          className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 hover:bg-[#1E293B] text-slate-200 transition"
                        >
                          <UserIcon className="h-4 w-4 text-[#22D3EE]" />
                          <span>Gerenciar Nickname no Chat</span>
                        </button>
                      )}

                      {onOpenFriendships && (
                        <button
                          onClick={() => {
                            setShowMobileDropdown(false);
                            onOpenFriendships();
                          }}
                          className="w-full flex items-center justify-between rounded-xl px-3 py-2 hover:bg-[#1E293B] text-slate-200 transition"
                        >
                          <div className="flex items-center gap-2.5">
                            <Users className="h-4 w-4 text-[#22D3EE]" />
                            <span>Amizades & Grupos</span>
                          </div>
                          {pendingRequestsCount > 0 && (
                            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-black text-white">
                              {pendingRequestsCount}
                            </span>
                          )}
                        </button>
                      )}

                      {onOpenMyCodes && (
                        <button
                          onClick={() => {
                            setShowMobileDropdown(false);
                            onOpenMyCodes();
                          }}
                          className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 hover:bg-[#1E293B] text-slate-200 transition"
                        >
                          <KeyRound className="h-4 w-4 text-[#22D3EE]" />
                          <span>Meus 11 Códigos Descartáveis 2FA</span>
                        </button>
                      )}

                      {onOpenSocialProfile && (
                        <button
                          onClick={() => {
                            setShowMobileDropdown(false);
                            onOpenSocialProfile();
                          }}
                          className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 hover:bg-[#1E293B] text-slate-200 transition"
                        >
                          <UserCheck className="h-4 w-4 text-[#22D3EE]" />
                          <span>Meu Perfil Social & Fotos</span>
                        </button>
                      )}
                    </div>
                  </>
                ) : (
                  <div className="space-y-2 p-1">
                    <p className="text-[11px] text-slate-400 mb-2">
                      Faça login com sua conta segura protegida por CPF e 2FA Google Authenticator.
                    </p>
                    <button
                      onClick={() => {
                        setShowMobileDropdown(false);
                        onOpenLogin();
                      }}
                      className="w-full rounded-xl border border-[#1E293B] bg-[#1E293B] px-4 py-2.5 text-xs font-semibold text-[#E2E8F0] hover:bg-[#334155] transition text-center"
                    >
                      Entrar com CPF & 2FA
                    </button>
                    <button
                      onClick={() => {
                        setShowMobileDropdown(false);
                        onOpenRegister();
                      }}
                      className="w-full rounded-xl bg-gradient-to-r from-[#22D3EE] to-[#F472B6] px-4 py-2.5 text-xs font-black text-black shadow-md text-center"
                    >
                      Cadastre-se Gratuitamente
                    </button>
                  </div>
                )}

                <div className="border-t border-[#1E293B] mt-2.5 pt-2 space-y-1">
                  {onOpenIntro && (
                    <button
                      onClick={() => {
                        setShowMobileDropdown(false);
                        onOpenIntro();
                      }}
                      className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 hover:bg-[#1E293B] text-slate-300 transition"
                    >
                      <Film className="h-4 w-4 text-[#22D3EE]" />
                      <span>Assistir Vinheta de Abertura</span>
                    </button>
                  )}

                  {currentUser && (
                    <button
                      onClick={() => {
                        setShowMobileDropdown(false);
                        onLogout();
                      }}
                      className="w-full flex items-center gap-2.5 rounded-xl px-3 py-2 hover:bg-rose-950/30 text-rose-400 font-semibold transition mt-1"
                    >
                      <LogOut className="h-4 w-4" />
                      <span>Sair da Conta</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Botão Especial da Área Restrita do Super Admin (Cadeado 5x5mm Azul Ciano) */}
          <div className="ml-1 pl-2 border-l border-[#1E293B]">
            <button
              id="btn-super-admin-cadeado"
              onClick={onOpenAdmin}
              aria-label="Área Restrita do Super Administrador (Cadeado 5x5mm Azul Ciano)"
              title="Área Restrita Super Admin (roger577@ukbelol.space)"
              className="group relative flex items-center justify-center rounded-xl border border-[#22D3EE]/40 bg-[#1E293B] p-2 shadow-md shadow-[#22D3EE]/20 hover:border-[#22D3EE] hover:bg-[#334155] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#22D3EE]/50 active:scale-90"
            >
              <Lock
                style={{ width: '5mm', height: '5mm' }}
                className="text-[#00f0ff] filter drop-shadow-[0_0_6px_rgba(0,240,255,0.7)] transition-transform duration-200 group-hover:scale-110"
              />
              <span className="sr-only">Área Restrita Super Admin</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
