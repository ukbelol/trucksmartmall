/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { RoomLobby } from './components/RoomLobby.tsx';
import { ConferenceRoom } from './components/ConferenceRoom.tsx';
import { RegisterModal } from './components/RegisterModal.tsx';
import { LoginModal } from './components/LoginModal.tsx';
import { DisposableCodesModal } from './components/DisposableCodesModal.tsx';
import { CreateRoomModal } from './components/CreateRoomModal.tsx';
import { AdminDashboard } from './components/AdminDashboard.tsx';
import { FriendshipModal } from './components/FriendshipModal.tsx';
import { IntroScreen } from './components/IntroScreen.tsx';
import { DevicePermissionsModal } from './components/DevicePermissionsModal.tsx';
import { NicknameModal } from './components/NicknameModal.tsx';
import { LiveTransmissionModal } from './components/LiveTransmissionModal.tsx';
import { TermsOfUseModal } from './components/TermsOfUseModal.tsx';
import { PrivacyPolicyModal } from './components/PrivacyPolicyModal.tsx';
import { RechargeModal } from './components/RechargeModal.tsx';
import { SocialProfileLandingPage } from './components/SocialProfileLandingPage.tsx';
import { Film, FileText, Shield, CreditCard } from 'lucide-react';
import type { User, Room, UserStatus } from './types.ts';

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => window.location.pathname);

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('chamasso_user');
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => {
    if (!currentUser) return;
    fetch('/api/auth/session', { credentials: 'same-origin' })
      .then((r) => r.json())
      .then((data) => {
        if (!data.authenticated || data.session?.sub !== currentUser.id) {
          localStorage.removeItem('chamasso_user');
          setCurrentUser(null);
        }
      })
      .catch(() => {});
  }, []);

  const [rooms, setRooms] = useState<Room[]>([]);
  const [activeRoom, setActiveRoom] = useState<Room | null>(null);

  // Modals visibility
  const [showRegister, setShowRegister] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showCreateRoom, setShowCreateRoom] = useState(false);
  const [showDisposableCodes, setShowDisposableCodes] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);
  const [showFriendshipModal, setShowFriendshipModal] = useState(false);
  const [showNicknameModal, setShowNicknameModal] = useState(false);
  const [showLiveModal, setShowLiveModal] = useState(false);
  const [initialLiveId, setInitialLiveId] = useState<string | undefined>(undefined);
  const [showTerms, setShowTerms] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showRecharge, setShowRecharge] = useState(false);
  const [viewSocialProfileUserId, setViewSocialProfileUserId] = useState<string | null>(null);

  // Pending Friend Requests Count
  const [pendingRequestsCount, setPendingRequestsCount] = useState(0);

  // Security notification banner (e.g. when disposable code is used or new friend request)
  const [securityNotice, setSecurityNotice] = useState<string | null>(null);

  // Load Rooms from Server
  const fetchRooms = async () => {
    try {
      const res = await fetch('/api/rooms');
      if (res.ok) {
        const data = await res.json();
        setRooms(data);
      }
    } catch (err) {
      console.error('Erro ao buscar salas:', err);
    }
  };

  // Fetch pending friend requests
  const fetchPendingFriendships = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/users/${currentUser.id}/friendship-requests`);
      if (res.ok) {
        const data = await res.json();
        const count = (data.incoming || []).filter((r: any) => r.status === 'pending').length;
        setPendingRequestsCount(count);
      }
    } catch (err) {
      console.error('Erro ao buscar solicitações de amizade:', err);
    }
  };

  useEffect(() => {
    fetchRooms();
    const interval = setInterval(fetchRooms, 6000);
    return () => clearInterval(interval);
  }, []);

  // Global WebSocket listener for friend requests & live status
  useEffect(() => {
    if (!currentUser) {
      setPendingRequestsCount(0);
      return;
    }
    fetchPendingFriendships();

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    let ws: WebSocket | null = null;

    try {
      ws = new WebSocket(wsUrl);
      ws.onopen = () => {
        ws?.send(
          JSON.stringify({
            type: 'join',
            roomId: 'global',
            userId: currentUser.id,
            userName: currentUser.name,
          })
        );
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'friendship_request' && msg.receiverId === currentUser.id) {
            setPendingRequestsCount((prev) => prev + 1);
            setSecurityNotice(`Nova solicitação de amizade recebida de ${msg.senderName}!`);
          }
          if (msg.type === 'friendship_response' && msg.senderId === currentUser.id) {
            if (msg.status === 'accepted') {
              setSecurityNotice(`${msg.receiverName} aceitou seu pedido de amizade!`);
            }
          }
          if (msg.type === 'status_update' && msg.userId === currentUser.id) {
            setCurrentUser((prev) => (prev ? { ...prev, status: msg.status } : null));
          }
        } catch (err) {
          console.error(err);
        }
      };
    } catch (err) {
      console.error('WS Error:', err);
    }

    const interval = setInterval(fetchPendingFriendships, 12000);

    return () => {
      clearInterval(interval);
      if (ws) ws.close();
    };
  }, [currentUser?.id]);

  // Save current user to local storage on change
  const handleSetUser = (user: User | null) => {
    setCurrentUser(user);
    if (user) {
      localStorage.setItem('chamasso_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('chamasso_user');
    }
  };

  // Handle Nickname Update or Removal
  const handleNicknameUpdated = (nickname?: string, nicknameType?: 'permanent' | 'temporary') => {
    if (currentUser) {
      const updated: User = {
        ...currentUser,
        nickname,
        nicknameType,
      };
      handleSetUser(updated);
    }
  };

  // Handle Login Success
  const handleLoginSuccess = (user: User, usedDisposable: boolean, matchedCode?: string) => {
    handleSetUser(user);
    if (usedDisposable) {
      setSecurityNotice(
        `Você entrou utilizando o código descartável ${matchedCode || ''}. Este código foi invalidado e um alerta de segurança foi despachado para ${user.googleEmail}.`
      );
    } else {
      setSecurityNotice(null);
    }
  };

  // Handle Join Room Click
  const handleJoinRoom = (room: Room) => {
    if (!currentUser) {
      setShowLogin(true);
      return;
    }
    setActiveRoom(room);
  };

  // Redirecionamento completo para a página de funcionalidades (Home / Lobby)
  const handleGoHome = () => {
    setActiveRoom(null);
    setViewSocialProfileUserId(null);
    setShowAdminDashboard(false);
    setShowFriendshipModal(false);
    setShowDisposableCodes(false);
    setShowCreateRoom(false);
    setShowLogin(false);
    setShowRegister(false);
    if (window.location.pathname !== '/app') {
      window.history.pushState({}, '', '/app');
      setCurrentPath('/app');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
    fetchRooms();
  };

  // Redirecionamento para a Vinheta de Abertura
  const handleOpenIntro = () => {
    setActiveRoom(null);
    setViewSocialProfileUserId(null);
    setShowAdminDashboard(false);
    setShowFriendshipModal(false);
    setShowDisposableCodes(false);
    setShowCreateRoom(false);
    setShowLogin(false);
    setShowRegister(false);
    window.history.pushState({}, '', '/intro');
    setCurrentPath('/intro');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      setCurrentPath(path);
      if (path.startsWith('/profile/')) {
        const uid = path.replace('/profile/', '');
        setViewSocialProfileUserId(uid);
      } else if (path === '/' || path === '/intro') {
        setActiveRoom(null);
        setViewSocialProfileUserId(null);
        setShowAdminDashboard(false);
        setShowFriendshipModal(false);
        setShowDisposableCodes(false);
        setShowCreateRoom(false);
        setShowLogin(false);
        setShowRegister(false);
      } else if (path === '/app' || path === '/lobby' || path === '/home') {
        setActiveRoom(null);
        setViewSocialProfileUserId(null);
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Handle Leave Room
  const handleLeaveRoom = () => {
    handleGoHome();
  };

  // Handle Room Created
  const handleRoomCreated = (newRoom: Room) => {
    setRooms((prev) => [newRoom, ...prev]);
    setActiveRoom(newRoom);
  };

  // Se a rota for '/' ou '/intro', exibe a vinheta de abertura com o letreiro neon
  const isIntroRoute = currentPath === '/' || currentPath === '/intro';

  if (isIntroRoute) {
    return (
      <IntroScreen
        targetRoute="/app"
        onEnterApp={() => {
          setCurrentPath('/app');
          window.scrollTo({ top: 0, behavior: 'smooth' });
          fetchRooms();
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0C10] text-[#E2E8F0] flex flex-col font-sans selection:bg-[#22D3EE] selection:text-black">
      {/* Top Navigation */}
      <Navbar
        currentUser={currentUser}
        onOpenLogin={() => setShowLogin(true)}
        onOpenRegister={() => setShowRegister(true)}
        onOpenAdmin={() => setShowAdminDashboard(true)}
        onOpenDisposableCodes={() => setShowDisposableCodes(true)}
        onOpenMyCodes={() => setShowDisposableCodes(true)}
        onOpenFriendships={() => setShowFriendshipModal(true)}
        pendingRequestsCount={pendingRequestsCount}
        onStatusChange={(newStatus) => {
          if (currentUser) {
            handleSetUser({ ...currentUser, status: newStatus });
          }
        }}
        onOpenCreateRoom={() => {
          if (!currentUser) {
            setShowLogin(true);
          } else {
            setShowCreateRoom(true);
          }
        }}
        currentView={activeRoom ? 'room' : 'lobby'}
        onNavigateLobby={handleGoHome}
        onOpenIntro={handleOpenIntro}
        onOpenNicknameModal={() => {
          if (!currentUser) setShowLogin(true);
          else setShowNicknameModal(true);
        }}
        onOpenLiveModal={() => {
          setInitialLiveId(undefined);
          setShowLiveModal(true);
        }}
        onOpenRecharge={() => {
          if (!currentUser) setShowLogin(true);
          else setShowRecharge(true);
        }}
        onOpenSocialProfile={() => {
          if (!currentUser) {
            setShowLogin(true);
          } else {
            setViewSocialProfileUserId(currentUser.id);
            window.history.pushState({}, '', `/profile/${currentUser.id}`);
          }
        }}
        onLogout={() => {
          fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
          setViewSocialProfileUserId(null);
          handleSetUser(null);
        }}
      />

      {/* Main View Area: Social Profile OR Conference Room OR Room Lobby */}
      <div className="flex-1 flex flex-col">
        {viewSocialProfileUserId ? (
          <SocialProfileLandingPage
            targetUserId={viewSocialProfileUserId}
            currentUser={currentUser}
            onBackToChat={() => {
              setViewSocialProfileUserId(null);
              window.history.pushState({}, '', '/app');
            }}
            onOpenLiveChatRoom={(roomId) => {
              setViewSocialProfileUserId(null);
              if (roomId) {
                const room = rooms.find((r) => r.id === roomId);
                if (room) setActiveRoom(room);
              }
            }}
            onOpenPasqcoinShop={() => setShowRecharge(true)}
          />
        ) : activeRoom && currentUser ? (
          <ConferenceRoom
            room={activeRoom}
            currentUser={currentUser}
            onLeaveRoom={handleLeaveRoom}
          />
        ) : (
          <RoomLobby
            rooms={rooms}
            currentUser={currentUser}
            onJoinRoom={handleJoinRoom}
            onNavigateHome={handleGoHome}
            onCreateRoom={() => {
              if (!currentUser) {
                setShowLogin(true);
              } else {
                setShowCreateRoom(true);
              }
            }}
            onOpenLogin={() => setShowLogin(true)}
            onOpenRegister={() => setShowRegister(true)}
            securityNotice={securityNotice}
            onOpenLiveModal={(liveId) => {
              setInitialLiveId(liveId);
              setShowLiveModal(true);
            }}
            onOpenNicknameModal={() => {
              if (!currentUser) setShowLogin(true);
              else setShowNicknameModal(true);
            }}
          />
        )}
      </div>

      {/* Footer com Links de Termos de Uso, Políticas de Privacidade e Tarifas */}
      <footer className="min-h-12 bg-[#0A0C10] border-t border-[#1E293B] px-4 sm:px-8 py-2.5 flex flex-col md:flex-row items-center justify-between gap-2.5 text-[11px] shrink-0">
        <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
          <div className="flex items-center gap-2">
            <a
              href="/app"
              onClick={(e) => {
                e.preventDefault();
                handleGoHome();
              }}
              title="Ir para a página de salas (Lobby)"
              className="cursor-pointer hover:opacity-80 transition-opacity"
            >
              <img
                src="/fenix_chamas.gif"
                alt="chamasso live chat"
                className="w-5 h-5 rounded-md object-cover border border-[#22D3EE]/40"
              />
            </a>
            <p className="uppercase tracking-widest text-slate-400 font-medium">
              © CHAMASSO LIVE CHAT — DEBIAN 12
            </p>
          </div>

          <div className="flex items-center gap-2.5 text-slate-400">
            <span className="text-slate-700 hidden sm:inline">•</span>
            <button
              onClick={() => setShowTerms(true)}
              className="hover:text-[#22D3EE] transition flex items-center gap-1 font-semibold cursor-pointer text-slate-300"
              title="Ler Termos de Uso do Chamasso Live Chat"
            >
              <FileText className="w-3.5 h-3.5 text-[#22D3EE]" />
              <span>Termos de Uso</span>
            </button>

            <span className="text-slate-700">•</span>
            <button
              onClick={() => setShowPrivacy(true)}
              className="hover:text-[#F472B6] transition flex items-center gap-1 font-semibold cursor-pointer text-slate-300"
              title="Ler Políticas de Privacidade e Proteção de Dados (LGPD)"
            >
              <Shield className="w-3.5 h-3.5 text-[#F472B6]" />
              <span>Políticas de Privacidade</span>
            </button>

            <span className="text-slate-700">•</span>
            <button
              onClick={() => {
                if (!currentUser) setShowLogin(true);
                else setShowRecharge(true);
              }}
              className="hover:text-emerald-300 transition flex items-center gap-1 font-semibold cursor-pointer text-emerald-400"
              title="Informações sobre Tarifas Chamasso e Recarga via Mercado Pago"
            >
              <CreditCard className="w-3.5 h-3.5 text-emerald-400" />
              <span>Tarifas & Recarga</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-3 uppercase tracking-widest text-[#22D3EE] font-mono font-medium text-[10px]">
          <button
            onClick={handleOpenIntro}
            className="hover:text-white transition flex items-center gap-1 cursor-pointer text-[#22D3EE]"
            title="Assistir à vinheta de abertura novamente"
          >
            <Film className="w-3 h-3" />
            <span className="hidden sm:inline">VER VINHETA DE ABERTURA</span>
            <span className="sm:hidden">VINHETA</span>
          </button>
          <span className="text-slate-600">|</span>
          <span className="hidden sm:inline">SSL: CHAMASSO.UKBELOL.SPACE</span>
          <span className="hidden sm:inline text-slate-600">|</span>
          <span className="hidden md:inline">PM2: ONLINE</span>
        </div>
      </footer>

      {/* Modals */}
      <TermsOfUseModal
        isOpen={showTerms}
        onClose={() => setShowTerms(false)}
      />

      <PrivacyPolicyModal
        isOpen={showPrivacy}
        onClose={() => setShowPrivacy(false)}
      />

      {currentUser && (
        <RechargeModal
          isOpen={showRecharge}
          onClose={() => setShowRecharge(false)}
          currentUser={currentUser}
          onRechargeSuccess={(newPasqcoins) => {
            handleSetUser({ ...currentUser, pasqcoins: newPasqcoins });
          }}
          onGoHome={() => {
            setShowRecharge(false);
            handleGoHome();
          }}
        />
      )}
      <RegisterModal
        isOpen={showRegister}
        onClose={() => setShowRegister(false)}
        onSuccess={(user) => {
          handleSetUser(user);
          setSecurityNotice(null);
        }}
        onSwitchToLogin={() => {
          setShowRegister(false);
          setShowLogin(true);
        }}
      />

      <LoginModal
        isOpen={showLogin}
        onClose={() => setShowLogin(false)}
        onSuccess={handleLoginSuccess}
        onSwitchToRegister={() => {
          setShowLogin(false);
          setShowRegister(true);
        }}
      />

      {currentUser && (
        <DisposableCodesModal
          isOpen={showDisposableCodes}
          onClose={() => setShowDisposableCodes(false)}
          user={currentUser}
        />
      )}

      {currentUser && (
        <CreateRoomModal
          isOpen={showCreateRoom}
          onClose={() => setShowCreateRoom(false)}
          currentUser={currentUser}
          onRoomCreated={handleRoomCreated}
        />
      )}

      {showAdminDashboard && (
        <AdminDashboard
          onClose={() => setShowAdminDashboard(false)}
          onRefreshData={fetchRooms}
        />
      )}

      {currentUser && (
        <FriendshipModal
          isOpen={showFriendshipModal}
          onClose={() => {
            setShowFriendshipModal(false);
            fetchPendingFriendships();
          }}
          currentUser={currentUser}
          onRequestsUpdated={fetchPendingFriendships}
        />
      )}

      {/* Detecção do Formato do Dispositivo e Solicitação de Permissões de Áudio/Vídeo */}
      <DevicePermissionsModal />

      {/* Modal de Criação e Gerenciamento de Nickname Permanente ou Temporário */}
      {currentUser && (
        <NicknameModal
          isOpen={showNicknameModal}
          onClose={() => setShowNicknameModal(false)}
          currentUser={currentUser}
          onNicknameUpdated={handleNicknameUpdated}
        />
      )}

      {/* Janela Pop-up de Transmissão de Câmera ao Vivo */}
      <LiveTransmissionModal
        isOpen={showLiveModal}
        onClose={() => {
          setShowLiveModal(false);
          setInitialLiveId(undefined);
        }}
        currentUser={currentUser}
        initialLiveId={initialLiveId}
      />
    </div>
  );
}

