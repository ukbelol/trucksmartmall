-- Chamasso 2.0.5 - camada dedicada de recuperação do saldo PASQcoin
-- Execute uma vez no SQL Editor do projeto Supabase.

create table if not exists public.chamasso_pasqcoin_balances (
  user_id text primary key,
  pasqcoins numeric(20,6) not null default 0 check (pasqcoins >= 0),
  user_email text,
  user_name text,
  reason text,
  updated_at timestamptz not null default now()
);

create index if not exists idx_chamasso_pasqcoin_balances_updated_at
  on public.chamasso_pasqcoin_balances (updated_at desc);

alter table public.chamasso_pasqcoin_balances enable row level security;

-- O backend usa a Service Role Key, que ignora RLS.
-- Não criamos política pública para evitar que clientes alterem saldos diretamente.

comment on table public.chamasso_pasqcoin_balances is
  'Último saldo PASQcoin confirmado por usuário para disaster recovery do Chamasso.';
