# Chamasso 2.0.4 — Galeria Social

## Implementado
- Galeria de fotos e vídeos no perfil social de cada membro.
- Cota individual de 200 MB compartilhada entre fotos e vídeos.
- Upload binário (sem Base64), com formatos JPG, PNG, WEBP, GIF, MP4, WEBM e MOV.
- Barra de utilização de armazenamento e indicação de espaço consumido.
- Privacidade por mídia: `public` ou `contacts` (somente contatos/amigos confirmados).
- Entrega de mídia por endpoint protegido; arquivos restritos não ficam expostos por diretório estático.
- Fotos da galeria podem virar foto de perfil ou foto de capa.
- Alteração posterior da privacidade de cada item.
- Exclusão de mídia libera imediatamente a cota usada.
- Persistência dos metadados no cadastro do usuário e arquivos no diretório privado `data/gallery/<userId>`.
- Amizades aceitas agora são persistidas para que a autorização “somente contatos” sobreviva a reinícios.

## Segurança
- Upload exige a sessão do próprio usuário.
- Backend aplica a cota de 200 MB; não depende apenas da interface.
- Backend valida MIME permitido.
- Mídias de contatos exigem sessão autenticada e relacionamento confirmado.
- Respostas de mídia usam `Cache-Control: private, no-store` e `X-Content-Type-Options: nosniff` para que mudanças de privacidade tenham efeito imediato.

## Observação de escala
A cota é individual, mas o armazenamento atual é no disco do servidor. Para múltiplos nós de aplicação, migrar os binários para um storage compartilhado/S3 compatível e manter os mesmos endpoints de autorização.
