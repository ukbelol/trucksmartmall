# Chamasso Live Chat 2.0.5

## PASQcoin: sincronização imediata com Supabase
- Toda alteração de PASQcoin gerada por compra, consumo por tempo, bônus administrativo ou rotina legada dispara sincronização imediata.
- Saldo é gravado por UPSERT em `chamasso_pasqcoin_balances`.
- O envio é serializado por usuário para impedir que respostas antigas sobrescrevam saldos novos.
- Se o Supabase estiver indisponível, o último saldo de cada usuário fica em `data/pasqcoin_cloud_pending.json`.
- O ciclo automático de 7 minutos tenta reenviar os saldos pendentes.
- A restauração completa do Supabase reaplica a camada dedicada de saldos após recuperar o snapshot.
- Na inicialização, `PASQCOIN_AUTO_RECOVER_ON_START=true` tenta recuperar os saldos da nuvem.
- Incluído `supabase_pasqcoin_balances.sql` para criação segura da tabela no Supabase.

## Navegação: Voltar para Home
- Compra PASQcoin: botão Voltar Home encerra a sessão da interface da compra e retorna ao Home.
- PIX já emitido não é cancelado automaticamente; se for pago, o webhook ainda pode confirmar e creditar o saldo.
- Sala: botão Voltar Home sai da sala e encerra a conexão corrente.
- Chat/mensagem privada e fluxo 1x1: Voltar Home fecha o contexto privado, encerra mídia local e sai para Home.

## Segurança
- A tabela de saldo é protegida por RLS e não possui política pública de escrita.
- O backend deve usar `SUPABASE_SERVICE_ROLE_KEY` no servidor.
